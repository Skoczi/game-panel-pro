<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';

use Flute\Modules\MixQueue2\Domain\{Engine, MatchRules, ServerTests, TestMatches};
use Flute\Modules\MixQueue2\Http\Application;
use Flute\Modules\MixQueue2\Infrastructure\Catalog;

function rulesFixture(string $version = '0.6.4', string $mode = '5v5'): Engine
{
    $e = fixture();
    $maps = $e->ladder('cs16-' . $mode)['maps'];
    $e->db->run('UPDATE mq2_servers SET game=?,adapter=?,capabilities=? WHERE id=?', [
        'cs16', 'amxx', Engine::json(['maps' => $maps, 'modes' => [$mode]]), 's1'
    ]);
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
        's1', Engine::json([
            ...cs16Status(), 'controller_version' => $version, 'agent_version' => '0.6.1',
            'solo_test' => true, 'full_test' => true,
            'map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $maps]
        ]), $e->now()
    ]);
    return $e;
}

function rulesVersion(Engine $e, string $version): void
{
    $status = json_decode($e->db->one('SELECT payload FROM mq2_observations WHERE server_id=?', ['s1'])['payload'], true);
    $status['controller_version'] = $version;
    $e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?', [Engine::json($status), 's1']);
}

// Scope and defaults: the existing queues and ELO identity are preserved.
$e = rulesFixture();
check($e->ladder('cs16-5v5')['rules']['mr'] === 15, 'Default MR15 changed');
check($e->ladder('cs16-2v2')['rules']['mr'] === 8, 'Wingman default changed');
foreach ([8, 10, 16, -1] as $bad)
    rejects(fn() => $e->setLadderRules('cs16-5v5', $bad, '1'), 'match_rules');
foreach ([12, 15] as $bad)
    rejects(fn() => $e->setLadderRules('cs16-2v2', $bad, '1'), 'match_rules');
rejects(fn() => $e->setLadderRules('csco-5v5', 12, '1'), 'match_rules');
$e->setLadderEnabled('cs16-5v5', false, '1');
$e->setLadderRules('cs16-5v5', 12, '1');
$e->setLadderRules('cs16-5v5', 12, '1');
check(!(int) $e->ladder('cs16-5v5')['enabled'], 'Setting format enabled public queue');
check(count($e->db->all('SELECT * FROM mq2_audit WHERE action=?', ['ladder.rules'])) === 1, 'Retry duplicated rules audit');
Catalog::install($e->db);
check($e->ladder('cs16-5v5')['rules']['mr'] === 12, 'Installation reset administrator format');
check(count($e->db->all('SELECT * FROM mq2_ladders')) === 6, 'Format created separate queue/ranking');
foreach (['12', 12.0, null, true] as $bad)
    rejects(fn() => MatchRules::cs16(5, ['mr' => $bad, 'ot_mr' => 3]), 'match_rules');
rejects(fn() => MatchRules::cs16(5, ['mr' => 12, 'ot_mr' => 1]), 'match_rules');
echo "PASS scoped rules, default MR15/MR8, MR3 only, idempotence, install retention, queue remains disabled\n";

// Gate the reservation before any generation, ticket or lease changes.
$e = rulesFixture('0.6.3');
$e->setLadderRules('cs16-5v5', 12, '1');
for ($i = 1; $i <= 10; ++$i) $e->join((string) $i, 'cs16-5v5');
check($e->tick() === 0 && !$e->db->all('SELECT * FROM mq2_leases'), 'MR12 assigned to old controller');
check((int) $e->db->one('SELECT generation FROM mq2_servers')['generation'] === 0, 'Gate consumed generation');
rulesVersion($e, '0.6.4');
$e->db->run('UPDATE mq2_observations SET observed_at=?', [$e->now() - 31]);
check($e->tick() === 0, 'Stale version observation allowed MR12');
$e->db->run('UPDATE mq2_observations SET observed_at=?', [$e->now()]);
check($e->tick() === 1, 'MR12 unsupported on 0.6.4');
$m = $e->db->one('SELECT * FROM mq2_matches');
$firstConfig = $e->configuration($m['id']);
$e->setLadderRules('cs16-5v5', 15, '1');
check(json_decode($e->match($m['id'])['rules'], true)['mr'] === 12, 'Ladder edit rewrote reserved match');
check($e->configuration($m['id']) === $firstConfig, 'Ladder edit changed signed hash/roster/rules');
check((new Engine($e->db))->configuration($m['id']) === $firstConfig, 'Worker restart changed frozen rules');
echo "PASS MR12 fresh controller gate before reservation; frozen match and signed hash survive format switch/restart\n";

// Capability regression between reservation and load drains through normal cancellation.
$e = rulesFixture();
$e->setLadderRules('cs16-5v5', 12, '1');
for ($i = 1; $i <= 10; ++$i) $e->join((string) $i, 'cs16-5v5');
check($e->tick() === 1, 'No reserved match');
$m = $e->db->one('SELECT * FROM mq2_matches');
rulesVersion($e, '0.6.3');
for ($i = 1; $i <= 10; ++$i) $e->ready((string) $i, $m['id'], true);
while (($m = $e->match($m['id']))['state'] === 'veto') {
    $p = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1', [$m['id'], Engine::vetoTeam($m)]);
    $e->ban($p['user_id'], $m['id'], json_decode($m['maps'], true)[0], (int) $m['version']);
}
$r = json_decode($m['rules'], true);
$p = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1', [$m['id'], $r['side_chooser']]);
$e->chooseSide($p['user_id'], $m['id'], 'ct', (int) $m['version']);
check($e->match($m['id'])['state'] === 'cancelled' && $e->match($m['id'])['reason'] === 'load_rejected:unsupported_rules', 'Downgrade failed to cancel safely');
check(!$e->db->all('SELECT * FROM mq2_commands WHERE type=?', ['load']), 'Unsupported load enqueued');
check(!$e->db->all('SELECT * FROM mq2_penalties') && !$e->db->all('SELECT * FROM mq2_settlements'), 'Downgrade caused penalty or ELO');
check(count($e->db->all('SELECT * FROM mq2_matches')) === 1, 'Cancelled history deleted');
echo "PASS downgrade during veto aborts without load, ELO, penalties or history deletion\n";

foreach ([12 => [[13, 0], [13, 11], [16, 12], [16, 14], [19, 17]],
    15 => [[16, 0], [16, 14], [19, 15], [19, 17], [22, 20]],
    8 => [[9, 0], [9, 7], [12, 8], [12, 10], [15, 13]]] as $mr => $scores) {
    foreach ($scores as [$a, $b]) {
        $mode = $mr === 8 ? '2v2' : '5v5';
        $e = rulesFixture($mr === 12 ? '0.6.4' : '0.6.3', $mode);
        $e->setLadderRules('cs16-' . $mode, $mr, '1');
        $m = readyMatch($e, 'cs16-' . $mode, $mr === 8 ? 4 : 10);
        live($e, $m);
        if ($mr !== 8) $e->setLadderRules('cs16-' . $mode, $mr === 12 ? 15 : 12, '1');
        $config = $e->configuration($m['id']);
        check($config['rules']['mr'] === $mr, 'Live rules replaced by current queue rules');
        rejects(fn() => event($e, $m, 'finished', ['team1_score' => $mr, 'team2_score' => $mr]), 'final_score');
        rejects(fn() => event($e, $m, 'finished', ['team1_score' => $mr + 1, 'team2_score' => $mr]), 'final_score');
        event($e, $m, 'finished', ['team1_score' => $a, 'team2_score' => $b]);
        check($e->match($m['id'])['state'] === 'finished', 'Valid regulation/overtime result rejected');
        $cleanup = $e->db->one('SELECT available_at FROM mq2_commands WHERE match_id=? AND type=?', [$m['id'], 'cleanup']);
        check((int) $cleanup['available_at'] === $e->now() + 180, 'Format lost postmatch grace');
    }
}
echo "PASS MR12/MR15/MR8 regulation and repeated MR3 results, invalid ties rejected, frozen settlement and 180s grace\n";

// Full tests may override the queue format, but retries cannot silently change it.
$e = rulesFixture('0.6.3');
$tests = new TestMatches($e);
rejects(fn() => $tests->create('1', 's1', 12), 'rules_version');
check(!$e->db->all('SELECT * FROM mq2_leases'), 'Rejected test consumed lease');
rulesVersion($e, '0.6.4');
$id = $tests->create('1', 's1', 12);
check($tests->create('1', 's1', 12) === $id, 'MR12 test retry duplicated');
rejects(fn() => $tests->create('1', 's1', 15), 'test_busy');
check($e->ladder('cs16-5v5')['rules']['mr'] === 15, 'Test override modified public format');
check($e->configuration($id)['rules']['mr'] === 12, 'Test assignment lost MR12');
$tests->fill($id, '1');
rulesVersion($e, '0.6.3');
rejects(fn() => $tests->start($id, '1'), 'rules_version');
check($e->match($id)['state'] === 'lobby', 'Downgrade mutated test state');
echo "PASS full test MR override, capability gate, retry immutability and start recheck\n";

foreach ([['5v5', 12], ['5v5', 15], ['2v2', 8]] as [$mode, $mr]) {
    $e = rulesFixture('0.6.4', $mode);
    $test = (new ServerTests($e))->start('s1', '1', 'de_nuke', $mr);
    $cmd = $e->commands('s1')[0]['payload'];
    check($cmd['rules']['mr'] === $mr && $cmd['rules']['test'] === true, 'Solo test format lost');
    check(json_decode($test['details'], true)['rules']['mr'] === $mr, 'Solo frozen format not retained');
}
$e = rulesFixture('0.6.3');
rejects(fn() => (new ServerTests($e))->start('s1', '1', 'de_nuke', 12), 'rules_version');
$e = rulesFixture('0.6.4', '2v2');
rejects(fn() => (new ServerTests($e))->start('s1', '1', 'de_nuke', 12), 'match_rules');
$e = rulesFixture();
$e->setLadderRules('cs16-5v5', 12, '1');
$t = (new ServerTests($e))->start('s1', '1', 'de_nuke');
check($e->commands('s1')[0]['payload']['rules']['mr'] === 12, 'Default solo ignored current format');
echo "PASS solo test MR12/MR15 and fixed MR8, retained signed format, default queue format, old controller rejection\n";

// Public HTTP policy is separate from trusted domain methods.
$e = rulesFixture();
$app = new Application($e);
rejects(fn() => $app->act('1', ['action' => 'ladder_rules', 'ladder' => 'cs16-5v5', 'mr' => 12]), 'forbidden');
foreach (['12', 12.9, true, null] as $bad)
    rejects(fn() => $app->act('1', ['action' => 'ladder_rules', 'ladder' => 'cs16-5v5', 'mr' => $bad], true), 'match_rules');
$app->act('1', ['action' => 'ladder_rules', 'ladder' => 'cs16-5v5', 'mr' => 12], true);
check($app->state('1', 'cs16-5v5', null, true)['ladder']['rules']['mr'] === 12, 'API omitted saved rules');
echo "PASS admin authorization, strict MR input and state contract\n";
