#pragma once

// One version for Metamod and the CSCO status/heartbeat contract.
// Bump before the next release; never rebuild and replace an existing package.
#define CSCO_CONTROLLER_VERSION "0.6.5"
