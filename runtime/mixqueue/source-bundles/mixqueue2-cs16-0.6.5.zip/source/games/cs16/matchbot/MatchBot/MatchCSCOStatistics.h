// CSCO, GPL-3.0. Completed-round telemetry keyed by signed roster index, never engine slot.
#pragma once
#include <array>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
namespace mq2 {
enum Stat { KILLS, DEATHS, ASSISTS, DAMAGE, ROUNDS, HEADSHOTS, KAST, FIRST_KILLS, FIRST_DEATHS,
    TRADE_KILLS, TRADED_DEATHS, TWO_K, THREE_K, FOUR_K, FIVE_K, CLUTCH_ATTEMPTS, CLUTCH_WINS,
    CLUTCH_1, CLUTCH_2, CLUTCH_3, CLUTCH_4, CLUTCH_5, PLANTS, DEFUSES, UTILITY_DAMAGE, STAT_COUNT };
inline const char* stat_name(int i) {
    static const char* names[]={"kills","deaths","assists","damage","rounds","headshots","kast_rounds",
        "opening_kills","opening_deaths","trade_kills","traded_deaths","multi2","multi3","multi4","multi5",
        "clutch_attempts","clutch_wins","clutch1","clutch2","clutch3","clutch4","clutch5","plants","defuses","utility_damage"};
    return names[i];
}
class RoundStatistics {
    struct Row { int team=0; bool present=false,alive=false,left=false,traded=false; double damage=0,utility=0;
        std::array<int,STAT_COUNT> values{}; };
    struct Kill { int killer,victim; double at; bool traded; };
    std::array<Row,10> round{};
    std::array<std::array<int,STAT_COUNT>,10> totals{};
    std::vector<Kill> kills;
    int count=0,winner=0,clutcher[3]={-1,-1,-1},against[3]={0,0,0};
    bool open=false,ending=false,opening=false,planted=false,defused=false;
    bool valid(int i) const { return i>=0 && i<count && round[i].present; }
    bool enemy(int a,int b) const { return valid(a)&&valid(b)&&round[a].team!=round[b].team; }
    void clutches() {
        for(int team=1;team<=2;++team) {
            int own=0,other=0,candidate=-1;
            for(int i=0;i<count;++i) if(round[i].alive) {if(round[i].team==team){++own;candidate=i;}else ++other;}
            if(own==1 && other>0 && clutcher[team]<0) {clutcher[team]=candidate;against[team]=std::min(other,5);}
        }
    }
public:
    void reset() { *this=RoundStatistics(); }
    void begin(const std::vector<int>& teams,const std::vector<bool>& present) {
        if(open || teams.size()>10 || present.size()!=teams.size()) return;
        count=int(teams.size()); round={}; kills.clear(); winner=0;
        clutcher[1]=clutcher[2]=-1;against[1]=against[2]=0;
        opening=planted=defused=ending=false;open=true;
        for(int i=0;i<count;++i){round[i].team=teams[i];round[i].present=round[i].alive=present[i];}
        clutches();
    }
    void disconnect(int i) { if(open&&!ending&&valid(i)) {round[i].left=true;round[i].alive=false;} }
    void damage(int a,int v,double hp,bool utility) {
        // Kept open through nested RoundEnd; seal only after TakeDamage unwinds.
        if(!open || !enemy(a,v) || !std::isfinite(hp) || hp<=0) return;
        round[a].damage+=hp; if(utility) round[a].utility+=hp;
    }
    void death(int k,int v,int assistant,bool hs,double time) {
        if(!open || ending || !valid(v) || !round[v].alive) return;
        round[v].alive=false; ++round[v].values[DEATHS];
        if(enemy(k,v)) {
            ++round[k].values[KILLS];if(hs)++round[k].values[HEADSHOTS];
            if(enemy(assistant,v)&&assistant!=k)++round[assistant].values[ASSISTS];
            if(!opening) {opening=true;++round[k].values[FIRST_KILLS];++round[v].values[FIRST_DEATHS];}
            bool trade=false;
            for(auto& old:kills) if(!old.traded && old.killer==v && round[old.victim].team==round[k].team && time>=old.at && time-old.at<=5.0) {
                old.traded=true;round[old.victim].traded=true;++round[old.victim].values[TRADED_DEATHS];trade=true;
            }
            if(trade)++round[k].values[TRADE_KILLS];
            kills.push_back({k,v,time,false});
        }
        clutches();
    }
    void objective(int player,bool plant) {
        if(!open||!valid(player))return;
        bool& recorded=plant?planted:defused;
        if(!recorded) {recorded=true;++round[player].values[plant?PLANTS:DEFUSES];}
    }
    void end(int winningTeam) { if(open&&!ending) {winner=winningTeam;ending=true;} }
    bool seal() {
        if(!open||!ending)return false;
        for(int t=1;t<=2;++t) if(clutcher[t]>=0) {
            auto& p=round[clutcher[t]];++p.values[CLUTCH_ATTEMPTS];
            if(winner==t&&!p.left&&p.alive) {++p.values[CLUTCH_WINS];++p.values[CLUTCH_1+against[t]-1];}
        }
        for(int i=0;i<count;++i) if(round[i].present) {
            auto& p=round[i];++p.values[ROUNDS];
            if(p.values[KILLS]||p.values[ASSISTS]||(p.alive&&!p.left)||p.traded)++p.values[KAST];
            int k=p.values[KILLS];if(k>=2)++p.values[TWO_K+std::min(k,5)-2];
            p.values[DAMAGE]=int(std::ceil(p.damage));p.values[UTILITY_DAMAGE]=int(std::ceil(p.utility));
            for(int n=0;n<STAT_COUNT;++n) totals[i][n]+=p.values[n];
        }
        open=ending=false;return true;
    }
    const std::array<int,STAT_COUNT>& get(int i) const {return totals.at(i);}
};
}
