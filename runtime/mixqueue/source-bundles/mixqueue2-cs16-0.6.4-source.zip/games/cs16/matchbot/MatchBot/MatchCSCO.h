// CSCO integration for MatchBot. GPL-3.0; upstream attribution in ../LICENSE.
#pragma once
#include "MatchCSCOFeedback.h"
#include "MatchCSCOBreak.h"
#include "MatchCSCOEnd.h"
#include "MatchCSCOSafety.h"
#include "MatchCSCOStatistics.h"

class CMatchCSCO {
public:
    void Activate();
    void Deactivate();
    void Frame();
    bool AllowState(int state);
    void StateChanged(int state);
    bool CanStart();
    bool Connect(edict_t* entity, char* reject);
    void Disconnect(edict_t* entity);
    int TeamSlot(CBasePlayer* player);
    bool ClientCommand(CBasePlayer* player,const char* command,const char* argument);
    void Joined(CBasePlayer* player);
    void Spawned(CBasePlayer* player);
    void Swapped();
    void FreezeEnd();
    void BeginLiveFreeze();
    bool ReadyAllowed() const;
    bool ReadyCountdownActive() const { return Active() && !live && phase=="warmup" && (!config.test || config.fullTest); }
    bool AllowRoundEnd();
    bool AllowEngineReset(ScenarioEventEndRound event);
    void ObserveTeams();
    bool StartDisconnectPause();
    void DisconnectPauseEnded();
    bool BeforeRoundRestart();
    bool SuppressTeamMenu(CBasePlayer* player, int menu, const char* text);
    void RoundEnded(ScenarioEventEndRound event);
    void Damage(CBasePlayer* victim,entvars_t* attacker,float actual,bool utility=false);
    void Objective(GameEventType event,CBaseEntity* player);
    bool Managed() const { return !config.id.empty() || quarantine || loading; }
    std::string Scope() const { return config.id+":"+std::to_string(config.generation); }
    int RosterIndex(CBasePlayer* player) const;
    const mq2::Player* RosterPlayer(int index) const;
    void DamageRoster(mq2::DamageSnapshot& snapshot) const;
    bool RequestTimeout(CBasePlayer* player);
    void RequestUnpause(CBasePlayer* player);
    bool CanResumePause(bool early) const;
    bool BetweenHalves() const;
    void PauseStarted();
    void PauseResumed();
    void PauseHud(int seconds);
    void SyncPause();
    void Feedback(int index,const std::string& message);
    bool Tactical() const { return tactical.running; }
    void Death(CBaseEntity* killer,CBasePlayer* victim,CBasePlayer* assister,int rarity);
    bool Active() const { return !config.id.empty() && !quarantine && !loading; }
    bool Scoring() const { return Active() && roundOpen; }
    bool ReadyForLive() const;
    bool AutoReady(CBasePlayer* player) const;
    void Profile(int state);
    static void StatusCommand();
    static void LoadCommand();
    static void ClearCommand();
    static void EndTestCommand();
    static bool ScoreInfo(int destination,int type,const float* origin,edict_t* entity);
    static bool ServerName(int destination,int type,const float* origin,edict_t* entity);
#ifdef MQ2_QA
    static void QACommand();
#endif
private:
    mq2::Config config;
    mq2::RoundStatistics statistics;
    bool quarantine=false, loading=false, live=false, roundOpen=false, teamOneCT=true;
    bool emptySideObserved=false;
    int reconnectResumes=0;
    bool disconnectPause=false;
    mq2::HalfBreak halfBreak;
    bool breakAdvancing=false,halfTransitionPending=false;
    void StartHalfBreak();
    void BreakFrame();
    void HoldBreakFreeze();
    mq2::PostMatchClock postMatch;
    void StartPostMatch();
    void PostMatchFrame();
    std::string roundReason="other";
    mq2::PauseConsent tactical;
    int voteTeam=0;
    float voteDeadline=0, voteCooldown[2]={0,0};
    std::vector<int> voteEligible, voteYes;
    bool voteMenu[33]={};
    bool creatingBot=false, clearing=false, paused=false, pendingRound=false;
    int timeouts[2]={0,0};
    int bot=0, sequence=0, highWater=0, score[2]={0,0};
    float nextFrame=0;
    float authDeadline[33]={};
    int botSlots[33]={};
    int botUserIds[33]={}; // Engine-issued connection identity; a reused slot cannot inherit a bot.
    int creatingBotSlot=-1, creatingBotClient=0;
    bool botSettingsActive=false;
    bool bootstrappingBots=false;
    std::string boot, root, marker, journal, highPath, phase="idle";
#ifdef MQ2_QA
    int qaSlots[33]={};
    std::array<std::vector<std::string>,33> qaFeedback;
#endif
    int Slot(edict_t* entity) const;
    TeamName Side(int logicalTeam) const;
    void Kick(edict_t* entity,const std::string& reason="server_error");
    const char* Reason(const std::string& reason,const std::string& locale) const;
    static bool ValidReason(const std::string& reason);
    void EndTest(const std::string& reason);
    void SaveHostname();
    void RestoreHostname(bool remove=false);
    void UpdateHostname();
    std::string Header() const;
    void SendHeader(edict_t* client=nullptr);
    std::string lastHostname;
    bool hostnameRestored=true;
    void SetPhase(const std::string& value);
    void Persist(const std::string& value);
    void Emit(const std::string& type,const std::string& data,const std::string& stable="");
    void Fail(const char* code);
    void Load(const std::string& id,int generation);
    void Clear(const std::string& reason="server_error");
    void Ready();
    void EnsureBot();
    bool NeedsBots(const mq2::Config& assignment) const;
    std::string BotIssue(const mq2::Config& assignment) const;
    void ConfigureBots();
    void RestoreBots(bool remove=false);
    void BotQuota();
    int BotCount() const;
    bool CreateBot(int slot);
    bool TestOpponent(CBasePlayer* player) const;
    void ReportScore(bool finished);
    std::string PlayerStats() const;
    void DisconnectFrame();
    void ReconnectWindow(mq2::Player& player,const char* stage,int seconds);
    void StartSurrender(CBasePlayer* player);
    void SurrenderVote(CBasePlayer* player,bool yes);
    void EndSurrender(bool passed);
    bool RulesReady() const;
    std::string FormatIssue() const;
    std::string RulesIssue() const;
    void SafetyFrame();
    void ActivityBegin();
    void ActivityFrame();
    void ActivityEnd();
    void ActivityAlert(int index,const char* code,int count,unsigned bit);
    std::array<Vector,32> activityOrigin,activityAngles;
    std::array<bool,32> activitySeen{},activityTrack{};
    std::array<int,32> idleRounds{},teamDamage{},teamKills{};
    std::array<unsigned,32> activityAlerts{};
    float roundSince=0,activityCheck=0;
    std::string PauseData() const;
    unsigned pauseSerial=0;
    long pauseDeadline=0, readyUntil=0;
    mq2::ReconnectBudget reconnectBudget;
    std::array<int,32> reportedReady{};
    float readyDeadline=0, nextRulesCheck=0, rulesMismatchSince=0;
    int readyWarning=0;
    bool readyExpired=false;
    std::string rulesFault;
    bool AllPresent() const;
    bool BothSidesPresent() const;
    void Announce(const std::string& pl,const std::string& en);
    void CloseTeamMenu(CBasePlayer* player);
    static void Print(const std::string& value);
};
extern CMatchCSCO gMatchCSCO;
