MixQueue2 / CS:GO and Classic Offensive

EN: Install SourceMod and Get5 separately. This package contains the MQ2 bridge, not Get5 itself.
Copy addons/ into the game's csgo directory. Reload on an idle server and check sm plugins list.
Install the separate Python agent. sm-json headers are build dependencies, not a separate runtime plugin.
Get5: https://github.com/splewis/get5 ; API revision d937484beb1ddb8870126e6127d92c8df7845956.
Build: SourceMod compiler 1.11.0.6970; spcomp mq2_bridge.sp -iinclude -omq2_bridge.smx
PL: Zainstaluj SourceMod i Get5, wgraj addons/ do katalogu csgo. Sprawdz sm plugins list.
Paczka zawiera most MQ2. Get5 instalujesz osobno. CSCO wymaga odbioru konkretnego buildu.

No credentials are included. Download your PRIVATE configuration separately from the server's Setup dialog.
Compilation is verified; test a full match on your specific game build before enabling public queues.
Game plugin source is included. Third-party notices and licenses are preserved in licenses/ and include headers.
The package version is 0.2.3; unchanged game controller code reports its own version 0.2.0.

PL: Paczka nie zawiera sekretow. Prywatna konfiguracje pobierz osobno z okna Instalacja.
Kompilacja jest sprawdzona; odbior rzeczywistego meczu na konkretnym buildzie gry nadal jest wymagany.
