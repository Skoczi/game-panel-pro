# Odbiór 0.6.0 / WWW 0.7.0 — 29.09.2026

## Wykonane

- 14 zestawów PHP na SQLite i MariaDB: cykl meczu, konflikty, reconnect,
  moderacja/pauzy, inventory, testy, statystyki i nowy draft.
- Draft: 24 kombinacje 3/4/7/8/11/12 map, obie pierwsze drużyny, wybór CT/T,
  autoryzacja kapitana, stale version, jeden load, stabilny hash, fallback i cancel.
- Walidator stats v2: pełne pola/skład, typy, bounds, monotoniczność, niezmienny
  terminalny snapshot, brak downgrade, historyczne unknown zamiast zera.
- 33 testy Python agenta, V1/V2/V3, side hash/odrzucenie starego kontrolera,
  spool/idempotencja oraz wcześniejsze testy adaptera.
- Cztery zestawy C++ z ASan/UBSan: contract, feedback, safety, statistics.
- npm locales/check; lint PHP: zero błędów, istniejące uwagi stylistyczne pozostają.
- Screenshoty PL/EN, desktop/mobile: wynik i szczegóły, profil, pick i CT/T.

Izolowany GameDLL, Docker network=none, osobna kopia labu na WAW1:

1. `7e57000018d9d12b1b775597`, gen. 69: podpisany start team1=T, trzy restarty,
   obrażenia/pancerz/HE/C4/świat/TK, prywatny druk i /dmg PL/EN, uprawnienia
   kapitanów, obie kolejności zgód, duplikaty/reconnect, timer/race, zachowanie
   wyniku/ekwipunku/pozycji, zmiana stron i wynik 16:1. Zakończenie i idle.
   Kapitan nieobecny przy jednym starcie ma 16 rund udziału, reszta 17 — celowo.
2. `0520000018d9d173b346fc0a`, gen. 70: faktyczny clutch 1v2, trade/KAST,
   capped 200 HP, HE po pancerzu, regulacja 8:8, OT 4:2, końcowe 12:10,
   22 zakończone rundy, zmiana stron w połowie i OT, cleanup/idle.
3. `0520000018d9d1f387052f5c`, gen. 71: rzeczywisty CC4::PrimaryAttack i
   grenade Use/Think wywołują plant/defuse, 0:1, bez wymyślonych fragów/obrażeń.
4. Binarka produkcyjna: brak mq2_qa, różne storage/config/map rejection,
   brak fałszywego loaded, inventory BSP, powtórny load, 9 botów w warmup,
   test_ended, cleanup, original hostname i stale generation. Rzeczywisty restart
   procesu w osobnym labie daje recovery; load nie omija kwarantanny, normalny
   cleanup zachowuje high-water generation i przywraca hostname.
5. Replay rzeczywistych journal do nowego WWW: full 52 zdarzenia i OT 36 zdarzeń.
   Identyfikatory fixture/map/hash/zegar przepięte; wartości gameplay zachowane.
   Każdy duplikat odrzucony, 25 liczników zachowane, KAST w overall zgodny,
   ELO dokładnie raz dla fixture ranked, zero ELO/kar/overall dla full_test.

Pliki feedback-060-*.json są dowodami z encji QA, NIE prawdziwych klientów Steam.
Produkcja 0.6.0 zbadana osobno. Lab zachowuje wcześniejsze journal/generacje;
SRV-107 nie był restartowany ani modyfikowany w ramach tych prób.

## Wymagany odbiór ESERV/Steam

Na pustym SRV-107 bez aktywnego lease, po backupie i instalacji 0.6.0:

1. Nowy full_test 2+8: obaj kapitanowie ludźmi; sprawdzić bany aż do dwóch map,
   pick, stronę przez przeciwnego kapitana, start CT i T, zmianę połowy i OT.
2. PL/EN, TAB WARMUP → LIVE → PAUSED → LIVE, trzy restarty, reconnect bez nowego
   load i utraty wyniku. /timeout odmawia zwykłemu graczowi; /unpause wymaga obu
   kapitanów, naturalny timer nadal działa. Pauza disconnect/recovery chroniona.
3. Po rundzie /dmg zgodny z automatycznym drukiem, także ostatni kill, granat,
   pancerz, plant/defuse, martwy gracz. Tabela WWW K/D/A/ADR/KAST/trade/clutch
   porównana z realnymi akcjami. End test zachowuje tylko ukończone rundy.
4. Cleanup potwierdzony idle, lease zwolniony, zero testowego ELO/kar. Brak
   slotów/botów po teście, kolejny mecz ma czyste statystyki i zgody.
5. Osobno prawdziwe 2v2 i 10 klientów oraz wszystkie dostępne BSP; inventory
   nie potwierdza poprawności mapy ani jej zasobów na klientach.

Bez tego nie deklarujemy odbioru Steam nowej wersji. Przyczyna dawnego crasha
pozostaje nieustalona. Publiczna pula nadal wyłączona.
