# Realizacja audytu CS 1.6

Rozpoczęto 29.09.2026. Źródło zakresu: AUDIT-CS16-2026-09-29.md.

Pierwsza fala: kontroler 0.5.3, agent 0.5.2, WWW 0.6.7. Kod/testy automatyczne nie oznaczają odbioru Steam ani zamknięcia całego audytu.

| ID | Stan |
|---|---|
| A01 | Incydenty, bezpieczne anulowanie, UI i quarantine do idle; testy domeny/UI |
| A02 | Dwie pauzy 90 s na logiczną drużynę; C++/GameDLL sprawdzone, Steam pozostaje |
| A03 | /ready 300 s + warunkowa kara 5 min; sygnały AFK/TD/TK i ręczna ocena. Pełny antygrief pozostaje |
| A04 | Nowy próg ranked i wersjonowane downloady |
| A05 | Wspólny profil v2, trwały dryf → recovery; sprawdzone na silniku |
| A06 | Rotacja kandydatów; test odtworzenia blokady i 230 ticketów |
| A07 | 0.6.0: multikill/opening/objective, KAST/trade/clutch/utility + profil i tabela WWW 0.7.0. Pozostają MVP/Rating, broń/celność/hitboxy i odbiór Steam |
| A08 | Pozostaje: autoryzowane HLTV, nagrania, dostęp/retencja; integracja ESERV |
| A09 | 0.6.0: bany do dwóch map, pick, strona przeciwnego kapitana, podpisany V3 i pełne parzyste pule. Knife nie jest częścią uzgodnionej polityki |
| A10 | Minimum ochrony A01; pełny checkpoint ekonomii/rundy pozostaje |
| A11 | Minimum: blokady kolejki/cofnięcie/audyt. Pozostają sprawy/odwołania i kompensacje ELO |
| A12 | Pauza/zgody WWW i główne komunikaty gry PL/EN; Steam pozostaje |
| A13 | Metryki spool. Pozostają bezpieczna rotacja, agregaty po pomiarach, benchmark 100/500 |
| A14 | Pozostaje realny odbiór 12 map i 2v2; inventory nie certyfikuje gameplay |
| A15 | Agent samodzielny zachowuje kontrolę/cleanup po błędzie flush, bez kasowania rekordu |

Druga fala: controller i agent 0.6.0, WWW 0.7.0. Pakiet zbiorczy zawiera pierwszą falę. Następny zakres: A08 z ESERV, pozostałe A07, checkpoint i retencja z osobnymi próbami awarii/idempotencji. Przed publicznym rankingiem obowiązuje odbiór Steam z MATCHBOT-060-ACCEPTANCE.md oraz osobna weryfikacja ochrony hosta/antycheata.

Binarki gry przekazujemy ESERV; nie podmieniamy ich na aktywnych serwerach.
Istniejące wydania, historie, klucze, generacje i trwałe dzienniki pozostają zachowane.
Publiczne kolejki pozostają wyłączone do odbioru.
