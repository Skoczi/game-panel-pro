# ESERV — zbiorcze wydanie CS 1.6 0.6.0

Zainstaluj controller MatchBot **0.6.0** i agent **0.6.0** z tej nowej paczki.
Wymagane WWW **>=0.7.0**. Zawiera także poprzednią falę 0.5.3/0.5.2; nie trzeba
jej wdrażać oddzielnie. Nie podmieniaj plików starych wydań.

Najpierw sprawdź manifest i SHA256SUMS wszystkich warstw ZIP. Binary/source hash
są w manifest.json, a hash zewnętrznego ZIP w sąsiednim .sha256. Źródła, testy,
dependencies.json i dowody z osobnego labu są dołączone. Brak mq2_qa w produkcji.

1. Sprawdź AGENTS.md, bieżącą wersję WWW, brak lease i graczy na SRV-107
   (waw1-cs-mm-1, 51.77.44.64:27015). Przy zajętym serwerze odłóż restart.
2. Wersjonowany instalator/runtime WAW1/WAW2: podmień kod agenta w obrazie
   i kontroler/language.txt ze sprawdzonej paczki. Zachowaj adapter amxx,
   transport protocol 2, broker isolation, ograniczoną listę RCON. Nie ma nowej
   dowolnej komendy. MQ2V3 ma starting_ct_team; eventy stats mają stats_version 2.
3. Backup, następnie kontrolowany restart wyłącznie pustego SRV-107. Nie zmieniaj
   serwerów z lease. Innych AMXX nie wyłączaj. Zachowaj wcześniej przejrzaną listę
   konfliktów: stary mq2_match.amxx i StatsX statsx.amxx, który przechwytuje komendy.
4. Zachowaj prywatny JSON, klucze, RCON, server_id, spool.sqlite/WAL, journal,
   config assignments, generację, active-matchbot, original-hostname i recovery.
   Nie kasuj ani nie zeruj stanu w celu przejścia testu. Nie przykrywaj konfiguracji
   hosta przykładem matchbot.cfg. Prefix domyślny [CSCO.GG].
5. Heartbeat: controller_version=0.6.0, agent_version=0.6.0, assignment_contract=3,
   stats_version=2, side_choice=1, ruleset=2, reconnect_budget=2, player_ready=true.
   Sprawdź rzeczywiste inventory BSP i zdrowe idle. Public pool nadal disabled.
6. Wykonaj odbiór Steam opisany w ACCEPTANCE.md; przekaż identyfikatory meczu,
   generacje, wyniki, wycinki eventów i screenshoty. Wyraźnie oddziel Steam od QA.

Veto: naprzemienne bany do dwóch map, następny kapitan robi pick, przeciwna
drużyna wybiera CT/T (30 s, fallback CT). Działa dla parzystej i nieparzystej puli.
Nowy full_test wybiera ten wariant dopiero po reklamowaniu V3 przez agenta/serwer.

Nie otwieraj publicznych kolejek. Nie zgłaszaj zaliczonego 2+8/10 klientów,
wszystkich map lub rozwiązania starego crasha bez wykonania odpowiednich prób.

Rollback: najpierw zatrzymaj nowe przydziały i zakończ przypisanie normalną ścieżką.
Zachowaj WWW >=0.7.0 do odebrania wszystkich eventów v2 ze spool. Nie przywracaj
starej bazy nad nowe zdarzenia. Starszy kontroler nie przyjmuje MQ2V3; nie wolno
przerabiać aktywnego przypisania na V2 ani omijać recovery.
