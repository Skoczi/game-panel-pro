# Instalacja CS 1.6 0.6.0

Wymagane WWW >=0.7.0, agent 0.6.0, ReHLDS >=3.14 i ReGameDLL >=5.27.
Zobacz dependencies.json. W ESERV proces i restart prowadzi istniejący installer;
pełna procedura w PROMPT-ESERV.md. Wyłącznie pusty serwer bez lease.

Plugin to Metamod Linux i386: addons/matchbot/dlls/matchbot_csco_mm.so oraz
addons/matchbot/language.txt. Zachowaj istniejący wpis Metamod. Nowa instalacja
wymaga wpisu linux addons/matchbot/dlls/matchbot_csco_mm.so. Przykład cfg nie
zastępuje server.cfg. Wyłącz tylko uzgodnione konflikty mq2_match.amxx/statsx.amxx;
pozostałe AMXX zostają. StatsX przechwytuje /stats i /score przed MatchBotem.

Prywatny JSON jest dla agenta Python, poza webroot. Nie jest konfiguracją AMXX.
Agent zapisuje assignment do addons/amxmodx/configs/mq2/<id>-<generation>.txt
i odczytuje addons/amxmodx/data/mq2/events.jsonl. Zachowaj spool, klucze, generację,
active-matchbot.txt i original-hostname.txt. Recovery wymaga normalnego abort/
cleanup; usunięcie markera nie jest naprawą. Score w TAB jest lokalizowany klientem;
K/D/A jest dostępne w /stats i /score. Prefix domyślnie [CSCO.GG].

Build ze źródeł na Linux/WSL z Docker:

```
docker build -t csco-matchbot-builder:bookworm -f games/cs16/matchbot/Dockerfile.build .
sh bin/build-matchbot.sh "$PWD" 0
```

Argument 1 buduje QA wyłącznie do izolowanego labu. Nigdy nie publikuj QA na
serwerze gry. Wydanie i testy tej paczki dotyczą Linux i386, nie Windows DLL.
