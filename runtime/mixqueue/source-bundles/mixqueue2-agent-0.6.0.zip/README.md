# Agent 0.6.0

Wymaga WWW >=0.7.0 dla nowych statystyk; kontroler 0.6.0 dla MQ2V3 i wyboru CT/T.
Transport protocol 2, adapter amxx. V1/V2 pozostają zgodne, V3 nigdy nie jest
po cichu redukowany do starego kontraktu. Hash źródła jest w manifest.json.

ESERV: zaktualizuj runtime/mixqueue/mq_agent.py i obraz istniejącego runnera.
Nie uruchamiaj drugiego agenta dla tego samego server_id/spool. Zachowaj prywatny
JSON, sekrety, RCON, ścieżki game_root/journal, spool SQLite/WAL i broker isolation.
Konfiguracja strukturalnie nie zmienia się; przykład jest tylko dla nowych hostów.

Samodzielnie: python3 mq_agent.py /etc/mq2/server.json. JSON poza webroot, jedna
baza spool na serwer. Usługa deploy/mq2-agent.service jest przykładem; w ESERV
użyj istniejącego zarządzania procesem. Testy: python3 -m unittest discover -s tests
-p 'test_agent*.py'. Nie kasuj zablokowanego eventu; wyjaśnij błąd walidatora.

Loaded journal pozostaje autorytetem przyjęcia przypisania. Odrzucone mq2_load
nie oznacza udanego przygotowania mimo poprawnego transportu RCON. Kolejność,
idempotencja, kontrola/cleanup po błędzie wysyłki i poprzednie metryki zachowane.
