# WWW 0.7.0

Potwierdzony host: WAW1 /var/www/csco.gg; worker /opt/csco-matchmaking/current.
Najpierw WWW, następnie kontroler i agent 0.6.0 przez ESERV.

Guard hashy względem lokalnego snapshotu 0.6.7; backup modułu, assetów, bazy i
symlinku. Nowy release 0.7.0, pliki tylko z kontrolowanej delty. Dane historii,
generacje, lease, flagi serwerów i kolejek porównane przed/po. Nie importujemy
demo fixtures do bazy produkcyjnej. Tryb podglądu pozostaje per konto.

Nie dochodzą tabele w tej fali. Stats JSON i rules przechowują wersjonowane dane.
Migrate jest idempotentny; publikacja assetów, cache/template clear, opcache oraz
restart wyłącznie workera. Downloady 0.6.0 przed publikacją aliasów UI.

Stare mecze i kontrakty kończą się dotychczasową ścieżką. Nowy ranked CS 1.6 wymaga
kontrolera/agenta 0.6.0 i odpowiednich capability. Starszy test nie zmienia zasad
veto w trakcie. Po aktualizacji twórz nowe lobby, żeby otrzymać V3.

Rollback plików tylko przed rozpoczęciem V3; po nowych przydziałach i eventach
utrzymaj kompatybilny walidator. Nigdy nie odtwarzaj starej bazy nad równoległą
historią ani nie usuwaj spool dla obejścia błędu.
