# CS 1.6 — controller 0.6.0, agent 0.6.0, WWW 0.7.0

Druga fala audytu: A07 (natywne statystyki) i A09 (veto oraz strona startowa).
Pakiet zbiorczy zawiera także zmiany kontrolera 0.5.3, agenta 0.5.2 i WWW 0.6.7.
Nie wymaga instalowania tych wersji pośrednich. Starsze wydania pozostają niezmienne.

## Veto BO1

Pierwsza drużyna jest losowana raz i zapisana. Kapitanowie banują naprzemiennie
do pozostania dwóch map. Następny kapitan wybiera mapę; przeciwny kapitan wybiera
dla swojej drużyny CT albo T. Przy siedmiu mapach: pięć banów, pick, wybór strony.
Przy dwunastu: dziesięć banów, pick, wybór strony. Parzystych pul nie skracamy.
Kandydaci nadal muszą być potwierdzonymi BSP na przypisanym serwerze; minimum trzy.

Wybór strony ma 30 s. Po przekroczeniu terminu drużyna wybierająca dostaje CT.
Nie ma knife round. Brak odpowiedzi podczas wcześniejszego veto zachowuje
dotychczasową obsługę timeout. W full_test bot-kapitan może automatycznie wykonać
veto i wybrać CT; nie daje to administratorowi uprawnień kapitana w ranked.

Przypisanie MQ2V3 / assignment_contract 3 zawiera starting_ct_team (1 lub 2),
objęte niezmiennym config_hash. Dotyczy logicznej drużyny, także po zmianie stron.
Load jest wysyłany dopiero po wyborze strony i ponownej kontroli inventory.
Nowy agent odrzuca V3 na starszym kontrolerze zamiast gubić wybór strony.

## Natywne statystyki

stats_version 2: komplet 25 liczników na każdego uczestnika podpisanego składu.
K/D/A, HS, rzeczywiste obrażenia, rozegrane rundy, KAST, opening kills/deaths,
trade kills/traded deaths, 2K–5K, clutch attempts/wins i 1v1–1v5, plants, defuses,
utility damage. Wyniki meczu i profil Flute pokazują nowe dane oraz ich pokrycie.
Szczegóły tabeli można rozwinąć. PL/EN i układ mobilny zachowane.

- Liczymy wyłącznie potwierdzone zakończone rundy live. Ostatni kill, także
  zagnieżdżony RoundEnd w TakeDamage, trafia do tej samej rundy. Częściowa runda
  przy ręcznym zakończeniu nie staje się rozegraną rundą.
- KAST: kill, assist, przeżycie albo wymieniona śmierć. Wyjście z gry nie daje
  przeżycia. Mianownik obejmuje rundy rozpoczęte żywym, obecnym graczem w składzie.
- Trade: zabicie przeciwnika do 5 s włącznie od zabicia przez niego kolegi.
  Jedno zabicie to jeden trade kill; kwalifikujące się śmierci są oznaczane raz.
- Multikill: dokładnie 2/3/4 lub co najmniej 5 zabójstw w rundzie.
- Clutch: pierwsza sytuacja 1vN danej drużyny w rundzie. Wygrana wymaga wygrania
  rundy i żywego, obecnego ostatniego gracza. Nie jest to model FACEIT Rating.
- Damage: rzeczywista utrata HP po pancerzu, ograniczona HP ofiary, suma
  zaokrąglana w górę raz na rundę. Utility obejmuje HE; C4/świat nie dostają
  przypadkowej tożsamości atakującego. Friendly fire nie podbija tych statystyk.
- Plant/defuse pochodzą z rzeczywistych zdarzeń GameDLL i są deduplikowane.
- Dane są powiązane z indeksem podpisanego uczestnika, nie slotem silnika.

WWW waliduje pełny skład, typy, granice i monotoniczność. Końcowy snapshot tej
samej zakończonej rundy nie może zmienić wyniku. Powtórzony journal nie nalicza
ELO drugi raz. Historyczne brakujące dane pozostają nieznane; nie dopisujemy zer.
Średnie profilowe korzystają z sum o zgodnym pokryciu, nie średniej z procentów.
Testy pozostają poza ELO, karami i overall rankingu.

## Zgodność i granice

Najpierw WWW >=0.7.0, następnie agent 0.6.0 i kontroler 0.6.0. Transport agenta
pozostaje protocol 2, adapter amxx, inventory 1. Nowe nazwy eventów nie dochodzą;
round/finished/test_ended/surrendered mają wersjonowane rozszerzenie players.
MQ2V1/V2 nadal są odczytywane. Starsze aktywne testy mogą się normalnie zakończyć;
nowy próg ranked wymaga V3, stats_version 2 i side_choice 1. Solo zachowuje v1.

Nie dostarczamy jeszcze MVP/Rating/Swing, broni, celności ani hitboxów. Oddzielnie
pozostają HLTV, pełny checkpoint rundy/ekonomii, kompensacje ELO, retencja i skala.
Odbiór Steam 2+8/10 klientów, wszystkie mapy i wcześniejszy crash nadal wymagają
odrębnych prób. Szczegóły dowodów: MATCHBOT-060-ACCEPTANCE.md.
