#include "../games/cs16/matchbot/MatchBot/MatchCSCOSafety.h"
#include <cassert>
#include <map>
#include <string>
#include <iostream>
int main() {
    mq2::ReconnectBudget budget;
    assert(!budget.available(0) && !budget.available(3));
    assert(budget.available(1) && budget.available(2));
    budget.consume({true,false});budget.consume({true,false});
    assert(!budget.available(1) && budget.available(2));
    budget.consume({true,true});
    assert(budget.used[0]==1 && budget.used[1]==1);
    // Reconnect and halftime do not call reset; only assignment lifecycle does.
    budget.consume({false,true}); assert(!budget.available(2));
    budget.reset();assert(budget.used[0]==0 && budget.available(2));
    for(bool warm:{false,true}) for(bool ot:{false,true}) for(bool pause:{false,true}) {
        std::map<std::string,float> rules;
        for(const auto& rule:mq2::tournament_rules(warm,ot,pause,90)) {
            assert(!rules.count(rule.name)); rules[rule.name]=rule.expected;
        }
        assert(rules["sv_gravity"]==800 && rules["mp_forcecamera"]==2);
        assert(rules["mp_infinite_ammo"]==0 && rules["mp_free_armor"]==0);
        assert(rules["mp_startmoney"]==(warm?16000:ot?10000:800));
        assert(rules["mp_buytime"]==(pause?1.5f:warm?1.75f:0.25f));
    }
    std::cout<<"PASS bounded logical-team reconnect budget and phase-specific shared tournament rules\n";
}
