MixQueue2 / CS 1.6

EN: Install AMX Mod X with the CStrike module. Copy addons/ into the cstrike game directory.
Append mq2_match.amxx to addons/amxmodx/configs/plugins.ini (do not overwrite that file).
Reload on an idle server and check amxx plugins. Install the Python agent from the separate package.
Build: AMX Mod X compiler 1.10.0.5486; run amxxpc mq2_match.sma from its scripting directory.
PL: Wgraj addons/ do cstrike, dopisz mq2_match.amxx do plugins.ini i sprawdz amxx plugins.
Wymagane AMX Mod X i CStrike. Zainstaluj rowniez osobno agenta Python.

No credentials are included. Download your PRIVATE configuration separately from the server's Setup dialog.
Compilation is verified; test a full match on your specific game build before enabling public queues.
Game plugin source is included. Third-party notices and licenses are preserved in licenses/ and include headers.
The package version is 0.2.3; unchanged game controller code reports its own version 0.2.0.

PL: Paczka nie zawiera sekretow. Prywatna konfiguracje pobierz osobno z okna Instalacja.
Kompilacja jest sprawdzona; odbior rzeczywistego meczu na konkretnym buildzie gry nadal jest wymagany.
