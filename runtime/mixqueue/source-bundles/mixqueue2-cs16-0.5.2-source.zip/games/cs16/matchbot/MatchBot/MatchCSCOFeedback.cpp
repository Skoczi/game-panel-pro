// CSCO roster-scoped feedback and tactical pauses. GPL-3.0.
#include "precompiled.h"

int CMatchCSCO::RosterIndex(CBasePlayer* player) const {
    if(!player || player->IsDormant()) return 0;
    const int slot=Slot(player->edict());
    if(slot<0) return config.test && !config.fullTest && player->entindex()==bot?11:0;
    const auto& row=config.players[slot];
    if(row.client!=player->entindex() || player->m_iTeam!=Side(row.team) || player->m_iJoiningState!=JOINED) return 0;
    return slot+1;
}
const mq2::Player* CMatchCSCO::RosterPlayer(int index) const {
    return index>0 && index<=int(config.players.size())?&config.players[index-1]:nullptr;
}
void CMatchCSCO::DamageRoster(mq2::DamageSnapshot& data) const {
    for(size_t i=0;i<config.players.size();++i) {
        const auto& p=config.players[i];const int index=int(i)+1;
        data.identity[index]=p.steam;data.name[index]=p.name;data.locale[index]=p.locale;data.team[index]=p.team;
    }
    if(config.test && !config.fullTest) {
        data.identity[11]=Scope()+":solo-bot";data.name[11]="Test opponent";data.team[11]=2;
    }
}
void CMatchCSCO::Feedback(int index,const std::string& text) {
    const auto row=RosterPlayer(index);
    if(!row || !row->client) return;
    auto player=UTIL_PlayerByIndexSafe(row->client);
    if(!player || RosterIndex(player)!=index) return;
    const auto message=mq2::wire_text(text);
#ifdef MQ2_QA
    auto& log=qaFeedback[index];
    if(log.size()>=100) log.erase(log.begin());
    log.push_back(message);
#endif
    gMatchUtil.SayText(player->edict(),PRINT_TEAM_DEFAULT,"%s",message.c_str());
}
void CMatchCSCO::Announce(const std::string& pl,const std::string& en) {
    for(size_t i=0;i<config.players.size();++i) Feedback(int(i)+1,config.players[i].locale=="pl"?pl:en);
}
bool CMatchCSCO::RequestTimeout(CBasePlayer* player) {
    const int index=RosterIndex(player);const auto row=RosterPlayer(index);
    if(!row) return false;
    const bool pl=row->locale=="pl";
    const auto name=mq2::wire_text(config.teams[row->team-1],40);
    if(!row->captain) {
        Feedback(index,pl?"Tylko kapitan "+name+" moze zarzadzac pauza.":"Only the captain of "+name+" can manage timeouts.");return false;
    }
    if(!Scoring() || !live || gMatchLO3.Running() || disconnectPause || gMatchPause.m_Pause || gMatchPause.m_Paused) {
        Feedback(index,pl?"Pauza taktyczna jest teraz niedostepna.":"A tactical timeout is not available now.");return false;
    }
    if(timeouts[row->team-1]>=2) {
        Feedback(index,pl?name+": limit pauz wykorzystany.":name+": no tactical timeouts left.");return false;
    }
    if(!gMatchPause.QueueTeam(name)) {
        Feedback(index,pl?"Poczekaj na koniec freeze time, aby zglosic pauze.":"Wait for freeze time to end before requesting a timeout.");return false;
    }
    // Queue acceptance is the quota boundary; rejected requests consume nothing.
    if(!tactical.request(Scope(),row->team)) {gMatchPause.m_Pause=false;return false;}
    ++timeouts[row->team-1];
    Announce(name+": pauza od nastepnej rundy.",name+": timeout at the start of the next round.");
    return true;
}
void CMatchCSCO::RequestUnpause(CBasePlayer* player) {
    const int index=RosterIndex(player);const auto row=RosterPlayer(index);
    if(!row) return;
    const bool pl=row->locale=="pl";
    const auto name=mq2::wire_text(config.teams[row->team-1],40);
    if(!row->captain) {
        Feedback(index,pl?"Tylko kapitan "+name+" moze zarzadzac pauza.":"Only the captain of "+name+" can manage timeouts.");return;
    }
    if(!Active() || disconnectPause || !gMatchPause.m_Paused || !tactical.running || tactical.scope!=Scope()) {
        Feedback(index,pl?"Brak aktywnej pauzy taktycznej. /unpause nie konczy pauzy reconnect ani recovery.":
            "No active tactical timeout. /unpause cannot end reconnect pauses or recovery.");return;
    }
    if(!CanResumePause(false) || !AllPresent()) {
        Feedback(index,pl?"Wczesniejsze wznowienie wymaga obecnosci obu pelnych druzyn.":"Early resume requires both complete teams to be present.");return;
    }
    const auto result=tactical.vote(Scope(),row->team,row->captain);
    if(result==mq2::Consent::duplicate) {
        Feedback(index,pl?name+": zgoda juz udzielona.":name+": consent already given.");return;
    }
    if(result==mq2::Consent::ready) {gMatchPause.Resume(true);return;}
    if(result==mq2::Consent::waiting) {
        Feedback(index,pl?name+": zgoda przyjeta.":name+": consent accepted.");
        const auto other=mq2::wire_text(config.teams[2-row->team],40);
        Announce("Czekamy na kapitana "+other+". Wpisz /unpause.","Waiting for the captain of "+other+". Type /unpause.");
    }
}
bool CMatchCSCO::CanResumePause(bool early) const {
    if(!Managed()) return true;
    if(!Active() || !live || phase=="finished" || phase=="halftime" || gMatchLO3.Running()) return false;
    return !early || (!disconnectPause && tactical.running && tactical.scope==Scope() &&
        tactical.votes==3 && AllPresent());
}
void CMatchCSCO::SyncPause() {
    if(Active() && live && phase!="finished" && paused!=gMatchPause.m_Paused) {
        paused=gMatchPause.m_Paused;UpdateHostname();Emit(paused?"pause":"resume","{}");
    }
}
void CMatchCSCO::PauseStarted() {
    if(tactical.pending && tactical.scope==Scope() && !disconnectPause) {
        tactical.start();
        const auto name=mq2::wire_text(config.teams[tactical.team-1],40);
        Announce("Pauza "+name+". Obaj kapitanowie: /unpause, aby wznowic wczesniej.",
            "Timeout: "+name+". Both captains: /unpause to resume early.");
    }
    SyncPause();
}
void CMatchCSCO::PauseResumed() {
    const bool wasTactical=tactical.running;
    tactical.reset();DisconnectPauseEnded();SyncPause();
    if(wasTactical) Announce("Pauza zakonczona. Gra zostaje wznowiona.","Timeout ended. Play resumes.");
}
void CMatchCSCO::PauseHud(int seconds) {
    const auto name=tactical.running?mq2::wire_text(config.teams[tactical.team-1],40):std::string();
    for(size_t i=0;i<config.players.size();++i) {
        const auto& row=config.players[i];auto player=UTIL_PlayerByIndexSafe(row.client);
        if(!player || RosterIndex(player)!=int(i)+1) continue;
        const bool pl=row.locale=="pl";
        std::string text=(pl?"PAUZA":"TIMEOUT")+std::string(disconnectPause?" / RECONNECT":name.empty()?"":" / "+name);
        text+="\n"+std::to_string(seconds)+(pl?" s do wznowienia":" s remaining");
        gMatchUtil.HudMessage(player->edict(),gMatchUtil.HudParam(0,255,0,-1.0,0.2,0,0.53,0.53,0,0,1),"%s",text.c_str());
    }
}
