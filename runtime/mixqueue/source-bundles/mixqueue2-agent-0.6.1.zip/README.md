# Agent 0.6.1

Wymagane WWW >=0.7.2 dla nowych bezpiecznych kodów odrzucenia testu AI.
Kontroler w tym wydaniu: MatchBot 0.6.2. Agent zachowuje adapter amxx,
protocol 2, assignment_contract 3, journal oraz dotychczasowy spool.

Zmiana względem 0.6.0: rozpoznawanie test_ai_disabled,
test_bot_profiles_missing, test_bot_nav_missing, test_bot_nav_invalid.
Agent wysyła istniejące load_rejected zamiast traktować odmowę jak
niedookreślony wynik transportu. Zdarzenie loaded z journal pozostaje
autorytetem potwierdzenia uruchomienia przydziału.

Zaktualizuj kod przez istniejący uniwersalny instalator ESERV. Zachowaj
konfigurację, klucze, server_id, broker isolation, RCON, spool.sqlite/WAL,
journal, generacje oraz historię. Pliki config.example.json są przykładami.
Nie zakładaj nowej usługi dla każdego serwera, jeśli host używa już
uniwersalnego procesu obsługującego wiele serwerów.
