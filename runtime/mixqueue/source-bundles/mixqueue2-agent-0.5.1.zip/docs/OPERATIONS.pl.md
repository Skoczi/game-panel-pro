# Operacje i protokół

Konfiguracja platformy: `MQ2_CONFIG` wskazuje plik PHP poza katalogiem publicznym. DSN używa PDO MySQL/MariaDB lub SQLite; produkcyjnie zalecana osobna baza MariaDB. Klucz `server_keys[server_id]` identyfikuje dokładnie jeden serwer. `admin_ids` to rzeczywiste ID kont Flute, nie SteamID. Zmiana powiązanego SteamID nie podmienia tożsamości istniejącego gracza.

## Rejestr serwerów

Od 0.2.2 dostępny jest formularz **Administracja Flute → Matchmaking · Serwery → Dodaj serwer** (`/admin/matchmaking/servers`) oraz skrót **/play → Panel → Zarządzaj**. Wymagane są jednocześnie uprawnienie Flute `admin` i konto w `admin_ids`. Formularz obsługuje nazwę, stałe ID, grę, adres, mapy i tryby. Zapis pozostawia serwer wyłączony; edycja serwera z dzierżawą jest blokowana. Wyłączenie zatrzymuje nowe przydziały i zachowuje trwający mecz.

**Instalacja → Pobierz prywatną konfigurację** eksportuje JSON z obiektem `agent`, zmiennymi `environment` i instrukcjami. Zapisz `agent` do `agent.json`, a wartości `environment` do prywatnego pliku usługi; `MQ2_RCON_PASSWORD: null` należy zastąpić lokalnym hasłem. Pakiet nie instaluje pluginów automatycznie. Uzupełnij ścieżki, odczytaj i zweryfikuj build (obowiązkowo dla CSCO), zainstaluj właściwy plugin i uruchom `python3 agent/mq_agent.py /etc/mq2-agent/agent.json` przez dostosowaną usługę `deploy/mq2-agent.service`.

Klucze HMAC generowane przez panel znajdują się poza webrootem: `server_keys_dir`, na WAW1 `/etc/mq2/agent-keys` (0700, www-data), pliki `.key` mają 0600. Istniejące wpisy `server_keys` mają pierwszeństwo. Powtórne pobranie zachowuje ten sam klucz. Nie dołączać tych plików ani pobranych konfiguracji do repozytorium. Nie ma automatycznej rotacji kluczy.

Diagnostyka pokazuje ostatni podpisany heartbeat, stan kontrolera i zgodność map. Nie wykonuje połączeń RCON z serwera WWW i nie zastępuje prawdziwego meczu odbiorowego. Włączenie wymaga zdrowego agenta z sygnałem nie starszym niż 30 sekund oraz pełnej puli map wybranych trybów.

Przygotuj plik na podstawie `config/server.example.json` i uruchom `MQ2_CONFIG=/etc/mq2/platform.php php bin/register-server.php /etc/mq2/server.json`. Polecenie waliduje grę, adapter, adres i mapy, odmawia zmiany serwera z aktywną dzierżawą i zapisuje audyt. Domyślnie serwer pozostaje wyłączony; po odbiorze zmień `enabled` w prywatnym pliku na `true` i zarejestruj go ponownie. Klucze HMAC pozostają w konfiguracji platformy i środowisku agenta.

Tabela `mq2_servers` zawiera `id`, nazwę, `game` (`csco`, `csgo`, `cs16`), publiczny adres `host:port`, adapter (`get5` lub `amxx`), `enabled`, `healthy`, `generation`, `seen_at` i JSON `capabilities` z tablicami `modes` oraz `maps`. Utwórz wpis z `healthy=0`, `generation=0`, `seen_at=0`. Agent ustawi zdrowie dopiero po sprawdzeniu kontrolera i dziennika. Pełna pula map drabinki musi być dostępna na wybranym serwerze.

Na Source: skompiluj `games/source/mq2_bridge.sp` z dołączonym Get5 API i sm-json; wynik umieść w `addons/sourcemod/plugins`. Agent oraz proces gry muszą widzieć ten sam katalog `configs/mq2` i `data/mq2`. Użyj `agent/config.example.json`. Klucze HMAC i RCON są pobierane ze zmiennych środowiskowych, nie z konfiguracji meczu.

Na CS 1.6 od 0.4.0: zainstaluj MatchBot CSCO w Metamod, z ReHLDS i ReGameDLL; wyłącz stary `mq2_match.amxx`. Szczegóły: [CS16-MATCHBOT-INSTALL.md](CS16-MATCHBOT-INSTALL.md). Nazwa transportu `adapter=amxx`, `game=cs16`, `game_root=cstrike` i ścieżki `addons/amxmodx/configs/mq2` oraz `addons/amxmodx/data/mq2/events.jsonl` pozostają zgodne z poprzednią integracją. WWW wymaga identyfikacji kontrolera `matchbot`, wersji co najmniej 0.4.0 i protokołu agenta 2. RCON wyłącznie w sieci lokalnej hosta.

Rejestracja CLI pozostaje dostępna dla instalacji automatycznych. Panel nie przechowuje hasła RCON; ustawiasz je lokalnie na hoście gry.

## Podpis

Agent wysyła POST JSON na `/mq2-agent`, z nagłówkami `X-MQ-Server`, `X-MQ-Time` (Unix time), `X-MQ-Signature`. Podpis to hex HMAC-SHA256 z dokładnego ciągu `server_id + "\n" + timestamp + "\n" + raw_body`. Dopuszczalna różnica zegara to 60 s. Odpowiedzi zdarzeń można bezpiecznie ponawiać; potwierdzenie drugiego odbioru nie ponawia skutków.

Akcje: `poll` z `healthy` i obserwacją kontrolera oraz `event`. Zdarzenia mają `schema_version=1`, trwały `event_id`, `match_id`, `generation`, numer `sequence`, `boot_id`, `type`, `data`. Numer sekwencji przydziela trwale agent podczas zapisu do SQLite. Platforma wymaga kolejnego numeru i odrzuca lukę. Zduplikowany identyczny event jest potwierdzany przed walidacją aktualnej dzierżawy, również po zakończeniu sprzątania.

Typy: `loaded` (mapa, hash konfiguracji), `connected` (SteamID64 i boolean), `live`, `pause`, `resume`, `round`, `finished` (wyniki drużyn i opcjonalne `players` ze statystykami), `idle`. Statystyki: `kills`, `deaths`, `assists`, `damage`, `rounds`, `headshots`; brak danych pozostaje brakiem danych. Wyniki CT/T są tłumaczone na drużyny w kontrolerze gry.

Komendy `load`, `abort`, `cleanup` są ponawiane do potwierdzenia właściwym zdarzeniem. Agent nie traktuje odpowiedzi RCON jako dowodu przygotowania meczu. `loaded` pochodzi z kontrolera po zgodności mapy/przydziału; `idle` wymaga potwierdzenia pustego, wolnego serwera. Obca tożsamość oznacza odmowę nadpisania i interwencję.

## Awarie

- Przerwa platformy (bieżące demo: WAW1): agent zapisuje dziennik i ponawia. Nie kasować dziennika ani bazy SQLite agenta.
- Konflikt ID / luka sekwencji / ucięty lub wymieniony plik: agent przestaje przydzielać nowe mecze; sprawdzić logi i uzgodnić zdarzenia. Automatyczne omijanie błędu byłoby ryzykiem błędnego ELO.
- Serwer nie trzyma przypisanego meczu: kwarantanna, alert w pokoju i zapis w audycie. Administrator może anulować z powodem. Brak automatycznego przyznawania zwycięstwa.
- Anulowanie po komendzie startu: pending load staje się `superseded`; `abort` zostaje do potwierdzenia idle. Upływ czasu nie uwalnia serwera.
- Wycofanie wdrożenia: zamknij nowe kolejki, dokończ lub jawnie anuluj mecze, zachowaj ledger i zdarzenia, przywróć poprzednią nawigację. Nie usuwaj danych v2.

Retencja dzienników i rotacja po uzgodnieniu archiwum wymagają procedury operacyjnej. Obecny agent celowo odrzuca automatyczną podmianę/truncation pliku, żeby nie utracić niepotwierdzonych rekordów.
