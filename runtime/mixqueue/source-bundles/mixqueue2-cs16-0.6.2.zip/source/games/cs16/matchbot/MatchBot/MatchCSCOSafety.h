// CSCO ranked safety policy. GPL-3.0. No engine/slot state in these helpers.
#pragma once
#include <array>
#include <vector>

namespace mq2 {
constexpr int RECONNECT_LIMIT=1, RECONNECT_SECONDS=90, TACTICAL_LIMIT=3, TACTICAL_SECONDS=30, READY_SECONDS=300;
struct ReconnectBudget {
    std::array<int,2> used{};
    bool available(int team) const { return team>=1 && team<=2 && used[team-1]<RECONNECT_LIMIT; }
    void consume(const std::array<bool,2>& teams) {
        for(int i=0;i<2;++i) if(teams[i] && available(i+1)) ++used[i];
    }
    void reset() { used={}; }
};
struct Rule { const char* name; float expected; bool optional;
    Rule(const char* key,float wanted,bool mayBeMissing=false):name(key),expected(wanted),optional(mayBeMissing) {}
};
inline std::vector<Rule> tournament_rules(bool warm,bool overtime,bool paused,int pauseSeconds=TACTICAL_SECONDS,bool test=false) {
    return {
        {"mp_autoteambalance",0},{"mp_limitteams",0},{"mp_auto_join_team",0},
        {"mp_timelimit",0},{"mp_maxrounds",0},{"mp_winlimit",0},
        {"mp_freezetime",warm?0.0f:10.0f},{"mp_roundtime",test && !warm?0.5f:1.75f},{"mp_c4timer",35},
        {"mp_buytime",paused?pauseSeconds/60.0f:warm?1.75f:0.25f},
        {"mp_startmoney",warm?16000.0f:overtime?10000.0f:800.0f},
        {"mp_friendlyfire",warm?0.0f:1.0f},{"mp_fadetoblack",0},
        {"mp_forcecamera",2},{"mp_forcechasecam",2},{"mp_autokick",0},{"mp_tkpunish",0},
        {"mp_hostagepenalty",0},{"sv_alltalk",warm?1.0f:0.0f},{"sv_voiceenable",1},
        {"sv_cheats",0},{"sv_gravity",800},{"sv_airaccelerate",10},{"sv_maxspeed",320},
        {"pausable",0},{"mp_freeforall",0},{"mp_round_infinite",warm?1.0f:0.0f},
        {"mp_forcerespawn",warm?2.0f:0.0f},{"mp_roundrespawn_time",warm?-1.0f:0.0f},
        {"mp_maxmoney",16000},{"mp_buy_anywhere",warm?1.0f:0.0f},
        {"mp_infinite_ammo",0},{"mp_infinite_grenades",0},{"mp_free_armor",0},
        {"mp_auto_reload_weapons",0},{"mp_refill_bpammo_weapons",0},
        {"mp_round_restart_delay",5},{"mp_team_flash",1},{"mp_assist_damage_threshold",40},
        {"bot_quota",0,true},{"bot_deathmatch",0,true}
    };
}
}
