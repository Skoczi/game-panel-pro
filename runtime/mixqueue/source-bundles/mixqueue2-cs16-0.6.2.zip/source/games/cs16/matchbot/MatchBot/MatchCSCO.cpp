// MatchBot -> CSCO assignment/journal adapter. GPL-3.0.
#include "precompiled.h"
#include "MatchCSCO.h"
#include "MatchCSCOBots.h"
#include <fstream>
#include <iomanip>
#include <cstdio>
#include <cerrno>
#include <cmath>
#include <ctime>
#include <random>
#ifndef _WIN32
#include <fcntl.h>
#else
#include <io.h>
#endif

CMatchCSCO gMatchCSCO;
namespace {
const char* VERSION="0.6.2";
const std::pair<const char*,const char*> botSettings[]={
    {"bot_quota","0"},{"bot_quota_mode","normal"},{"bot_join_after_player","0"},
    {"bot_auto_vacate","0"},{"bot_join_delay","0"},{"bot_stop","0"},{"bot_freeze","0"},
    {"bot_zombie","0"},{"bot_mimic","0"},{"bot_walk","0"},{"bot_deathmatch","0"},
    {"bot_difficulty","1"},{"bot_chatter","off"},{"bot_defer_to_human","0"},
    {"bot_allow_pistols","1"},{"bot_allow_shotguns","1"},{"bot_allow_sub_machine_guns","1"},
    {"bot_allow_rifles","1"},{"bot_allow_machine_guns","1"},{"bot_allow_grenades","1"},
    {"bot_allow_snipers","1"},{"bot_allow_shield","1"},{"bot_prefix",""}
};
void directories(const std::string& path) {
    for(size_t i=1;i<=path.size();++i) if(i==path.size() || path[i]=='/') {
        const auto part=path.substr(0,i);
#ifdef _WIN32
        const int result=_mkdir(part.c_str());
#else
        const int result=mkdir(part.c_str(),0750);
#endif
        if(result && errno!=EEXIST) throw std::runtime_error("directory_io");
    }
}
bool exists(const std::string& path) { std::ifstream f(path); return bool(f); }
void sync_file(FILE* file) {
    if(fflush(file)) throw std::runtime_error("flush_io");
#ifdef _WIN32
    if(_commit(_fileno(file))) throw std::runtime_error("sync_io");
#else
    if(fsync(fileno(file))) throw std::runtime_error("sync_io");
#endif
}
void sync_directory(const std::string& path) {
#ifndef _WIN32
    int fd=open(path.substr(0,path.find_last_of('/')).c_str(),O_RDONLY|O_DIRECTORY);
    if(fd<0) throw std::runtime_error("directory_io");
    int result=fsync(fd); close(fd);
    if(result) throw std::runtime_error("directory_io");
#endif
}
void write(const std::string& path,const std::string& content,bool append=false) {
    const std::string target=append?path:path+".next";
    FILE* f=fopen(target.c_str(),append?"ab":"wb");
    if(!f) throw std::runtime_error("open_io");
    try {
        if(fwrite(content.data(),1,content.size(),f)!=content.size()) throw std::runtime_error("write_io");
        sync_file(f);
    } catch(...) { fclose(f); throw; }
    if(fclose(f)) throw std::runtime_error("close_io");
    if(!append) {
#ifdef _WIN32
        if(!MoveFileExA(target.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))
            throw std::runtime_error("rename_io");
#else
        if(rename(target.c_str(),path.c_str())) throw std::runtime_error("rename_io");
#endif
        sync_directory(path);
    }
}
void remove_file(const std::string& path) {
    if(std::remove(path.c_str()) && errno!=ENOENT) throw std::runtime_error("remove_io");
    sync_directory(path);
}
void cvar(const char* name,const char* value) {
    auto p=g_engfuncs.pfnCVarGetPointer(name);
    if(p) g_engfuncs.pfnCvar_DirectSet(p,value);
}
bool value(const char* name,float expected) {
    auto p=g_engfuncs.pfnCVarGetPointer(name);
    return p && std::fabs(p->value-expected)<0.001f;
}
std::string number(int n) { return std::to_string(n); }
const char* boolean(bool b) { return b?"true":"false"; }
}

void CMatchCSCO::Print(const std::string& value) { g_engfuncs.pfnServerPrint((value+"\n").c_str()); }
void CMatchCSCO::Fail(const char* code) {
    quarantine=true; roundOpen=false; phase="recovery"; tactical.reset(); gMatchRound.ResetCSCO();
    cvar("mp_round_infinite","1");
    Print(std::string("[CSCO] recovery: ")+code);
    try { RestoreBots(); } catch(...) { cvar("bot_quota","0");cvar("bot_stop","1");Print("[CSCO] bot_restore_io"); }
    try { RestoreHostname(); } catch(...) { Print("[CSCO] hostname_restore_io"); }
}
void CMatchCSCO::Activate() {
    pauseSerial=0; pauseDeadline=0;
    reconnectBudget.reset(); readyDeadline=nextRulesCheck=rulesMismatchSince=0; readyExpired=false; readyWarning=0; rulesFault.clear(); reportedReady.fill(-1);
    tactical.reset(); gMatchRound.ResetCSCO();
    try {
        if(boot.empty()) {
            std::ostringstream token; std::random_device random;
            token<<std::hex<<std::time(nullptr)<<random()<<random(); boot=token.str();
            static char statusCommand[]="mq2_status",loadCommand[]="mq2_load",clearCommand[]="mq2_clear",endCommand[]="mq2_endtest";
            g_engfuncs.pfnAddServerCommand(statusCommand,StatusCommand);
            g_engfuncs.pfnAddServerCommand(loadCommand,LoadCommand);
            g_engfuncs.pfnAddServerCommand(clearCommand,ClearCommand);
            g_engfuncs.pfnAddServerCommand(endCommand,EndTestCommand);
#ifdef MQ2_QA
            static char qaCommand[]="mq2_qa"; g_engfuncs.pfnAddServerCommand(qaCommand,QACommand);
#endif
        }
        char directory[260]={}; g_engfuncs.pfnGetGameDir(directory);
        root=std::string(directory)+"/addons/amxmodx/configs/mq2";
        creatingBot=false; creatingBotSlot=-1; creatingBotClient=0; bootstrappingBots=false;
        RestoreBots();
        lastHostname.clear();
        gMatchMessage.RegisterHook("ServerName",ServerName);
        marker=root+"/active-matchbot.txt"; highPath=root+"/generation-matchbot.txt";
        const auto data=std::string(directory)+"/addons/amxmodx/data/mq2";
        journal=data+"/events.jsonl"; directories(root); directories(data);
        write(journal,"",true);
        statistics.reset();config=mq2::Config(); sequence=0; bot=0; live=false; loading=false; clearing=false;
        roundOpen=false; quarantine=false; teamOneCT=true; paused=false; nextFrame=0;
        score[0]=score[1]=0; timeouts[0]=timeouts[1]=0; pendingRound=false; emptySideObserved=false; reconnectResumes=0; disconnectPause=false;
        voteTeam=0; voteEligible.clear(); voteYes.clear();
        voteCooldown[0]=voteCooldown[1]=0; std::fill(voteMenu,voteMenu+33,false); phase="idle"; highWater=0;
        std::fill(authDeadline,authDeadline+33,0); std::fill(botSlots,botSlots+33,0); std::fill(botUserIds,botUserIds+33,0);
        RestoreHostname();
#ifdef MQ2_QA
        std::fill(qaSlots,qaSlots+33,0);
        for(auto& rows:qaFeedback) rows.clear();
#endif
        std::ifstream high(highPath);
        if(high && (!(high>>highWater) || highWater<1)) throw std::runtime_error("generation_io");
        Profile(STATE_DEAD);
        if(exists(root+"/active.txt")) { Fail("legacy_assignment"); return; }
        if(exists(marker)) {
            std::ifstream file(marker); std::string id,stage,owner,extra; int gen=0;
            if(!(file>>id>>gen>>stage>>owner) || (file>>extra) || !mq2::hex(id,24) || gen<1)
                throw std::runtime_error("invalid_marker");
            std::ifstream input(root+"/"+id+"-"+number(gen)+".txt");
            config=mq2::parse(input,id,gen);teamOneCT=config.startingCT==1;
            // Only the map change initiated in THIS process may resume warmup.
            if(stage=="loading" && owner==boot && config.map==STRING(gpGlobals->mapname)) Ready();
            else Fail("interrupted_assignment");
        }
    } catch(...) { Fail("storage_or_config"); }
}
void CMatchCSCO::Deactivate() { tactical.reset(); gMatchRound.ResetCSCO(); roundOpen=false; try { RestoreBots(true);RestoreHostname(); } catch(...) { Fail("deactivate_io"); } }
void CMatchCSCO::Persist(const std::string& stage) {
    write(marker,config.id+" "+number(config.generation)+" "+stage+" "+boot+"\n");
}
void CMatchCSCO::SetPhase(const std::string& stage) {
    Persist(stage); phase=stage; UpdateHostname();
}
void CMatchCSCO::Emit(const std::string& type,const std::string& data,const std::string& stable) {
    if(config.id.empty() || quarantine) return;
    const auto id=config.id+":"+number(config.generation)+":"+
        (stable.empty()?boot+":"+number(++sequence):stable);
    try {
        write(journal,"{\"event_id\":\""+id+"\",\"match_id\":\""+config.id+
            "\",\"generation\":"+number(config.generation)+",\"type\":\""+type+"\",\"data\":"+data+"}\n",true);
    } catch(...) { Fail("journal_io"); }
}
void CMatchCSCO::LoadCommand() {
    const std::string id=g_engfuncs.pfnCmd_Argv(1),gen=g_engfuncs.pfnCmd_Argv(2);
    if(g_engfuncs.pfnCmd_Argc()!=3 || !mq2::hex(id,24) || gen.empty() || gen.size()>9 ||
       gen.find_first_not_of("0123456789")!=std::string::npos) { Print("invalid_assignment"); return; }
    try { gMatchCSCO.Load(id,std::stoi(gen)); }
    catch(...) { gMatchCSCO.Fail("load_io"); Print("storage_failure"); }
}
void CMatchCSCO::Load(const std::string& id,int generation) {
    if(generation<1) { Print("invalid_assignment"); return; }
    if(!config.id.empty() || quarantine || clearing) {
        Print(config.id==id && config.generation==generation && !quarantine?"already_loaded":"busy"); return;
    }
    if(generation<=highWater) { Print("stale_generation"); return; }
    mq2::Config next;
    std::ifstream input(root+"/"+id+"-"+number(generation)+".txt");
    if(!input.is_open()) { Print("storage_failure"); return; }
    try {
        next=mq2::parse(input,id,generation);
    } catch(...) { Print(input.bad()?"storage_failure":"malformed_assignment"); return; }
    if(input.bad()) { Print("storage_failure"); return; }
    // The engine is authoritative even if inventory changed after veto.
    if(!g_engfuncs.pfnIsMapValid(const_cast<char*>(next.map.c_str()))) { Print("missing_map"); return; }
    const auto botIssue=BotIssue(next);if(!botIssue.empty()) {Print(botIssue);return;}
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto player=UTIL_PlayerByIndexSafe(i);
        if(player && !player->IsDormant()) { Print("server_not_empty"); return; }
    }
    SaveHostname();
    write(highPath,number(generation)+"\n"); highWater=generation;
    tactical.reset(); gMatchRound.ResetCSCO();
#ifdef MQ2_QA
    for(auto& rows:qaFeedback) rows.clear();
#endif
    pauseSerial=0; pauseDeadline=0;
    reconnectBudget.reset(); readyExpired=false; readyWarning=0; rulesFault.clear(); reportedReady.fill(-1);
    statistics.reset();config=next; sequence=0; live=false; roundOpen=false; teamOneCT=config.startingCT==1; score[0]=score[1]=0;
    timeouts[0]=timeouts[1]=0; pendingRound=false; emptySideObserved=false; reconnectResumes=0; disconnectPause=false;
        voteTeam=0; voteEligible.clear(); voteYes.clear();
        voteCooldown[0]=voteCooldown[1]=0; std::fill(voteMenu,voteMenu+33,false);
    if(config.map!=STRING(gpGlobals->mapname)) {
        loading=true; SetPhase("loading"); Print("loading_map");
        g_engfuncs.pfnChangeLevel(const_cast<char*>(config.map.c_str()),nullptr);
    } else { Ready(); Print(quarantine?"storage_failure":"loaded"); }
}
void CMatchCSCO::Ready() {
    const auto botIssue=BotIssue(config);if(!botIssue.empty()){Fail(botIssue.c_str());return;}
    ConfigureBots();
    readyDeadline=gpGlobals->time+mq2::READY_SECONDS;readyUntil=std::time(nullptr)+mq2::READY_SECONDS; reportedReady.fill(-1);
    idleRounds.fill(0);teamDamage.fill(0);teamKills.fill(0);activityAlerts.fill(0);
    loading=false; SetPhase("warmup");
    cvar("mb_players_min",number(config.test && !config.fullTest?2:config.players.size()).c_str());
    cvar("mb_players_max",number(config.test && !config.fullTest?2:config.players.size()).c_str());
    cvar("mb_play_rounds",number(config.mr*2).c_str()); cvar("mb_play_rounds_ot","6");
    cvar("mb_play_ot_mode","1"); cvar("mb_ready_type","1"); cvar("mb_ready_auto_continue","1");
    cvar("mb_team_pick_type","2"); cvar("mb_vote_map","0"); cvar("mb_vote_map_auto","0");
    cvar("mb_players_min_diff","0"); cvar("mb_knife_round","0"); cvar("mb_retry_mode","0");
    cvar("mb_pause_auto",config.test?"1":"0"); cvar("mb_pause_time","30"); cvar("mb_scoreboard_team","1");
    cvar("mb_scoreboard_player","0"); // Roster counters survive reconnects; entity-slot counters do not.
    gMatchBot.SetState(STATE_WARMUP);
    // A successful RCON exchange or profile file is insufficient: require the
    // native factory to create the full requested roster before loaded. Joining
    // hooks bind identities now; connected events follow their loaded authority.
    bootstrappingBots=true;EnsureBot();bootstrappingBots=false;
    if(quarantine)return;
    Emit("loaded","{\"map\":\""+config.map+"\",\"config_hash\":\""+config.hash+"\",\"ready_deadline\":"+std::to_string(readyUntil)+"}","loaded");
    if(config.fullTest)for(const auto& row:config.players)
        if(row.bot && row.client)Emit("connected","{\"steam_id\":\""+row.steam+"\",\"connected\":true}");
}
void CMatchCSCO::ClearCommand() {
    const std::string reason=g_engfuncs.pfnCmd_Argc()==1?"server_error":g_engfuncs.pfnCmd_Argv(1);
    if(g_engfuncs.pfnCmd_Argc()>2 || !ValidReason(reason)) { Print("invalid_reason"); return; }
    try { gMatchCSCO.Clear(reason); Print("cleared"); }
    catch(...) { gMatchCSCO.Fail("cleanup_io"); Print("cleanup_failed"); }
}
void CMatchCSCO::Clear(const std::string& reason) {
    reconnectBudget.reset(); readyDeadline=0; readyExpired=false; rulesFault.clear(); reportedReady.fill(-1);
    clearing=true; roundOpen=false; tactical.reset(); gMatchRound.ResetCSCO();
    if(pendingRound) { pendingRound=false; ReportScore(mq2::won(score[0],score[1],config.mr,config.ot)); }
    gMatchTask.ServerDeactivate(); gMatchReady.Stop(false); gMatchTimer.Stop(false);
    gMatchLO3.Stop(); gMatchWarmup.Stop(); gMatchPause.ServerActivate();
    cvar("sv_restart","0"); cvar("sv_restartround","0");
    RestoreBots(true);
    RestoreHostname(true);
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto player=UTIL_PlayerByIndexSafe(i); if(player && !player->IsDormant()) Kick(player->edict(),reason);
    }
    remove_file(marker); remove_file(root+"/active.txt");
    statistics.reset();config=mq2::Config(); quarantine=false; loading=false; live=false; bot=0; paused=false;
    score[0]=score[1]=0;
    // Idle tournament invariants intentionally override the restored bot quota
    // and bot_deathmatch. Other test AI settings return to their saved values;
    // an idle/ranked server must not autonomously refill or run deathmatch AI.
    phase="idle"; gMatchBot.SetState(STATE_DEAD); Profile(STATE_DEAD);
    std::fill(botSlots,botSlots+33,0); std::fill(botUserIds,botUserIds+33,0); clearing=false;
}
bool CMatchCSCO::ValidReason(const std::string& reason) {
    for(const auto code:{"test_admin","test_timeout","match_finished","not_roster","no_match","steam_timeout","server_error"}) if(reason==code) return true;
    return false;
}
const char* CMatchCSCO::Reason(const std::string& reason,const std::string& locale) const {
    // Explicit ASCII Polish fallback for the legacy GoldSrc reject/kick UI.
    const bool pl=locale=="pl";
    if(reason=="test_admin") return pl?"[CSCO.GG] Administrator zakonczyl mecz testowy.":"[CSCO.GG] The administrator ended this test match.";
    if(reason=="test_timeout") return pl?"[CSCO.GG] Uplynal czas meczu testowego.":"[CSCO.GG] This test match has expired.";
    if(reason=="match_finished") return pl?"[CSCO.GG] Mecz zakonczony. Wynik jest na CSCO.gg.":"[CSCO.GG] Match finished. View the result on CSCO.gg.";
    if(reason=="not_roster") return pl?"[CSCO.GG] Nie nalezysz do skladu tego meczu.":"[CSCO.GG] You are not on this match roster.";
    if(reason=="no_match") return pl?"[CSCO.GG] Brak aktywnego meczu. Dolacz przez CSCO.gg.":"[CSCO.GG] No active match. Join through CSCO.gg.";
    if(reason=="steam_timeout") return pl?"[CSCO.GG] Nie potwierdzono Steam. Polacz sie ponownie.":"[CSCO.GG] Steam authentication timed out. Please reconnect.";
    return pl?"[CSCO.GG] Serwer wymaga odzyskania sesji. Sprawdz CSCO.gg.":"[CSCO.GG] Server recovery is required. Check CSCO.gg.";
}
void CMatchCSCO::Kick(edict_t* entity,const std::string& reason) {
    const int slot=Slot(entity);
    const auto code=ValidReason(reason)?reason:std::string("server_error");
    const auto locale=slot>=0?config.players[slot].locale:std::string("en");
    Print("[CSCO] reject="+code+" userid="+number(g_engfuncs.pfnGetPlayerUserId(entity)));
    gMatchUtil.ServerCommand("kick #%d \"%s\"",g_engfuncs.pfnGetPlayerUserId(entity),Reason(code,locale));
}
void CMatchCSCO::SaveHostname() {
    const auto path=root+"/original-hostname.txt";
    if(!exists(path)) {
        const std::string original=g_engfuncs.pfnCVarGetString("hostname");
        if(original.size()>255) throw std::runtime_error("hostname_io");
        write(path,original);
    }
}
void CMatchCSCO::RestoreHostname(bool remove) {
    if(root.empty()) return;
    const auto path=root+"/original-hostname.txt";
    if(!exists(path)) return;
    std::ifstream file(path,std::ios::binary);
    std::string original((std::istreambuf_iterator<char>(file)),std::istreambuf_iterator<char>());
    if(original.size()>255 || original.find('\0')!=std::string::npos) throw std::runtime_error("hostname_io");
    cvar("hostname",original.c_str());
    hostnameRestored=true;
    lastHostname=original;
    SendHeader();
    if(remove) remove_file(path);
}
void CMatchCSCO::UpdateHostname() {
    if(config.id.empty() || quarantine) return;
    const auto stage=phase=="finished"?"FINISHED":paused?"PAUSED":live?"LIVE":"WARMUP";
    // 127-byte engine/browser budget; truncate each UTF-8 name independently.
    const std::string name=std::string("[")+stage+"] "+mq2::clip(config.teams[0],48)+" vs "+mq2::clip(config.teams[1],48)+" @CSCO.gg";
    cvar("hostname",name.c_str());
    hostnameRestored=false;
    if(lastHostname!=name) { lastHostname=name; SendHeader(); }
}
std::string CMatchCSCO::Header() const {
    // Cleanup/recovery must show the saved original, never an old match label.
    if(hostnameRestored || config.id.empty() || quarantine || clearing)
        return mq2::clip(g_engfuncs.pfnCVarGetString("hostname"),31);
    const auto stage=phase=="finished"?"FINISHED":paused?"PAUSED":live?"LIVE":"WARMUP";
    return mq2::server_title(stage,config.teams[0],config.teams[1]);
}
void CMatchCSCO::SendHeader(edict_t* client) {
    const int message=gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info,"ServerName",nullptr);
    if(!message) return;
    const auto title=Header();
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto player=UTIL_PlayerByIndexSafe(i);
        if(!player || player->IsDormant() || (player->pev->flags&(FL_FAKECLIENT|FL_PROXY)) ||
           player->m_iJoiningState!=JOINED || (client && player->edict()!=client)) continue;
        g_engfuncs.pfnMessageBegin(MSG_ONE,message,nullptr,player->edict());
        g_engfuncs.pfnWriteString(title.c_str());
        g_engfuncs.pfnMessageEnd();
    }
}
bool CMatchCSCO::ServerName(int destination,int type,const float* origin,edict_t* entity) {
    // Also bound the GameDLL's sign-on / HUD refresh message; it otherwise sends
    // the long browser hostname and may overwrite a just-sent compact title.
    const auto title=gMatchCSCO.Header();
    gMatchMessage.SetArgString(0,title.c_str());
    return false;
}
void CMatchCSCO::EndTestCommand() {
    const std::string reason=g_engfuncs.pfnCmd_Argv(1);
    if(g_engfuncs.pfnCmd_Argc()!=2 || (reason!="test_admin" && reason!="test_timeout" && reason!="server_error")) { Print("invalid_reason"); return; }
    gMatchCSCO.EndTest(reason);
}
void CMatchCSCO::EndTest(const std::string& reason) {
    if(!Active() || !config.fullTest || phase=="finished") { Print("test_not_active"); return; }
    if(pendingRound) { pendingRound=false; ReportScore(false); }
    roundOpen=false;
    try { SetPhase("finished"); } catch(...) { Fail("state_io"); return; }
    gMatchTask.ServerDeactivate(); gMatchLO3.Stop(); gMatchReady.Stop(false);
    gMatchTimer.Stop(false); gMatchWarmup.Stop(); gMatchPause.ServerActivate(); tactical.reset(); gMatchRound.ResetCSCO();
    cvar("sv_restart","0"); cvar("sv_restartround","0"); cvar("mp_round_infinite","1");
    Emit("test_ended","{\"team1_score\":"+number(score[0])+",\"team2_score\":"+number(score[1])+
        ",\"stats_version\":"+number((!config.test||config.fullTest)?2:1)+",\"players\":"+PlayerStats()+",\"reason\":\""+reason+"\",\"actor\":\""+config.owner+"\"}","test-ended");
    Print("test_ended");
}
int CMatchCSCO::Slot(edict_t* entity) const {
    if(FNullEnt(entity)) return -1;
    if(ENTINDEX(entity)<1 || ENTINDEX(entity)>gpGlobals->maxClients) return -1;
    if(config.fullTest && botSlots[ENTINDEX(entity)]>0 && botUserIds[ENTINDEX(entity)]==g_engfuncs.pfnGetPlayerUserId(entity)) return botSlots[ENTINDEX(entity)]-1;
    const auto auth=g_engfuncs.pfnGetPlayerAuthId(entity);
    const auto steam=mq2::steam64(auth?auth:"");
    for(size_t i=0;i<config.players.size();++i) {
#ifdef MQ2_QA
        if(qaSlots[ENTINDEX(entity)]==int(i)+1) return i;
#endif
        if(!steam.empty() && config.players[i].steam==steam) return i;
    }
    return -1;
}
TeamName CMatchCSCO::Side(int team) const { return ((team==1)==teamOneCT)?CT:TERRORIST; }
bool CMatchCSCO::Connect(edict_t* entity,char* reject) {
    authDeadline[ENTINDEX(entity)]=gpGlobals->time+30;
    if(creatingBot) return true;
    const auto auth=g_engfuncs.pfnGetPlayerAuthId(entity);
    const bool pending=auth && !strcmp(auth,"STEAM_ID_PENDING");
    const int slot=Slot(entity);
    if(Active() && !(entity->v.flags&(FL_FAKECLIENT|FL_PROXY)) &&
       (pending || slot>=0)) return true;
    const std::string reason=quarantine?"server_error":config.id.empty()?"no_match":"not_roster";
    Print("[CSCO] reject="+reason);
    std::snprintf(reject,128,"%s",Reason(reason,slot>=0?config.players[slot].locale:"en")); return false;
}
void CMatchCSCO::Disconnect(edict_t* entity) {
    if(FNullEnt(entity)) return;
    const int client=ENTINDEX(entity);
    const int leaving=Slot(entity);
    statistics.disconnect(leaving);
    voteYes.erase(std::remove(voteYes.begin(),voteYes.end(),leaving),voteYes.end());
    authDeadline[client]=0; voteMenu[client]=false; botSlots[client]=0; botUserIds[client]=0;
#ifdef MQ2_QA
    qaSlots[client]=0;
#endif
    if(client==bot) bot=0;
    for(auto& p:config.players) if(p.client==client) {
        const auto player=UTIL_PlayerByIndexSafe(client);
        if(live && player) p.reconnectMoney=player->m_iAccount;
        const int roster=int(&p-config.players.data());activityTrack[roster]=false;idleRounds[roster]=0;
        p.client=0;
        if(Active() && live && !clearing && phase!="finished" && !config.test && p.absence!=4) {
            p.absence=disconnectPause?2:1;
            p.absenceDeadline=0;
        }
        if(!bootstrappingBots)Emit("connected","{\"steam_id\":\""+p.steam+"\",\"connected\":false}");
    }
    BotQuota();
}
int CMatchCSCO::TeamSlot(CBasePlayer* p) {
    if(!Active()) return 0;
    if(creatingBot && config.test && p->IsBot() && !creatingBotClient) {
        const int client=p->entindex();creatingBotClient=client;
        botUserIds[client]=g_engfuncs.pfnGetPlayerUserId(p->edict());
        if(config.fullTest && creatingBotSlot>=0 && size_t(creatingBotSlot)<config.players.size() && config.players[creatingBotSlot].bot) {
            botSlots[client]=creatingBotSlot+1;return int(Side(config.players[creatingBotSlot].team));
        }
        if(!config.fullTest && creatingBotSlot==-1) {bot=client;return int(Side(2));}
        return 0;
    }
    int slot=Slot(p->edict());
    const TeamName desired=TestOpponent(p)?Side(2):
        (slot<0?UNASSIGNED:Side(config.players[slot].team));
    if(desired==UNASSIGNED) return 0;
    // Choosing the same side again can kill/respawn a live player in GoldSrc.
    if(p->m_iTeam==desired && p->m_iJoiningState==JOINED) return 0;
    return int(desired);
}
void CMatchCSCO::Joined(CBasePlayer* p) {
    if(TestOpponent(p)) return;
    int slot=Slot(p->edict());
    if(!Active() || slot<0 || p->m_iTeam!=Side(config.players[slot].team)) { Kick(p->edict()); return; }
    auto& data=config.players[slot];
    if(data.client && data.client!=p->entindex()) { Kick(p->edict()); return; }
    if(!data.client) {
        if(data.absence==4 && voteTeam==data.team) EndSurrender(false);
        data.client=p->entindex();
        SendHeader(p->edict());
        if(data.absence!=4) data.absence=0;
        data.absenceDeadline=0;
        if(live && data.reconnectMoney>=0) {
            p->CSPlayer()->AddAccount(data.reconnectMoney-p->m_iAccount,RT_NONE,false);
            data.restoredMoney=p->m_iAccount;
            data.reconnectMoney=-1;
        }
        if(!bootstrappingBots)Emit("connected","{\"steam_id\":\""+data.steam+"\",\"connected\":true}");
        Feedback(slot+1,mq2::wire_text(config.teams[data.team-1],40)+" | "+
            (data.locale=="pl"?(live?"Mecz trwa. /score":"Wpisz /ready, gdy jestes gotowy."):(live?"Match in progress. /score":"Type /ready when ready.")));
    }
}
void CMatchCSCO::CloseTeamMenu(CBasePlayer* p) {
    if(p->m_iMenu==Menu_ChooseTeam || p->m_iMenu==Menu_IGChooseTeam || p->m_iMenu==Menu_ChooseAppearance)
        p->m_iMenu=Menu_OFF;
}
bool CMatchCSCO::SuppressTeamMenu(CBasePlayer* p,int menu,const char* text) {
    // Initial menus may arrive while Steam authentication is still pending.
    // Team choice is never manual during an assignment; Frame still validates
    // the signed roster before joining anyone and rejects unknown identities.
    if(!Active() || !p) return false;
    bool team=menu==VGUI_Menu_Team || menu==VGUI_Menu_Class_T || menu==VGUI_Menu_Class_CT;
    if(menu==0 && text) {
        static const char* keys[]={"#Team_Select","#Team_Select_Spect","#IG_Team_Select",
            "#IG_Team_Select_Spect","#IG_VIP_Team_Select","#IG_VIP_Team_Select_Spect",
            "#CT_Select","#Terrorist_Select"};
        for(const auto key:keys) if(!strcmp(text,key)) team=true;
    }
    if(team) CloseTeamMenu(p);
    return team;
}
void CMatchCSCO::Spawned(CBasePlayer* p) {
    const int slot=Slot(p->edict()); if(slot>=0) config.players[slot].deathCounted=false;
    if(Active() && phase=="warmup") p->CSPlayer()->AddAccount(16000-p->m_iAccount,RT_NONE,false);
}
bool CMatchCSCO::AllPresent() const {
    if(!Active()) return false;
    for(const auto& p:config.players) {
        const auto player=UTIL_PlayerByIndexSafe(p.client);
        if(!p.client || !player || player->IsDormant() || player->m_iTeam!=Side(p.team) ||
           player->m_iJoiningState!=JOINED) return false;
    }
    if(config.test && !config.fullTest) {
        const auto target=UTIL_PlayerByIndexSafe(bot);
        if(!TestOpponent(target) || target->IsDormant() || target->m_iTeam!=Side(2)) return false;
    }
    return true;
}
bool CMatchCSCO::ReadyAllowed() const { return !Managed() || (Active() && !readyExpired && (live || (config.test && !config.fullTest) || gpGlobals->time<readyDeadline)); }
bool CMatchCSCO::CanStart() {
    if(Active() && !live && phase=="warmup") SafetyFrame();
    return !readyExpired && AllPresent() && RulesReady();
}
void CMatchCSCO::BeginLiveFreeze() {
    if(!Active() || live || phase!="starting" || gMatchLO3.Running() || gMatchLO3.Completed()!=3 ||
       gMatchBot.GetState()!=STATE_FIRST_HALF || !AllPresent() || !RulesReady()) return;
    live=true;SetPhase("live");Emit("live","{}","live");
}
bool CMatchCSCO::ReadyForLive() const { return (live || AllPresent()) && !gMatchLO3.Running(); }
bool CMatchCSCO::AllowState(int state) {
    if(state==STATE_DEAD) return true;
    if(!Active()) return false;
    if(phase=="finished") return state==STATE_END;
    if(state==STATE_WARMUP) return phase=="warmup" || (!live && phase=="starting");
    if(state==STATE_START || state==STATE_FIRST_HALF) {
        if(!AllPresent()) { gMatchBot.SetState(STATE_WARMUP); return false; }
    }
    if(state==STATE_END) return mq2::won(score[0],score[1],config.mr,config.ot);
    return true;
}
void CMatchCSCO::StateChanged(int state) {
    try {
        if(state==STATE_HALFTIME || state==STATE_END || state==STATE_DEAD) {
            tactical.reset();gMatchPause.m_Pause=false;
        }
        if(state==STATE_DEAD) return;
        if(state==STATE_WARMUP) {
            cvar("mb_vote_map","0"); cvar("mb_team_pick_type","2");
            SetPhase("warmup");
        }
        if(state==STATE_START || state==STATE_FIRST_HALF) { roundOpen=false; SetPhase("starting"); }
        if(state==STATE_HALFTIME) { roundOpen=false; SetPhase("halftime"); }
        if(state==STATE_SECOND_HALF || state==STATE_OVERTIME) { roundOpen=false; SetPhase("starting"); }
        Profile(state);
        if(state==STATE_END) { roundOpen=false; SetPhase("finished"); }
    } catch(...) { Fail("state_io"); }
}
void CMatchCSCO::Swapped() { teamOneCT=!teamOneCT; }
void CMatchCSCO::FreezeEnd() {
    if(!Active() || gMatchPause.m_Paused || !ReadyForLive() || phase=="halftime" || phase=="finished" ||
       gMatchBot.GetState()<STATE_FIRST_HALF || gMatchBot.GetState()==STATE_HALFTIME) return;
    if(!RulesReady()) { rulesFault=RulesIssue(); Fail("rules_drift"); return; }
    try { SetPhase("live"); } catch(...) { Fail("state_io"); return; }
    roundOpen=true; ActivityBegin();
    std::vector<int> teams;std::vector<bool> present;
    for(const auto& row:config.players) {
        teams.push_back(row.team);auto p=UTIL_PlayerByIndexSafe(row.client);
        present.push_back(p && !p->IsDormant() && p->IsAlive() && p->m_iTeam==Side(row.team));
    }
    statistics.begin(teams,present);
    if(!live) { live=true; UpdateHostname(); Emit("live","{}","live"); }
}
bool CMatchCSCO::BothSidesPresent() const {
    bool sides[2]={false,false};
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto p=UTIL_PlayerByIndexSafe(i);
        if(!p || p->IsDormant() || p->m_iMenu==Menu_ChooseAppearance) continue;
        const int slot=Slot(p->edict());
        if(slot>=0 && p->m_iTeam==Side(config.players[slot].team)) sides[config.players[slot].team-1]=true;
        else if(TestOpponent(p) && p->m_iTeam==Side(2)) sides[1]=true;
    }
    return sides[0] && sides[1];
}
void CMatchCSCO::ObserveTeams() {
    // Called before the real GameDLL win check, including its disconnect path.
    // Let NeededPlayersCheck observe the empty side. Only its later COMMENCE
    // may be consumed; do not restart the round or reset any player/team state.
    if(Active() && live && phase=="live" && !BothSidesPresent()) emptySideObserved=true;
}
bool CMatchCSCO::AllowRoundEnd() {
    return Scoring() && (!config.test || BothSidesPresent()) && !gMatchLO3.Running();
}
bool CMatchCSCO::AllowEngineReset(ScenarioEventEndRound event) {
    if(quarantine) return false;
    if(live && phase=="live" && !gMatchLO3.Running()) {
        if(event==ROUND_GAME_COMMENCE && Active() && emptySideObserved && BothSidesPresent() &&
           !CSGameRules()->m_bGameStarted && !CSGameRules()->m_bCompleteReset &&
           value("sv_restart",0) && value("sv_restartround",0)) {
            CSGameRules()->m_bGameStarted=true;
            CSGameRules()->m_bNeededPlayers=false;
            emptySideObserved=false;
            ++reconnectResumes;
            Print("[CSCO] reconnect_resume: score="+number(score[0])+":"+number(score[1]));
            return false; // NEVER call NeededPlayersCheck(delay): it performs a complete reset.
        }
        Fail("unexpected_engine_reset"); return false;
    }
    return true;
}
bool CMatchCSCO::BeforeRoundRestart() {
    if(quarantine) return false;
    // Defence in depth: a plugin calling RestartRound directly must not bypass
    // the RoundEnd reset guard. Ordinary round transitions remain untouched.
    if(live && phase=="live" && !gMatchLO3.Running() && CSGameRules()->m_bCompleteReset) {
        Fail("unexpected_complete_reset"); return false;
    }
    if(Active() && CSGameRules()->m_bCompleteReset) {
        // A legitimate halftime/OT reset also changes the disconnected roster's economy.
        for(auto& p:config.players) if(p.reconnectMoney>=0)
            p.reconnectMoney=int(g_engfuncs.pfnCVarGetFloat("mp_startmoney"));
    }
    return true;
}
void CMatchCSCO::RoundEnded() {
    if(!Scoring()) return;
    ActivityFrame();ActivityEnd();
    roundOpen=false;
    statistics.end(gMatchBot.GetScore(Side(1))>score[0]?1:2);
    score[0]=gMatchBot.GetScore(Side(1)); score[1]=gMatchBot.GetScore(Side(2));
    for(auto& p:config.players) if(p.client) ++p.rounds;
    const bool finished=mq2::won(score[0],score[1],config.mr,config.ot);
    // A kill can trigger RoundEnd inside TakeDamage. Flush from the next frame
    // so that the final hit is included in the same immutable score snapshot.
    pendingRound=true;
    if(finished) {
        tactical.reset();gMatchPause.m_Pause=false;
        try { SetPhase("finished"); } catch(...) { Fail("state_io"); }
    }
    const auto result=mq2::wire_text(config.teams[0],40)+" "+number(score[0])+" : "+number(score[1])+" "+mq2::wire_text(config.teams[1],40);
    Announce((finished?"KONIEC | ":"")+result,(finished?"FINAL | ":"")+result);
}
std::string CMatchCSCO::PlayerStats() const {
    std::string players="{"; bool first=true;
    for(const auto& p:config.players) {
        if(!first) players+=",";
        first=false;
        if(!config.test || config.fullTest) {
            players+="\""+p.steam+"\":{";
            const auto& totals=statistics.get(int(&p-config.players.data()));
            for(int n=0;n<mq2::STAT_COUNT;++n) {if(n)players+=",";players+="\""+std::string(mq2::stat_name(n))+"\":"+number(totals[n]);}
            players+="}";continue;
        }
        players+="\""+p.steam+"\":{\"kills\":"+number(p.kills)+",\"deaths\":"+number(p.deaths)+
            ",\"assists\":"+number(p.assists)+",\"damage\":"+number(p.damage)+",\"headshots\":"+number(p.headshots)+",\"rounds\":"+number(p.rounds)+"}";
    }
    return players+"}";
}
void CMatchCSCO::ReportScore(bool finished) {
    statistics.seal();
    const auto players=PlayerStats();
    const std::string type=finished?"finished":"round";
    Emit(type,"{\"team1_score\":"+number(score[0])+",\"team2_score\":"+number(score[1])+
        ",\"stats_version\":"+number((!config.test||config.fullTest)?2:1)+",\"players\":"+players+"}",type+"-"+number(score[0])+"-"+number(score[1]));
}
void CMatchCSCO::Damage(CBasePlayer* victim,entvars_t* attacker,float actual,bool utility) {
    if(!Active() || (!roundOpen && !pendingRound) || !live || !attacker || actual<=0) return;
    int a=Slot(ENT(attacker)),v=Slot(victim->edict());
    if(!config.test && a>=0 && v>=0 && a!=v && config.players[a].team==config.players[v].team) {
        const int before=teamDamage[a];teamDamage[a]+=int(std::ceil(std::min(actual,10000.0f)));
        if(before<100 && teamDamage[a]>=100) Feedback(a+1,config.players[a].locale=="pl"?"Uwaga: ranisz wlasna druzyne.":"Warning: you are damaging teammates.");
        if(teamDamage[a]>=300) ActivityAlert(a,"team_damage",teamDamage[a],2);
    }
    statistics.damage(a,v,actual,utility);
    const bool testOpponent=TestOpponent(victim);
    if(a>=0 && ((v>=0 && config.players[a].team!=config.players[v].team) || testOpponent))
        config.players[a].damage+=int(std::ceil(std::min(actual,10000.0f)));
}
void CMatchCSCO::Death(CBaseEntity* killer,CBasePlayer* victim,CBasePlayer* assister,int rarity) {
    if(!Scoring()) return;
    const int v=Slot(victim->edict()),k=killer?Slot(killer->edict()):-1;
    statistics.death(k,v,assister?Slot(assister->edict()):-1,(rarity&1)!=0,gpGlobals->time);
    if(v>=0) {
        if(config.players[v].deathCounted) return;
        config.players[v].deathCounted=true; ++config.players[v].deaths;
    }
    if(!config.test && k>=0 && v>=0 && k!=v && config.players[k].team==config.players[v].team) {
        ++teamKills[k]; if(teamKills[k]>=3) ActivityAlert(k,"team_kills",teamKills[k],4);
    }
    if(k>=0) activitySeen[k]=true;
    const bool testOpponent=TestOpponent(victim);
    if(k>=0 && ((v>=0 && config.players[k].team!=config.players[v].team) || testOpponent)) {
        ++config.players[k].kills; if(rarity&1) ++config.players[k].headshots;
        const int a=assister?Slot(assister->edict()):-1;
        if(a>=0 && a!=k && a!=v && config.players[a].team==config.players[k].team) ++config.players[a].assists;
    }
}
void CMatchCSCO::Objective(GameEventType event,CBaseEntity* player) {
    if(!Active() || (!roundOpen&&!pendingRound) || !live || !player) return;
    if(event==EVENT_BOMB_PLANTED || event==EVENT_BOMB_DEFUSED)
        statistics.objective(Slot(player->edict()),event==EVENT_BOMB_PLANTED);
}
bool CMatchCSCO::ClientCommand(CBasePlayer* p,const char* cmd,const char* arg) {
    if(!cmd) return false;
    if(voteMenu[p->entindex()] && !strcmp(cmd,"menuselect")) {
        if(arg && (!strcmp(arg,"1") || !strcmp(arg,"2"))) SurrenderVote(p,!strcmp(arg,"1"));
        else voteMenu[p->entindex()]=false;
        return true;
    }
    if(!strcmp(cmd,"buy") || !strcmp(cmd,"buyequip")) voteMenu[p->entindex()]=false;
    if(Active() && Slot(p->edict())>=0 &&
       (!strcmp(cmd,"chooseteam") || !strcmp(cmd,"jointeam") || !strcmp(cmd,"joinclass"))) {
        CloseTeamMenu(p); return true; // Frame owns assignment; never rejoin/respawn a live player.
    }
    std::string text=cmd;
    if(text=="say" || text=="say_team") text=arg?arg:"";
    if(text.size()>1 && text.front()=='"' && text.back()=='"') text=text.substr(1,text.size()-2);
    if(text.empty() || (text[0]!='/' && text[0]!='.' && text[0]!='!')) return false;
    const int slot=Slot(p->edict()); if(slot<0) return true;
    text=text.substr(1);
    if(!Active()) {
        if(text=="timeout" || text=="pause" || text=="unpause")
            Feedback(slot+1,config.players[slot].locale=="pl"?"Pauza jest zablokowana przez recovery.":"Pause controls are locked by recovery.");
        return true;
    }
    if(text=="surrender" || text=="ff") StartSurrender(p);
    else if(text=="yes") SurrenderVote(p,true);
    else if(text=="no") SurrenderVote(p,false);
    else if(text=="ready" || text=="r") gMatchReady.Ready(p);
    else if(text=="unready" || text=="notready") gMatchReady.NotReady(p);
    else if(text=="endtest") {
        if(config.fullTest && config.players[slot].steam==config.owner) EndTest("test_admin");
    }
    else if(text=="score" || text=="scores" || text=="status" || text=="stats") {
        gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"%s | %s %d : %d %s",phase.c_str(),config.teams[0].c_str(),score[0],score[1],config.teams[1].c_str());
        for(const auto& row:config.players)
            gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"T%d | %s | K/D/A %d/%d/%d",row.team,row.name.c_str(),row.kills,row.deaths,row.assists);
    }
    // Even dead teammates must not relay current-round damage/HP.
    else if(text=="dmg" || text=="rdmg" || text=="sum") gMatchRound.ShowDamage(p,true,false);
    else if(text=="hp" && CSGameRules()->m_bRoundTerminating) gMatchRound.ShowHP(p,true,false);
    else if(text=="timeout" || text=="pause" || text=="votepause") RequestTimeout(p);
    else if(text=="unpause") RequestUnpause(p);
    else if(text=="help")
        gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"/ready /score /dmg /hp /timeout /unpause /ff /yes /no");
    return true; // Match/map/team/admin control belongs to the signed assignment.
}
bool CMatchCSCO::NeedsBots(const mq2::Config& assignment) const {
    if(!assignment.test)return false;
    if(!assignment.fullTest)return true;
    for(const auto& row:assignment.players)if(row.bot)return true;
    return false;
}
bool CMatchCSCO::TestOpponent(CBasePlayer* p) const {
    return config.test && !config.fullTest && p && bot>0 && p->entindex()==bot && p->IsBot() &&
        botUserIds[bot]==g_engfuncs.pfnGetPlayerUserId(p->edict());
}
std::string CMatchCSCO::BotIssue(const mq2::Config& assignment) const {
    if(!NeedsBots(assignment))return "";
    if(!value("bot_enable",1))return "test_ai_disabled";
    for(const auto& setting:botSettings)
        if(!g_engfuncs.pfnCVarGetPointer(setting.first))return "test_ai_disabled";
    char directory[260]={};g_engfuncs.pfnGetGameDir(directory);
    const std::string game=directory;
    auto profile=g_engfuncs.pfnCVarGetPointer("bot_profile_db");
    if(!profile || !profile->string || !exists(game+"/"+profile->string) || !exists(game+"/BotChatter.db"))
        return "test_bot_profiles_missing";
    std::ifstream nav(game+"/maps/"+assignment.map+".nav",std::ios::binary);
    if(!nav)return "test_bot_nav_missing";
    std::ifstream bsp(game+"/maps/"+assignment.map+".bsp",std::ios::binary|std::ios::ate);
    if(!bsp || bsp.tellg()<=0 || uint64_t(bsp.tellg())>UINT32_MAX || !mq2::bot_nav_header(nav,uint32_t(bsp.tellg())))
        return "test_bot_nav_invalid";
    return "";
}
void CMatchCSCO::ConfigureBots() {
    if(!NeedsBots(config))return;
    // Persist before mutating so a process crash can restore the previous
    // settings without accepting a stale signed assignment.
    RestoreBots(true);
    std::ostringstream saved;
    for(const auto& setting:botSettings) {
        const auto cv=g_engfuncs.pfnCVarGetPointer(setting.first);
        if(!cv || !cv->string)throw std::runtime_error("bot_cvar_missing");
        const std::string text=cv->string;std::string encoded;
        for(unsigned char c:text) {encoded+="0123456789abcdef"[c>>4];encoded+="0123456789abcdef"[c&15];}
        saved<<setting.first<<" "<<(encoded.empty()?"-":encoded)<<"\n";
    }
    write(root+"/original-bots.txt",saved.str());
    for(const auto& setting:botSettings)cvar(setting.first,setting.second);
    botSettingsActive=true;
}
void CMatchCSCO::RestoreBots(bool remove) {
    botSettingsActive=false;
    cvar("bot_quota","0"); // No independent quota may refill an idle/ranked server.
    if(root.empty() || !exists(root+"/original-bots.txt"))return;
    std::ifstream input(root+"/original-bots.txt");std::vector<std::pair<std::string,std::string>> saved;
    for(const auto& setting:botSettings) {
        std::string name,encoded,text;
        if(!(input>>name>>encoded) || name!=setting.first || encoded.size()>256 ||
           (encoded!="-" && (encoded.size()%2 || !mq2::hex(encoded,encoded.size()))))
            throw std::runtime_error("bot_restore_io");
        if(encoded!="-")for(size_t i=0;i<encoded.size();i+=2)text+=char(std::stoi(encoded.substr(i,2),nullptr,16));
        if(text.find_first_of("\r\n")!=std::string::npos || text.find('\0')!=std::string::npos)throw std::runtime_error("bot_restore_io");
        saved.emplace_back(name,text);
    }
    std::string extra;if(input>>extra)throw std::runtime_error("bot_restore_io");
    for(const auto& setting:saved)
        if(setting.first!="bot_quota")cvar(setting.first.c_str(),setting.second.c_str());
    if(remove)remove_file(root+"/original-bots.txt");
}
int CMatchCSCO::BotCount() const {
    int count=0;
    if(botSettingsActive && Active() && config.test && !clearing) {
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);
            if(p && !p->IsDormant() && p->IsBot() && botUserIds[i]==g_engfuncs.pfnGetPlayerUserId(p->edict()) &&
               (config.fullTest?botSlots[i]>0:i==bot))++count;
        }
    }
    return count;
}
void CMatchCSCO::BotQuota() {
    const int count=BotCount();
    if(botSettingsActive && Active() && config.test)cvar("bot_stop",phase=="finished"?"1":"0");
    if(!value("bot_quota",float(count)))cvar("bot_quota",number(count).c_str());
}
bool CMatchCSCO::CreateBot(int slot) {
    if(!Active() || !config.test || creatingBot || !botSettingsActive)return false;
    const int team=slot<0?2:config.players[slot].team;
    creatingBot=true;creatingBotSlot=slot;creatingBotClient=0;
    // Fixed native commands invoke ReGameDLL's real CCSBot factory. Roster
    // names never enter a command; TeamSlot binds the connection while the
    // synchronous factory is inside its team-selection hook.
    g_engfuncs.pfnServerCommand(const_cast<char*>(Side(team)==CT?"bot_add_ct\n":"bot_add_t\n"));
    g_engfuncs.pfnServerExecute();
    const int client=creatingBotClient;
    creatingBot=false;creatingBotSlot=-1;creatingBotClient=0;
    auto p=client>0?UTIL_PlayerByIndexSafe(client):nullptr;
    // Native HandleMenu_ChooseAppearance leaves GETINTOGAME; its next AI tick
    // performs the actual spawn. Do not replace that native lifecycle or fake
    // a client movement tick. Both states prove a completed native factory.
    if(!p || p->IsDormant() || !p->IsBot() || p->m_iTeam!=Side(team) ||
       (p->m_iJoiningState!=JOINED && p->m_iJoiningState!=GETINTOGAME) ||
       botUserIds[client]!=g_engfuncs.pfnGetPlayerUserId(p->edict())) {
        BotQuota();return false;
    }
    const auto name=mq2::clip(slot<0?"CSCO Test Opponent":config.players[slot].name,31);
    g_engfuncs.pfnSetClientKeyValue(client,g_engfuncs.pfnGetInfoKeyBuffer(p->edict()),const_cast<char*>("name"),const_cast<char*>(name.c_str()));
    if(slot>=0) {
        config.players[slot].client=client;
        if(!bootstrappingBots)Emit("connected","{\"steam_id\":\""+config.players[slot].steam+"\",\"connected\":true}");
    }
    BotQuota();return true;
}
void CMatchCSCO::EnsureBot() {
    if(!Active() || !NeedsBots(config))return;
    if(config.fullTest) {
        for(size_t slot=0;slot<config.players.size();++slot) {
            const auto& row=config.players[slot];if(!row.bot || row.client)continue;
            if(!CreateBot(int(slot))) {Fail("test_bot_unavailable");return;}
        }
    } else if(!bot && !CreateBot(-1))Fail("test_bot_unavailable");
}
void CMatchCSCO::Frame() {
    BotQuota();
    gMatchRound.FeedbackFrame();
    if(pendingRound) { pendingRound=false; ReportScore(mq2::won(score[0],score[1],config.mr,config.ot)); }
    if(gpGlobals->time<nextFrame) return;
    nextFrame=gpGlobals->time+0.25f;
    if(Active() && !live && phase=="starting" && !AllPresent()) {
        gMatchTask.ServerDeactivate(); gMatchLO3.Stop();
        cvar("sv_restart","0"); cvar("sv_restartround","0");
        gMatchBot.SetState(STATE_WARMUP);
    }
    if(!root.empty() && config.test && phase=="warmup") EnsureBot();
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto p=UTIL_PlayerByIndexSafe(i); if(!p || p->IsDormant()) continue;
        if(TestOpponent(p))continue;
        const int slot=Slot(p->edict());
        if(!Active() || slot<0) {
            const auto auth=g_engfuncs.pfnGetPlayerAuthId(p->edict());
            if(Active() && auth && !strcmp(auth,"STEAM_ID_PENDING") &&
               authDeadline[i]>gpGlobals->time) continue;
            Kick(p->edict(),quarantine?"server_error":config.id.empty()?"no_match":auth && !strcmp(auth,"STEAM_ID_PENDING")?"steam_timeout":"not_roster"); continue;
        }
        const auto assigned=Side(config.players[slot].team);
        if(p->m_iTeam==UNASSIGNED || p->m_iTeam==SPECTATOR) {
            p->CSPlayer()->JoinTeam(assigned);
            p->m_iModelName=assigned==CT?MODEL_URBAN:MODEL_TERROR;
            p->CSPlayer()->SetPlayerModel(false);
        } else if(p->m_iTeam!=assigned && phase!="halftime") { Kick(p->edict()); continue; }
#ifdef MQ2_QA
        // QA human stand-ins still need their engine movement tick. Native
        // CCSBots own their movement and must never receive this zero input.
        if(!p->IsBot() && (p->pev->flags&FL_FAKECLIENT))
            g_engfuncs.pfnRunPlayerMove(p->edict(),p->pev->v_angle,0,0,0,0,0,50);
#endif
        if(p->m_iJoiningState==JOINED) { CloseTeamMenu(p); Joined(p); }
    }
    SafetyFrame();
    ActivityFrame();
    DisconnectFrame();
    gMatchPause.TryPending();
    SyncPause();
}
bool CMatchCSCO::ScoreInfo(int destination,int type,const float* origin,edict_t* entity) {
    if(gMatchCSCO.live) {
        const int index=gMatchMessage.GetByte(0);
        const auto p=UTIL_PlayerByIndexSafe(index);
        const int slot=p?gMatchCSCO.Slot(p->edict()):-1;
        if(slot>=0) {
            gMatchMessage.SetArgInt(1,gMatchCSCO.config.players[slot].kills);
            gMatchMessage.SetArgInt(2,gMatchCSCO.config.players[slot].deaths);
        }
    }
    return false;
}
void CMatchCSCO::Profile(int state) {
    for(const auto& rule:mq2::tournament_rules(state==STATE_WARMUP,state==STATE_OVERTIME,false,mq2::TACTICAL_SECONDS,config.test))
        cvar(rule.name,std::to_string(!strcmp(rule.name,"bot_quota")?float(BotCount()):rule.expected).c_str());
    rulesMismatchSince=0; nextRulesCheck=gpGlobals->time+1;
}
std::string CMatchCSCO::RulesIssue() const {
    if(!rulesFault.empty()) return rulesFault;
    if(phase=="finished") return "";
    if(botSettingsActive && Active() && config.test) {
        for(const auto& setting:botSettings) {
            if(!strcmp(setting.first,"bot_quota"))continue;
            const auto actual=g_engfuncs.pfnCVarGetPointer(setting.first);
            const bool stringValue=!strcmp(setting.first,"bot_quota_mode") || !strcmp(setting.first,"bot_chatter") || !strcmp(setting.first,"bot_prefix");
            if(!actual || (stringValue?strcmp(actual->string,setting.second)!=0:!value(setting.first,std::atof(setting.second))))
                return std::string("rules_drift:")+setting.first;
        }
    }
    for(const auto& rule:mq2::tournament_rules(phase=="warmup",gMatchBot.GetState()==STATE_OVERTIME,
                                            gMatchPause.m_Paused,disconnectPause?mq2::RECONNECT_SECONDS:mq2::TACTICAL_SECONDS,config.test)) {
        if(rule.optional && !g_engfuncs.pfnCVarGetPointer(rule.name)) continue;
        if(!value(rule.name,!strcmp(rule.name,"bot_quota")?float(BotCount()):rule.expected)) return rule.name;
    }
    return "";
}
bool CMatchCSCO::RulesReady() const { return !quarantine && RulesIssue().empty(); }
void CMatchCSCO::SafetyFrame() {
    if(!Active() || phase=="finished") return;
    if(gpGlobals->time>=nextRulesCheck) {
        nextRulesCheck=gpGlobals->time+1;
        const auto issue=RulesIssue();
        if(issue.empty()) rulesMismatchSince=0;
        else if(!rulesMismatchSince) rulesMismatchSince=gpGlobals->time;
        else if(gpGlobals->time-rulesMismatchSince>=5) {
            rulesFault=issue; Print("[CSCO] rules_mismatch: "+issue); Fail("rules_drift"); return;
        }
    }
    if(live || phase!="warmup" || !gMatchReady.Running() || readyExpired || (config.test && !config.fullTest)) return;
    bool all=true;int readyCount=0;
    std::string missing="[";
    for(size_t i=0;i<config.players.size();++i) {
        const auto& row=config.players[i];
        const auto player=UTIL_PlayerByIndexSafe(row.client);
        const bool ready=player && RosterIndex(player)==int(i)+1 && (row.bot || gMatchReady.GetReady(row.client));
        if(ready) ++readyCount;
        if(!ready) { all=false; if(missing.size()>1)missing+=","; missing+="\""+row.steam+"\""; }
        if(reportedReady[i]!=int(ready)) {
            reportedReady[i]=int(ready);
            Emit("player_ready","{\"steam_id\":\""+row.steam+"\",\"ready\":"+boolean(ready)+"}");
        }
    }
    if(all || !RulesReady()) return;
    const int left=std::max(0,int(std::ceil(readyDeadline-gpGlobals->time)));
    for(size_t i=0;i<config.players.size();++i) {
        const auto& row=config.players[i];auto p=UTIL_PlayerByIndexSafe(row.client);
        if(!p || RosterIndex(p)!=int(i)+1) continue;
        const auto text=std::string(row.locale=="pl"?"GOTOWOSC /ready":"READY /ready")+"\n"+number(left/60)+":"+(left%60<10?"0":"")+number(left%60)+"  |  "+number(readyCount)+"/"+number(config.players.size());
        gMatchUtil.HudMessage(p->edict(),gMatchUtil.HudParam(220,220,220,-1.0,0.12,0,0.53,0.53,0,0,2),"%s",text.c_str());
    }
    const int warning=left<=30?2:left<=60?1:0;
    if(warning>readyWarning && left>0) {
        readyWarning=warning;
        Announce("Pozostalo "+number(left)+" s na /ready. Potem mecz zostanie anulowany.",
                 number(left)+" s left to /ready. The match will then be cancelled.");
    }
    if(left<=0) {
        readyExpired=true; gMatchReady.Stop(false);
        Emit("not_ready","{\"missing\":"+missing+"],\"occurred_at\":"+std::to_string(std::time(nullptr))+"}","not-ready");
        Announce("Uplynal czas na /ready. Mecz zostanie anulowany.","Ready deadline expired. The match will be cancelled.");
    }
}
void CMatchCSCO::StatusCommand() {
    const auto& s=gMatchCSCO; bool empty=true;
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto p=UTIL_PlayerByIndexSafe(i); if(p && !p->IsDormant()) empty=false;
    }
    const std::string assignment=s.config.id.empty()?"":s.config.id+":"+number(s.config.generation);
    Print("{\"bridge\":1,\"full_test\":true,\"assignment_contract\":3,\"stats_version\":2,\"side_choice\":1,\"solo_test\":true,\"matchid\":\""+assignment+"\",\"idle\":"+
        boolean(empty && assignment.empty() && !s.quarantine)+",\"healthy\":"+boolean(!s.quarantine && s.RulesReady())+
        ",\"controller_version\":\""+VERSION+"\",\"controller\":\"matchbot\",\"phase\":\""+s.phase+
        "\",\"profile\":\"cs16-classic-v2\",\"ruleset\":2,\"reconnect_budget\":1,\"pause_policy\":2,\"tactical_limit\":3,\"tactical_seconds\":30,\"ready_seconds\":300,\"player_ready\":true,\"rules_ready\":"+boolean(s.RulesReady())+
        ",\"rules_issue\":\""+s.RulesIssue()+"\""+
        ",\"restarts_completed\":"+number(gMatchLO3.Completed())+",\"reconnect_resumes\":"+number(s.reconnectResumes)+",\"score\":["+number(s.score[0])+","+number(s.score[1])+"]}");
}
#ifdef MQ2_QA
// Deliberately compiled out of release. Uses actual GameDLL clients, damage,
// death and win checks; does not inject synthetic finished/round events.
template<typename... Args> class QAMenuChain : public IHookChain<void,Args...> {
public:
    int calls=0;
    void callNext(Args... args) override { ++calls; }
    void callOriginal(Args... args) override { ++calls; }
};
void CMatchCSCO::QACommand() {
    auto& s=gMatchCSCO;
    const std::string op=g_engfuncs.pfnCmd_Argv(1);
    const int arg=atoi(g_engfuncs.pfnCmd_Argv(2));
    if(op=="add" && s.Active() && arg>=0 && arg<int(s.config.players.size()) && !s.config.players[arg].client) {
        s.creatingBot=true;
        const auto name="QA roster "+number(arg);
        auto entity=g_engfuncs.pfnCreateFakeClient(name.c_str());
        if(FNullEnt(entity)) {s.creatingBot=false;Print("qa_full");return;}
        int i=ENTINDEX(entity);s.qaSlots[i]=arg+1;
        char reject[128]={}; MDLL_ClientConnect(entity,name.c_str(),"127.0.0.1",reject);
        MDLL_ClientPutInServer(entity); entity->v.flags|=FL_FAKECLIENT;
        auto p=UTIL_PlayerByIndexSafe(i);
        const auto side=s.Side(s.config.players[arg].team);
        p->CSPlayer()->JoinTeam(side);
        p->m_iModelName=side==CT?MODEL_URBAN:MODEL_TERROR;
        p->CSPlayer()->SetPlayerModel(false);
        s.creatingBot=false; Print("qa_added");
    } else if(op=="ready") {
        for(const auto& row:s.config.players) {
            const auto p=UTIL_PlayerByIndexSafe(row.client);
            if(p) s.ClientCommand(p,"say","/ready");
        }
        Print("qa_ready");
    } else if(op=="eliminate" && (arg==1 || arg==2) && s.Scoring()) {
        CBasePlayer* attacker=nullptr;
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);
            if(p && !p->IsDormant() && p->IsAlive() && p->m_iTeam==s.Side(3-arg)) {attacker=p;break;}
        }
        if(!attacker) {Print("qa_no_attacker");return;}
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);
            if(p && !p->IsDormant() && p->IsAlive() && p->m_iTeam==s.Side(arg))
                p->TakeDamage(attacker->pev,attacker->pev,500,DMG_BULLET);
        }
        Print("qa_damage_applied");
    } else if(op=="damage" && s.Scoring() && arg>=0 && arg<int(s.config.players.size())) {
        const int victim=atoi(g_engfuncs.pfnCmd_Argv(3));
        if(victim<0 || victim>=int(s.config.players.size())) { Print("qa_invalid"); return; }
        auto a=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        auto v=UTIL_PlayerByIndexSafe(s.config.players[victim].client);
        const float amount=g_engfuncs.pfnCmd_Argc()>4?atof(g_engfuncs.pfnCmd_Argv(4)):50;
        if(a && v && a->IsAlive() && v->IsAlive()) v->TakeDamage(a->pev,a->pev,amount,DMG_BULLET);
        Print("qa_damage_applied");
    } else if(op=="environment" && s.Scoring() && arg>=0 && arg<int(s.config.players.size())) {
        auto v=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        const std::string kind=g_engfuncs.pfnCmd_Argv(3);
        if(v && v->IsAlive()) {
            if(kind=="world") {auto world=VARS(INDEXENT(0));v->TakeDamage(world,world,20,DMG_FALL);}
            else {
                auto ent=g_engfuncs.pfnCreateNamedEntity(g_engfuncs.pfnAllocString("grenade"));
                MDLL_Spawn(ent);auto grenade=static_cast<CGrenade*>(CBaseEntity::Instance(ent));
                grenade->m_bIsC4=kind=="c4";
                auto owner=UTIL_PlayerByIndexSafe(s.config.players[0].client);
                v->TakeDamage(grenade->pev,owner?owner->pev:nullptr,20,DMG_BLAST);
                g_engfuncs.pfnRemoveEntity(ent);
            }
        }
        Print("qa_environment_applied");
    } else if(op=="plant" && s.Scoring() && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(!p || !p->IsAlive() || p->m_iTeam!=TERRORIST) {Print("qa_invalid");return;}
        CC4* c4=nullptr;
        for(int slot=0;slot<6;++slot) for(auto item=p->m_rgpPlayerItems[slot];item;item=item->m_pNext)
            if(item->m_iId==WEAPON_C4)c4=static_cast<CC4*>(item);
        if(!c4)c4=static_cast<CC4*>(p->CSPlayer()->GiveNamedItemEx("weapon_c4"));
        if(!c4) {Print("qa_no_c4");return;}
        p->pev->flags|=FL_ONGROUND;p->m_signals.m_flState|=SIGNAL_BOMB;
        c4->m_bStartedArming=true;c4->m_fArmedTime=gpGlobals->time-0.1f;
        c4->PrimaryAttack(); // Actual GameDLL completion + real bot-manager event hook.
        Print("qa_planted");
    } else if(op=="defuse" && s.Scoring() && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(!p || !p->IsAlive() || p->m_iTeam!=CT) {Print("qa_invalid");return;}
        edict_t* ent=nullptr;
        while(!FNullEnt(ent=g_engfuncs.pfnFindEntityByString(ent,"classname","grenade"))) {
            auto grenade=static_cast<CGrenade*>(CBaseEntity::Instance(ent));
            if(!grenade || !grenade->m_bIsC4)continue;
            p->pev->flags|=FL_ONGROUND;grenade->Use(p,p,USE_ON,1);
            grenade->m_flDefuseCountDown=gpGlobals->time-0.1f;grenade->m_fNextDefuse=gpGlobals->time+1;
            grenade->Think();Print("qa_defused");return;
        }
        Print("qa_no_bomb");
    } else if(op=="armor" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) {p->pev->armorvalue=100;p->m_iKevlar=ARMOR_VESTHELM;}
        Print("qa_armor");
    } else if(op=="feedback-clear") {
        for(auto& rows:s.qaFeedback) rows.clear();
        Print("qa_feedback_cleared");
    } else if(op=="feedback-all" && arg>=0 && arg<int(s.config.players.size())) {
        std::string out;
        for(const auto& row:s.qaFeedback[arg+1]) {if(out.size()+row.size()+1>1300)break;out+=row+"\n";}
        Print(out.empty()?"qa_empty":out);
    } else if(op=="feedback" && arg>=0 && arg<int(s.config.players.size())) {
        const auto& rows=s.qaFeedback[arg+1];const int line=atoi(g_engfuncs.pfnCmd_Argv(3));
        if(g_engfuncs.pfnCmd_Argc()<4) Print(number(rows.size()));
        else if(line>=0 && line<int(rows.size())) Print(rows[line]);
        else Print("qa_no_line");
    } else if(op=="pause-state") {
        Print("{\"pending\":"+std::string(boolean(gMatchPause.m_Pause))+",\"paused\":"+boolean(gMatchPause.m_Paused)+
            ",\"votes\":"+number(s.tactical.votes)+",\"serial\":"+number(s.tactical.serial)+
            ",\"tactical\":"+boolean(s.tactical.running)+",\"disconnect\":"+boolean(s.disconnectPause)+
            ",\"timeouts\":["+number(s.timeouts[0])+","+number(s.timeouts[1])+
            "],\"buytime\":"+std::to_string(gMatchBot.m_BuyTime->value)+"}");
    } else if(op=="player" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(!p) {Print("{}");return;}
        Print("{\"hp\":"+std::to_string(p->pev->health)+",\"armor\":"+std::to_string(p->pev->armorvalue)+
            ",\"money\":"+number(p->m_iAccount)+",\"weapons\":"+number(p->pev->weapons)+
            ",\"side\":"+number(p->m_iTeam)+",\"xyz\":["+std::to_string(p->pev->origin.x)+","+
            std::to_string(p->pev->origin.y)+","+std::to_string(p->pev->origin.z)+"]}");
    } else if(op=="legacy-pause") {
        auto p=arg>=0 && arg<int(s.config.players.size())?UTIL_PlayerByIndexSafe(s.config.players[arg].client):nullptr;
        Print(gMatchPause.Init(p,CT)?"qa_accepted":"qa_denied");
    } else if(op=="expire-vote" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        CSGameRules()->m_fRoundStartTime=gpGlobals->time-91;
        if(atoi(g_engfuncs.pfnCmd_Argv(3))==1) {if(p)s.RequestUnpause(p);gMatchPause.PauseTimer(mq2::TACTICAL_SECONDS);}
        else {gMatchPause.PauseTimer(mq2::TACTICAL_SECONDS);if(p)s.RequestUnpause(p);}
        Print("qa_expire_vote");
    } else if(op=="fast" && g_pGameRules) {
        // Advance only a scheduled engine transition, never score arithmetic.
        if(CSGameRules()->m_flRestartRoundTime>gpGlobals->time)
            CSGameRules()->m_flRestartRoundTime=gpGlobals->time+0.05f;
        if(gMatchPause.m_Paused) {
            CSGameRules()->m_fRoundStartTime=gpGlobals->time-91;
            gMatchPause.PauseTimer(s.disconnectPause?mq2::RECONNECT_SECONDS:mq2::TACTICAL_SECONDS);
        } else if(CSGameRules()->IsFreezePeriod())
            CSGameRules()->m_fRoundStartTime=gpGlobals->time-CSGameRules()->m_iIntroRoundTime-1;
        Print("qa_clock_advanced");
    } else if(op=="timeout" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) s.ClientCommand(p,"say","/timeout");
        Print("qa_timeout_requested");
    } else if(op=="drop" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) s.Kick(p->edict());
        Print("qa_drop");
    } else if(op=="talk" && arg>=0 && arg<int(s.config.players.size())) {
        const auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) s.ClientCommand(p,"say",("/"+std::string(g_engfuncs.pfnCmd_Argv(3))).c_str());
        Print("qa_talk");
    } else if(op=="activity-fast") {
        s.roundSince=gpGlobals->time-46; Print("qa_activity_clock");
    } else if(op=="ready-fast") {
        s.readyDeadline=gpGlobals->time-1; Print("qa_ready_deadline");
    } else if(op=="safety") {
        Print("{\"reconnect_used\":["+number(s.reconnectBudget.used[0])+","+number(s.reconnectBudget.used[1])+"],\"ready_expired\":"+boolean(s.readyExpired)+"}");
    } else if(op=="grace-fast") {
        for(auto& p:s.config.players) if(p.absence==3) p.absenceDeadline=gpGlobals->time+0.1f;
        Print("qa_grace_advanced");
    } else if(op=="direct-reset") {
        CSGameRules()->m_bCompleteReset=true;
        CSGameRules()->RestartRound();
        Print("qa_direct_reset");
    } else if(op=="menus" && arg>=0 && arg<int(s.config.players.size())) {
        const auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(!p) { Print("qa_no_player"); return; }
        QAMenuChain<CBasePlayer*,int,int,char*> vgui;
        QAMenuChain<CBasePlayer*,int,int,BOOL,char*> text;
        char team[]="#Team_Select",appearance[]="#CT_Select",buy[]="#Buy",admin[]="Admin menu";
        for(const int kind:{VGUI_Menu_Team,VGUI_Menu_Class_T,VGUI_Menu_Class_CT}) {
            p->m_iMenu=Menu_ChooseTeam;
            ReGameDLL_ShowVGUIMenu(&vgui,p,kind,3,team);
        }
        ReGameDLL_ShowMenu(&text,p,3,-1,0,team);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,appearance);
        const int saved=s.qaSlots[p->entindex()]; s.qaSlots[p->entindex()]=0;
        ReGameDLL_ShowVGUIMenu(&vgui,p,VGUI_Menu_Team,3,team);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,team);
        s.qaSlots[p->entindex()]=saved;
        const bool suppressed=vgui.calls==0 && text.calls==0 && p->m_iMenu==Menu_OFF;
        ReGameDLL_ShowVGUIMenu(&vgui,p,VGUI_Menu_Buy,3,buy);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,buy);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,admin);
        const auto side=p->m_iTeam;
        const auto xyz=p->pev->origin;
        bool commands=s.ClientCommand(p,"jointeam","1") && s.ClientCommand(p,"joinclass","1") && s.ClientCommand(p,"chooseteam","");
        Print(suppressed && vgui.calls==1 && text.calls==2 && commands &&
            p->m_iTeam==side && p->pev->origin==xyz ? "qa_menus_pass" : "qa_menus_fail");
    } else if(op=="botstate") {
        const int index=g_engfuncs.pfnCmd_Argc()>2?std::atoi(g_engfuncs.pfnCmd_Argv(2)):0;
        if(index<1 || index>gpGlobals->maxClients) {
            int native=0,owned=0;
            for(int i=1;i<=gpGlobals->maxClients;++i) {
                auto p=UTIL_PlayerByIndexSafe(i);if(!p||p->IsDormant()||!p->IsBot())continue;
                ++native;if(s.botUserIds[i]==g_engfuncs.pfnGetPlayerUserId(p->edict()) && (s.botSlots[i]>0||i==s.bot))++owned;
            }
            Print("{\"native_bots\":"+number(native)+",\"owned_bots\":"+number(owned)+
                ",\"quota\":"+number(int(g_engfuncs.pfnCVarGetFloat("bot_quota")))+",\"preflight\":\""+s.BotIssue(s.config)+"\"}");
        } else {
            auto p=UTIL_PlayerByIndexSafe(index);if(!p||p->IsDormant()){Print("qa_absent");return;}
            const int slot=s.Slot(p->edict());const auto row=slot>=0?&s.config.players[slot]:nullptr;
            const auto weapon=p->m_pActiveItem?static_cast<CBasePlayerWeapon*>(p->m_pActiveItem):nullptr;
            auto name=mq2::wire_text(STRING(p->pev->netname),31);
            for(auto& c:name)if(c=='"'||c=='\\')c='\'';
            Print("{\"id\":"+number(index)+",\"slot\":"+number(slot)+",\"userid\":"+number(g_engfuncs.pfnGetPlayerUserId(p->edict()))+
                ",\"native_bot\":"+boolean(p->IsBot())+",\"owned\":"+boolean(s.botUserIds[index]==g_engfuncs.pfnGetPlayerUserId(p->edict()))+
                ",\"name\":\""+name+"\",\"team\":"+number(p->m_iTeam)+",\"alive\":"+boolean(p->IsAlive())+
                ",\"health\":"+number(int(p->pev->health))+",\"buttons\":"+number(p->pev->button)+",\"weapon_shots\":"+number(weapon?weapon->m_iShotsFired:0)+
                ",\"kills\":"+number(row?row->kills:0)+",\"damage\":"+number(row?row->damage:0)+
                ",\"xyz\":["+number(int(p->pev->origin.x))+","+number(int(p->pev->origin.y))+","+number(int(p->pev->origin.z))+"]}");
        }
    } else if(op=="round-clock") {
        Print("{\"configured_seconds\":"+number(CSGameRules()->m_iRoundTime)+
            ",\"clock_seconds\":"+number(CSGameRules()->m_iRoundTimeSecs)+
            ",\"remaining\":"+std::to_string(CSGameRules()->GetRoundRemainingTime())+
            ",\"freeze\":"+boolean(CSGameRules()->IsFreezePeriod())+
            ",\"round_open\":"+boolean(s.roundOpen)+",\"healthy\":"+boolean(s.RulesReady())+
            ",\"state\":"+number(gMatchBot.GetState())+",\"test\":"+boolean(s.config.test)+"}");
    } else if(op=="snapshot") {
        std::string out="{\"engine_started\":"+std::string(boolean(CSGameRules()->m_bGameStarted))+
            ",\"freeze\":"+boolean(CSGameRules()->IsFreezePeriod())+",\"lo3\":"+boolean(gMatchLO3.Running())+
            ",\"round_open\":"+boolean(s.roundOpen)+",\"paused\":"+boolean(gMatchPause.m_Paused)+",\"ct_score\":"+number(gMatchBot.GetScore(CT))+
            ",\"t_score\":"+number(gMatchBot.GetScore(TERRORIST))+",\"clients\":[";
        bool first=true;
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);if(!p || p->IsDormant())continue;
            if(!first)out+=",";
            first=false;
            out+="{\"id\":"+number(i)+",\"slot\":"+number(s.Slot(p->edict()))+
                ",\"team\":"+number(p->m_iTeam)+",\"joined\":"+number(p->m_iJoiningState)+
                ",\"alive\":"+boolean(p->IsAlive())+",\"money\":"+number(p->m_iAccount)+
                ",\"xyz\":["+number(int(p->pev->origin.x))+","+number(int(p->pev->origin.y))+","+number(int(p->pev->origin.z))+"]}";
        }
        if(s.config.fullTest) { Print(out+"]}"); return; } // Stay within the single RCON datagram budget.
        out+="],\"roster\":[";
        first=true;
        for(const auto& p:s.config.players) {
            if(!first) out+=","; first=false;
            out+="{\"absence\":"+number(p.absence)+",\"restored_money\":"+number(p.restoredMoney)+"}";
        }
        Print(out+"],\"vote_team\":"+number(s.voteTeam)+",\"vote_yes\":"+number(s.voteYes.size())+
            ",\"vote_eligible\":"+number(s.voteEligible.size())+"}");
    } else Print("qa_invalid");
}
#endif

void CMatchCSCO::ReconnectWindow(mq2::Player& p,const char* stage,int seconds) {
    Emit("reconnect_window","{\"steam_id\":\""+p.steam+"\",\"stage\":\""+stage+
        "\",\"seconds\":"+number(seconds)+",\"deadline\":"+std::to_string(std::time(nullptr)+seconds)+"}");
}
bool CMatchCSCO::StartDisconnectPause() {
    if(!Active() || !live || config.test || phase=="finished" || phase=="halftime" ||
       gMatchLO3.Running() || disconnectPause || gMatchPause.m_Paused) return false;
    std::array<bool,2> teams{}; bool waiting=false;
    for(const auto& p:config.players) if(!p.client && p.absence==1) {
        waiting=true; if(reconnectBudget.available(p.team)) teams[p.team-1]=true;
    }
    if(!waiting) return false;
    if(!teams[0] && !teams[1]) {
        for(auto& p:config.players) if(!p.client && p.absence==1) {
            p.absence=3; p.absenceDeadline=gpGlobals->time+180; ReconnectWindow(p,"grace",180);
        }
        Announce("Limit pauz reconnect wykorzystany. 3 minuty na powrot.","Reconnect pause budget exhausted. 3 minutes to return.");
        return false;
    }
    disconnectPause=true; // A queued tactical pause keeps its place and is not charged yet.
    gMatchPause.m_Pause=false; gMatchPause.m_PauseTeam="RECONNECT";
    gMatchPause.Pause(90);
    if(!gMatchPause.m_Paused) { disconnectPause=false; return false; }
    reconnectBudget.consume(teams);
    for(auto& p:config.players) if(!p.client && p.absence==1) {
        p.absence=2; ReconnectWindow(p,"pause",90);
    }
    Announce("Gracz rozlaczony. Pauza reconnect: 90 sekund.","Player disconnected. Reconnect pause: 90 seconds.");
    return true;
}
void CMatchCSCO::DisconnectPauseEnded() {
    if(!disconnectPause) return;
    disconnectPause=false;
    for(auto& p:config.players) if(!p.client && p.absence==2) {
        p.absence=3; p.absenceDeadline=gpGlobals->time+180;
        ReconnectWindow(p,"grace",180);
    }
    Announce("Gra wznowiona. Nieobecni maja 3 minuty na powrot.","Play continues. Missing players have 3 minutes to reconnect.");
}
void CMatchCSCO::DisconnectFrame() {
    if(!Active() || !live || config.test || phase=="finished") return;
    if(CSGameRules()->IsFreezePeriod()) StartDisconnectPause();
    for(auto& p:config.players) if(!p.client && p.absence==3 && gpGlobals->time>=p.absenceDeadline) {
        p.absence=4; p.absenceDeadline=0;
        Emit("abandoned","{\"steam_id\":\""+p.steam+"\",\"cooldown_seconds\":1800}","abandoned-"+p.steam);
        if(voteTeam==p.team) EndSurrender(false); // Never shrink an ongoing vote's denominator.
        const auto team=mq2::wire_text(config.teams[p.team-1],40);
        Announce(team+": gracz porzucil mecz. Blokada kolejki 30 min. /ff - glosowanie.",
                 team+": player abandoned. 30 minute queue cooldown. /ff to vote to surrender.");
    }
    if(voteTeam && gpGlobals->time>=voteDeadline) EndSurrender(false);
}
void CMatchCSCO::StartSurrender(CBasePlayer* player) {
    const int slot=Slot(player->edict());
    if(!Active() || !live || config.test || phase=="finished" || slot<0 || voteTeam) return;
    const int team=config.players[slot].team;
    if(gpGlobals->time<voteCooldown[team-1]) {
        Feedback(slot+1,config.players[slot].locale=="pl"?"Poczekaj przed kolejnym glosowaniem.":"Wait before calling another surrender vote."); return;
    }
    bool missing=false;
    for(const auto& p:config.players) if(p.team==team && p.absence==4 && !p.client) missing=true;
    if(!missing) {
        Feedback(slot+1,config.players[slot].locale=="pl"?"Poddanie jest dostepne po porzuceniu meczu przez gracza druzyny.":"Surrender is available after a teammate abandons."); return;
    }
    voteTeam=team; voteDeadline=gpGlobals->time+30; voteEligible.clear(); voteYes.clear();
    for(size_t i=0;i<config.players.size();++i) {
        const auto& p=config.players[i];
        if(p.team!=team || (p.absence==4 && !p.client)) continue;
        voteEligible.push_back(i);
        const auto client=UTIL_PlayerByIndexSafe(p.client);
        if(!client || client->IsDormant()) continue;
        Feedback(int(i)+1,p.locale=="pl"?"Poddanie: /yes lub /no (30 s). Wymagana wiekszosc.":"Surrender vote: /yes or /no (30 seconds). Majority required.");
        const int msg=gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info,"ShowMenu",nullptr);
        if(msg) {
            client->m_iMenu=Menu_OFF; voteMenu[client->entindex()]=true;
            g_engfuncs.pfnMessageBegin(MSG_ONE,msg,nullptr,client->edict());
            g_engfuncs.pfnWriteShort(3); g_engfuncs.pfnWriteChar(30); g_engfuncs.pfnWriteByte(0);
            g_engfuncs.pfnWriteString(p.locale=="pl"?"\\yCSCO.GG - Poddanie?\\w\n\n1. Tak\n2. Nie":"\\yCSCO.GG - Surrender?\\w\n\n1. Yes\n2. No");
            g_engfuncs.pfnMessageEnd();
        }
    }
    SurrenderVote(player,true); // Calling /ff counts as one affirmative vote.
}
void CMatchCSCO::SurrenderVote(CBasePlayer* p,bool yes) {
    const int slot=Slot(p->edict());
    if(!voteTeam || gpGlobals->time>=voteDeadline || !Active() ||
       std::find(voteEligible.begin(),voteEligible.end(),slot)==voteEligible.end()) return;
    voteMenu[p->entindex()]=false;
    const auto found=std::find(voteYes.begin(),voteYes.end(),slot);
    if(yes && found==voteYes.end()) voteYes.push_back(slot);
    else if(!yes && found!=voteYes.end()) voteYes.erase(found);
    if(voteYes.size()>voteEligible.size()/2) EndSurrender(true);
}
void CMatchCSCO::EndSurrender(bool passed) {
    if(!voteTeam) return;
    const int team=voteTeam; voteTeam=0; voteCooldown[team-1]=gpGlobals->time+120;
    for(int i=1;i<=gpGlobals->maxClients;++i) if(voteMenu[i]) {
        voteMenu[i]=false;
        const auto p=UTIL_PlayerByIndexSafe(i);
        if(p && !p->IsDormant()) {
            const int msg=gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info,"ShowMenu",nullptr);
            if(msg) {
                g_engfuncs.pfnMessageBegin(MSG_ONE,msg,nullptr,p->edict());
                g_engfuncs.pfnWriteShort(0); g_engfuncs.pfnWriteChar(0); g_engfuncs.pfnWriteByte(0);
                g_engfuncs.pfnWriteString(""); g_engfuncs.pfnMessageEnd();
            }
        }
    }
    if(!passed) {
        const auto name=mq2::wire_text(config.teams[team-1],40);
        Announce(name+": poddanie odrzucone. Gramy dalej.",name+": surrender vote failed. Play continues."); return;
    }
    if(pendingRound) { pendingRound=false; ReportScore(false); }
    roundOpen=false;
    try { SetPhase("finished"); } catch(...) { Fail("state_io"); return; }
    gMatchTask.ServerDeactivate(); gMatchPause.ServerActivate(); tactical.reset(); gMatchRound.ResetCSCO(); disconnectPause=false;
    gMatchPause.SetRoundTime(9999,true);
    std::string voters="[";
    for(const int index:voteYes) { if(voters.size()>1) voters+=","; voters+="\""+config.players[index].steam+"\""; }
    Emit("surrendered","{\"loser_team\":"+number(team)+",\"yes_votes\":"+voters+
        "],\"team1_score\":"+number(score[0])+",\"team2_score\":"+number(score[1])+
        ",\"stats_version\":"+number((!config.test||config.fullTest)?2:1)+",\"players\":"+PlayerStats()+"}","surrendered");
    const auto loser=mq2::wire_text(config.teams[team-1],40),winner=mq2::wire_text(config.teams[2-team],40);
    Announce(loser+" poddaje mecz. Wygrywa "+winner+".",loser+" surrendered. "+winner+" wins.");
}

bool CMatchCSCO::AutoReady(CBasePlayer* player) const {
    if(!Active() || player->m_iJoiningState!=JOINED) return false;
    if(TestOpponent(player)) return player->m_iTeam==Side(2);
    const int slot=Slot(player->edict());
    return slot>=0 && config.players[slot].bot && config.players[slot].client==player->entindex() && player->m_iTeam==Side(config.players[slot].team);
}
