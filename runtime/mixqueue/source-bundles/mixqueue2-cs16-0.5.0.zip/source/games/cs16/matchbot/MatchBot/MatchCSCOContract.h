// CSCO integration, GPL-3.0. Pure contract validation shared by runtime and tests.
#pragma once
#include <algorithm>
#include <cstdint>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace mq2 {
inline bool hex(const std::string& s, size_t n) {
    return s.size()==n && s.find_first_not_of("0123456789abcdef")==std::string::npos;
}
inline bool map_name(const std::string& s) {
    return s.size()>3 && s.size()<40 && s.compare(0,3,"de_")==0 &&
        s.find_first_not_of("abcdefghijklmnopqrstuvwxyz0123456789_")==std::string::npos;
}
inline std::string steam64(const std::string& auth) {
    if (auth.size()<11 || (auth.compare(0,8,"STEAM_0:") && auth.compare(0,8,"STEAM_1:")) ||
        (auth[8]!='0' && auth[8]!='1') || auth[9]!=':' ||
        auth.find_first_not_of("0123456789",10)!=std::string::npos) return "";
    if(auth.size()>20) return "";
    uint64_t z=0;
    for(size_t i=10;i<auth.size();++i) { z=z*10+(auth[i]-'0'); if(z>2147483647ULL) return ""; }
    return std::to_string(76561197960265728ULL+z*2+(auth[8]-'0'));
}
struct Player {
    std::string auth, steam, name="Player", locale="en";
    bool bot=false, captain=false, deathCounted=false;
    int team=0, kills=0, deaths=0, assists=0, damage=0, headshots=0, rounds=0, client=0;
    int absence=0; // 0 present, 1 waiting for freeze, 2 pause, 3 grace, 4 abandoned
    float absenceDeadline=0;
    int restoredMoney=-1;
    int reconnectMoney=-1; // Process-local only; never used to resume a crashed assignment.
};
struct Config {
    std::string id, map, hash, owner, teams[2]={"Team 1","Team 2"};
    int generation=0, size=0, mr=0, ot=0;
    bool test=false, fullTest=false;
    std::vector<Player> players;
};
// Reject controls, overlong UTF-8, surrogates and invalid continuation bytes.
inline bool name_valid(const std::string& text,size_t limit=64) {
    if(text.empty() || text.size()>limit) return false;
    for(size_t i=0;i<text.size();) {
        unsigned char a=text[i++];
        if(a<32 || a==127 || a==';' || a=='"' || a=='\\') return false;
        if(a<128) continue;
        int n=a>=0xc2 && a<=0xdf?1:a>=0xe0 && a<=0xef?2:a>=0xf0 && a<=0xf4?3:-1;
        if(n<0 || i+n>text.size()) return false;
        unsigned char b=text[i];
        if((a==0xe0 && b<0xa0)||(a==0xed && b>=0xa0)||(a==0xf0 && b<0x90)||(a==0xf4 && b>=0x90)) return false;
        while(n--) if((static_cast<unsigned char>(text[i++])&0xc0)!=0x80) return false;
    }
    return true;
}
inline std::string unhex(const std::string& value) {
    if(value.empty() || value.size()%2 || !hex(value,value.size())) throw std::runtime_error("invalid_name");
    std::string out;
    for(size_t i=0;i<value.size();i+=2) out+=char(std::stoi(value.substr(i,2),nullptr,16));
    if(!name_valid(out)) throw std::runtime_error("invalid_name");
    return out;
}
inline std::string clip(const std::string& value,size_t bytes) {
    if(value.size()<=bytes) return value;
    size_t end=bytes;
    while(end && (static_cast<unsigned char>(value[end])&0xc0)==0x80) --end;
    return value.substr(0,end);
}
inline Config parse(std::istream& in, const std::string& id, int generation) {
    Config c; std::string line, extra; int test=-1;
    if(!std::getline(in,line) || line.size()>240) throw std::runtime_error("invalid_header");
    const bool v2=line.compare(0,6,"MQ2V2 ")==0;
    std::istringstream header(v2?line.substr(6):line);
    if(!(header>>c.id>>c.generation>>c.map>>c.size>>c.mr>>c.ot>>c.hash>>test) || (header>>extra) ||
       !hex(c.id,24) || c.id!=id || c.generation!=generation || generation<1 ||
       !map_name(c.map) || !hex(c.hash,64) || (c.size!=2 && c.size!=5) ||
       c.mr!=(c.size==2?8:15) || c.ot!=3 || test<0 || test>(v2?2:1))
        throw std::runtime_error("invalid_header");
    c.test=test>0; c.fullTest=test==2; int counts[3]={0,0,0}, captains[3]={0,0,0}, humans=0;
    if(c.fullTest && (c.size!=5 || c.id.compare(0,6,"7e5700"))) throw std::runtime_error("invalid_test");
    if(v2) {
        if(!std::getline(in,line) || line.size()>320) throw std::runtime_error("invalid_labels");
        std::string a,b; std::istringstream labels(line);
        if(!(labels>>c.owner>>a>>b) || (labels>>extra)) throw std::runtime_error("invalid_labels");
        if(c.owner=="-") c.owner.clear();
        c.teams[0]=unhex(a); c.teams[1]=unhex(b);
    }
    while(std::getline(in,line)) {
        if(line.empty()) continue;
        if(line.size()>240 || c.players.size()>=10) throw std::runtime_error("invalid_roster");
        Player p; std::istringstream row(line);
        if(!(row>>p.auth>>p.steam>>p.team) || p.team<1 || p.team>2)
            throw std::runtime_error("invalid_player");
        if(v2) {
            int bot=-1,cap=-1; std::string name;
            if(!(row>>bot>>cap>>p.locale>>name) || (bot!=0 && bot!=1) || (cap!=0 && cap!=1) ||
                (p.locale!="pl" && p.locale!="en")) throw std::runtime_error("invalid_player");
            p.bot=bot==1; p.captain=cap==1; p.name=unhex(name);
            if(p.name.size()>48) throw std::runtime_error("invalid_name");
            captains[p.team]+=cap;
            if(p.captain && c.teams[p.team-1]!=p.name+" team") throw std::runtime_error("captain_name_mismatch");
        }
        if(row>>extra) throw std::runtime_error("invalid_player");
        if(p.bot) {
            if(!c.fullTest || p.auth!="BOT" || p.steam.compare(0,4,"bot:") || !hex(p.steam.substr(4),24)) throw std::runtime_error("invalid_bot");
        } else {
            if(steam64(p.auth).empty() || steam64(p.auth)!=p.steam) throw std::runtime_error("invalid_player");
            ++humans;
        }
        for(const auto& old:c.players) if(old.steam==p.steam) throw std::runtime_error("duplicate_player");
        ++counts[p.team]; c.players.push_back(p);
    }
    if((c.test && !c.fullTest) ? (counts[1]!=1 || counts[2]!=0) : (counts[1]!=c.size || counts[2]!=c.size))
        throw std::runtime_error("unbalanced_roster");
    if(v2 && (!c.test || c.fullTest) && (captains[1]!=1 || captains[2]!=1)) throw std::runtime_error("invalid_captains");
    if(c.fullTest) {
        bool owner=false; for(const auto& p:c.players) if(!p.bot && p.steam==c.owner) owner=true;
        if(!humans || !owner) throw std::runtime_error("invalid_owner");
    }
    return c;
}
inline bool won(int a,int b,int mr,int ot) {
    const int hi=std::max(a,b),lo=std::min(a,b);
    if(lo<mr) return hi==mr+1;
    const int period=(lo-mr)/ot;
    return hi==mr+(period+1)*ot+1 && lo<=mr+(period+1)*ot-1;
}
}
