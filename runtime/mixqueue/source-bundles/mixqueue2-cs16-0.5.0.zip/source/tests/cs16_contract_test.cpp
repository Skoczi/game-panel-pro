#include "../games/cs16/matchbot/MatchBot/MatchCSCOContract.h"
#include <cassert>
#include <iostream>

std::string fixture(int size=5,bool solo=false) {
    std::string s=std::string(24,'a')+" 7 de_dust2 "+std::to_string(size)+" "+
        std::to_string(size==5?15:8)+" 3 "+std::string(64,'b')+(solo?" 1\n":" 0\n");
    for(int i=0;i<(solo?1:2*size);++i) {
        std::string auth="STEAM_0:"+std::to_string(i%2)+":"+std::to_string(19867136+i/2);
        s+=auth+" "+mq2::steam64(auth)+" "+std::to_string(i<size?1:2)+"\n";
    }
    return s;
}
bool valid(const std::string& value) {
    try {std::istringstream in(value); mq2::parse(in,std::string(24,'a'),7);return true;} catch(...) {return false;}
}

std::string hex_name(const std::string& s) {
    const char* h="0123456789abcdef"; std::string out;
    for(unsigned char c:s) {out+=h[c>>4];out+=h[c&15];} return out;
}
std::string full_fixture(bool ranked=false) {
    const std::string id="7e5700"+std::string(18,'a');
    std::string s="MQ2V2 "+id+" 7 de_dust2 5 15 3 "+std::string(64,'b')+(ranked?" 0\n":" 2\n");
    s+="76561198000000000 "+hex_name("Żółć Captain team")+" "+hex_name("Bot 5 team")+"\n";
    s+="STEAM_0:0:19867136 76561198000000000 1 0 1 pl "+hex_name("Żółć Captain")+"\n";
    for(int i=1;i<10;++i) s+="BOT bot:"+std::string(23,'b')+std::to_string(i)+" "+std::to_string(i<5?1:2)+" 1 "+(i==5?"1":"0")+" en "+hex_name("Bot "+std::to_string(i))+"\n";
    return s;
}
bool full_valid(const std::string& s) {
    try {std::istringstream in(s); auto c=mq2::parse(in,"7e5700"+std::string(18,'a'),7); return c.fullTest && c.players.size()==10;} catch(...) {return false;}
}
int main() {
    assert(full_valid(full_fixture())); assert(!full_valid(full_fixture(true)));
    auto full=full_fixture(); full.replace(full.find(" 1 0 1 pl "),10," 1 0 1 de "); assert(!full_valid(full));
    full=full_fixture(); full.replace(full.find(hex_name("Żółć Captain")),hex_name("Żółć Captain").size(),hex_name("Bad;command")); assert(!full_valid(full));
    full=full_fixture(); full.replace(full.find("76561198000000000"),17,"76561198000000001"); assert(!full_valid(full));
    assert(mq2::name_valid("Żółć Captain")); assert(!mq2::name_valid("bad\nname"));
    assert(!mq2::name_valid(std::string("\xc0\x80"))); assert(!mq2::name_valid(std::string("\xed\xa0\x80")));
    assert(!mq2::name_valid(std::string("\xf4\x90\x80\x80"))); assert(!mq2::name_valid("bad\\name"));
    assert(mq2::clip("Żółć",3)=="Ż"); assert(mq2::clip("Żółć",4)=="Żó");

    assert(valid(fixture())); assert(valid(fixture(2))); assert(valid(fixture(5,true)));
    auto s=fixture();s.replace(s.find("de_dust2"),8,"../etc/x");assert(!valid(s));
    s=fixture();s[0]='c';assert(!valid(s));
    s=fixture();s.replace(25,1,"8");assert(!valid(s));
    s=fixture();s=s.substr(0,s.find_last_of('\n',s.size()-2)+1);assert(!valid(s));
    s=fixture(5,true);s.replace(s.find(" 1\n"),3," 0\n");assert(!valid(s));
    s=fixture();const auto pos=s.find('\n')+1,last=s.find('\n',pos)+1;
    s.replace(last,s.find('\n',last)+1-last,s.substr(pos,last-pos));assert(!valid(s));
    assert(mq2::steam64("STEAM_1:0:19867136")=="76561198000000000");
    assert(mq2::steam64("STEAM_0:1:2147483648").empty());
    assert(mq2::steam64("STEAM_ID_PENDING").empty());
    assert(!mq2::won(15,15,15,3));assert(mq2::won(16,14,15,3));
    assert(!mq2::won(18,18,15,3));assert(mq2::won(19,17,15,3));
    assert(mq2::won(22,20,15,3));assert(!mq2::won(19,18,15,3));
    assert(mq2::won(9,7,8,3));
    std::cout<<"PASS contract: immutable identity, v1/v2 roster, test-only bots, owner, UTF-8, Steam IDs, maps, MR/OT\n";
}
