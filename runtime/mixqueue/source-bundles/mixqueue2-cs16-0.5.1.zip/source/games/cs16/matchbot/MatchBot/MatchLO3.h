#pragma once

class CMatchLO3
{
public:
	void Start();
	void RoundRestart();
    int Completed() const { return m_Completed; }
    bool Running() const { return m_Restart > 0; }
    void Stop() { m_Restart = 0; }

private:
	int m_Restart = 0;
    int m_Completed = 0;
};

extern CMatchLO3 gMatchLO3;
