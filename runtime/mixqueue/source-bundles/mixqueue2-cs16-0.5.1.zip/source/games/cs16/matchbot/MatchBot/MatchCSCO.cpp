// MatchBot -> CSCO assignment/journal adapter. GPL-3.0.
#include "precompiled.h"
#include "MatchCSCO.h"
#include <fstream>
#include <iomanip>
#include <cstdio>
#include <cerrno>
#include <cmath>
#include <ctime>
#include <random>
#ifndef _WIN32
#include <fcntl.h>
#else
#include <io.h>
#endif

CMatchCSCO gMatchCSCO;
namespace {
const char* VERSION="0.5.1";
void directories(const std::string& path) {
    for(size_t i=1;i<=path.size();++i) if(i==path.size() || path[i]=='/') {
        const auto part=path.substr(0,i);
#ifdef _WIN32
        const int result=_mkdir(part.c_str());
#else
        const int result=mkdir(part.c_str(),0750);
#endif
        if(result && errno!=EEXIST) throw std::runtime_error("directory_io");
    }
}
bool exists(const std::string& path) { std::ifstream f(path); return bool(f); }
void sync_file(FILE* file) {
    if(fflush(file)) throw std::runtime_error("flush_io");
#ifdef _WIN32
    if(_commit(_fileno(file))) throw std::runtime_error("sync_io");
#else
    if(fsync(fileno(file))) throw std::runtime_error("sync_io");
#endif
}
void sync_directory(const std::string& path) {
#ifndef _WIN32
    int fd=open(path.substr(0,path.find_last_of('/')).c_str(),O_RDONLY|O_DIRECTORY);
    if(fd<0) throw std::runtime_error("directory_io");
    int result=fsync(fd); close(fd);
    if(result) throw std::runtime_error("directory_io");
#endif
}
void write(const std::string& path,const std::string& content,bool append=false) {
    const std::string target=append?path:path+".next";
    FILE* f=fopen(target.c_str(),append?"ab":"wb");
    if(!f) throw std::runtime_error("open_io");
    try {
        if(fwrite(content.data(),1,content.size(),f)!=content.size()) throw std::runtime_error("write_io");
        sync_file(f);
    } catch(...) { fclose(f); throw; }
    if(fclose(f)) throw std::runtime_error("close_io");
    if(!append) {
#ifdef _WIN32
        if(!MoveFileExA(target.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))
            throw std::runtime_error("rename_io");
#else
        if(rename(target.c_str(),path.c_str())) throw std::runtime_error("rename_io");
#endif
        sync_directory(path);
    }
}
void remove_file(const std::string& path) {
    if(std::remove(path.c_str()) && errno!=ENOENT) throw std::runtime_error("remove_io");
    sync_directory(path);
}
void cvar(const char* name,const char* value) {
    auto p=g_engfuncs.pfnCVarGetPointer(name);
    if(p) g_engfuncs.pfnCvar_DirectSet(p,value);
}
bool value(const char* name,float expected) {
    auto p=g_engfuncs.pfnCVarGetPointer(name);
    return p && std::fabs(p->value-expected)<0.001f;
}
std::string number(int n) { return std::to_string(n); }
const char* boolean(bool b) { return b?"true":"false"; }
}

void CMatchCSCO::Print(const std::string& value) { g_engfuncs.pfnServerPrint((value+"\n").c_str()); }
void CMatchCSCO::Fail(const char* code) {
    quarantine=true; roundOpen=false; phase="recovery";
    cvar("mp_round_infinite","1");
    Print(std::string("[CSCO] recovery: ")+code);
    try { RestoreHostname(); } catch(...) { Print("[CSCO] hostname_restore_io"); }
}
void CMatchCSCO::Activate() {
    try {
        if(boot.empty()) {
            std::ostringstream token; std::random_device random;
            token<<std::hex<<std::time(nullptr)<<random()<<random(); boot=token.str();
            static char statusCommand[]="mq2_status",loadCommand[]="mq2_load",clearCommand[]="mq2_clear",endCommand[]="mq2_endtest";
            g_engfuncs.pfnAddServerCommand(statusCommand,StatusCommand);
            g_engfuncs.pfnAddServerCommand(loadCommand,LoadCommand);
            g_engfuncs.pfnAddServerCommand(clearCommand,ClearCommand);
            g_engfuncs.pfnAddServerCommand(endCommand,EndTestCommand);
#ifdef MQ2_QA
            static char qaCommand[]="mq2_qa"; g_engfuncs.pfnAddServerCommand(qaCommand,QACommand);
#endif
        }
        char directory[260]={}; g_engfuncs.pfnGetGameDir(directory);
        root=std::string(directory)+"/addons/amxmodx/configs/mq2";
        lastHostname.clear();
        gMatchMessage.RegisterHook("ServerName",ServerName);
        marker=root+"/active-matchbot.txt"; highPath=root+"/generation-matchbot.txt";
        const auto data=std::string(directory)+"/addons/amxmodx/data/mq2";
        journal=data+"/events.jsonl"; directories(root); directories(data);
        write(journal,"",true);
        config=mq2::Config(); sequence=0; bot=0; live=false; loading=false; clearing=false;
        roundOpen=false; quarantine=false; teamOneCT=true; paused=false; nextFrame=0;
        score[0]=score[1]=0; timeouts[0]=timeouts[1]=0; pendingRound=false; emptySideObserved=false; reconnectResumes=0; disconnectPause=false;
        voteTeam=0; voteEligible.clear(); voteYes.clear();
        voteCooldown[0]=voteCooldown[1]=0; std::fill(voteMenu,voteMenu+33,false); phase="idle"; highWater=0;
        std::fill(authDeadline,authDeadline+33,0); std::fill(botSlots,botSlots+33,0); std::fill(botUserIds,botUserIds+33,0);
        RestoreHostname();
#ifdef MQ2_QA
        std::fill(qaSlots,qaSlots+33,0);
#endif
        std::ifstream high(highPath);
        if(high && (!(high>>highWater) || highWater<1)) throw std::runtime_error("generation_io");
        Profile(STATE_DEAD);
        if(exists(root+"/active.txt")) { Fail("legacy_assignment"); return; }
        if(exists(marker)) {
            std::ifstream file(marker); std::string id,stage,owner,extra; int gen=0;
            if(!(file>>id>>gen>>stage>>owner) || (file>>extra) || !mq2::hex(id,24) || gen<1)
                throw std::runtime_error("invalid_marker");
            std::ifstream input(root+"/"+id+"-"+number(gen)+".txt");
            config=mq2::parse(input,id,gen);
            // Only the map change initiated in THIS process may resume warmup.
            if(stage=="loading" && owner==boot && config.map==STRING(gpGlobals->mapname)) Ready();
            else Fail("interrupted_assignment");
        }
    } catch(...) { Fail("storage_or_config"); }
}
void CMatchCSCO::Deactivate() { roundOpen=false; try { RestoreHostname(); } catch(...) { Fail("hostname_io"); } }
void CMatchCSCO::Persist(const std::string& stage) {
    write(marker,config.id+" "+number(config.generation)+" "+stage+" "+boot+"\n");
}
void CMatchCSCO::SetPhase(const std::string& stage) {
    Persist(stage); phase=stage; UpdateHostname();
}
void CMatchCSCO::Emit(const std::string& type,const std::string& data,const std::string& stable) {
    if(config.id.empty() || quarantine) return;
    const auto id=config.id+":"+number(config.generation)+":"+
        (stable.empty()?boot+":"+number(++sequence):stable);
    try {
        write(journal,"{\"event_id\":\""+id+"\",\"match_id\":\""+config.id+
            "\",\"generation\":"+number(config.generation)+",\"type\":\""+type+"\",\"data\":"+data+"}\n",true);
    } catch(...) { Fail("journal_io"); }
}
void CMatchCSCO::LoadCommand() {
    const std::string id=g_engfuncs.pfnCmd_Argv(1),gen=g_engfuncs.pfnCmd_Argv(2);
    if(g_engfuncs.pfnCmd_Argc()!=3 || !mq2::hex(id,24) || gen.empty() || gen.size()>9 ||
       gen.find_first_not_of("0123456789")!=std::string::npos) { Print("invalid_assignment"); return; }
    try { gMatchCSCO.Load(id,std::stoi(gen)); }
    catch(...) { gMatchCSCO.Fail("load_io"); Print("storage_failure"); }
}
void CMatchCSCO::Load(const std::string& id,int generation) {
    if(generation<1) { Print("invalid_assignment"); return; }
    if(!config.id.empty() || quarantine || clearing) {
        Print(config.id==id && config.generation==generation && !quarantine?"already_loaded":"busy"); return;
    }
    if(generation<=highWater) { Print("stale_generation"); return; }
    mq2::Config next;
    std::ifstream input(root+"/"+id+"-"+number(generation)+".txt");
    if(!input.is_open()) { Print("storage_failure"); return; }
    try {
        next=mq2::parse(input,id,generation);
    } catch(...) { Print(input.bad()?"storage_failure":"malformed_assignment"); return; }
    if(input.bad()) { Print("storage_failure"); return; }
    // The engine is authoritative even if inventory changed after veto.
    if(!g_engfuncs.pfnIsMapValid(const_cast<char*>(next.map.c_str()))) { Print("missing_map"); return; }
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto player=UTIL_PlayerByIndexSafe(i);
        if(player && !player->IsDormant()) { Print("server_not_empty"); return; }
    }
    SaveHostname();
    write(highPath,number(generation)+"\n"); highWater=generation;
    config=next; sequence=0; live=false; roundOpen=false; teamOneCT=true; score[0]=score[1]=0;
    timeouts[0]=timeouts[1]=0; pendingRound=false; emptySideObserved=false; reconnectResumes=0; disconnectPause=false;
        voteTeam=0; voteEligible.clear(); voteYes.clear();
        voteCooldown[0]=voteCooldown[1]=0; std::fill(voteMenu,voteMenu+33,false);
    if(config.map!=STRING(gpGlobals->mapname)) {
        loading=true; SetPhase("loading"); Print("loading_map");
        g_engfuncs.pfnChangeLevel(const_cast<char*>(config.map.c_str()),nullptr);
    } else { Ready(); Print(quarantine?"storage_failure":"loaded"); }
}
void CMatchCSCO::Ready() {
    loading=false; SetPhase("warmup");
    cvar("mb_players_min",number(config.test && !config.fullTest?2:config.players.size()).c_str());
    cvar("mb_players_max",number(config.test && !config.fullTest?2:config.players.size()).c_str());
    cvar("mb_play_rounds",number(config.mr*2).c_str()); cvar("mb_play_rounds_ot","6");
    cvar("mb_play_ot_mode","1"); cvar("mb_ready_type","1"); cvar("mb_ready_auto_continue","1");
    cvar("mb_team_pick_type","2"); cvar("mb_vote_map","0"); cvar("mb_vote_map_auto","0");
    cvar("mb_players_min_diff","0"); cvar("mb_knife_round","0"); cvar("mb_retry_mode","0");
    cvar("mb_pause_auto",config.test?"1":"0"); cvar("mb_pause_time","60"); cvar("mb_scoreboard_team","1");
    cvar("mb_scoreboard_player","0"); // Roster counters survive reconnects; entity-slot counters do not.
    gMatchBot.SetState(STATE_WARMUP);
    Emit("loaded","{\"map\":\""+config.map+"\",\"config_hash\":\""+config.hash+"\"}","loaded");
}
void CMatchCSCO::ClearCommand() {
    const std::string reason=g_engfuncs.pfnCmd_Argc()==1?"server_error":g_engfuncs.pfnCmd_Argv(1);
    if(g_engfuncs.pfnCmd_Argc()>2 || !ValidReason(reason)) { Print("invalid_reason"); return; }
    try { gMatchCSCO.Clear(reason); Print("cleared"); }
    catch(...) { gMatchCSCO.Fail("cleanup_io"); Print("cleanup_failed"); }
}
void CMatchCSCO::Clear(const std::string& reason) {
    clearing=true; roundOpen=false;
    if(pendingRound) { pendingRound=false; ReportScore(mq2::won(score[0],score[1],config.mr,config.ot)); }
    gMatchTask.ServerDeactivate(); gMatchReady.Stop(false); gMatchTimer.Stop(false);
    gMatchLO3.Stop(); gMatchWarmup.Stop(); gMatchPause.ServerActivate();
    cvar("sv_restart","0"); cvar("sv_restartround","0");
    RestoreHostname(true);
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto player=UTIL_PlayerByIndexSafe(i); if(player && !player->IsDormant()) Kick(player->edict(),reason);
    }
    remove_file(marker); remove_file(root+"/active.txt");
    config=mq2::Config(); quarantine=false; loading=false; live=false; bot=0; paused=false;
    score[0]=score[1]=0;
    phase="idle"; gMatchBot.SetState(STATE_DEAD); Profile(STATE_DEAD);
    std::fill(botSlots,botSlots+33,0); std::fill(botUserIds,botUserIds+33,0); clearing=false;
}
bool CMatchCSCO::ValidReason(const std::string& reason) {
    for(const auto code:{"test_admin","test_timeout","match_finished","not_roster","no_match","steam_timeout","server_error"}) if(reason==code) return true;
    return false;
}
const char* CMatchCSCO::Reason(const std::string& reason,const std::string& locale) const {
    // Explicit ASCII Polish fallback for the legacy GoldSrc reject/kick UI.
    const bool pl=locale=="pl";
    if(reason=="test_admin") return pl?"[CSCO.GG] Administrator zakonczyl mecz testowy.":"[CSCO.GG] The administrator ended this test match.";
    if(reason=="test_timeout") return pl?"[CSCO.GG] Uplynal czas meczu testowego.":"[CSCO.GG] This test match has expired.";
    if(reason=="match_finished") return pl?"[CSCO.GG] Mecz zakonczony. Wynik jest na CSCO.gg.":"[CSCO.GG] Match finished. View the result on CSCO.gg.";
    if(reason=="not_roster") return pl?"[CSCO.GG] Nie nalezysz do skladu tego meczu.":"[CSCO.GG] You are not on this match roster.";
    if(reason=="no_match") return pl?"[CSCO.GG] Brak aktywnego meczu. Dolacz przez CSCO.gg.":"[CSCO.GG] No active match. Join through CSCO.gg.";
    if(reason=="steam_timeout") return pl?"[CSCO.GG] Nie potwierdzono Steam. Polacz sie ponownie.":"[CSCO.GG] Steam authentication timed out. Please reconnect.";
    return pl?"[CSCO.GG] Serwer wymaga odzyskania sesji. Sprawdz CSCO.gg.":"[CSCO.GG] Server recovery is required. Check CSCO.gg.";
}
void CMatchCSCO::Kick(edict_t* entity,const std::string& reason) {
    const int slot=Slot(entity);
    const auto code=ValidReason(reason)?reason:std::string("server_error");
    const auto locale=slot>=0?config.players[slot].locale:std::string("en");
    Print("[CSCO] reject="+code+" userid="+number(g_engfuncs.pfnGetPlayerUserId(entity)));
    gMatchUtil.ServerCommand("kick #%d \"%s\"",g_engfuncs.pfnGetPlayerUserId(entity),Reason(code,locale));
}
void CMatchCSCO::SaveHostname() {
    const auto path=root+"/original-hostname.txt";
    if(!exists(path)) {
        const std::string original=g_engfuncs.pfnCVarGetString("hostname");
        if(original.size()>255) throw std::runtime_error("hostname_io");
        write(path,original);
    }
}
void CMatchCSCO::RestoreHostname(bool remove) {
    if(root.empty()) return;
    const auto path=root+"/original-hostname.txt";
    if(!exists(path)) return;
    std::ifstream file(path,std::ios::binary);
    std::string original((std::istreambuf_iterator<char>(file)),std::istreambuf_iterator<char>());
    if(original.size()>255 || original.find('\0')!=std::string::npos) throw std::runtime_error("hostname_io");
    cvar("hostname",original.c_str());
    hostnameRestored=true;
    lastHostname=original;
    SendHeader();
    if(remove) remove_file(path);
}
void CMatchCSCO::UpdateHostname() {
    if(config.id.empty() || quarantine) return;
    const auto stage=phase=="finished"?"FINISHED":paused?"PAUSED":live?"LIVE":"WARMUP";
    // 127-byte engine/browser budget; truncate each UTF-8 name independently.
    const std::string name=std::string("[")+stage+"] "+mq2::clip(config.teams[0],48)+" vs "+mq2::clip(config.teams[1],48)+" @CSCO.gg";
    cvar("hostname",name.c_str());
    hostnameRestored=false;
    if(lastHostname!=name) { lastHostname=name; SendHeader(); }
}
std::string CMatchCSCO::Header() const {
    // Cleanup/recovery must show the saved original, never an old match label.
    if(hostnameRestored || config.id.empty() || quarantine || clearing)
        return mq2::clip(g_engfuncs.pfnCVarGetString("hostname"),31);
    const auto stage=phase=="finished"?"FINISHED":paused?"PAUSED":live?"LIVE":"WARMUP";
    return mq2::server_title(stage,config.teams[0],config.teams[1]);
}
void CMatchCSCO::SendHeader(edict_t* client) {
    const int message=gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info,"ServerName",nullptr);
    if(!message) return;
    const auto title=Header();
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto player=UTIL_PlayerByIndexSafe(i);
        if(!player || player->IsDormant() || (player->pev->flags&(FL_FAKECLIENT|FL_PROXY)) ||
           player->m_iJoiningState!=JOINED || (client && player->edict()!=client)) continue;
        g_engfuncs.pfnMessageBegin(MSG_ONE,message,nullptr,player->edict());
        g_engfuncs.pfnWriteString(title.c_str());
        g_engfuncs.pfnMessageEnd();
    }
}
bool CMatchCSCO::ServerName(int destination,int type,const float* origin,edict_t* entity) {
    // Also bound the GameDLL's sign-on / HUD refresh message; it otherwise sends
    // the long browser hostname and may overwrite a just-sent compact title.
    const auto title=gMatchCSCO.Header();
    gMatchMessage.SetArgString(0,title.c_str());
    return false;
}
void CMatchCSCO::EndTestCommand() {
    const std::string reason=g_engfuncs.pfnCmd_Argv(1);
    if(g_engfuncs.pfnCmd_Argc()!=2 || (reason!="test_admin" && reason!="test_timeout" && reason!="server_error")) { Print("invalid_reason"); return; }
    gMatchCSCO.EndTest(reason);
}
void CMatchCSCO::EndTest(const std::string& reason) {
    if(!Active() || !config.fullTest || phase=="finished") { Print("test_not_active"); return; }
    if(pendingRound) { pendingRound=false; ReportScore(false); }
    roundOpen=false;
    try { SetPhase("finished"); } catch(...) { Fail("state_io"); return; }
    gMatchTask.ServerDeactivate(); gMatchLO3.Stop(); gMatchReady.Stop(false);
    gMatchTimer.Stop(false); gMatchWarmup.Stop(); gMatchPause.ServerActivate();
    cvar("sv_restart","0"); cvar("sv_restartround","0"); cvar("mp_round_infinite","1");
    Emit("test_ended","{\"team1_score\":"+number(score[0])+",\"team2_score\":"+number(score[1])+
        ",\"players\":"+PlayerStats()+",\"reason\":\""+reason+"\",\"actor\":\""+config.owner+"\"}","test-ended");
    Print("test_ended");
}
int CMatchCSCO::Slot(edict_t* entity) const {
    if(FNullEnt(entity)) return -1;
    if(ENTINDEX(entity)<1 || ENTINDEX(entity)>gpGlobals->maxClients) return -1;
    if(config.fullTest && botSlots[ENTINDEX(entity)]>0 && botUserIds[ENTINDEX(entity)]==g_engfuncs.pfnGetPlayerUserId(entity)) return botSlots[ENTINDEX(entity)]-1;
    const auto auth=g_engfuncs.pfnGetPlayerAuthId(entity);
    const auto steam=mq2::steam64(auth?auth:"");
    for(size_t i=0;i<config.players.size();++i) {
#ifdef MQ2_QA
        if(qaSlots[ENTINDEX(entity)]==int(i)+1) return i;
#endif
        if(!steam.empty() && config.players[i].steam==steam) return i;
    }
    return -1;
}
TeamName CMatchCSCO::Side(int team) const { return ((team==1)==teamOneCT)?CT:TERRORIST; }
bool CMatchCSCO::Connect(edict_t* entity,char* reject) {
    authDeadline[ENTINDEX(entity)]=gpGlobals->time+30;
    if(creatingBot) return true;
    const auto auth=g_engfuncs.pfnGetPlayerAuthId(entity);
    const bool pending=auth && !strcmp(auth,"STEAM_ID_PENDING");
    const int slot=Slot(entity);
    if(Active() && !(entity->v.flags&(FL_FAKECLIENT|FL_PROXY)) &&
       (pending || slot>=0)) return true;
    const std::string reason=quarantine?"server_error":config.id.empty()?"no_match":"not_roster";
    Print("[CSCO] reject="+reason);
    std::snprintf(reject,128,"%s",Reason(reason,slot>=0?config.players[slot].locale:"en")); return false;
}
void CMatchCSCO::Disconnect(edict_t* entity) {
    if(FNullEnt(entity)) return;
    const int client=ENTINDEX(entity);
    const int leaving=Slot(entity);
    voteYes.erase(std::remove(voteYes.begin(),voteYes.end(),leaving),voteYes.end());
    authDeadline[client]=0; voteMenu[client]=false; botSlots[client]=0; botUserIds[client]=0;
#ifdef MQ2_QA
    qaSlots[client]=0;
#endif
    if(client==bot) bot=0;
    for(auto& p:config.players) if(p.client==client) {
        const auto player=UTIL_PlayerByIndexSafe(client);
        if(live && player) p.reconnectMoney=player->m_iAccount;
        p.client=0;
        if(Active() && live && !clearing && phase!="finished" && !config.test && p.absence!=4) {
            p.absence=disconnectPause?2:1;
            p.absenceDeadline=0;
        }
        Emit("connected","{\"steam_id\":\""+p.steam+"\",\"connected\":false}");
    }
}
int CMatchCSCO::TeamSlot(CBasePlayer* p) {
    if(!Active()) return 0;
    int slot=Slot(p->edict());
    const TeamName desired=(config.test && p->entindex()==bot)?Side(2):
        (slot<0?UNASSIGNED:Side(config.players[slot].team));
    if(desired==UNASSIGNED) return 0;
    // Choosing the same side again can kill/respawn a live player in GoldSrc.
    if(p->m_iTeam==desired && p->m_iJoiningState==JOINED) return 0;
    return int(desired);
}
void CMatchCSCO::Joined(CBasePlayer* p) {
    if(config.test && p->entindex()==bot) return;
    int slot=Slot(p->edict());
    if(!Active() || slot<0 || p->m_iTeam!=Side(config.players[slot].team)) { Kick(p->edict()); return; }
    auto& data=config.players[slot];
    if(data.client && data.client!=p->entindex()) { Kick(p->edict()); return; }
    if(!data.client) {
        if(data.absence==4 && voteTeam==data.team) EndSurrender(false);
        data.client=p->entindex();
        SendHeader(p->edict());
        if(data.absence!=4) data.absence=0;
        data.absenceDeadline=0;
        if(live && data.reconnectMoney>=0) {
            p->CSPlayer()->AddAccount(data.reconnectMoney-p->m_iAccount,RT_NONE,false);
            data.restoredMoney=p->m_iAccount;
            data.reconnectMoney=-1;
        }
        Emit("connected","{\"steam_id\":\""+data.steam+"\",\"connected\":true}");
        gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"Team %d | %s",data.team,
            live?"Match in progress. /score":"Type /ready when ready.");
    }
}
void CMatchCSCO::CloseTeamMenu(CBasePlayer* p) {
    if(p->m_iMenu==Menu_ChooseTeam || p->m_iMenu==Menu_IGChooseTeam || p->m_iMenu==Menu_ChooseAppearance)
        p->m_iMenu=Menu_OFF;
}
bool CMatchCSCO::SuppressTeamMenu(CBasePlayer* p,int menu,const char* text) {
    // Initial menus may arrive while Steam authentication is still pending.
    // Team choice is never manual during an assignment; Frame still validates
    // the signed roster before joining anyone and rejects unknown identities.
    if(!Active() || !p) return false;
    bool team=menu==VGUI_Menu_Team || menu==VGUI_Menu_Class_T || menu==VGUI_Menu_Class_CT;
    if(menu==0 && text) {
        static const char* keys[]={"#Team_Select","#Team_Select_Spect","#IG_Team_Select",
            "#IG_Team_Select_Spect","#IG_VIP_Team_Select","#IG_VIP_Team_Select_Spect",
            "#CT_Select","#Terrorist_Select"};
        for(const auto key:keys) if(!strcmp(text,key)) team=true;
    }
    if(team) CloseTeamMenu(p);
    return team;
}
void CMatchCSCO::Spawned(CBasePlayer* p) {
    const int slot=Slot(p->edict()); if(slot>=0) config.players[slot].deathCounted=false;
    if(Active() && phase=="warmup") p->CSPlayer()->AddAccount(16000-p->m_iAccount,RT_NONE,false);
}
bool CMatchCSCO::AllPresent() const {
    if(!Active()) return false;
    for(const auto& p:config.players) {
        const auto player=UTIL_PlayerByIndexSafe(p.client);
        if(!p.client || !player || player->IsDormant() || player->m_iTeam!=Side(p.team) ||
           player->m_iJoiningState!=JOINED) return false;
    }
    if(config.test && !config.fullTest) {
        const auto target=UTIL_PlayerByIndexSafe(bot);
        if(!bot || !target || target->IsDormant() || target->m_iTeam!=Side(2)) return false;
    }
    return true;
}
bool CMatchCSCO::CanStart() { return AllPresent() && RulesReady(); }
bool CMatchCSCO::ReadyForLive() const { return (live || AllPresent()) && !gMatchLO3.Running(); }
bool CMatchCSCO::AllowState(int state) {
    if(state==STATE_DEAD) return true;
    if(!Active()) return false;
    if(phase=="finished") return state==STATE_END;
    if(state==STATE_WARMUP) return phase=="warmup" || (!live && phase=="starting");
    if(state==STATE_START || state==STATE_FIRST_HALF) {
        if(!AllPresent()) { gMatchBot.SetState(STATE_WARMUP); return false; }
    }
    if(state==STATE_END) return mq2::won(score[0],score[1],config.mr,config.ot);
    return true;
}
void CMatchCSCO::StateChanged(int state) {
    try {
        if(state==STATE_DEAD) return;
        if(state==STATE_WARMUP) {
            cvar("mb_vote_map","0"); cvar("mb_team_pick_type","2");
            SetPhase("warmup");
        }
        if(state==STATE_START || state==STATE_FIRST_HALF) { roundOpen=false; SetPhase("starting"); }
        if(state==STATE_HALFTIME) { roundOpen=false; SetPhase("halftime"); }
        if(state==STATE_SECOND_HALF || state==STATE_OVERTIME) { roundOpen=false; SetPhase("starting"); }
        Profile(state);
        if(state==STATE_END) { roundOpen=false; SetPhase("finished"); }
    } catch(...) { Fail("state_io"); }
}
void CMatchCSCO::Swapped() { teamOneCT=!teamOneCT; }
void CMatchCSCO::FreezeEnd() {
    if(!Active() || !ReadyForLive() || phase=="halftime" || phase=="finished" ||
       gMatchBot.GetState()<STATE_FIRST_HALF || gMatchBot.GetState()==STATE_HALFTIME) return;
    try { SetPhase("live"); } catch(...) { Fail("state_io"); return; }
    roundOpen=true;
    if(!live) { live=true; UpdateHostname(); Emit("live","{}","live"); }
}
bool CMatchCSCO::BothSidesPresent() const {
    bool sides[2]={false,false};
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto p=UTIL_PlayerByIndexSafe(i);
        if(!p || p->IsDormant() || p->m_iMenu==Menu_ChooseAppearance) continue;
        const int slot=Slot(p->edict());
        if(slot>=0 && p->m_iTeam==Side(config.players[slot].team)) sides[config.players[slot].team-1]=true;
        else if(config.test && i==bot && p->m_iTeam==Side(2)) sides[1]=true;
    }
    return sides[0] && sides[1];
}
void CMatchCSCO::ObserveTeams() {
    // Called before the real GameDLL win check, including its disconnect path.
    // Let NeededPlayersCheck observe the empty side. Only its later COMMENCE
    // may be consumed; do not restart the round or reset any player/team state.
    if(Active() && live && phase=="live" && !BothSidesPresent()) emptySideObserved=true;
}
bool CMatchCSCO::AllowRoundEnd() {
    return Scoring() && (!config.test || BothSidesPresent()) && !gMatchLO3.Running();
}
bool CMatchCSCO::AllowEngineReset(ScenarioEventEndRound event) {
    if(quarantine) return false;
    if(live && phase=="live" && !gMatchLO3.Running()) {
        if(event==ROUND_GAME_COMMENCE && Active() && emptySideObserved && BothSidesPresent() &&
           !CSGameRules()->m_bGameStarted && !CSGameRules()->m_bCompleteReset &&
           value("sv_restart",0) && value("sv_restartround",0)) {
            CSGameRules()->m_bGameStarted=true;
            CSGameRules()->m_bNeededPlayers=false;
            emptySideObserved=false;
            ++reconnectResumes;
            Print("[CSCO] reconnect_resume: score="+number(score[0])+":"+number(score[1]));
            return false; // NEVER call NeededPlayersCheck(delay): it performs a complete reset.
        }
        Fail("unexpected_engine_reset"); return false;
    }
    return true;
}
bool CMatchCSCO::BeforeRoundRestart() {
    if(quarantine) return false;
    // Defence in depth: a plugin calling RestartRound directly must not bypass
    // the RoundEnd reset guard. Ordinary round transitions remain untouched.
    if(live && phase=="live" && !gMatchLO3.Running() && CSGameRules()->m_bCompleteReset) {
        Fail("unexpected_complete_reset"); return false;
    }
    if(Active() && CSGameRules()->m_bCompleteReset) {
        // A legitimate halftime/OT reset also changes the disconnected roster's economy.
        for(auto& p:config.players) if(p.reconnectMoney>=0)
            p.reconnectMoney=int(g_engfuncs.pfnCVarGetFloat("mp_startmoney"));
    }
    return true;
}
void CMatchCSCO::RoundEnded() {
    if(!Scoring()) return;
    roundOpen=false;
    score[0]=gMatchBot.GetScore(Side(1)); score[1]=gMatchBot.GetScore(Side(2));
    for(auto& p:config.players) if(p.client) ++p.rounds;
    const bool finished=mq2::won(score[0],score[1],config.mr,config.ot);
    // A kill can trigger RoundEnd inside TakeDamage. Flush from the next frame
    // so that the final hit is included in the same immutable score snapshot.
    pendingRound=true;
    if(finished) {
        try { SetPhase("finished"); } catch(...) { Fail("state_io"); }
        gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"FINAL | Team 1 %d : %d Team 2",score[0],score[1]);
    } else gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"Team 1 %d : %d Team 2",score[0],score[1]);
}
std::string CMatchCSCO::PlayerStats() const {
    std::string players="{"; bool first=true;
    for(const auto& p:config.players) {
        if(!first) players+=",";
        first=false;
        players+="\""+p.steam+"\":{\"kills\":"+number(p.kills)+",\"deaths\":"+number(p.deaths)+
            ",\"assists\":"+number(p.assists)+",\"damage\":"+number(p.damage)+",\"headshots\":"+number(p.headshots)+",\"rounds\":"+number(p.rounds)+"}";
    }
    return players+"}";
}
void CMatchCSCO::ReportScore(bool finished) {
    const auto players=PlayerStats();
    const std::string type=finished?"finished":"round";
    Emit(type,"{\"team1_score\":"+number(score[0])+",\"team2_score\":"+number(score[1])+
        ",\"players\":"+players+"}",type+"-"+number(score[0])+"-"+number(score[1]));
}
void CMatchCSCO::Damage(CBasePlayer* victim,entvars_t* attacker,float actual) {
    if(!Active() || (!roundOpen && !pendingRound) || !live || !attacker || actual<=0) return;
    int a=Slot(ENT(attacker)),v=Slot(victim->edict());
    const bool testOpponent=config.test && bot>0 && victim->entindex()==bot;
    if(a>=0 && ((v>=0 && config.players[a].team!=config.players[v].team) || testOpponent))
        config.players[a].damage+=int(std::ceil(std::min(actual,10000.0f)));
}
void CMatchCSCO::Death(CBaseEntity* killer,CBasePlayer* victim,CBasePlayer* assister,int rarity) {
    if(!Scoring()) return;
    const int v=Slot(victim->edict()),k=killer?Slot(killer->edict()):-1;
    if(v>=0) {
        if(config.players[v].deathCounted) return;
        config.players[v].deathCounted=true; ++config.players[v].deaths;
    }
    const bool testOpponent=config.test && bot>0 && victim->entindex()==bot;
    if(k>=0 && ((v>=0 && config.players[k].team!=config.players[v].team) || testOpponent)) {
        ++config.players[k].kills; if(rarity&1) ++config.players[k].headshots;
        const int a=assister?Slot(assister->edict()):-1;
        if(a>=0 && a!=k && a!=v && config.players[a].team==config.players[k].team) ++config.players[a].assists;
    }
}
bool CMatchCSCO::ClientCommand(CBasePlayer* p,const char* cmd,const char* arg) {
    if(!cmd) return false;
    if(voteMenu[p->entindex()] && !strcmp(cmd,"menuselect")) {
        if(arg && (!strcmp(arg,"1") || !strcmp(arg,"2"))) SurrenderVote(p,!strcmp(arg,"1"));
        else voteMenu[p->entindex()]=false;
        return true;
    }
    if(!strcmp(cmd,"buy") || !strcmp(cmd,"buyequip")) voteMenu[p->entindex()]=false;
    if(Active() && Slot(p->edict())>=0 &&
       (!strcmp(cmd,"chooseteam") || !strcmp(cmd,"jointeam") || !strcmp(cmd,"joinclass"))) {
        CloseTeamMenu(p); return true; // Frame owns assignment; never rejoin/respawn a live player.
    }
    std::string text=cmd;
    if(text=="say" || text=="say_team") text=arg?arg:"";
    if(text.size()>1 && text.front()=='"' && text.back()=='"') text=text.substr(1,text.size()-2);
    if(text.empty() || (text[0]!='/' && text[0]!='.' && text[0]!='!')) return false;
    const int slot=Slot(p->edict()); if(!Active() || slot<0) return true;
    text=text.substr(1);
    if(text=="surrender" || text=="ff") StartSurrender(p);
    else if(text=="yes") SurrenderVote(p,true);
    else if(text=="no") SurrenderVote(p,false);
    else if(text=="ready" || text=="r") gMatchReady.Ready(p);
    else if(text=="unready" || text=="notready") gMatchReady.NotReady(p);
    else if(text=="endtest") {
        if(config.fullTest && config.players[slot].steam==config.owner) EndTest("test_admin");
    }
    else if(text=="score" || text=="scores" || text=="status" || text=="stats") {
        gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"%s | %s %d : %d %s",phase.c_str(),config.teams[0].c_str(),score[0],score[1],config.teams[1].c_str());
        for(const auto& row:config.players)
            gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"T%d | %s | K/D/A %d/%d/%d",row.team,row.name.c_str(),row.kills,row.deaths,row.assists);
    }
    // Even dead teammates must not relay enemy HP during a live round.
    else if(text=="dmg" && CSGameRules()->m_bRoundTerminating) gMatchRound.ShowDamage(p,true,false);
    else if(text=="hp" && CSGameRules()->m_bRoundTerminating) gMatchRound.ShowHP(p,true,false);
    else if(text=="timeout" && Scoring() && !gMatchPause.m_Pause && !gMatchPause.m_Paused &&
            timeouts[config.players[slot].team-1]<2) {
        ++timeouts[config.players[slot].team-1]; gMatchPause.Init(nullptr,p->m_iTeam);
    }
    else if(text=="help")
        gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"/ready /score /dmg /hp /timeout /ff /yes /no");
    return true; // Match/map/team/admin control belongs to the signed assignment.
}
void CMatchCSCO::EnsureBot() {
    if(config.fullTest && Active()) {
        for(size_t slot=0;slot<config.players.size();++slot) {
            auto& row=config.players[slot]; if(!row.bot || row.client) continue;
            creatingBot=true;
            auto entity=g_engfuncs.pfnCreateFakeClient(mq2::clip(row.name,31).c_str());
            if(FNullEnt(entity)) {creatingBot=false; Fail("test_bot_unavailable"); return;}
            botSlots[ENTINDEX(entity)]=int(slot)+1;
            botUserIds[ENTINDEX(entity)]=g_engfuncs.pfnGetPlayerUserId(entity); char reject[128]={};
            MDLL_ClientConnect(entity,row.name.c_str(),"127.0.0.1",reject);
            MDLL_ClientPutInServer(entity); entity->v.flags|=FL_FAKECLIENT;
            auto p=UTIL_PlayerByIndexSafe(ENTINDEX(entity));
            if(p) {
                p->CSPlayer()->JoinTeam(Side(row.team));
                p->m_iModelName=Side(row.team)==CT?MODEL_URBAN:MODEL_TERROR;
                p->CSPlayer()->SetPlayerModel(false);
            }
            creatingBot=false;
        }
        return;
    }
    if(!config.test || bot || !Active()) return;
    creatingBot=true;
    auto entity=g_engfuncs.pfnCreateFakeClient("CSCO Test Opponent");
    if(FNullEnt(entity)) { creatingBot=false; Fail("test_opponent_unavailable"); return; }
    bot=ENTINDEX(entity); char reject[128]={};
    MDLL_ClientConnect(entity,"CSCO Test Opponent","127.0.0.1",reject);
    MDLL_ClientPutInServer(entity); entity->v.flags|=FL_FAKECLIENT;
    auto p=UTIL_PlayerByIndexSafe(bot);
    if(p) {
        p->CSPlayer()->JoinTeam(Side(2));
        p->m_iModelName=Side(2)==CT?MODEL_URBAN:MODEL_TERROR;
        p->CSPlayer()->SetPlayerModel(false);
    }
    creatingBot=false;
}
void CMatchCSCO::Frame() {
    if(pendingRound) { pendingRound=false; ReportScore(mq2::won(score[0],score[1],config.mr,config.ot)); }
    if(gpGlobals->time<nextFrame) return;
    nextFrame=gpGlobals->time+0.25f;
    if(Active() && !live && phase=="starting" && !AllPresent()) {
        gMatchTask.ServerDeactivate(); gMatchLO3.Stop();
        cvar("sv_restart","0"); cvar("sv_restartround","0");
        gMatchBot.SetState(STATE_WARMUP);
    }
    if(!root.empty() && config.test && phase=="warmup") EnsureBot();
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto p=UTIL_PlayerByIndexSafe(i); if(!p || p->IsDormant()) continue;
        if(i==bot && config.test) {
            g_engfuncs.pfnRunPlayerMove(p->edict(),p->pev->v_angle,0,0,0,0,0,50); continue;
        }
        const int slot=Slot(p->edict());
        if(!Active() || slot<0) {
            const auto auth=g_engfuncs.pfnGetPlayerAuthId(p->edict());
            if(Active() && auth && !strcmp(auth,"STEAM_ID_PENDING") &&
               authDeadline[i]>gpGlobals->time) continue;
            Kick(p->edict(),quarantine?"server_error":config.id.empty()?"no_match":auth && !strcmp(auth,"STEAM_ID_PENDING")?"steam_timeout":"not_roster"); continue;
        }
        const auto assigned=Side(config.players[slot].team);
        if(p->m_iTeam==UNASSIGNED || p->m_iTeam==SPECTATOR) {
            p->CSPlayer()->JoinTeam(assigned);
            p->m_iModelName=assigned==CT?MODEL_URBAN:MODEL_TERROR;
            p->CSPlayer()->SetPlayerModel(false);
        } else if(p->m_iTeam!=assigned && phase!="halftime") { Kick(p->edict()); continue; }
        if(config.players[slot].bot
#ifdef MQ2_QA
            || (p->pev->flags&FL_FAKECLIENT)
#endif
        ) g_engfuncs.pfnRunPlayerMove(p->edict(),p->pev->v_angle,0,0,0,0,0,50);
        if(p->m_iJoiningState==JOINED) { CloseTeamMenu(p); Joined(p); }
    }
    DisconnectFrame();
    if(Active() && live && phase!="finished" && paused!=gMatchPause.m_Paused) {
        paused=gMatchPause.m_Paused; UpdateHostname(); Emit(paused?"pause":"resume","{}");
    }
}
bool CMatchCSCO::ScoreInfo(int destination,int type,const float* origin,edict_t* entity) {
    if(gMatchCSCO.live) {
        const int index=gMatchMessage.GetByte(0);
        const auto p=UTIL_PlayerByIndexSafe(index);
        const int slot=p?gMatchCSCO.Slot(p->edict()):-1;
        if(slot>=0) {
            gMatchMessage.SetArgInt(1,gMatchCSCO.config.players[slot].kills);
            gMatchMessage.SetArgInt(2,gMatchCSCO.config.players[slot].deaths);
        }
    }
    return false;
}
void CMatchCSCO::Profile(int state) {
    const bool warm=state==STATE_WARMUP,ot=state==STATE_OVERTIME;
    cvar("mp_autoteambalance","0"); cvar("mp_limitteams","0"); cvar("mp_auto_join_team","0");
    cvar("mp_timelimit","0"); cvar("mp_maxrounds","0"); cvar("mp_winlimit","0");
    cvar("mp_freezetime",warm?"0":"10"); cvar("mp_roundtime","1.75"); cvar("mp_c4timer","35");
    cvar("mp_buytime",warm?"1.75":"0.25"); cvar("mp_startmoney",warm?"16000":ot?"10000":"800");
    cvar("mp_friendlyfire",warm?"0":"1"); cvar("mp_fadetoblack","0");
    cvar("mp_forcecamera","2"); cvar("mp_forcechasecam","2");
    cvar("mp_autokick","0"); cvar("mp_tkpunish","0"); cvar("mp_hostagepenalty","0");
    cvar("sv_alltalk",warm?"1":"0"); cvar("sv_voiceenable","1"); cvar("sv_cheats","0");
    cvar("sv_gravity","800"); cvar("sv_airaccelerate","10"); cvar("sv_maxspeed","320");
    cvar("pausable","0"); cvar("mp_freeforall","0"); cvar("mp_round_infinite",warm?"1":"0");
    cvar("mp_forcerespawn",warm?"2":"0"); cvar("mp_roundrespawn_time",warm?"-1":"0");
    cvar("mp_maxmoney","16000"); cvar("mp_buy_anywhere",warm?"1":"0");
    cvar("mp_infinite_ammo","0"); cvar("mp_infinite_grenades","0"); cvar("mp_free_armor","0");
    cvar("mp_auto_reload_weapons","0"); cvar("mp_refill_bpammo_weapons","0");
    cvar("mp_round_restart_delay","5"); cvar("mp_team_flash","1");
    cvar("mp_assist_damage_threshold","40");
    cvar("bot_quota","0"); cvar("bot_deathmatch","0");
}
bool CMatchCSCO::RulesReady() const {
    if(config.fullTest && phase=="finished") return !quarantine;
    const bool warm=phase=="warmup";
    const bool ot=gMatchBot.GetState()==STATE_OVERTIME;
    return value("mp_autoteambalance",0) && value("mp_limitteams",0) && value("mp_freeforall",0) &&
        value("mp_c4timer",35) && value("mp_roundtime",1.75f) && value("sv_cheats",0) && value("mp_assist_damage_threshold",40) &&
        value("mp_startmoney",warm?16000:ot?10000:800) && value("mp_round_infinite",warm?1:0) &&
        value("mp_forcerespawn",warm?2:0) && value("mp_friendlyfire",warm?0:1) &&
        value("mp_freezetime",warm?0:10) && (gMatchPause.m_Paused || value("mp_buytime",warm?1.75f:0.25f));
}
void CMatchCSCO::StatusCommand() {
    const auto& s=gMatchCSCO; bool empty=true;
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto p=UTIL_PlayerByIndexSafe(i); if(p && !p->IsDormant()) empty=false;
    }
    const std::string assignment=s.config.id.empty()?"":s.config.id+":"+number(s.config.generation);
    Print("{\"bridge\":1,\"full_test\":true,\"assignment_contract\":2,\"solo_test\":true,\"matchid\":\""+assignment+"\",\"idle\":"+
        boolean(empty && assignment.empty() && !s.quarantine)+",\"healthy\":"+boolean(!s.quarantine && s.RulesReady())+
        ",\"controller_version\":\""+VERSION+"\",\"controller\":\"matchbot\",\"phase\":\""+s.phase+
        "\",\"profile\":\"cs16-classic-v1\",\"rules_ready\":"+boolean(s.RulesReady())+
        ",\"restarts_completed\":"+number(gMatchLO3.Completed())+",\"reconnect_resumes\":"+number(s.reconnectResumes)+",\"score\":["+number(s.score[0])+","+number(s.score[1])+"]}");
}
#ifdef MQ2_QA
// Deliberately compiled out of release. Uses actual GameDLL clients, damage,
// death and win checks; does not inject synthetic finished/round events.
template<typename... Args> class QAMenuChain : public IHookChain<void,Args...> {
public:
    int calls=0;
    void callNext(Args... args) override { ++calls; }
    void callOriginal(Args... args) override { ++calls; }
};
void CMatchCSCO::QACommand() {
    auto& s=gMatchCSCO;
    const std::string op=g_engfuncs.pfnCmd_Argv(1);
    const int arg=atoi(g_engfuncs.pfnCmd_Argv(2));
    if(op=="add" && s.Active() && arg>=0 && arg<int(s.config.players.size()) && !s.config.players[arg].client) {
        s.creatingBot=true;
        const auto name="QA roster "+number(arg);
        auto entity=g_engfuncs.pfnCreateFakeClient(name.c_str());
        if(FNullEnt(entity)) {s.creatingBot=false;Print("qa_full");return;}
        int i=ENTINDEX(entity);s.qaSlots[i]=arg+1;
        char reject[128]={}; MDLL_ClientConnect(entity,name.c_str(),"127.0.0.1",reject);
        MDLL_ClientPutInServer(entity); entity->v.flags|=FL_FAKECLIENT;
        auto p=UTIL_PlayerByIndexSafe(i);
        const auto side=s.Side(s.config.players[arg].team);
        p->CSPlayer()->JoinTeam(side);
        p->m_iModelName=side==CT?MODEL_URBAN:MODEL_TERROR;
        p->CSPlayer()->SetPlayerModel(false);
        s.creatingBot=false; Print("qa_added");
    } else if(op=="ready") {
        for(const auto& row:s.config.players) {
            const auto p=UTIL_PlayerByIndexSafe(row.client);
            if(p) s.ClientCommand(p,"say","/ready");
        }
        Print("qa_ready");
    } else if(op=="eliminate" && (arg==1 || arg==2) && s.Scoring()) {
        CBasePlayer* attacker=nullptr;
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);
            if(p && !p->IsDormant() && p->IsAlive() && p->m_iTeam==s.Side(3-arg)) {attacker=p;break;}
        }
        if(!attacker) {Print("qa_no_attacker");return;}
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);
            if(p && !p->IsDormant() && p->IsAlive() && p->m_iTeam==s.Side(arg))
                p->TakeDamage(attacker->pev,attacker->pev,500,DMG_BULLET);
        }
        Print("qa_damage_applied");
    } else if(op=="damage" && s.Scoring() && arg>=0 && arg<int(s.config.players.size())) {
        const int victim=atoi(g_engfuncs.pfnCmd_Argv(3));
        if(victim<0 || victim>=int(s.config.players.size())) { Print("qa_invalid"); return; }
        auto a=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        auto v=UTIL_PlayerByIndexSafe(s.config.players[victim].client);
        if(a && v && a->IsAlive() && v->IsAlive()) v->TakeDamage(a->pev,a->pev,50,DMG_BULLET);
        Print("qa_damage_applied");
    } else if(op=="fast" && g_pGameRules) {
        // Advance only a scheduled engine transition, never score arithmetic.
        if(CSGameRules()->m_flRestartRoundTime>gpGlobals->time)
            CSGameRules()->m_flRestartRoundTime=gpGlobals->time+0.05f;
        if(gMatchPause.m_Paused) {
            CSGameRules()->m_fRoundStartTime=gpGlobals->time-91;
            gMatchPause.PauseTimer(s.disconnectPause?90:60);
        } else if(CSGameRules()->IsFreezePeriod())
            CSGameRules()->m_fRoundStartTime=gpGlobals->time-CSGameRules()->m_iIntroRoundTime-1;
        Print("qa_clock_advanced");
    } else if(op=="timeout" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) s.ClientCommand(p,"say","/timeout");
        Print("qa_timeout_requested");
    } else if(op=="drop" && arg>=0 && arg<int(s.config.players.size())) {
        auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) s.Kick(p->edict());
        Print("qa_drop");
    } else if(op=="talk" && arg>=0 && arg<int(s.config.players.size())) {
        const auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(p) s.ClientCommand(p,"say",("/"+std::string(g_engfuncs.pfnCmd_Argv(3))).c_str());
        Print("qa_talk");
    } else if(op=="grace-fast") {
        for(auto& p:s.config.players) if(p.absence==3) p.absenceDeadline=gpGlobals->time+0.1f;
        Print("qa_grace_advanced");
    } else if(op=="direct-reset") {
        CSGameRules()->m_bCompleteReset=true;
        CSGameRules()->RestartRound();
        Print("qa_direct_reset");
    } else if(op=="menus" && arg>=0 && arg<int(s.config.players.size())) {
        const auto p=UTIL_PlayerByIndexSafe(s.config.players[arg].client);
        if(!p) { Print("qa_no_player"); return; }
        QAMenuChain<CBasePlayer*,int,int,char*> vgui;
        QAMenuChain<CBasePlayer*,int,int,BOOL,char*> text;
        char team[]="#Team_Select",appearance[]="#CT_Select",buy[]="#Buy",admin[]="Admin menu";
        for(const int kind:{VGUI_Menu_Team,VGUI_Menu_Class_T,VGUI_Menu_Class_CT}) {
            p->m_iMenu=Menu_ChooseTeam;
            ReGameDLL_ShowVGUIMenu(&vgui,p,kind,3,team);
        }
        ReGameDLL_ShowMenu(&text,p,3,-1,0,team);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,appearance);
        const int saved=s.qaSlots[p->entindex()]; s.qaSlots[p->entindex()]=0;
        ReGameDLL_ShowVGUIMenu(&vgui,p,VGUI_Menu_Team,3,team);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,team);
        s.qaSlots[p->entindex()]=saved;
        const bool suppressed=vgui.calls==0 && text.calls==0 && p->m_iMenu==Menu_OFF;
        ReGameDLL_ShowVGUIMenu(&vgui,p,VGUI_Menu_Buy,3,buy);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,buy);
        ReGameDLL_ShowMenu(&text,p,3,-1,0,admin);
        const auto side=p->m_iTeam;
        const auto xyz=p->pev->origin;
        bool commands=s.ClientCommand(p,"jointeam","1") && s.ClientCommand(p,"joinclass","1") && s.ClientCommand(p,"chooseteam","");
        Print(suppressed && vgui.calls==1 && text.calls==2 && commands &&
            p->m_iTeam==side && p->pev->origin==xyz ? "qa_menus_pass" : "qa_menus_fail");
    } else if(op=="snapshot") {
        std::string out="{\"engine_started\":"+std::string(boolean(CSGameRules()->m_bGameStarted))+
            ",\"freeze\":"+boolean(CSGameRules()->IsFreezePeriod())+",\"lo3\":"+boolean(gMatchLO3.Running())+
            ",\"round_open\":"+boolean(s.roundOpen)+",\"paused\":"+boolean(gMatchPause.m_Paused)+",\"ct_score\":"+number(gMatchBot.GetScore(CT))+
            ",\"t_score\":"+number(gMatchBot.GetScore(TERRORIST))+",\"clients\":[";
        bool first=true;
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            auto p=UTIL_PlayerByIndexSafe(i);if(!p || p->IsDormant())continue;
            if(!first)out+=",";
            first=false;
            out+="{\"id\":"+number(i)+",\"slot\":"+number(s.Slot(p->edict()))+
                ",\"team\":"+number(p->m_iTeam)+",\"joined\":"+number(p->m_iJoiningState)+
                ",\"alive\":"+boolean(p->IsAlive())+",\"money\":"+number(p->m_iAccount)+
                ",\"xyz\":["+number(int(p->pev->origin.x))+","+number(int(p->pev->origin.y))+","+number(int(p->pev->origin.z))+"]}";
        }
        if(s.config.fullTest) { Print(out+"]}"); return; } // Stay within the single RCON datagram budget.
        out+="],\"roster\":[";
        first=true;
        for(const auto& p:s.config.players) {
            if(!first) out+=","; first=false;
            out+="{\"absence\":"+number(p.absence)+",\"restored_money\":"+number(p.restoredMoney)+"}";
        }
        Print(out+"],\"vote_team\":"+number(s.voteTeam)+",\"vote_yes\":"+number(s.voteYes.size())+
            ",\"vote_eligible\":"+number(s.voteEligible.size())+"}");
    } else Print("qa_invalid");
}
#endif

void CMatchCSCO::ReconnectWindow(mq2::Player& p,const char* stage,int seconds) {
    Emit("reconnect_window","{\"steam_id\":\""+p.steam+"\",\"stage\":\""+stage+
        "\",\"seconds\":"+number(seconds)+",\"deadline\":"+std::to_string(std::time(nullptr)+seconds)+"}");
}
bool CMatchCSCO::StartDisconnectPause() {
    if(!Active() || !live || config.test || phase=="finished" || phase=="halftime" ||
       gMatchLO3.Running() || disconnectPause || gMatchPause.m_Paused) return false;
    bool waiting=false;
    for(const auto& p:config.players) if(!p.client && p.absence==1) waiting=true;
    if(!waiting) return false;
    disconnectPause=true;
    gMatchPause.m_Pause=false;
    gMatchPause.m_PauseTeam="RECONNECT";
    gMatchPause.Pause(90);
    for(auto& p:config.players) if(!p.client && p.absence==1) {
        p.absence=2; ReconnectWindow(p,"pause",90);
    }
    gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"Player disconnected. Reconnect pause: 90 seconds.");
    return true;
}
void CMatchCSCO::DisconnectPauseEnded() {
    if(!disconnectPause) return;
    disconnectPause=false;
    for(auto& p:config.players) if(!p.client && p.absence==2) {
        p.absence=3; p.absenceDeadline=gpGlobals->time+180;
        ReconnectWindow(p,"grace",180);
    }
    gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"Play continues. Missing players have 3 minutes to reconnect.");
}
void CMatchCSCO::DisconnectFrame() {
    if(!Active() || !live || config.test || phase=="finished") return;
    if(CSGameRules()->IsFreezePeriod()) StartDisconnectPause();
    for(auto& p:config.players) if(!p.client && p.absence==3 && gpGlobals->time>=p.absenceDeadline) {
        p.absence=4; p.absenceDeadline=0;
        Emit("abandoned","{\"steam_id\":\""+p.steam+"\",\"cooldown_seconds\":1800}","abandoned-"+p.steam);
        if(voteTeam==p.team) EndSurrender(false); // Never shrink an ongoing vote's denominator.
        gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,
            "Team %d: player abandoned. 30 minute queue cooldown. Type /ff to vote to surrender.",p.team);
    }
    if(voteTeam && gpGlobals->time>=voteDeadline) EndSurrender(false);
}
void CMatchCSCO::StartSurrender(CBasePlayer* player) {
    const int slot=Slot(player->edict());
    if(!Active() || !live || config.test || phase=="finished" || slot<0 || voteTeam) return;
    const int team=config.players[slot].team;
    if(gpGlobals->time<voteCooldown[team-1]) {
        gMatchUtil.SayText(player->edict(),PRINT_TEAM_DEFAULT,"Wait before calling another surrender vote."); return;
    }
    bool missing=false;
    for(const auto& p:config.players) if(p.team==team && p.absence==4 && !p.client) missing=true;
    if(!missing) {
        gMatchUtil.SayText(player->edict(),PRINT_TEAM_DEFAULT,"Surrender is available after a teammate abandons."); return;
    }
    voteTeam=team; voteDeadline=gpGlobals->time+30; voteEligible.clear(); voteYes.clear();
    for(size_t i=0;i<config.players.size();++i) {
        const auto& p=config.players[i];
        if(p.team!=team || (p.absence==4 && !p.client)) continue;
        voteEligible.push_back(i);
        const auto client=UTIL_PlayerByIndexSafe(p.client);
        if(!client || client->IsDormant()) continue;
        gMatchUtil.SayText(client->edict(),PRINT_TEAM_DEFAULT,"Surrender vote: /yes or /no (30 seconds). Majority required.");
        const int msg=gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info,"ShowMenu",nullptr);
        if(msg) {
            client->m_iMenu=Menu_OFF; voteMenu[client->entindex()]=true;
            g_engfuncs.pfnMessageBegin(MSG_ONE,msg,nullptr,client->edict());
            g_engfuncs.pfnWriteShort(3); g_engfuncs.pfnWriteChar(30); g_engfuncs.pfnWriteByte(0);
            g_engfuncs.pfnWriteString("\\yCSCO.GG - Surrender?\\w\n\n1. Yes\n2. No");
            g_engfuncs.pfnMessageEnd();
        }
    }
    SurrenderVote(player,true); // Calling /ff counts as one affirmative vote.
}
void CMatchCSCO::SurrenderVote(CBasePlayer* p,bool yes) {
    const int slot=Slot(p->edict());
    if(!voteTeam || gpGlobals->time>=voteDeadline || !Active() ||
       std::find(voteEligible.begin(),voteEligible.end(),slot)==voteEligible.end()) return;
    voteMenu[p->entindex()]=false;
    const auto found=std::find(voteYes.begin(),voteYes.end(),slot);
    if(yes && found==voteYes.end()) voteYes.push_back(slot);
    else if(!yes && found!=voteYes.end()) voteYes.erase(found);
    if(voteYes.size()>voteEligible.size()/2) EndSurrender(true);
}
void CMatchCSCO::EndSurrender(bool passed) {
    if(!voteTeam) return;
    const int team=voteTeam; voteTeam=0; voteCooldown[team-1]=gpGlobals->time+120;
    for(int i=1;i<=gpGlobals->maxClients;++i) if(voteMenu[i]) {
        voteMenu[i]=false;
        const auto p=UTIL_PlayerByIndexSafe(i);
        if(p && !p->IsDormant()) {
            const int msg=gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info,"ShowMenu",nullptr);
            if(msg) {
                g_engfuncs.pfnMessageBegin(MSG_ONE,msg,nullptr,p->edict());
                g_engfuncs.pfnWriteShort(0); g_engfuncs.pfnWriteChar(0); g_engfuncs.pfnWriteByte(0);
                g_engfuncs.pfnWriteString(""); g_engfuncs.pfnMessageEnd();
            }
        }
    }
    if(!passed) {
        gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"Team %d surrender vote failed. Play continues.",team); return;
    }
    if(pendingRound) { pendingRound=false; ReportScore(false); }
    roundOpen=false;
    try { SetPhase("finished"); } catch(...) { Fail("state_io"); return; }
    gMatchTask.ServerDeactivate(); gMatchPause.ServerActivate(); disconnectPause=false;
    gMatchPause.SetRoundTime(9999,true);
    std::string voters="[";
    for(const int index:voteYes) { if(voters.size()>1) voters+=","; voters+="\""+config.players[index].steam+"\""; }
    Emit("surrendered","{\"loser_team\":"+number(team)+",\"yes_votes\":"+voters+
        "],\"team1_score\":"+number(score[0])+",\"team2_score\":"+number(score[1])+
        ",\"players\":"+PlayerStats()+"}","surrendered");
    gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"Team %d surrendered. Team %d wins. Final rounds: %d:%d.",team,3-team,score[0],score[1]);
}

bool CMatchCSCO::AutoReady(CBasePlayer* player) const {
    if(!Active() || player->m_iJoiningState!=JOINED) return false;
    if(config.test && !config.fullTest && player->entindex()==bot) return player->m_iTeam==Side(2);
    const int slot=Slot(player->edict());
    return slot>=0 && config.players[slot].bot && config.players[slot].client==player->entindex() && player->m_iTeam==Side(config.players[slot].team);
}
