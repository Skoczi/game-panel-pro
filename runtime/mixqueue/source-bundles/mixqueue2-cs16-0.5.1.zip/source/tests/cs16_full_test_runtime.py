"""Full-test contract from actual WWW ready/veto; isolated GameDLL only."""
import argparse, importlib.util, json, os, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True);p.add_argument('--load',required=True);p.add_argument('--complete',action='store_true');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-050/' in str(root)
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
spool=agent.Spool(':memory:');adapter=agent.AmxxAdapter({'game_root':str(root),'rcon_port':27095,'rcon_password_env':'MQ2_QA_RCON_PASSWORD'},spool)
def cmd(value):
 time.sleep(1.1);return adapter.rcon.command(value)
def status():return json.loads(cmd('mq2_status'))
def snapshot():return json.loads(cmd('mq2_qa snapshot'))
def live():
 end=time.monotonic()+85
 while time.monotonic()<end:
  v=snapshot()
  if v['round_open'] and not v['lo3'] and not v['freeze']:return v
  cmd('mq2_qa fast')
 raise AssertionError(('start failed',status(),v))
load=json.loads(Path(a.load).read_text());mid=load['match_id'];players=load['payload']['players'];humans=[i for i,p in enumerate(players) if not p['bot']]
assert status()['idle'];original=cmd('hostname')
adapter.execute(load);time.sleep(3)
assert status()['phase']=='warmup',status()
for i in humans:assert cmd(f'mq2_qa add {i}')=='qa_added'
assert len(snapshot()['clients'])==10,snapshot()
assert status()['phase']=='warmup','Bots auto-readied real humans'
assert cmd('mq2_qa ready')=='qa_ready'
v=live();assert status()['restarts_completed']==3,status()
assert all(p['money']==800 for p in v['clients']),v
print('PASS full roster and 3 restarts',len(humans),'humans',flush=True)
before={p['slot']:p['xyz'] for p in v['clients']};time.sleep(3);assert before=={p['slot']:p['xyz'] for p in snapshot()['clients']},'Bot or player teleported'
team1=[i for i,p in enumerate(players) if p['team']==1];team2=[i for i,p in enumerate(players) if p['team']==2]
# First connected team-1 client is the first bot, while the real human connected later.
# Give a DIFFERENT teammate >40% damage before the engine-selected killer finishes.
first=next(p['slot'] for p in v['clients'] if p['slot'] in team1)
assister=next(i for i in team1 if i!=first)
assert cmd(f'mq2_qa damage {assister} {team2[0]}').endswith('qa_damage_applied')
assert cmd('mq2_qa eliminate 2').endswith('qa_damage_applied');assert status()['score']==[1,0]
print('PASS engine round 1:0',flush=True)
live()
assert cmd(f'mq2_qa drop {humans[0]}').endswith('qa_drop')
assert cmd(f'mq2_qa add {humans[0]}')=='qa_added'
assert status()['score']==[1,0] and status()['healthy']
# A non-owner cannot end the session; owner can, without fabricating an MR winner.
if len(humans)>1:
 cmd(f'mq2_qa talk {humans[1]} endtest');assert status()['phase']!='finished'
cmd(f'mq2_qa talk {humans[0]} stats')
assert 'LIVE' in cmd('hostname') and 'CSCO.gg' in cmd('hostname')
if a.complete:
 expected=[1,0]
 for n,winner in enumerate([1]*14+[2]*15+[1]*3+[2]*3+[1]*4):
  live();cmd(f'mq2_qa eliminate {3-winner}');expected[winner-1]+=1
  assert status()['score']==expected and status()['healthy'],status()
  print('full round',n+2,expected,flush=True)
else:
 cmd(f'mq2_qa talk {humans[0]} endtest')
assert status()['phase']=='finished' and status()['score']==([22,18] if a.complete else [1,0])
events=[json.loads(x) for x in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if json.loads(x)['match_id']==mid]
final=[e for e in events if e['type']==('finished' if a.complete else 'test_ended')];assert len(final)==1,final
stats=final[0]['data']['players'];assert len(stats)==10
assert sum(p['kills'] for p in stats.values())==(200 if a.complete else 5),stats
assert sum(p['damage'] for p in stats.values())==(20000 if a.complete else 500),stats
assert sum(p['assists'] for p in stats.values())==1,stats
assert sum(p['deaths'] for p in stats.values())==(200 if a.complete else 5),stats
assert all(p['rounds']==(40 if a.complete else 1) for p in stats.values()),stats
if not a.complete: assert final[0]['data']['actor']==load['payload']['test_owner']
cleanup={'id':'qa-clean-'+mid,'match_id':mid,'generation':load['generation'],'type':'cleanup','payload':{'reason':'match_finished' if a.complete else 'test_admin'}}
adapter.execute(cleanup);time.sleep(2);adapter.execute(cleanup)
assert status()['idle'] and status()['healthy'] and not snapshot()['clients']
assert cmd('hostname')==original,'Original hostname not restored'
assert not (root/'addons/amxmodx/configs/mq2/original-hostname.txt').exists()
spool.flush(lambda row:events.append(row['event']))
Path(a.load+'.events.json').write_text(json.dumps(events,ensure_ascii=False))
print('PASS real K/D/A/damage/rounds, reconnect, '+('MR15 + 2 OT, 22:18' if a.complete else 'owner-only end, partial 1:0')+', cleanup retry, hostname restore',flush=True)
