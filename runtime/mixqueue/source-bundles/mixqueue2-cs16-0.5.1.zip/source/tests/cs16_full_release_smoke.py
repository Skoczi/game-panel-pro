"""Production full-test contract and restart recovery, isolated GameDLL only."""
import argparse, importlib.util, json, os, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True);p.add_argument('--load',required=True);p.add_argument('--mode',choices=['finish','arm','recover'],required=True);a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-050/' in str(root)
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
adapter=agent.AmxxAdapter({'game_root':str(root),'rcon_port':27095,'rcon_password_env':'MQ2_QA_RCON_PASSWORD'},agent.Spool(':memory:'))
def cmd(v):time.sleep(1.1);return adapter.rcon.command(v)
def status():return json.loads(cmd('mq2_status'))
load=json.loads(Path(a.load).read_text());mid=load['match_id'];gen=load['generation'];marker=root/'addons/amxmodx/configs/mq2/original-hostname.txt'
if a.mode!='recover':
 assert status()['idle'] and 'round_open' not in cmd('mq2_qa snapshot')
 original=cmd('hostname');Path(a.load+'.hostname').write_text(original)
 adapter.execute(load);time.sleep(3);adapter.execute(load)
 s=status();assert s['phase']=='warmup' and s['healthy'] and s['full_test']
 assert '[WARMUP]' in cmd('hostname') and 'CSCO.gg' in cmd('hostname') and marker.exists()
 if a.mode=='arm':
  print('PASS production full assignment, 9 real bots, load retry, durable hostname; armed process restart',flush=True)
  raise SystemExit(0)
 end={'id':'prod-end-'+mid,'match_id':mid,'generation':gen,'type':'finish_test','payload':{'reason':'test_admin'}}
 adapter.execute(end);adapter.execute(end)
 assert status()['phase']=='finished'
 events=[json.loads(x) for x in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if json.loads(x)['match_id']==mid]
 ended=[x for x in events if x['type']=='test_ended'];assert len(ended)==1 and len(ended[0]['data']['players'])==10
 assert ended[0]['data']['team1_score']==0 and ended[0]['data']['team2_score']==0
else:
 s=status();assert s['phase']=='recovery' and not s['healthy'] and s['matchid']==f'{mid}:{gen}',s
 assert cmd('hostname')==Path(a.load+'.hostname').read_text(),'Recovery lost original hostname'
 try: adapter.execute(load)
 except RuntimeError: pass
 else:raise AssertionError('Recovery bypassed')
cleanup={'id':'prod-clean-'+mid,'match_id':mid,'generation':gen,'type':'cleanup','payload':{'reason':'server_error' if a.mode=='recover' else 'test_admin'}}
adapter.execute(cleanup);time.sleep(2);adapter.execute(cleanup)
assert status()['idle'] and status()['healthy'] and not marker.exists()
assert cmd('hostname')==Path(a.load+'.hostname').read_text()
rows=[];adapter.spool.flush(rows.append);assert len(rows)==1 and rows[0]['event']['type']=='idle'
print('PASS production '+a.mode+': verified idle, normal agent cleanup retry, restored hostname, no recovery bypass',flush=True)
