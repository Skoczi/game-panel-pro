"""0.5.1 production binary, isolated loopback lab. Not Steam client acceptance."""
import argparse, importlib.util, json, os, time, hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True);p.add_argument('--mode',choices=['run','recover'],default='run');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-051/' in str(root),'Isolated lab only'
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
adapter=agent.AmxxAdapter({'game_root':str(root),'rcon_port':27095,'rcon_password_env':'MQ2_QA_RCON_PASSWORD'},agent.Spool(':memory:'))
def cmd(v):time.sleep(1.1);return adapter.rcon.command(v)
def status():return json.loads(cmd('mq2_status'))
cfg=root/'addons/amxmodx/configs/mq2';journal=root/'addons/amxmodx/data/mq2/events.jsonl'
proof=root.parent.parent/'followup-proof.json'
assert status()['controller_version']=='0.5.1'
if a.mode=='recover':
    saved=json.loads(proof.read_text());load=saved['load'];s=status()
    assert s['phase']=='recovery' and not s['healthy'] and s['matchid']==f"{load['match_id']}:{load['generation']}",s
    assert cmd('hostname')==saved['original'],'Recovery did not restore hostname'
    try:adapter.execute(load)
    except RuntimeError:pass
    else:raise AssertionError('Recovery bypass')
    cleanup={'id':'051-recovery','type':'cleanup','match_id':load['match_id'],'generation':load['generation'],'payload':{'reason':'server_error'}}
    adapter.execute(cleanup);time.sleep(2);adapter.execute(cleanup)
    assert status()['idle'] and status()['healthy']
    assert cmd('hostname')==saved['original']
    assert int((cfg/'generation-matchbot.txt').read_text())==load['generation']
    print('PASS production 0.5.1: process recovery quarantined, original hostname restored, normal cleanup/idle, high-water preserved')
    raise SystemExit(0)
# The lab is a separate preserved copy. Reconcile any copied prior lab marker via normal command.
if not status()['idle']:
    cmd('mq2_clear server_error');time.sleep(2)
assert status()['idle'] and status()['healthy']
assert 'round_open' not in cmd('mq2_qa snapshot'),'QA command in release'
assert 'CSCO.GG' in cmd('mb_log_tag')
original=cmd('hostname');high=int((cfg/'generation-matchbot.txt').read_text());gen=high+1
mid='7e5700'+f'{time.time_ns():018x}'[-18:]
payload={'contract_version':2,'game':'cs16','match_id':mid,'generation':gen,'map':'de_dust2','team_size':5,
         'config_hash':'d'*64,'rules':{'mr':15,'ot_mr':3,'test':True,'test_type':'full'},
         'test_owner':'76561198000000000','teams':{'1':'Steam owner team','2':'Bot 2-1 team'},'players':[]}
for team in (1,2):
    for i in range(1,6):
        human=team==1 and i==1
        identity=payload['test_owner'] if human else 'bot:'+hashlib.sha256(f'{mid}:{gen}:{team}:{i}'.encode()).hexdigest()[:24]
        payload['players'].append(dict(steam_id=identity,team=team,bot=not human,captain=int(i==1),locale='en',name='Steam owner' if human else f'Bot {team}-{i}'))
path=cfg/f'{mid}-{gen}.txt'
assert cmd(f'mq2_load {mid} {gen}')=='storage_failure'
path.write_text('broken assignment\n',encoding='utf-8')
assert cmd(f'mq2_load {mid} {gen}')=='malformed_assignment'
path.write_text(agent.AmxxAdapter.build({**payload,'map':'de_csco_missing_051'}),encoding='utf-8')
assert cmd(f'mq2_load {mid} {gen}')=='missing_map'
assert int((cfg/'generation-matchbot.txt').read_text())==high
assert status()['idle'] and status()['healthy'] and cmd('hostname')==original
assert not any(json.loads(x)['match_id']==mid for x in journal.read_text().splitlines()),'Rejected load emitted event'
# Replacing only this new, never accepted lab assignment fixture is intentional.
path.write_text(agent.AmxxAdapter.build(payload),encoding='utf-8')
load=dict(id='051-load',type='load',match_id=mid,generation=gen,payload=payload)
adapter.execute(load);time.sleep(3);adapter.execute(load)
assert status()['phase']=='warmup' and status()['healthy']
assert '[WARMUP]' in cmd('hostname')
assert 'de_dust2' in adapter.map_inventory()['maps'] and 'de_csco_missing_051' not in adapter.map_inventory()['maps']
adapter.execute(dict(id='051-end',type='finish_test',match_id=mid,generation=gen,payload={'reason':'test_admin'}))
assert status()['phase']=='finished' and '[FINISHED]' in cmd('hostname')
events=[json.loads(x) for x in journal.read_text().splitlines() if json.loads(x)['match_id']==mid]
assert sum(x['type']=='loaded' for x in events)==1
ended=[x for x in events if x['type']=='test_ended'];assert len(ended)==1 and len(ended[0]['data']['players'])==10
cleanup=dict(id='051-clear',type='cleanup',match_id=mid,generation=gen,payload={'reason':'test_admin'})
adapter.execute(cleanup);time.sleep(2);adapter.execute(cleanup)
assert status()['idle'] and cmd('hostname')==original
assert cmd(f'mq2_load {mid} {gen}')=='stale_generation'
print('PASS production 0.5.1: distinct storage/config/map rejections, no false loaded, real BSP inventory, load retry, 9 bots warmup, test_ended snapshot, cleanup/hostname, stale generation',flush=True)
# Arm a different assignment for an actual process restart, never reset generation.
gen+=1;mid='7e5700'+f'{time.time_ns():018x}'[-18:]
payload.update(match_id=mid,generation=gen)
for row in payload['players']:
    if row['bot']:
        i=int(row['name'].split('-')[-1]);row['steam_id']='bot:'+hashlib.sha256(f"{mid}:{gen}:{row['team']}:{i}".encode()).hexdigest()[:24]
load=dict(id='051-arm',type='load',match_id=mid,generation=gen,payload=payload)
adapter.execute(load);time.sleep(3)
assert status()['phase']=='warmup'
proof.write_text(json.dumps({'load':load,'original':original}),encoding='utf-8')
print('Armed isolated process restart; this is not a player reconnect test',flush=True)
