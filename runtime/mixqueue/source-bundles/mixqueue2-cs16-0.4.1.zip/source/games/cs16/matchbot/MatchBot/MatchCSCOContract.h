// CSCO integration, GPL-3.0. Pure contract validation shared by runtime and tests.
#pragma once
#include <algorithm>
#include <cstdint>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace mq2 {
inline bool hex(const std::string& s, size_t n) {
    return s.size()==n && s.find_first_not_of("0123456789abcdef")==std::string::npos;
}
inline bool map_name(const std::string& s) {
    return s.size()>3 && s.size()<40 && s.compare(0,3,"de_")==0 &&
        s.find_first_not_of("abcdefghijklmnopqrstuvwxyz0123456789_")==std::string::npos;
}
inline std::string steam64(const std::string& auth) {
    if (auth.size()<11 || (auth.compare(0,8,"STEAM_0:") && auth.compare(0,8,"STEAM_1:")) ||
        (auth[8]!='0' && auth[8]!='1') || auth[9]!=':' ||
        auth.find_first_not_of("0123456789",10)!=std::string::npos) return "";
    if(auth.size()>20) return "";
    uint64_t z=0;
    for(size_t i=10;i<auth.size();++i) { z=z*10+(auth[i]-'0'); if(z>2147483647ULL) return ""; }
    return std::to_string(76561197960265728ULL+z*2+(auth[8]-'0'));
}
struct Player {
    std::string auth, steam;
    int team=0, kills=0, deaths=0, damage=0, headshots=0, rounds=0, client=0;
    int absence=0; // 0 present, 1 waiting for freeze, 2 pause, 3 grace, 4 abandoned
    float absenceDeadline=0;
    int restoredMoney=-1;
    int reconnectMoney=-1; // Process-local only; never used to resume a crashed assignment.
};
struct Config {
    std::string id, map, hash;
    int generation=0, size=0, mr=0, ot=0;
    bool test=false;
    std::vector<Player> players;
};
inline Config parse(std::istream& in, const std::string& id, int generation) {
    Config c; std::string line, extra; int test=-1;
    if(!std::getline(in,line) || line.size()>240) throw std::runtime_error("invalid_header");
    std::istringstream header(line);
    if(!(header>>c.id>>c.generation>>c.map>>c.size>>c.mr>>c.ot>>c.hash>>test) || (header>>extra) ||
       !hex(c.id,24) || c.id!=id || c.generation!=generation || generation<1 ||
       !map_name(c.map) || !hex(c.hash,64) || (c.size!=2 && c.size!=5) ||
       c.mr!=(c.size==2?8:15) || c.ot!=3 || (test!=0 && test!=1))
        throw std::runtime_error("invalid_header");
    c.test=test==1; int counts[3]={0,0,0};
    while(std::getline(in,line)) {
        if(line.empty()) continue;
        if(line.size()>120 || c.players.size()>=10) throw std::runtime_error("invalid_roster");
        Player p; std::istringstream row(line);
        if(!(row>>p.auth>>p.steam>>p.team) || (row>>extra) || p.team<1 || p.team>2 ||
           steam64(p.auth).empty() || steam64(p.auth)!=p.steam)
            throw std::runtime_error("invalid_player");
        for(const auto& old:c.players) if(old.steam==p.steam) throw std::runtime_error("duplicate_player");
        ++counts[p.team]; c.players.push_back(p);
    }
    if(c.test ? (counts[1]!=1 || counts[2]!=0) : (counts[1]!=c.size || counts[2]!=c.size))
        throw std::runtime_error("unbalanced_roster");
    return c;
}
inline bool won(int a,int b,int mr,int ot) {
    const int hi=std::max(a,b),lo=std::min(a,b);
    if(lo<mr) return hi==mr+1;
    const int period=(lo-mr)/ot;
    return hi==mr+(period+1)*ot+1 && lo<=mr+(period+1)*ot-1;
}
}
