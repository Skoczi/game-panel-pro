"""Isolated ReHLDS/ReGameDLL integration: QA-only clients, real engine damage.

Refuses release controllers (mq2_qa must exist). Never use on a public game host.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--agent', required=True)
p.add_argument('--scenario', default='smoke')
a = p.parse_args()
spec = importlib.util.spec_from_file_location('mq_agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', 27095, os.environ['MQ2_QA_RCON_PASSWORD'])
root = Path(a.root)
assert any('/csco-lab/matchbot-'+v+'/' in str(root.resolve()) for v in ('040','041')), 'isolated path required'
last = 0
def cmd(value):
    global last
    time.sleep(max(0, 1.05 - (time.monotonic()-last)))
    result = rcon.command(value)
    last = time.monotonic()
    return result
def status():
    return json.loads(cmd('mq2_status'))
def snapshot():
    return json.loads(cmd('mq2_qa snapshot'))
def wait_live(timeout=65, fast=True):
    until = time.monotonic()+timeout
    while time.monotonic()<until:
        v = snapshot()
        if v['round_open'] and not v['freeze'] and not v['lo3']:
            return v
        if fast: cmd('mq2_qa fast')
    raise AssertionError(('live timeout',status(),v))
def load(size=5, solo=False, map_name='de_dust2', start=True):
    global mid, generation
    assert status()['idle'] is True
    generation = int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text())+1 if (root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').exists() else 1
    mid = f'{time.time_ns():024x}'
    players=[{'steam_id':str(76561198000000000+i),'team':1 if i<size else 2} for i in range(1 if solo else size*2)]
    payload={'game':'cs16','match_id':mid,'generation':generation,'map':map_name,'team_size':size,
             'config_hash':'b'*64,'rules':{'mr':15 if size==5 else 8,'ot_mr':3,'test':solo},'players':players}
    path=root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt'
    path.write_text(agent.AmxxAdapter.build(payload))
    print('load',cmd(f'mq2_load {mid} {generation}'),flush=True)
    for i in range(len(players)):
        assert cmd(f'mq2_qa add {i}')=='qa_added'
    print('joined',snapshot(),flush=True)
    if not start:
        return
    print('ready',cmd('mq2_qa ready'),flush=True)
    initial=wait_live()
    assert status()['score']==[0,0]
    assert all(p['money']==800 for p in initial['clients']),initial
    return initial
def clear():
    assert cmd('mq2_clear')=='cleared'
    assert status()['idle'] is True
    assert cmd(f'mq2_load {mid} {generation}')=='stale_generation'
def events():
    return [json.loads(l) for l in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if json.loads(l)['match_id']==mid]

assert 'round_open' in snapshot(), 'QA-only binary required'
if a.scenario=='smoke':
    initial=load(solo=True)
    # The opponent may still settle onto the floor after spawning. The reported
    # regression concerns the roster player being forcibly moved while alive.
    before={p['id']:p['xyz'] for p in initial['clients'] if p['slot']>=0}
    time.sleep(3)
    after=snapshot()
    assert before=={p['id']:p['xyz'] for p in after['clients'] if p['slot']>=0}, (initial,after)
    assert cmd('mq2_qa eliminate 2').endswith('qa_damage_applied')
    assert status()['score']==[1,0]
    assert len([e for e in events() if e['type']=='live'])==1
    solo_round=[e for e in events() if e['type']=='round'][-1]['data']['players']['76561198000000000']
    assert solo_round['kills']==1 and solo_round['damage']==100, solo_round
    clear()
    print('PASS solo start, no teleport, real round 1:0, 1 kill / 100 damage, cleanup, stale assignment',flush=True)
elif a.scenario=='match':
    initial=load()
    expected=[0,0]
    # Regulation 15:15, first OT 3:3, second OT 4:0 -> 22:18.
    winners=[1]*15+[2]*15+[1]*3+[2]*3+[1]*4
    for n,winner in enumerate(winners):
        if n: wait_live()
        assert cmd(f'mq2_qa eliminate {3-winner}').endswith('qa_damage_applied')
        expected[winner-1]+=1
        got=status()
        assert got['score']==expected, (n,got,expected)
        assert got['healthy'], got
        print('round',n+1,expected,got['phase'],flush=True)
    ev=events()
    assert len([e for e in ev if e['type']=='live'])==1
    end=[e for e in ev if e['type']=='finished']
    assert len(end)==1 and end[0]['data']['team1_score']==22 and end[0]['data']['team2_score']==18,end
    stats=end[0]['data']['players']
    assert sum(v['kills'] for v in stats.values())==200, stats
    assert sum(v['deaths'] for v in stats.values())==200, stats
    assert all(v['rounds']==40 for v in stats.values()),stats
    assert sum(v['damage'] for v in stats.values())==20000,stats
    clear()
    print('PASS 5v5, 40 real rounds, both halves, repeated OT, 22:18, 200 kills/deaths, 20000 damage',flush=True)
elif a.scenario=='short':
    load(size=2, map_name='de_nuke')
    for n in range(9):
        if n: wait_live()
        if n==1:
            assert cmd('mq2_qa drop 0').endswith('qa_drop')
            assert cmd('mq2_qa add 0')=='qa_added'
            time.sleep(1)
            assert len(snapshot()['clients'])==4
        assert cmd('mq2_qa eliminate 2').endswith('qa_damage_applied')
        assert status()['score']==[n+1,0]
        print('short round',n+1,flush=True)
    ev=events()
    end=[e for e in ev if e['type']=='finished'][0]['data']
    assert end['team1_score']==9 and end['team2_score']==0
    assert sum(v['kills'] for v in end['players'].values())==18,end
    assert sum(v['damage'] for v in end['players'].values())==1800,end
    assert len([e for e in ev if e['type']=='connected' and not e['data']['connected']])==1,ev
    clear()
    print('PASS map change, 2v2 MR8 9:0, reconnect preserves stats, cleanup',flush=True)
elif a.scenario in ('reconnect-solo','reconnect-2v2','reconnect-5v5'):
    solo=a.scenario=='reconnect-solo'
    size=2 if a.scenario=='reconnect-2v2' else 5
    load(size=size, solo=solo, start=False)
    t=time.monotonic()
    cmd('mq2_qa ready')
    initial=wait_live(fast=False)
    elapsed=time.monotonic()-t
    assert elapsed>=16, ('three real restarts plus freeze expected',elapsed)
    assert status()['restarts_completed']==3
    assert all(p['money']==800 for p in initial['clients']), initial
    cmd('mq2_qa eliminate 2')
    assert status()['score']==[1,0]
    wait_live()
    before=snapshot()
    money={p['slot']:p['money'] for p in before['clients'] if p['slot']>=0}
    assert cmd('mq2_qa menus 0')=='qa_menus_pass'
    rounds_before=[e for e in events() if e['type']=='round']
    for i in range(1 if solo else size): cmd(f'mq2_qa drop {i}')
    time.sleep(3)
    empty=snapshot()
    assert not empty['engine_started'], ('real NeededPlayersCheck must see empty side',empty)
    assert status()['healthy'], status()
    assert all(a>=b for a,b in zip(status()['score'],[1,0]))
    for i in range(1 if solo else size): assert cmd(f'mq2_qa add {i}')=='qa_added'
    time.sleep(2)
    returned=snapshot()
    assert cmd('mq2_qa menus 0')=='qa_menus_pass'
    current=status()
    assert current['healthy'] and current['reconnect_resumes']==1, current
    assert current['matchid']==f'{mid}:{generation}'
    # A returning late player waits dead for the next competitive round;
    # the GameDLL may already resolve elimination on the repopulated side.
    for p in returned['clients']:
        if 0<=p['slot']<(1 if solo else size):
            assert returned['roster'][p['slot']]['restored_money']==money[p['slot']], (money,returned)
    round_ev=[e for e in events() if e['type']=='round']
    assert round_ev[:len(rounds_before)]==rounds_before
    assert len({e['event_id'] for e in events()})==len(events())
    assert len([e for e in events() if e['type']=='loaded'])==1
    assert len([e for e in events() if e['type']=='live'])==1
    print('reconnect',a.scenario,'startup_seconds',round(elapsed,2),'status',current,'clients',returned,flush=True)
    # Continue a genuine elimination round after any reconnect elimination.
    wait_live()
    expected=status()['score']
    cmd('mq2_qa eliminate 2')
    expected[0]+=1
    assert status()['score']==expected, status()
    clear()
    print('PASS',a.scenario,'empty-side lifecycle, identity, economy, immutable stats and continued scoring',flush=True)
elif a.scenario=='abandon':
    load()
    assert cmd('mq2_qa menus 0')=='qa_menus_pass'
    cmd('mq2_qa talk 1 ff')
    assert snapshot()['vote_team']==0, 'vote before abandon'
    cmd('mq2_qa eliminate 2')
    wait_live()
    cmd('mq2_qa drop 0')
    cmd('mq2_qa eliminate 2')
    until=time.monotonic()+15
    while not snapshot()['paused']:
        assert time.monotonic()<until, 'disconnect did not pause next round'
    assert status()['score']==[2,0]
    started=time.monotonic()
    assert any(e['type']=='reconnect_window' and e['data']['stage']=='pause' for e in events())
    print('90 second reconnect pause started (real clock)',flush=True)
    while not any(e['type']=='reconnect_window' and e['data']['stage']=='grace' for e in events()):
        assert time.monotonic()-started<100
        assert not any(e['type']=='abandoned' for e in events())
        time.sleep(1)
    pause_elapsed=time.monotonic()-started
    assert pause_elapsed>=87, pause_elapsed
    grace_started=time.monotonic()
    print('pause ended after',round(pause_elapsed,2),'seconds; 180 second grace started',flush=True)
    while not any(e['type']=='abandoned' for e in events()):
        assert time.monotonic()-grace_started<190
        time.sleep(1)
    grace_elapsed=time.monotonic()-grace_started
    assert grace_elapsed>=179, grace_elapsed
    assert len([e for e in events() if e['type']=='abandoned'])==1
    assert status()['healthy']
    print('abandon after grace',round(grace_elapsed,2),'seconds',flush=True)
    # Late reconnect is allowed for THIS match. It cannot erase the penalty.
    cmd('mq2_qa add 0')
    cmd('mq2_qa talk 1 ff')
    assert snapshot()['vote_team']==0, 'surrender with full team'
    cmd('mq2_qa drop 0')
    cmd('mq2_qa talk 1 ff')
    vote=snapshot()
    assert vote['vote_team']==1 and vote['vote_yes']==1 and vote['vote_eligible']==4,vote
    cmd('mq2_qa talk 5 yes')
    cmd('mq2_qa talk 1 yes')
    assert snapshot()['vote_yes']==1, 'opponent or duplicate vote counted'
    cmd('mq2_qa talk 2 yes')
    assert status()['phase']=='live', 'two of four is not a majority'
    cmd('mq2_qa talk 3 yes')
    assert status()['phase']=='finished'
    ev=events()
    assert len([e for e in ev if e['type']=='abandoned'])==1
    result=[e for e in ev if e['type']=='surrendered']
    assert len(result)==1 and result[0]['data']['loser_team']==1
    assert len(result[0]['data']['yes_votes'])==3
    assert not any(e['type']=='finished' for e in ev), 'duplicate settlement path'
    (root.parent.parent/'abandon-events.json').write_text(json.dumps(ev,indent=2))
    clear()
    print('PASS real-time 90 + 180, late return, one abandon, majority 3/4, unique surrender and cleanup',flush=True)
elif a.scenario in ('recovery-direct','recovery-map','recovery-arm'):
    load(size=2)
    cmd('mq2_qa eliminate 2')
    wait_live()
    assert cmd('mq2_qa menus 0')=='qa_menus_pass'
    if a.scenario=='recovery-arm':
        print('ARMED process restart: score and active marker', status(),flush=True)
    else:
        cmd('mq2_qa direct-reset' if a.scenario=='recovery-direct' else 'changelevel de_nuke')
        until=time.monotonic()+20
        while True:
            try:
                got=status()
                if got['phase']=='recovery' and not got['healthy']: break
            except (ValueError,OSError,RuntimeError): pass
            assert time.monotonic()<until, 'recovery not entered'
        assert got['matchid']==f'{mid}:{generation}',got
        assert len([e for e in events() if e['type']=='live'])==1
        clear()
        print('PASS',a.scenario,'quarantine, no replayed live, normal cleanup and stale generation',flush=True)
elif a.scenario=='recovery-verify':
    got=status()
    assert got['phase']=='recovery' and not got['healthy'],got
    mid,gen=got['matchid'].split(':'); generation=int(gen)
    assert len([e for e in events() if e['type']=='live'])==1
    clear()
    print('PASS process restart quarantine, no replayed live, normal cleanup and stale generation',flush=True)
elif a.scenario=='lifecycle':
    load(size=2, start=False)
    cmd('mq2_qa ready')
    until=time.monotonic()+8
    while status()['phase']=='warmup':
        assert time.monotonic()<until, 'ready never began startup'
    assert status()['phase']=='starting'
    cmd('mq2_qa drop 0')
    assert status()['phase']=='warmup'
    assert not snapshot()['lo3']
    cmd('mq2_qa add 0')
    cmd('mq2_qa ready')
    wait_live()
    cmd('mq2_qa timeout 0')
    cmd('mq2_qa eliminate 2')
    # Advance the scheduled round restart, then observe a real pause.
    cmd('mq2_qa fast')
    until=time.monotonic()+12
    while not snapshot()['paused']:
        assert time.monotonic()<until, 'timeout never paused'
    assert status()['healthy']
    wait_live()
    assert status()['healthy']
    assert any(e['type']=='pause' for e in events())
    assert any(e['type']=='resume' for e in events())
    cmd('sv_restart 1')
    until=time.monotonic()+8
    while status()['healthy']:
        assert time.monotonic()<until, 'unsolicited restart was not quarantined'
    assert status()['phase']=='recovery'
    clear()
    print('PASS interrupted LO3, restart /ready, tactical pause/resume, unsolicited restart quarantine, cleanup',flush=True)
else:
    raise ValueError('unknown scenario')
