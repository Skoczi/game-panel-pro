"""Loopback-only production-binary loading/cleanup check in the isolated lab."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

root=Path(sys.argv[1]).resolve()
assert '/csco-lab/matchbot-041/' in str(root), 'Isolated lab required'
spec=importlib.util.spec_from_file_location('mq',sys.argv[2])
agent=importlib.util.module_from_spec(spec); spec.loader.exec_module(agent)
rcon=agent.GoldSrcRcon('127.0.0.1',27095,os.environ['MQ2_QA_RCON_PASSWORD'])
def cmd(value):
    time.sleep(1.1)
    return rcon.command(value)
status=json.loads(cmd('mq2_status'))
assert status['controller_version']=='0.4.1' and status['healthy'] and status['idle'], status
assert 'round_open' not in cmd('mq2_qa snapshot'), 'QA binary must not be released'
assert 'CSCO.GG' in cmd('mb_log_tag'), 'Wrong default prefix'
generation=int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text())+1
mid=f'{time.time_ns():024x}'
payload={'game':'cs16','match_id':mid,'generation':generation,'map':'de_dust2','team_size':5,
         'config_hash':'b'*64,'rules':{'mr':15,'ot_mr':3,'test':True},
         'players':[{'steam_id':'76561198000000000','team':1}]}
(root/f'addons/amxmodx/configs/mq2/{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(payload))
assert cmd(f'mq2_load {mid} {generation}')=='loaded'
status=json.loads(cmd('mq2_status'))
assert status['phase']=='warmup' and status['healthy'] and status['rules_ready'],status
assert cmd('mq2_clear')=='cleared'
assert json.loads(cmd('mq2_status'))['idle']
assert cmd(f'mq2_load {mid} {generation}')=='stale_generation'
print('PASS production 0.4.1: native load, CSCO.GG default, no QA command, profile, cleanup and stale assignment',flush=True)
