MixQueue2 / CS 1.6

EN: Requires Linux i386 / glibc 2.36+, ReHLDS, ReGameDLL_CS and Metamod.
Tested engine versions: ReHLDS 3.15.0.896, ReGameDLL 5.30.0.814, Metamod-r 1.3.0.149.
Stop an idle server and back it up. Disable mq2_match.amxx and other match/respawn/team controllers.
Copy addons/ into cstrike/. APPEND, do not overwrite, addons/metamod/plugins.ini:
linux addons/matchbot/dlls/matchbot_csco_mm.so
Install the separate Python agent 0.4.0. Preserve adapter=amxx, identities, secrets,
spool and journal paths; they remain the integration contract, not the binary type.
Restart the server: meta list must show MatchBot CSCO 0.4.0 RUN; mq2_status must
show controller=matchbot, healthy=true, rules_ready=true and idle=true when empty.
Run a solo test, then human match acceptance before enabling public queues.
GPL-3.0 complete corresponding source and build scripts are included in source/.
PL: Szczegolowa instalacja, profil turniejowy i odzyskiwanie: INSTALL.pl.md.

No credentials are included. Download your PRIVATE configuration separately from the server's Setup dialog.
Compilation is verified; test a full match on your specific game build before enabling public queues.
Game plugin source is included. Third-party notices and licenses are preserved in licenses/ and include headers.
Package 0.4.0: MatchBot CSCO 0.4.0, agent protocol 2; unchanged Source bridge 0.2.0.

PL: Paczka nie zawiera sekretow. Prywatna konfiguracje pobierz osobno z okna Instalacja.
Kompilacja jest sprawdzona; odbior rzeczywistego meczu na konkretnym buildzie gry nadal jest wymagany.
