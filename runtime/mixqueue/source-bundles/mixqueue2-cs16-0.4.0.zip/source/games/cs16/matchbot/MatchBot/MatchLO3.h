#pragma once

class CMatchLO3
{
public:
	void Start();
	void RoundRestart();
    bool Running() const { return m_Restart > 0; }
    void Stop() { m_Restart = 0; }

private:
	int m_Restart = 0;
};

extern CMatchLO3 gMatchLO3;
