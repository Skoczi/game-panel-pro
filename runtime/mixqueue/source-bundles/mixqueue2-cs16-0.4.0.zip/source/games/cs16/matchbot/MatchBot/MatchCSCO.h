// CSCO integration for MatchBot. GPL-3.0; upstream attribution in ../LICENSE.
#pragma once
#include "MatchCSCOContract.h"

class CMatchCSCO {
public:
    void Activate();
    void Deactivate();
    void Frame();
    bool AllowState(int state);
    void StateChanged(int state);
    bool CanStart();
    bool Connect(edict_t* entity, char* reject);
    void Disconnect(edict_t* entity);
    int TeamSlot(CBasePlayer* player);
    bool ClientCommand(CBasePlayer* player,const char* command,const char* argument);
    void Joined(CBasePlayer* player);
    void Spawned(CBasePlayer* player);
    void Swapped();
    void FreezeEnd();
    bool AllowRoundEnd();
    bool AllowEngineReset();
    void RoundEnded();
    void Damage(CBasePlayer* victim,entvars_t* attacker,float actual);
    void Death(CBaseEntity* killer,CBasePlayer* victim,int rarity);
    bool Active() const { return !config.id.empty() && !quarantine && !loading; }
    bool Scoring() const { return Active() && roundOpen; }
    bool ReadyForLive() const;
    bool AutoReady(CBasePlayer* player) const { return config.test && player->entindex()==bot; }
    void Profile(int state);
    static void StatusCommand();
    static void LoadCommand();
    static void ClearCommand();
    static bool ScoreInfo(int destination,int type,const float* origin,edict_t* entity);
#ifdef MQ2_QA
    static void QACommand();
#endif
private:
    mq2::Config config;
    bool quarantine=false, loading=false, live=false, roundOpen=false, teamOneCT=true;
    bool creatingBot=false, clearing=false, paused=false, pendingRound=false;
    int timeouts[2]={0,0};
    int bot=0, sequence=0, highWater=0, score[2]={0,0};
    float nextFrame=0;
    float authDeadline[33]={};
    std::string boot, root, marker, journal, highPath, phase="idle";
#ifdef MQ2_QA
    int qaSlots[33]={};
#endif
    int Slot(edict_t* entity) const;
    TeamName Side(int logicalTeam) const;
    void Kick(edict_t* entity);
    void SetPhase(const std::string& value);
    void Persist(const std::string& value);
    void Emit(const std::string& type,const std::string& data,const std::string& stable="");
    void Fail(const char* code);
    void Load(const std::string& id,int generation);
    void Clear();
    void Ready();
    void EnsureBot();
    void ReportScore(bool finished);
    bool RulesReady() const;
    bool AllPresent() const;
    static void Print(const std::string& value);
};
extern CMatchCSCO gMatchCSCO;
