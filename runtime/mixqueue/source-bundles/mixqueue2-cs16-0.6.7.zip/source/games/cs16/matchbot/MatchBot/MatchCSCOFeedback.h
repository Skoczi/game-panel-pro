// CSCO pause consent and round ledger. GPL-3.0. No engine-slot identities here.
#pragma once
#include "MatchCSCOContract.h"
#include <array>
#include <cmath>

namespace mq2 {
inline std::string wire_text(std::string text,size_t limit=150) {
    for(auto& c:text) if(static_cast<unsigned char>(c)<32 || c==127 || c=='^') c=' ';
    return clip(text,limit);
}
enum class Consent { denied, no_pause, duplicate, waiting, ready };
struct PauseConsent {
    std::string scope;
    unsigned serial=0, votes=0;
    int team=0;
    bool pending=false, running=false;
    void reset() {scope.clear();votes=0;team=0;pending=running=false;++serial;}
    bool request(const std::string& match,int logicalTeam) {
        if(match.empty() || logicalTeam<1 || logicalTeam>2 || pending || running) return false;
        reset();scope=match;team=logicalTeam;pending=true;return true;
    }
    void start() {if(pending) {pending=false;running=true;votes=0;}}
    Consent vote(const std::string& match,int logicalTeam,bool captain) {
        if(!captain || logicalTeam<1 || logicalTeam>2) return Consent::denied;
        if(!running || scope!=match) return Consent::no_pause;
        const unsigned bit=1U<<(logicalTeam-1);
        if(votes&bit) return Consent::duplicate;
        votes|=bit;
        return votes==3?Consent::ready:Consent::waiting;
    }
};
inline int display_damage(float value) {return int(std::ceil(std::max(0.0f,value)));}
inline float hp_loss(float before,float after) {
    if(!std::isfinite(before) || !std::isfinite(after)) return 0;
    return std::max(0.0f,std::min(std::max(0.0f,before),before-std::max(0.0f,after)));
}
struct DamageSnapshot {
    std::array<std::array<float,33>,33> damage{};
    std::array<std::array<int,33>,33> hits{};
    std::array<std::string,33> identity{},name{},locale{};
    std::array<int,33> team{};
    std::string scope;
    unsigned serial=0;
};
struct DamageLedger {
    DamageSnapshot current,completed;
    unsigned epoch=0;
    bool open=false,pending=false,available=false;
    void reset() {++epoch;current=DamageSnapshot();completed=DamageSnapshot();open=pending=available=false;}
    void begin(const std::string& scope) {
        ++epoch;current=DamageSnapshot();current.scope=scope;current.serial=epoch;open=true;pending=false;
    }
    void end() {if(open) {open=false;pending=true;}}
    bool add(unsigned token,int from,int to,float actual) {
        if(token!=current.serial || (!open && !pending) || to<1 || to>32 || from<0 || from>32 ||
           !std::isfinite(actual) || actual<=0) return false;
        if(from==to) from=0; // Self/world/C4 cannot inherit another player's slot.
        current.damage[from][to]+=actual;++current.hits[from][to];return true;
    }
    bool seal() {if(!pending)return false;completed=current;pending=false;available=true;return true;}
};
inline std::string hits_text(int hits,bool pl) {
    if(!pl) return std::to_string(hits)+(hits==1?" hit":" hits");
    const int last=hits%10,lastTwo=hits%100;
    return std::to_string(hits)+(hits==1?" trafienie":last>=2 && last<=4 && !(lastTwo>=12 && lastTwo<=14)?" trafienia":" trafien");
}
inline std::vector<std::string> damage_lines(const DamageSnapshot& round,int viewer) {
    std::vector<std::string> lines;
    if(viewer<1 || viewer>32 || round.identity[viewer].empty()) return lines;
    const bool pl=round.locale[viewer]=="pl";
    for(int target=1;target<=32;++target) {
        const int dealt=round.hits[viewer][target],taken=round.hits[target][viewer];
        if(target==viewer || round.identity[target].empty() || (!dealt && !taken)) continue;
        const bool friendly=round.team[viewer]==round.team[target];
        lines.push_back("vs "+wire_text(round.name[target],28)+(friendly?(pl?" [DRUZYNA]":" [TEAM]"):"")+
            (pl?" | Zadane: ":" | Dealt: ")+std::to_string(display_damage(round.damage[viewer][target]))+
            " ("+hits_text(dealt,pl)+")"+(pl?" | Otrzymane: ":" | Taken: ")+
            std::to_string(display_damage(round.damage[target][viewer]))+" ("+hits_text(taken,pl)+")");
    }
    if(round.hits[0][viewer]) lines.push_back(std::string(pl?"Swiat / C4 / sam | Otrzymane: ":"World / C4 / self | Taken: ")+
        std::to_string(display_damage(round.damage[0][viewer]))+" ("+hits_text(round.hits[0][viewer],pl)+")");
    if(lines.empty()) lines.push_back(pl?"Brak obrazen w tej rundzie.":"No damage this round.");
    return lines;
}
}
