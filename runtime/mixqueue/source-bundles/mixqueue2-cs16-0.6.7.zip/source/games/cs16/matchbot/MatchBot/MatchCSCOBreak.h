// Assignment-scoped between-halves clock. GPL-3.0; independent of timeouts.
#pragma once
#include <algorithm>
#include <cmath>
#include <string>

namespace mq2 {
constexpr int HALF_BREAK_SECONDS=20;
// Count only the current overtime, never regulation rounds (MR8 is not
// divisible by MR3). The winner check takes precedence at the call site.
inline bool overtime_half_complete(int one,int two,int half) {
    const int played=one+two;
    return half>0 && one>=0 && two>=0 && played>0 && played%half==0;
}
struct HalfBreak {
    std::string scope;
    float since=0,until=0;
    int nextState=0;
    bool active=false,beforeOvertime=false;
    bool start(const std::string& current,float now,int next,bool overtime) {
        if(active || current.empty() || !std::isfinite(now)) return false;
        scope=current;since=now;until=now+HALF_BREAK_SECONDS;
        nextState=next;beforeOvertime=overtime;active=true;return true;
    }
    bool due(const std::string& current,float now) const {
        return active && scope==current && std::isfinite(now) && now>=until;
    }
    int remaining(float now) const {
        return active?std::max(0,int(std::ceil(until-now))):0;
    }
    void reset() { *this=HalfBreak(); }
};
}
