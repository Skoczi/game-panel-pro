#include "precompiled.h"

CMatchPause gMatchPause;

void CMatchPause::ServerActivate() {
    gMatchTask.Remove(TASK_PAUSE_MATCH);
    m_Pause=false;m_Paused=false;m_PauseTeam.clear();m_BuyTime=0;m_BuyTimeSaved=false;
}
bool CMatchPause::QueueTeam(const std::string& name) {
    const int state=gMatchBot.GetState();
    if(!g_pGameRules || m_Pause || m_Paused || (!gMatchCSCO.Managed() && CSGameRules()->IsFreezePeriod()) ||
       (state!=STATE_FIRST_HALF && state!=STATE_SECOND_HALF && state!=STATE_OVERTIME)) return false;
    m_PauseTeam=name;m_Pause=true;return true;
}
bool CMatchPause::Init(CBasePlayer* player,TeamName team) {
    // All legacy admin menus/votes must use the signed captain policy in CSCO.
    if(gMatchCSCO.Managed()) return gMatchCSCO.RequestTimeout(player);
    if(player && !gMatchAdmin.Access(player->entindex(),ADMIN_LEVEL_B)) {
        gMatchUtil.SayText(player->edict(),PRINT_TEAM_DEFAULT,_T("You do not have access to that command."));return false;
    }
    const std::string name=player?STRING(player->pev->netname):gMatchBot.GetTeam(team,false);
    if(!QueueTeam(name)) return false;
    gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,_T("^3%s^1 Paused Match: Game will pause on next round start."),name.c_str());
    return true;
}
void CMatchPause::TryPending() {
    if(m_Pause && !m_Paused && g_pGameRules && CSGameRules()->IsFreezePeriod()) Pause();
}
void CMatchPause::RoundRestart() {
    gMatchCSCO.BeginLiveFreeze();
    if(gMatchCSCO.StartDisconnectPause()) return;
    const int state=gMatchBot.GetState();
    if(state!=STATE_FIRST_HALF && state!=STATE_SECOND_HALF && state!=STATE_OVERTIME) return;
    if(m_Pause) {Pause();return;}
    if(gMatchBot.m_PauseAuto->value>0) {
        const auto count=gMatchUtil.GetCount();
        if(count[SPECTATOR]<1 && count[TERRORIST]+count[CT]<int(gMatchBot.m_PlayersMin->value)) {
            m_PauseTeam.clear();Pause();
        }
    }
}
void CMatchPause::Pause(int seconds) {
    if(m_Paused || !g_pGameRules || (gMatchCSCO.Managed() && !gMatchCSCO.CanResumePause(false))) return;
    m_Paused=true;m_Pause=false;
    const int duration=seconds>0?seconds:gMatchCSCO.Managed()?mq2::TACTICAL_SECONDS:gMatchBot.m_PauseTime && gMatchBot.m_PauseTime->value>0?int(gMatchBot.m_PauseTime->value):60;
    m_BuyTime=gMatchBot.m_BuyTime->value;m_BuyTimeSaved=true;
    g_engfuncs.pfnCvar_DirectSet(gMatchBot.m_BuyTime,std::to_string(duration/60.0f).c_str());
    SetRoundTime(duration+1,true);
    gMatchTask.Create(TASK_PAUSE_MATCH,0.5f,true,(void*)PauseTimer,duration);
    if(gMatchCSCO.Managed()) gMatchCSCO.PauseStarted();
    else gMatchUtil.SayText(nullptr,PRINT_TEAM_DEFAULT,"Match paused: %d seconds.",duration);
}
bool CMatchPause::Resume(bool early) {
    if(!m_Paused || !g_pGameRules || !gMatchCSCO.CanResumePause(early)) return false;
    // One completion path for expiry and consent. No restart/load/spawn or stat reset.
    gMatchTask.Remove(TASK_PAUSE_MATCH);
    m_Paused=false;m_Pause=false;
    if(m_BuyTimeSaved) g_engfuncs.pfnCvar_DirectSet(gMatchBot.m_BuyTime,std::to_string(m_BuyTime).c_str());
    m_BuyTimeSaved=false;
    SetRoundTime(int(gMatchBot.m_Freezetime->value),true);
    gMatchCSCO.PauseResumed();m_PauseTeam.clear();
    return true;
}
void CMatchPause::PauseTimer(int duration) {
    if(!g_pGameRules || !gMatchPause.m_Paused) return;
    const int left=duration-int(gpGlobals->time-CSGameRules()->m_fRoundStartTime);
    if(left<=0) {gMatchPause.Resume();return;}
    if(gMatchCSCO.Managed()) gMatchCSCO.PauseHud(left);
    else gMatchUtil.HudMessage(nullptr,gMatchUtil.HudParam(0,255,0,-1.0,0.2,0,0.53,0.53,0,0,1),
        "MATCH PAUSED BY %s\n%d SECONDS LEFT",gMatchPause.m_PauseTeam.c_str(),left);
}

void CMatchPause::SetRoundTime(int Time, bool FreezePeriod)
{
	// If has CS Game Rules
	if (g_pGameRules)
	{
		// If is not a full sv_restart
		if (!CSGameRules()->m_bCompleteReset)
		{
			// Set Freeze Period 
			CSGameRules()->m_bFreezePeriod = FreezePeriod;

			// Set Round Time Seconds
			CSGameRules()->m_iRoundTimeSecs = Time;

			// Set Round Time Freeze Time
			CSGameRules()->m_iIntroRoundTime = Time;

			// Set Round Start Time
			CSGameRules()->m_fRoundStartTime = gpGlobals->time;
		}
	}

	//  Message Index
	static int iMsgRoundTime;

	// If has message index or set message index if is null
	if (iMsgRoundTime || (iMsgRoundTime = gpMetaUtilFuncs->pfnGetUserMsgID(&Plugin_info, "RoundTime", NULL)))
	{
		g_engfuncs.pfnMessageBegin(MSG_ALL, iMsgRoundTime, NULL, NULL);
		g_engfuncs.pfnWriteShort(Time);
		g_engfuncs.pfnMessageEnd();
	}
}
