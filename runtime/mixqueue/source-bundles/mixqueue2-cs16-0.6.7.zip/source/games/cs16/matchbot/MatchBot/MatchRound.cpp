#include "precompiled.h"

CMatchRound gMatchRound;

void CMatchRound::ServerActivate()
{
	// Match stats commands
	this->m_StatsCommandFlags = CMD_ALL;
    ResetCSCO();
}

void CMatchRound::SetState(int State, bool KnifeRound)
{
	// New Match State
	this->m_State = State;

	// All commands are enabled by default
	this->m_StatsCommandFlags = CMD_ALL;

	// If variable is not null
	if (gMatchBot.m_StatsCommands)
	{
		// If string is not null
		if (gMatchBot.m_StatsCommands->string)
		{
			// If string is not empty
			if (gMatchBot.m_StatsCommands->string[0] != '\0')
			{
				// Read menu flags from team pickup variable
				this->m_StatsCommandFlags |= gMatchAdmin.ReadFlags(gMatchBot.m_StatsCommands->string);
			}
		}
	}
}

// The existing round matrices now use signed roster indices for CSCO.
// A disconnected/reused engine slot cannot inherit another participant's damage.
void CMatchRound::ResetCSCO() {
    ledger.reset();for(auto& lines:outgoing) lines.clear();sent.fill(0);manualAt.fill(0);nextFeedback=0;
    gMatchTask.Remove(TASK_ROUND_END_STATS);
}
void CMatchRound::RoundStart() {
    if(gMatchCSCO.Managed()) {
        if(!gMatchCSCO.Scoring() || gMatchPause.m_Paused) return;
        ledger.begin(gMatchCSCO.Scope());gMatchCSCO.DamageRoster(ledger.current);
        for(auto& lines:outgoing) lines.clear();
        sent.fill(0);return;
    }
    ledger.begin("legacy");
}
void CMatchRound::RoundEnd(int winStatus,ScenarioEventEndRound event,float delay) {
    if(winStatus!=WINSTATUS_TERRORISTS && winStatus!=WINSTATUS_CTS) return;
    if(gMatchCSCO.Managed()) {
        if(ledger.current.scope==gMatchCSCO.Scope()) ledger.end();
        return; // Never schedule the old cvar-based stats printer for CSCO.
    }
    gMatchTask.Create(TASK_ROUND_END_STATS,1.0f,false,(void*)RoundEndStats,m_State);
}
void CMatchRound::PlayerPutInServer(edict_t* entity) {
    if(gMatchCSCO.Managed() || FNullEnt(entity)) return;
    const int index=ENTINDEX(entity);if(index<1 || index>32)return;
    ledger.current.damage[index].fill(0);ledger.current.hits[index].fill(0);
}
void CMatchRound::PlayerDisconnect(edict_t* entity) {
    if(gMatchCSCO.Managed() || FNullEnt(entity)) return;
    const int index=ENTINDEX(entity);if(index<1 || index>32)return;
    for(int i=0;i<=32;++i) {ledger.current.damage[i][index]=0;ledger.current.hits[i][index]=0;}
}
void CMatchRound::PlayerDamage(unsigned token,int victim,int attacker,float actual) {
    ledger.add(token,attacker,victim,actual);
}
void CMatchRound::FeedbackFrame() {
    if(!gMatchCSCO.Active() || ledger.current.scope!=gMatchCSCO.Scope()) return;
    // Frame runs after TakeDamage unwinds: include the lethal final hit even when
    // GameDLL calls RoundEnd inside that damage call, including the final round.
    if(ledger.seal()) {
        sent.fill(0);
        for(int i=1;i<=32;++i) outgoing[i]=mq2::damage_lines(ledger.completed,i);
        nextFeedback=gpGlobals->time;
    }
    if(gMatchCSCO.Scoring() || ledger.pending || !ledger.available || gpGlobals->time<nextFeedback) return;
    nextFeedback=gpGlobals->time+0.18f;
    for(int i=1;i<=32;++i) {
        const auto row=gMatchCSCO.RosterPlayer(i);
        if(!row || row->steam!=ledger.completed.identity[i] || !row->client || sent[i]>=outgoing[i].size()) continue;
        // One line per recipient per tick, only outside an open live round.
        gMatchCSCO.Feedback(i,outgoing[i][sent[i]++]);
    }
}
bool CMatchRound::ShowCSCO(CBasePlayer* player,bool manual) {
    const int index=gMatchCSCO.RosterIndex(player);const auto row=gMatchCSCO.RosterPlayer(index);
    if(!row) return false;
    const bool pl=row->locale=="pl";
    if(!gMatchCSCO.Active() || gMatchCSCO.Scoring() || ledger.pending || !ledger.available ||
       ledger.completed.scope!=gMatchCSCO.Scope() || ledger.completed.identity[index]!=row->steam) {
        gMatchCSCO.Feedback(index,pl?"Podsumowanie obrazen bedzie dostepne po zakonczeniu rundy.":"Damage summary is available after the round ends.");return false;
    }
    if(manual && gpGlobals->time<manualAt[index]) return true;
    manualAt[index]=gpGlobals->time+3.0f;
    // If automatic output is still draining, reuse that same queue instead of duplicating it.
    if(sent[index]<outgoing[index].size()) return true;
    outgoing[index]=mq2::damage_lines(ledger.completed,index);sent[index]=0;
    return true;
}

// Show Enemy HP
bool CMatchRound::ShowHP(CBasePlayer* Player, bool Command, bool InConsole)
{
	if (!Command || (this->m_StatsCommandFlags & CMD_HP))
	{
		if (this->m_State == STATE_FIRST_HALF || this->m_State == STATE_SECOND_HALF || this->m_State == STATE_OVERTIME)
		{
			if (g_pGameRules)
			{
				if (!Player->IsAlive() || CSGameRules()->m_bRoundTerminating)
				{
					if (Player->m_iTeam == TERRORIST || Player->m_iTeam == CT)
					{
						auto StatsCount = 0;

						auto Players = gMatchUtil.GetPlayers(true, true);

						for (auto Target : Players)
						{
							if (Target->m_iTeam != Player->m_iTeam)
							{
								if (Target->IsAlive())
								{
									StatsCount++;

									gMatchUtil.SayText
									(
										Player->edict(),
										Target->entindex(),
										_T("^3%s^1 with %d HP (%d AP)"),
										STRING(Target->edict()->v.netname),
										(int)Target->edict()->v.health,
										(int)Target->edict()->v.armorvalue
									);
								}
							}
						}

						if (!StatsCount && !InConsole)
						{
							gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("No one is alive."));
						}

						return true;
					}
				}
			}
		}

		gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("Unable to use this command now."));
	}

	return false;
}

// Show Damage
bool CMatchRound::ShowDamage(CBasePlayer* Player, bool Command, bool InConsole)
{
    if(gMatchCSCO.Managed()) return ShowCSCO(Player,Command);
	if (!Command || (this->m_StatsCommandFlags & CMD_DMG))
	{
		if (this->m_State == STATE_FIRST_HALF || this->m_State == STATE_SECOND_HALF || this->m_State == STATE_OVERTIME)
		{
			if (g_pGameRules)
			{
				if (!Player->IsAlive() || CSGameRules()->m_bRoundTerminating || CSGameRules()->IsFreezePeriod())
				{
					if (Player->m_iTeam == TERRORIST || Player->m_iTeam == CT)
					{
						auto StatsCount = 0;

						auto Players = gMatchUtil.GetPlayers(true, true);

						for (auto Target : Players)
						{
							if (ledger.current.hits[Player->entindex()][Target->entindex()])
							{
								StatsCount++;

								if (!InConsole)
								{
									gMatchUtil.SayText
									(
										Player->edict(),
										Target->entindex(),
										_T("Hit ^3%s^1 %d time(s) (Damage %d)"),
										STRING(Target->edict()->v.netname),
										ledger.current.hits[Player->entindex()][Target->entindex()],
										mq2::display_damage(ledger.current.damage[Player->entindex()][Target->entindex()])
									);
								}
								else
								{
									gMatchUtil.ClientPrint
									(
										Player->edict(),
										PRINT_CONSOLE,
										_T("* Hit %s %d time(s) (Damage %d)"),
										STRING(Target->edict()->v.netname),
										ledger.current.hits[Player->entindex()][Target->entindex()],
										mq2::display_damage(ledger.current.damage[Player->entindex()][Target->entindex()])
									);
								}
							}
						}

						if (!StatsCount && !InConsole)
						{
							gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("You haven't hit anyone this round."));
						}

						return true;
					}
				}
			}
		}

		if (!InConsole)
		{
			gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("Unable to use this command now."));
		}
	}

	return false;
}

// Show Received Damage
bool CMatchRound::ShowReceivedDamage(CBasePlayer* Player, bool Command, bool InConsole)
{
    if(gMatchCSCO.Managed()) return ShowCSCO(Player,Command);
	if (!Command || (this->m_StatsCommandFlags & CMD_RDMG))
	{
		if (this->m_State == STATE_FIRST_HALF || this->m_State == STATE_SECOND_HALF || this->m_State == STATE_OVERTIME)
		{
			if (g_pGameRules)
			{
				if (!Player->IsAlive() || CSGameRules()->m_bRoundTerminating || CSGameRules()->IsFreezePeriod())
				{
					if (Player->m_iTeam == TERRORIST || Player->m_iTeam == CT)
					{
						auto StatsCount = 0;

						auto Players = gMatchUtil.GetPlayers(true, true);

						for (auto Target : Players)
						{
							if (ledger.current.hits[Target->entindex()][Player->entindex()])
							{
								StatsCount++;

								gMatchUtil.SayText
								(
									Player->edict(),
									Target->entindex(),
									_T("Hit by ^3%s^1 %d time(s) (Damage %d)"),
									STRING(Target->edict()->v.netname),
									ledger.current.hits[Target->entindex()][Player->entindex()],
									mq2::display_damage(ledger.current.damage[Target->entindex()][Player->entindex()])
								);
							}
						}

						if (!StatsCount && !InConsole)
						{
							gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("You weren't hit this round."));
						}

						return true;
					}
				}
			}
		}

		gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("Unable to use this command now."));
	}

	return false;
}

// Show Round Summary
bool CMatchRound::ShowSummary(CBasePlayer* Player, bool Command, bool InConsole)
{
    if(gMatchCSCO.Managed()) return ShowCSCO(Player,Command);
	if (!Command || (this->m_StatsCommandFlags & CMD_SUM))
	{
		if (this->m_State == STATE_FIRST_HALF || this->m_State == STATE_SECOND_HALF || this->m_State == STATE_OVERTIME)
		{
			if (g_pGameRules)
			{
				if (!Player->IsAlive() || CSGameRules()->m_bRoundTerminating || CSGameRules()->IsFreezePeriod())
				{
					if (Player->m_iTeam == TERRORIST || Player->m_iTeam == CT)
					{
						auto StatsCount = 0;

						auto Players = gMatchUtil.GetPlayers(true, true);

						for (auto Target : Players)
						{
							if (ledger.current.hits[Player->entindex()][Target->entindex()] || ledger.current.hits[Target->entindex()][Player->entindex()])
							{
								StatsCount++;

								if (!InConsole)
								{
									gMatchUtil.SayText
									(
										Player->edict(),
										Target->entindex(),
										_T("(%d dmg | %d hits) to (%d dmg | %d hits) from ^3%s^1 (%d HP)"),
										mq2::display_damage(ledger.current.damage[Player->entindex()][Target->entindex()]),
										ledger.current.hits[Player->entindex()][Target->entindex()],
										mq2::display_damage(ledger.current.damage[Target->entindex()][Player->entindex()]),
										ledger.current.hits[Target->entindex()][Player->entindex()],
										STRING(Target->edict()->v.netname),
										Target->IsAlive() ? (int)Target->edict()->v.health : 0
									);
								}
								else
								{
									gMatchUtil.ClientPrint
									(
										Player->edict(),
										PRINT_CONSOLE,
										_T("* (%d dmg | %d hits) to (%d dmg | %d hits) from %s (%d HP)"),
										mq2::display_damage(ledger.current.damage[Player->entindex()][Target->entindex()]),
										ledger.current.hits[Player->entindex()][Target->entindex()],
										mq2::display_damage(ledger.current.damage[Target->entindex()][Player->entindex()]),
										ledger.current.hits[Target->entindex()][Player->entindex()],
										STRING(Target->edict()->v.netname),
										Target->IsAlive() ? (int)Target->edict()->v.health : 0
									);
								}
							}
						}

						if (!StatsCount && !InConsole)
						{
							gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("No stats in this round."));
						}

						return true;
					}
				}
			}
		}

		if (!InConsole)
		{
			gMatchUtil.SayText(Player->edict(), PRINT_TEAM_DEFAULT, _T("Unable to use this command now."));
		}
	}

	return false;
}

// Round End Stats
void CMatchRound::RoundEndStats(int State)
{
    if(gMatchCSCO.Managed()) return;
	// Get round end stats type
	auto Type = (int)(gMatchBot.m_RoundEndStats->value);

	// If is enabled
	if (Type > 0)
	{
		// Get Players
		auto Players = gMatchUtil.GetPlayers(true, false);

		// Loop each player
		for (auto Player : Players)
		{
			// Show Damage command
			if (Type == 1 || Type == 3)
			{
				gMatchRound.ShowDamage(Player, false, (Type == 3));
			}
			// Show Summary command
			else if (Type == 2 || Type == 4)
			{
				gMatchRound.ShowSummary(Player, false, (Type == 4));
			}
		}
	}
}
