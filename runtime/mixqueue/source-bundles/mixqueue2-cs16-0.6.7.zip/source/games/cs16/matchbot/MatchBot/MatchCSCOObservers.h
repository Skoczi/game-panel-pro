// Scoped observer permissions. Native runtime and pure contract tests share this parser.
#pragma once
#include "MatchCSCOContract.h"
#include <cstdint>
#include <limits>

namespace mq2 {
inline bool observer_steam(const std::string& value) {
    if(value.size()!=17 || value.find_first_not_of("0123456789")!=std::string::npos) return false;
    const uint64_t n=std::stoull(value);
    return n>76561197960265728ULL && n<=76561202255233023ULL;
}
inline uint64_t observer_number(const std::string& value) {
    if(value.empty() || value.size()>10 || value.find_first_not_of("0123456789")!=std::string::npos)
        throw std::runtime_error("observer_invalid");
    const auto result=std::stoull(value);
    if(result>2147483647ULL) throw std::runtime_error("observer_invalid");
    return result;
}
struct ObserverGrant {
    std::string steam,role,locale;
    bool xray=false;
    uint64_t expires=0;
};
struct ObserverSnapshot {
    std::string id,body;
    unsigned generation=0,revision=0;
    uint64_t expires=0;
    std::vector<ObserverGrant> grants;
    const ObserverGrant* find(const std::string& steam,uint64_t now,bool roster=false) const {
        // Roster membership always wins over an observer grant, including dead players.
        if(roster || steam.empty() || expires<=now) return nullptr;
        for(const auto& grant:grants) if(grant.steam==steam && grant.expires>now) return &grant;
        return nullptr;
    }
};
inline ObserverSnapshot parse_observers(const std::string& body,const std::string& id,unsigned generation,unsigned revision,uint64_t now) {
    if(body.size()>8192 || !hex(id,24) || !generation || !revision || revision>2147483647U)
        throw std::runtime_error("observer_invalid");
    ObserverSnapshot out;out.body=body;
    std::istringstream input(body);std::string line,magic,gen,rev,expiry,extra;
    if(!std::getline(input,line) || line.size()>160) throw std::runtime_error("observer_invalid");
    std::istringstream header(line);
    if(!(header>>magic>>out.id>>gen>>rev>>expiry) || (header>>extra) || magic!="MQ2OBS1")
        throw std::runtime_error("observer_invalid");
    const auto g=observer_number(gen),r=observer_number(rev);
    if(out.id!=id || g!=generation || r!=revision) throw std::runtime_error("observer_scope");
    out.generation=g;out.revision=r;out.expires=observer_number(expiry);
    if(out.expires<=now || out.expires>now+600) throw std::runtime_error("observer_invalid");
    while(std::getline(input,line)) {
        if(line.empty()) continue;
        if(line.size()>128 || out.grants.size()>=16) throw std::runtime_error("observer_invalid");
        ObserverGrant grant;std::string xray;
        std::istringstream row(line);
        if(!(row>>grant.steam>>grant.role>>xray>>expiry>>grant.locale) || (row>>extra) ||
           !observer_steam(grant.steam) || (grant.role!="admin" && grant.role!="commentator") ||
           (xray!="0" && xray!="1") || (grant.locale!="pl" && grant.locale!="en"))
            throw std::runtime_error("observer_invalid");
        grant.xray=xray=="1";grant.expires=observer_number(expiry);
        if(grant.expires<=now || grant.expires>out.expires) throw std::runtime_error("observer_invalid");
        for(const auto& previous:out.grants) if(previous.steam==grant.steam) throw std::runtime_error("observer_invalid");
        out.grants.push_back(grant);
    }
    return out;
}
inline const char* apply_observers(ObserverSnapshot& current,const ObserverSnapshot& next) {
    if(current.revision && (current.id!=next.id || current.generation!=next.generation)) return "observer_scope";
    if(next.revision<current.revision) return "observer_stale";
    if(next.revision==current.revision)
        return next.body==current.body?"observer_already_updated":"observer_stale";
    current=next;return "observer_updated";
}
}
