// Bounded observer snapshots: never follow a final symlink or wait on a FIFO.
#pragma once
#include <string>
#include <stdexcept>
#ifdef _WIN32
#include <windows.h>
#else
#include <cerrno>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace mq2 {
inline std::string read_observer_file(const std::string& path) {
    char data[8193];size_t size=0;
#ifdef _WIN32
    // OPEN_REPARSE_POINT opens the reparse object itself, never its target.
    // No write/delete sharing keeps the opened regular file stable during read.
    HANDLE file=CreateFileA(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
    if(file==INVALID_HANDLE_VALUE) throw std::runtime_error("observer_storage");
    struct Close {HANDLE file;~Close(){CloseHandle(file);}} close={file};
    BY_HANDLE_FILE_INFORMATION info={};
    if(GetFileType(file)!=FILE_TYPE_DISK || !GetFileInformationByHandle(file,&info) ||
       (info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT)))
        throw std::runtime_error("observer_storage");
    if(info.nFileSizeHigh || info.nFileSizeLow>8192) throw std::runtime_error("observer_invalid");
    DWORD count=0;
    if(!ReadFile(file,data,sizeof(data),&count,nullptr)) throw std::runtime_error("observer_storage");
    size=count;
    if(size!=info.nFileSizeLow) throw std::runtime_error("observer_storage");
#else
    // Open, verify and read the SAME descriptor: no check-then-open race.
    const int file=open(path.c_str(),O_RDONLY|O_NONBLOCK|O_NOFOLLOW|O_CLOEXEC);
    if(file<0) throw std::runtime_error("observer_storage");
    struct Close {int file;~Close(){::close(file);}} close={file};
    struct stat before={};
    if(fstat(file,&before) || !S_ISREG(before.st_mode)) throw std::runtime_error("observer_storage");
    if(before.st_size<0 || before.st_size>8192) throw std::runtime_error("observer_invalid");
    while(size<sizeof(data)) {
        const ssize_t count=read(file,data+size,sizeof(data)-size);
        if(count<0) {if(errno==EINTR) continue;throw std::runtime_error("observer_storage");}
        if(!count) break;
        size+=size_t(count);
    }
    struct stat after={};
    if(fstat(file,&after) || before.st_size!=after.st_size || size!=size_t(before.st_size) ||
       before.st_mtime!=after.st_mtime || before.st_ctime!=after.st_ctime)
        throw std::runtime_error("observer_storage");
#endif
    if(size>8192) throw std::runtime_error("observer_invalid");
    return std::string(data,size);
}
}
