// CSCO test-only native bot preflight. GPL-3.0.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <istream>
#include <string>
#include <unordered_set>
#include <vector>

namespace mq2 {
// Format: ReGameDLL_CS 5.30.0.814, game_shared/bot/nav_file.cpp and
// HidingSpot::Load in nav_area.cpp. v4/v5 are GoldSrc, not Source NAV files.
// Keep reads/counts bounded before GameDLL sees them: its loader trusts lengths
// and a fixed 16-entry approach array; a failed load can trigger auto-learning.
class BotNavReader {
    std::string bytes;
    size_t at=0;
public:
    bool load(std::istream& in) {
        in.seekg(0,std::ios::end);const auto length=in.tellg();
        if(length<16 || length>32*1024*1024)return false;
        in.seekg(0,std::ios::beg);bytes.resize(size_t(length));
        return bool(in.read(&bytes[0],std::streamsize(bytes.size())));
    }
    size_t remaining() const { return bytes.size()-at; }
    bool word(uint32_t& value,unsigned count=4) {
        if(count>4 || remaining()<count)return false;
        value=0;
        for(unsigned i=0;i<count;++i)value|=uint32_t(static_cast<unsigned char>(bytes[at++]))<<(8*i);
        return true;
    }
    bool coordinate(float& value) {
        uint32_t bits=0;if(!word(bits))return false;
        static_assert(sizeof(float)==sizeof(bits),"NAV requires binary32 floats");
        std::memcpy(&value,&bits,sizeof(value));
        // Bound the native grid allocation as well as rejecting NaN/infinity.
        return std::isfinite(value) && std::fabs(value)<=32768.0f;
    }
    bool name(std::string& value) {
        uint32_t count=0;
        if(!word(count,2) || count<2 || count>255 || remaining()<count)return false;
        value.clear();
        for(uint32_t i=0;i<count;++i) {
            const unsigned char c=bytes[at++];
            if(i+1==count) { if(c)return false; }
            else {if(c<32 || c==127)return false;value+=char(c);}
        }
        return true;
    }
};

// Retain the caller name, but validate the entire mesh and references.
// Traversability still needs a map test; BSP byte-size correlation is
// supplemented by reviewed BSP/NAV hashes in the ESERV manifest.
inline bool bot_nav_header(std::istream& in,uint32_t bspSize) {
    BotNavReader r;if(!r.load(in))return false;
    uint32_t magic=0,version=0,size=0,places=0,areas=0;
    if(!r.word(magic) || magic!=0xfeedface || !r.word(version) ||
       (version!=4 && version!=5) || !r.word(size) || !bspSize || size!=bspSize)return false;
    if(version==5) {
        if(!r.word(places,2) || places>1024)return false;
        std::unordered_set<std::string> names;
        for(uint32_t i=0;i<places;++i) {
            std::string name;if(!r.name(name) || !names.insert(name).second)return false;
        }
    }
    if(!r.word(areas) || !areas || areas>16384 || uint64_t(areas)*(version==5?61:59)>r.remaining())return false;
    std::unordered_set<uint32_t> areaIds,spotIds;
    std::vector<uint32_t> areaRefs,spotRefs;
    const auto reference=[&](std::vector<uint32_t>& target,bool allowZero)->bool {
        // HidingSpot IDs start at zero in GameDLL; area zero is a null reference.
        const bool spot=&target==&spotRefs;
        uint32_t id=0;if(!r.word(id) || (!id&&!allowZero&&!spot))return false;
        if(id || spot) { if(areaRefs.size()+spotRefs.size()>=1024*1024)return false;target.push_back(id); }
        return true;
    };
    for(uint32_t area=0;area<areas;++area) {
        uint32_t id=0,flags=0,count=0;
        if(!r.word(id) || !id || id==UINT32_MAX || !areaIds.insert(id).second || !r.word(flags,1) || (flags&~15u))return false;
        float extent[8];
        for(float& value:extent)if(!r.coordinate(value))return false;
        if(extent[0]>=extent[3] || extent[1]>=extent[4])return false;
        for(unsigned direction=0;direction<4;++direction) {
            if(!r.word(count) || count>areas || uint64_t(count)*4>r.remaining())return false;
            std::unordered_set<uint32_t> adjacent;
            for(uint32_t c=0;c<count;++c) {
                if(!reference(areaRefs,false) || !adjacent.insert(areaRefs.back()).second || areaRefs.back()==id)return false;
            }
        }
        if(!r.word(count,1) || uint64_t(count)*17>r.remaining())return false;
        for(uint32_t hiding=0;hiding<count;++hiding) {
            uint32_t spot=0;if(!r.word(spot) || spot==UINT32_MAX || !spotIds.insert(spot).second)return false;
            for(unsigned axis=0;axis<3;++axis){float value;if(!r.coordinate(value))return false;}
            if(!r.word(flags,1) || (flags&~7u))return false;
        }
        if(!r.word(count,1) || count>16 || uint64_t(count)*14>r.remaining())return false;
        for(uint32_t approach=0;approach<count;++approach) {
            uint32_t how=0;
            // 7 is GameDLL's NUM_TRAVERSE_TYPES sentinel for an absent leg.
            if(!reference(areaRefs,true) || !reference(areaRefs,true) || !r.word(how,1) || how>7 ||
               !reference(areaRefs,true) || !r.word(how,1) || how>7)return false;
        }
        if(!r.word(count) || count>65535 || uint64_t(count)*11>r.remaining())return false;
        for(uint32_t encounter=0;encounter<count;++encounter) {
            uint32_t direction=0,spots=0;
            if(!reference(areaRefs,false) || !r.word(direction,1) || direction>3 ||
               !reference(areaRefs,false) || !r.word(direction,1) || direction>3 || !r.word(spots,1) ||
               uint64_t(spots)*5>r.remaining())return false;
            for(uint32_t spot=0;spot<spots;++spot) {
                uint32_t distance=0;if(!reference(spotRefs,false) || !r.word(distance,1))return false;
            }
        }
        if(version==5 && (!r.word(count,2) || count>places))return false;
    }
    if(r.remaining())return false;
    for(uint32_t id:areaRefs)if(!areaIds.count(id))return false;
    for(uint32_t id:spotRefs)if(!spotIds.count(id))return false;
    return true;
}
}
