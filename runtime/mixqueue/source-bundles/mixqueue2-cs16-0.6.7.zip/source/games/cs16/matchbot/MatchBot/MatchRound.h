#pragma once
#include "MatchCSCOFeedback.h"

// Flags for stats commands
constexpr auto CMD_ALL	= 0;		/* All Options */
constexpr auto CMD_HP	= BIT(0);	/* flag "a" */
constexpr auto CMD_DMG	= BIT(1);	/* flag "b" */
constexpr auto CMD_RDMG = BIT(2);	/* flag "c" */
constexpr auto CMD_SUM	= BIT(3);	/* flag "d" */

class CMatchRound
{
public:
	// On Server activate
	void ServerActivate();

	// Match State
	void SetState(int State, bool KnifeRound);

	// Round Start
	void RoundStart();

	// Round End
	void RoundEnd(int winStatus, ScenarioEventEndRound eventScenario, float tmDelay);

	// Player Put In Server
	void PlayerPutInServer(edict_t* pEntity);

	// Player Disconnect
	void PlayerDisconnect(edict_t* pEntity);

	// Player Damage
	void PlayerDamage(unsigned token,int victim,int attacker,float actual);
	unsigned DamageToken() const { return ledger.current.serial; }
	void ResetCSCO();
	void FeedbackFrame();
	bool ShowCSCO(CBasePlayer* player,bool manual);

	// Show Enemy HP
	bool ShowHP(CBasePlayer* Player, bool Command, bool InConsole);

	// Show Damage
	bool ShowDamage(CBasePlayer* Player, bool Command, bool InConsole);

	// Show Received Damage
	bool ShowReceivedDamage(CBasePlayer* Player, bool Command, bool InConsole);

	// Show Round Summary
	bool ShowSummary(CBasePlayer* Player, bool Command, bool InConsole);

	// Round End Stats
	static void RoundEndStats(int State);

private:
	// Match State
	int m_State = STATE_DEAD;

	// Round Stats Damage
	mq2::DamageLedger ledger;

	// Round Stats Hits
	std::array<std::vector<std::string>,33> outgoing;
	std::array<size_t,33> sent{};
	std::array<float,33> manualAt{};
	float nextFeedback=0;

	// Match stats commands
	int m_StatsCommandFlags = CMD_ALL;
};

extern CMatchRound gMatchRound;
