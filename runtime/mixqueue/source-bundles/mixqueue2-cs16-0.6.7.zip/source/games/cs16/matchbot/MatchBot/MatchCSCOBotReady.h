// Assignment-scoped bot-only ready delay, armed after native loading. GPL-3.0.
#pragma once
#include <cmath>
#include <string>

namespace mq2 {
constexpr int BOT_ONLY_READY_SECONDS=15;
struct BotOnlyReadyClock {
    std::string scope;
    float until=0;
    bool active=false;
    bool start(const std::string& current,float now) {
        if(active || current.empty() || !std::isfinite(now)) return false;
        scope=current;until=now+BOT_ONLY_READY_SECONDS;active=true;return true;
    }
    bool due(const std::string& current,float now) const {
        return active && current==scope && std::isfinite(now) && now>=until;
    }
    void reset() { *this=BotOnlyReadyClock(); }
};
}
