#pragma once

class CMatchPause
{
public:
	// On server activate
	void ServerActivate();

	// Init pause
	bool Init(CBasePlayer* Player, TeamName Team);
	bool QueueTeam(const std::string& name);
	bool Resume(bool early = false);

	// On restart round event
	void RoundRestart();
	void TryPending();

	//  Pause function
	void Pause(int seconds = 0);

	// Pause timer hud message 
	static void PauseTimer(int PauseTime);

	// Set Round time
	void SetRoundTime(int Time, bool FreezePeriod);

	bool m_Pause = false;
	bool m_Paused = false;
	std::string m_PauseTeam;
	float m_BuyTime = 0.0f;
	bool m_BuyTimeSaved = false;
};

extern CMatchPause gMatchPause;
