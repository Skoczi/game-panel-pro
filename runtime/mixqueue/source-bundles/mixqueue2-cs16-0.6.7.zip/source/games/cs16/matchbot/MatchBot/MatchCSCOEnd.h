// Natural result retention and the GameDLL round-reason wire vocabulary.
// GPL-3.0. The clock never releases a server; WWW owns cleanup/lease release.
#pragma once
#include <algorithm>
#include <cmath>
#include <string>

namespace mq2 {
constexpr int POSTMATCH_SECONDS=180;
struct PostMatchClock {
    std::string scope;
    float since=0,until=0;
    bool active=false;
    bool start(const std::string& current,float now) {
        if(active || current.empty() || !std::isfinite(now)) return false;
        scope=current;since=now;until=now+POSTMATCH_SECONDS;active=true;return true;
    }
    int remaining(const std::string& current,float now) const {
        if(!active || scope!=current || !std::isfinite(now)) return 0;
        return std::max(0,int(std::ceil(until-now)));
    }
    void reset() { *this=PostMatchClock(); }
};
// Instantiate with the real ScenarioEventEndRound enum at the accepted hook.
// No numeric ABI guesses and no inference from damage, score or winning side.
template<class Scenario> const char* round_reason(Scenario event) {
    switch(event) {
        case Scenario::ROUND_TARGET_BOMB:return "bomb_exploded";
        case Scenario::ROUND_BOMB_DEFUSED:return "bomb_defused";
        case Scenario::ROUND_CTS_WIN:
        case Scenario::ROUND_TERRORISTS_WIN:return "elimination";
        case Scenario::ROUND_TARGET_SAVED:
        case Scenario::ROUND_HOSTAGE_NOT_RESCUED:
        case Scenario::ROUND_TERRORISTS_NOT_ESCAPED:
        case Scenario::ROUND_VIP_NOT_ESCAPED:return "time";
        default:return "other";
    }
}
}
