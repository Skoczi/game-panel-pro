// CSCO ranked safety policy. GPL-3.0. No engine/slot state in these helpers.
#pragma once
#include <array>
#include <vector>

namespace mq2 {
constexpr int RECONNECT_LIMIT=1, RECONNECT_SECONDS=90, TACTICAL_LIMIT=3, TACTICAL_SECONDS=30, READY_SECONDS=300;
struct ReconnectBudget {
    std::array<int,2> used{};
    bool available(int team) const { return team>=1 && team<=2 && used[team-1]<RECONNECT_LIMIT; }
    void consume(const std::array<bool,2>& teams) {
        for(int i=0;i<2;++i) if(teams[i] && available(i+1)) ++used[i];
    }
    void reset() { used={}; }
};
struct Rule { const char* name; float expected; bool optional;
    Rule(const char* key,float wanted,bool mayBeMissing=false):name(key),expected(wanted),optional(mayBeMissing) {}
};
inline std::vector<Rule> assignment_format_rules(int mr,int overtime) {
    return {{"mb_play_rounds",float(mr*2)},{"mb_play_rounds_ot",float(overtime*2)},{"mb_play_ot_mode",1}};
}
// Mode comes only from the validated assignment, never the current connected count.
inline std::vector<Rule> tournament_rules(bool warm,bool overtime,bool paused,int pauseSeconds=TACTICAL_SECONDS,bool test=false,int teamSize=5) {
    const bool doubles=teamSize==2;
    const float roundMinutes=doubles?2.0f:1.75f;
    return {
        {"mp_autoteambalance",0},{"mp_limitteams",0},{"mp_auto_join_team",0},
        {"mp_timelimit",0},{"mp_maxrounds",0},{"mp_winlimit",0},
        {"mp_freezetime",warm?0.0f:doubles?8.0f:10.0f},{"mp_roundtime",test && !warm?0.5f:roundMinutes},{"mp_c4timer",35},
        {"mp_buytime",paused?pauseSeconds/60.0f:warm?roundMinutes:0.25f},
        {"mp_startmoney",warm?16000.0f:overtime?10000.0f:800.0f},
        {"mp_friendlyfire",warm?0.0f:1.0f},{"mp_fadetoblack",0},
        {"mp_forcecamera",2},{"mp_forcechasecam",2},{"mp_autokick",0},{"mp_tkpunish",0},
        {"mp_chattime",5},{"mp_consistency",1},{"mp_flashlight",1},{"mp_footsteps",1},
        {"mp_kickpercent",1},{"mp_mapvoteratio",1},{"allow_spectators",0},
        {"mp_logdetail",3},{"mp_logecho",0},{"mp_logfile",1},{"mp_logmessages",1},
        {"decalfrequency",60},{"edgefriction",2},{"host_framerate",0},
        {"mp_hostagepenalty",0},{"sv_alltalk",warm?1.0f:0.0f},{"sv_voiceenable",1},
        {"sv_cheats",0},{"sv_gravity",800},{"sv_airaccelerate",10},{"sv_maxspeed",320},
        {"sv_accelerate",5},{"sv_aim",0},{"sv_friction",4},{"sv_clienttrace",1},
        {"sv_allowdownload",1},{"sv_allowupload",1},
        {"sv_maxrate",doubles?25000.0f:30000.0f},{"sv_minrate",2500},
        {"sv_maxupdaterate",doubles?100.0f:102.0f},{"sv_minupdaterate",20},
        {"sv_proxies",1},{"sv_send_logos",0},{"sv_send_resources",1},{"sv_stepsize",18},
        {"sv_timeout",65},{"sv_wateraccelerate",10},{"sv_wateramp",0},{"sv_waterfriction",1},
        {"pausable",0},{"mp_freeforall",0},{"mp_round_infinite",warm?1.0f:0.0f},
        {"mp_forcerespawn",warm?2.0f:0.0f},{"mp_roundrespawn_time",warm?-1.0f:0.0f},
        {"mp_maxmoney",16000},{"mp_buy_anywhere",warm?1.0f:0.0f},
        {"mp_infinite_ammo",0},{"mp_infinite_grenades",0},{"mp_free_armor",0},
        {"mp_auto_reload_weapons",0},{"mp_refill_bpammo_weapons",0},
        {"mp_round_restart_delay",5},{"mp_team_flash",1},{"mp_assist_damage_threshold",40},
        // Preserve classic movement, damage and economy instead of inheriting mod settings.
        {"mp_falldamage",1},{"mp_roundover",0},{"mp_fraglimit",0},
        {"sv_autobunnyhopping",0},{"sv_enablebunnyhopping",0},
        {"mp_respawn_immunitytime",0},{"mp_randomspawn",0},
        {"mp_plant_c4_anywhere",0},{"mp_give_player_c4",1},{"mp_defuser_allocation",0},
        {"mp_hegrenade_penetration",0},{"mp_mirrordamage",0,true},
        {"ff_damage_reduction_bullets",0.35f},{"ff_damage_reduction_grenade",0.25f},
        {"ff_damage_reduction_grenade_self",1},{"ff_damage_reduction_other",0.35f},
        {"mp_ct_give_player_knife",1},{"mp_t_give_player_knife",1},
        {"mp_allow_point_servercommand",0},
        // Extended Steam TAB fields exist only in BUILD_LATEST; keep classic information.
        {"mp_scoreboard_showhealth",-1,true},{"mp_scoreboard_showmoney",-1,true},
        {"mp_scoreboard_showdefkit",0,true},
        {"bot_quota",0,true},{"bot_deathmatch",0,true}
    };
}
struct TextRule { const char* name; const char* expected; };
inline std::vector<TextRule> tournament_text_rules() {
    return {
        {"mp_ct_default_weapons_secondary","usp"},{"mp_t_default_weapons_secondary","glock18"},
        {"mp_ct_default_weapons_primary",""},{"mp_t_default_weapons_primary",""},
        {"mp_ct_default_grenades",""},{"mp_t_default_grenades",""},{"mp_default_weapons_random",""}
    };
}
}
