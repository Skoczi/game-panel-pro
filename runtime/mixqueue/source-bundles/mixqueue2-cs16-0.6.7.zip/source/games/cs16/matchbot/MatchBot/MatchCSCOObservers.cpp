#include "precompiled.h"
#include "MatchCSCO.h"
#include "MatchCSCOObserverProjection.h"
#include "MatchCSCOObserverFile.h"
#include <ctime>

const mq2::ObserverGrant* CMatchCSCO::Observer(edict_t* entity) const {
    if(!Active() || FNullEnt(entity) || ENTINDEX(entity)<1 || ENTINDEX(entity)>gpGlobals->maxClients || Slot(entity)>=0) return nullptr;
#ifdef MQ2_QA
    const int index=ENTINDEX(entity);
    if((entity->v.flags&FL_FAKECLIENT) && !(entity->v.flags&FL_PROXY) && !qaObserverAuth[index].empty() &&
       qaObserverUserIds[index]==g_engfuncs.pfnGetPlayerUserId(entity))
        return observers.find(qaObserverAuth[index],std::time(nullptr));
#endif
    if(entity->v.flags&(FL_FAKECLIENT|FL_PROXY)) return nullptr;
    const auto auth=g_engfuncs.pfnGetPlayerAuthId(entity);
    return observers.find(mq2::steam64(auth?auth:""),std::time(nullptr));
}
bool CMatchCSCO::IsObserver(CBasePlayer* player) const { return player && Observer(player->edict()); }
void CMatchCSCO::ResetObservers() {
    observers=mq2::ObserverSnapshot();observerUserIds.fill(0);observerXray.fill(false);
    observerDrawAt=0;
#ifdef MQ2_QA
    for(auto& auth:qaObserverAuth) auth.clear();
    qaObserverUserIds.fill(0);
#endif
}
void CMatchCSCO::ObserverPrecache() {observerSprite=g_engfuncs.pfnPrecacheModel(const_cast<char*>("sprites/laserbeam.spr"));}
int CMatchCSCO::ObserverCapacity() const {
    if(!Active()) return 0;
    const int participants=int(config.players.size())+(config.test && !config.fullTest?1:0);
    return std::max(0,std::min(16,int(gpGlobals->maxClients)-participants));
}
int CMatchCSCO::ObserverCount(edict_t* except) const {
    int count=0;
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        const auto p=UTIL_PlayerByIndexSafe(i);
        if(p && !p->IsDormant() && p->edict()!=except && Observer(p->edict()) &&
           observerUserIds[i]==g_engfuncs.pfnGetPlayerUserId(p->edict())) ++count;
    }
    return count;
}
void CMatchCSCO::ObserversCommand() {
    auto& s=gMatchCSCO;
    if(g_engfuncs.pfnCmd_Argc()!=4) {Print("observer_invalid");return;}
    try {
        const std::string id=g_engfuncs.pfnCmd_Argv(1);
        const auto generation=mq2::observer_number(g_engfuncs.pfnCmd_Argv(2));
        const auto revision=mq2::observer_number(g_engfuncs.pfnCmd_Argv(3));
        if(!mq2::hex(id,24) || !generation || generation>2147483647ULL || !revision || revision>2147483647ULL) {
            Print("observer_invalid");return;
        }
        if(!s.Active() || s.config.id!=id || s.config.generation!=int(generation)) {Print("observer_scope");return;}
        if(revision<s.observers.revision) {Print("observer_stale");return;}
        const std::string path=s.root+"/"+id+"-"+std::to_string(generation)+"-observers-"+std::to_string(revision)+".txt";
        auto next=mq2::parse_observers(mq2::read_observer_file(path),id,generation,revision,std::time(nullptr));
        const auto result=mq2::apply_observers(s.observers,next);
        Print(result);
        // Permission checks use the new snapshot immediately. Frame removes revoked/expired observers.
        s.nextFrame=0;
    } catch(const std::runtime_error& error) {
        const std::string code=error.what();
        Print(code=="observer_scope" || code=="observer_storage"?code:"observer_invalid");
    } catch(...) {Print("observer_invalid");}
}
void CMatchCSCO::ObserverFeedback(CBasePlayer* p,const char* pl,const char* en) {
    const auto grant=Observer(p?p->edict():nullptr);
    if(p && grant) gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"%s",grant->locale=="pl"?pl:en);
}
void CMatchCSCO::ObserverJoined(CBasePlayer* p) {
    const auto grant=Observer(p->edict());if(!grant) return;
    const int client=p->entindex(),userId=g_engfuncs.pfnGetPlayerUserId(p->edict());
    if(observerUserIds[client]!=userId) {
        if(ObserverCount(p->edict())>=ObserverCapacity()) {Kick(p->edict(),"observer_full");return;}
        for(int i=1;i<=gpGlobals->maxClients;++i) {
            const auto other=UTIL_PlayerByIndexSafe(i);const auto existing=other?Observer(other->edict()):nullptr;
            if(other && i!=client && !other->IsDormant() && existing && existing->steam==grant->steam &&
               observerUserIds[i]==g_engfuncs.pfnGetPlayerUserId(other->edict())) {Kick(p->edict(),"not_roster");return;}
        }
    }
    CloseTeamMenu(p);
    if(p->m_iTeam!=SPECTATOR) {
        // CSPlayer::JoinTeam is the authoritative spectator transition and does
        // not require opening allow_spectators for ordinary players.
        if(!p->CSPlayer()->JoinTeam(SPECTATOR)) {Kick(p->edict(),"not_roster");return;}
    }
    if(observerUserIds[client]!=userId) {
        observerUserIds[client]=userId;observerXray[client]=false;
        gMatchReady.SetReady(client,false);
        SendHeader(p->edict());
        ObserverFeedback(p,"Tryb obserwatora. Nie bierzesz udzialu w meczu. /xray on|off",
            "Observer mode. You are not a match participant. /xray on|off");
    }
    if(!grant->xray) observerXray[client]=false;
}
bool CMatchCSCO::ObserverVoiceBlocked(CBasePlayer* listener,CBasePlayer* sender) const {
    // Block any non-roster speaker to the roster, including the frame between
    // permission expiry/revocation and the queued kick. Dead players count too.
    return Managed() && listener && sender && Slot(listener->edict())>=0 && Slot(sender->edict())<0;
}
bool CMatchCSCO::ObserverCommand(CBasePlayer* p,const char* cmd,const char* arg) {
    if(!Managed() || !p || Slot(p->edict())>=0) return false;
    std::string command=cmd?cmd:"";
    const bool chat=command=="say" || command=="say_team";
    std::string text=chat?(arg?arg:""):command;
    if(text.size()>1 && text.front()=='"' && text.back()=='"') text=text.substr(1,text.size()-2);
    if(!text.empty() && (text[0]=='/' || text[0]=='.' || text[0]=='!')) text=text.substr(1);
    const auto grant=Observer(p->edict());
    if(grant && (text=="xray" || text.compare(0,5,"xray ")==0)) {
        std::string option=chat?text.substr(std::min(size_t(5),text.size())):(arg?arg:"");
        if(!grant->xray) ObserverFeedback(p,"Brak uprawnien do xray.","X-ray is not permitted for this observer.");
        else if(option.empty() || option=="on" || option=="off") {
            auto& enabled=observerXray[p->entindex()];enabled=option.empty()?!enabled:option=="on";
            ObserverFeedback(p,enabled?"Xray wlaczone.":"Xray wylaczone.",enabled?"X-ray enabled.":"X-ray disabled.");
        } else ObserverFeedback(p,"Uzycie: /xray on lub /xray off.","Usage: /xray on or /xray off.");
        return true;
    }
    if(grant && (text=="score" || text=="stats" || text=="status")) {
        gMatchUtil.SayText(p->edict(),PRINT_TEAM_DEFAULT,"%s | %s %d : %d %s",phase.c_str(),
            config.teams[0].c_str(),score[0],score[1],config.teams[1].c_str());return true;
    }
    // No chat/radio from omniscient spectators to players and no legacy admin,
    // ready, team or vote menus. Camera navigation and normal client utilities
    // remain native. Administration actions require separately scoped commands.
    if(chat || command=="chooseteam" || command=="jointeam" || command=="joinclass" ||
       command=="menuselect" || command=="radio1" || command=="radio2" || command=="radio3" ||
       command=="kill" || command=="buy" || command=="buyequip" ||
       (!command.empty() && (command[0]=='/' || command[0]=='.' || command[0]=='!'))) return true;
    return false;
}

namespace {
mq2::observer::Vec point(const Vector& value) {return {value.x,value.y,value.z};}
bool clear_observer_ray(const Vector& eye,const mq2::observer::Vec& end,edict_t* camera) {
    const float target[]={end.x,end.y,end.z};TraceResult trace={};
    g_engfuncs.pfnTraceLine(eye,target,ignore_monsters,camera,&trace);
    return !trace.fStartSolid && !trace.fAllSolid && trace.flFraction>=0.999f;
}
void observer_beam(edict_t* recipient,int sprite,const mq2::observer::Vec& a,const mq2::observer::Vec& b,int team) {
    g_engfuncs.pfnMessageBegin(MSG_ONE_UNRELIABLE,SVC_TEMPENTITY,nullptr,recipient);
    g_engfuncs.pfnWriteByte(TE_BEAMPOINTS);
    for(const auto& p:{a,b}) {g_engfuncs.pfnWriteCoord(p.x);g_engfuncs.pfnWriteCoord(p.y);g_engfuncs.pfnWriteCoord(p.z);}
    g_engfuncs.pfnWriteShort(sprite);
    g_engfuncs.pfnWriteByte(0);g_engfuncs.pfnWriteByte(0); // frame, frame rate
    g_engfuncs.pfnWriteByte(2);g_engfuncs.pfnWriteByte(1);g_engfuncs.pfnWriteByte(0); // 0.2s life, 0.1 width, no noise
    g_engfuncs.pfnWriteByte(team==1?100:235);g_engfuncs.pfnWriteByte(team==1?220:175);g_engfuncs.pfnWriteByte(team==1?160:80);
    g_engfuncs.pfnWriteByte(190);g_engfuncs.pfnWriteByte(0);
    g_engfuncs.pfnMessageEnd();
}
}
void CMatchCSCO::ObserverXrayFrame() {
    if(!Active() || !live || phase=="finished" || !observerSprite || gpGlobals->time<observerDrawAt) return;
    observerDrawAt=gpGlobals->time+0.2f; // Bounded: 5 updates/s, 10 roster targets, 2 short lines each.
    for(int i=1;i<=gpGlobals->maxClients;++i) {
        auto viewer=UTIL_PlayerByIndexSafe(i);
        const auto grant=viewer?Observer(viewer->edict()):nullptr;
        if(!viewer || viewer->IsDormant() || !grant || !grant->xray || !observerXray[i] || viewer->m_iTeam!=SPECTATOR ||
           observerUserIds[i]!=g_engfuncs.pfnGetPlayerUserId(viewer->edict())) continue;
        CBasePlayer* camera=viewer;
        if(viewer->pev->iuser1==4) { // OBS_IN_EYE: use the actual followed player's camera.
            camera=UTIL_PlayerByIndexSafe(viewer->pev->iuser2);
            if(!camera || camera->IsDormant() || !camera->IsAlive() || !HasRosterIdentity(camera)) continue;
        } else if(viewer->pev->iuser1!=3) continue; // OBS_ROAMING only; chase/map cameras are client-side.
        const Vector eye=camera->pev->origin+camera->pev->view_ofs;
        const auto angles=point(camera->pev->v_angle);
        for(const auto& row:config.players) {
            auto target=UTIL_PlayerByIndexSafe(row.client);
            if(!target || target==camera || target->IsDormant() || !target->IsAlive() ||
               Slot(target->edict())!=int(&row-config.players.data())) continue;
            const Vector center=target->pev->origin+(target->pev->mins+target->pev->maxs)*0.5f;
            mq2::observer::Marker marker;
            if(!mq2::observer::Project(point(eye),angles,point(center),32,marker)) continue;
            const float destination[]={marker.center.x,marker.center.y,marker.center.z};TraceResult trace={};
            g_engfuncs.pfnTraceLine(eye,destination,ignore_monsters,camera->edict(),&trace);
            if(trace.fAllSolid || trace.fStartSolid) continue;
            const float depth=trace.flFraction<1?32*trace.flFraction-2:32;
            if(!mq2::observer::Project(point(eye),angles,point(center),depth,marker) ||
               !mq2::observer::WirePoint(marker.horizontal[0]) || !mq2::observer::WirePoint(marker.horizontal[1]) ||
               !mq2::observer::WirePoint(marker.vertical[0]) || !mq2::observer::WirePoint(marker.vertical[1]) ||
               !clear_observer_ray(eye,marker.horizontal[0],camera->edict()) ||
               !clear_observer_ray(eye,marker.horizontal[1],camera->edict()) ||
               !clear_observer_ray(eye,marker.vertical[0],camera->edict()) ||
               !clear_observer_ray(eye,marker.vertical[1],camera->edict())) continue;
            // Re-check identity/lease at every private send. Never broadcast,
            // modify target render flags/PVS, or make the viewer a proxy/HLTV.
            const auto horizontalGrant=Observer(viewer->edict());
            if(!horizontalGrant || !horizontalGrant->xray) break;
            observer_beam(viewer->edict(),observerSprite,marker.horizontal[0],marker.horizontal[1],row.team);
            const auto verticalGrant=Observer(viewer->edict());
            if(!verticalGrant || !verticalGrant->xray) break;
            observer_beam(viewer->edict(),observerSprite,marker.vertical[0],marker.vertical[1],row.team);
        }
    }
}

#ifdef MQ2_QA
// Isolated GameDLL stand-ins only. This code is absent from production builds;
// it cannot establish that a real Steam client renders or authenticates correctly.
bool CMatchCSCO::ObserverQACommand(const std::string& operation) {
    if(operation=="observer_add") {
        const std::string steam=g_engfuncs.pfnCmd_Argv(2);
        if(!Active() || !mq2::observer_steam(steam) || !observers.find(steam,std::time(nullptr))) {Print("qa_observer_denied");return true;}
        for(const auto& row:config.players) if(row.steam==steam) {Print("qa_observer_roster");return true;}
        creatingBot=true;
        auto entity=g_engfuncs.pfnCreateFakeClient("QA observer");
        if(FNullEnt(entity)) {creatingBot=false;Print("qa_full");return true;}
        const int client=ENTINDEX(entity);
        char reject[128]={};MDLL_ClientConnect(entity,"QA observer","127.0.0.1",reject);MDLL_ClientPutInServer(entity);
        entity->v.flags|=FL_FAKECLIENT;
        qaObserverAuth[client]=steam;qaObserverUserIds[client]=g_engfuncs.pfnGetPlayerUserId(entity);
        creatingBot=false;
        auto p=UTIL_PlayerByIndexSafe(client);if(p) ObserverJoined(p);
        Print("qa_observer_added "+std::to_string(client));return true;
    }
    if(operation=="observer_probe" || operation=="observer_cmd" || operation=="observer_drop") {
        const int client=atoi(g_engfuncs.pfnCmd_Argv(2));
        if(client<1 || client>gpGlobals->maxClients) {Print("qa_observer_denied");return true;}
        auto p=UTIL_PlayerByIndexSafe(client);
        if(!p || p->IsDormant()) {Print("qa_observer_missing");return true;}
        if(operation=="observer_cmd") {
            Print(ClientCommand(p,g_engfuncs.pfnCmd_Argv(3),g_engfuncs.pfnCmd_Argv(4))?"qa_observer_handled":"qa_observer_passthrough");
        } else if(operation=="observer_drop") {
            if(qaObserverAuth[client].empty()) Print("qa_observer_denied");else Kick(p->edict());
        } else {
            struct CameraProbe : IHookChain<int,CBasePlayer*> {
                int callNext(CBasePlayer*) override {return 2;}
                int callOriginal(CBasePlayer*) override {return 2;}
            } cameraProbe;
            const auto listener=config.players.empty()?nullptr:UTIL_PlayerByIndexSafe(config.players[0].client);
            Print("{\"observer\":"+std::string(IsObserver(p)?"true":"false")+",\"team\":"+std::to_string(p->m_iTeam)+
                ",\"roster_index\":"+std::to_string(RosterIndex(p))+",\"xray\":"+(observerXray[client]?"true":"false")+
                ",\"camera_policy\":"+std::to_string(ReGameDLL_GetForceCamera(&cameraProbe,p))+
                ",\"voice_to_roster_blocked\":"+(ObserverVoiceBlocked(listener,p)?"true":"false")+
                ",\"spectator_capacity\":"+std::to_string(ObserverCapacity())+",\"observers\":"+std::to_string(ObserverCount())+"}");
        }
        return true;
    }
    return false;
}
#endif
