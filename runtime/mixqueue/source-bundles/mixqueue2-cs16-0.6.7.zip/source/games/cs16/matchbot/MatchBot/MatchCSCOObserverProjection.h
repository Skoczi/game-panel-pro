// Private observer marker geometry, not an outline or a depth-test override. GPL-3.0.
#pragma once
#include <cmath>

namespace mq2 { namespace observer {
struct Vec {
    float x,y,z;
    Vec(float xValue=0,float yValue=0,float zValue=0):x(xValue),y(yValue),z(zValue) {}
};
struct Marker {
    Vec center;
    Vec horizontal[2];
    Vec vertical[2];
};
inline bool Finite(const Vec& v) {
    return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);
}
// TE coordinates use MSG_WriteShort(int(value * 8)); reject rather than wrap
// or clamp a private marker into a different screen position.
inline bool WirePoint(const Vec& v) {
    return Finite(v) && v.x>=-4096.0f && v.x<=4095.875f
        && v.y>=-4096.0f && v.y<=4095.875f && v.z>=-4096.0f && v.z<=4095.875f;
}
inline Vec Offset(const Vec& origin,const Vec& direction,float distance) {
    return {origin.x+direction.x*distance,origin.y+direction.y*distance,origin.z+direction.z*distance};
}

// GoldSrc view angles: x=pitch (positive down), y=yaw, z=roll, in degrees.
// rayDistance is distance ALONG THE TARGET RAY, after the caller's world trace.
// The caller must separately authorize the recipient and trace all four endpoints.
// No world entity, PVS, player origin or client setting is modified by this helper.
inline bool Project(const Vec& eye,const Vec& angles,const Vec& target,float rayDistance,Marker& out) {
    out=Marker();
    if(!Finite(eye)||!Finite(angles)||!Finite(target)||!std::isfinite(rayDistance)
        ||rayDistance<8.0f||rayDistance>32.0f) return false;
    constexpr double radians=3.14159265358979323846/180.0;
    const double pitch=std::fmod(double(angles.x),360.0)*radians;
    const double yaw=std::fmod(double(angles.y),360.0)*radians;
    const double roll=std::fmod(double(angles.z),360.0)*radians;
    const double sp=std::sin(pitch),cp=std::cos(pitch),sy=std::sin(yaw),cy=std::cos(yaw);
    const double sr=std::sin(roll),cr=std::cos(roll);
    const Vec forward={float(cp*cy),float(cp*sy),float(-sp)};
    const Vec right={float(-sr*sp*cy+cr*sy),float(-sr*sp*sy-cr*cy),float(-sr*cp)};
    const Vec up={float(cr*sp*cy+sr*sy),float(cr*sp*sy-sr*cy),float(cr*cp)};
    const double x=double(target.x)-eye.x,y=double(target.y)-eye.y,z=double(target.z)-eye.z;
    const double distance=std::sqrt(x*x+y*y+z*z);
    if(!std::isfinite(distance)||distance<0.001) return false;
    const Vec direction={float(x/distance),float(y/distance),float(z/distance)};
    const double facing=double(direction.x)*forward.x+double(direction.y)*forward.y+double(direction.z)*forward.z;
    const double forwardDepth=rayDistance*facing;
    // A broad forward cone avoids back-facing/near-tangent markers. The client
    // clips to its actual FOV/aspect ratio; those settings are never forced.
    if(facing<0.25||forwardDepth<6.0) return false;
    const float halfSize=float(forwardDepth*0.018);
    Marker result;
    result.center=Offset(eye,direction,rayDistance);
    result.horizontal[0]=Offset(result.center,right,-halfSize);
    result.horizontal[1]=Offset(result.center,right,halfSize);
    result.vertical[0]=Offset(result.center,up,-halfSize);
    result.vertical[1]=Offset(result.center,up,halfSize);
    if(!Finite(result.center)||!Finite(result.horizontal[0])||!Finite(result.horizontal[1])
        ||!Finite(result.vertical[0])||!Finite(result.vertical[1])) return false;
    out=result;
    return true;
}
}}
