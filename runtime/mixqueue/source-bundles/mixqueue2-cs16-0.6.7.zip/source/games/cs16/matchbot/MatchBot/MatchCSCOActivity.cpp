// Conservative behaviour signals, not automatic verdicts or kicks. GPL-3.0.
#include "precompiled.h"

void CMatchCSCO::ActivityBegin() {
    roundSince=gpGlobals->time; activityCheck=0;
    activitySeen.fill(false);activityTrack.fill(false);
    if(config.test) return;
    for(size_t i=0;i<config.players.size();++i) {
        const auto p=UTIL_PlayerByIndexSafe(config.players[i].client);
        if(p && RosterIndex(p)==int(i)+1 && p->IsAlive()) {
            activityTrack[i]=true;activityOrigin[i]=p->pev->origin;activityAngles[i]=p->pev->v_angle;
        }
    }
}
void CMatchCSCO::ActivityFrame() {
    if(config.test || !Scoring() || gpGlobals->time<activityCheck || CSGameRules()->IsFreezePeriod()) return;
    activityCheck=gpGlobals->time+1;
    for(size_t i=0;i<config.players.size();++i) {
        const auto p=UTIL_PlayerByIndexSafe(config.players[i].client);
        if(!p || RosterIndex(p)!=int(i)+1 || !p->IsAlive()) {activityTrack[i]=false;continue;}
        if((p->pev->origin-activityOrigin[i]).Length()>8 ||
           (p->pev->v_angle-activityAngles[i]).Length()>3 || (p->pev->button&(IN_ATTACK|IN_ATTACK2|IN_USE|IN_JUMP))) activitySeen[i]=true;
    }
}
void CMatchCSCO::ActivityEnd() {
    if(config.test) return;
    for(size_t i=0;i<config.players.size();++i) {
        const auto p=UTIL_PlayerByIndexSafe(config.players[i].client);
        // Ignore short rounds, early deaths, disconnects and slot reuse. A signal
        // requires three long, wholly observed rounds without input/aim/movement.
        const bool inactive=activityTrack[i] && !activitySeen[i] && gpGlobals->time-roundSince>=45 &&
            p && RosterIndex(p)==int(i)+1 && p->IsAlive();
        idleRounds[i]=inactive?idleRounds[i]+1:0;
        if(idleRounds[i]==2) Feedback(int(i)+1,config.players[i].locale=="pl"?
            "Brak aktywnosci przez dwie rundy. Dalsza bezczynnosc trafi do sprawdzenia.":
            "No activity for two rounds. Continued inactivity will be flagged for review.");
        if(idleRounds[i]>=3) ActivityAlert(int(i),"afk",idleRounds[i],1);
    }
}
void CMatchCSCO::ActivityAlert(int index,const char* code,int count,unsigned bit) {
    if(config.test || !Active() || index<0 || index>=int(config.players.size()) || (activityAlerts[index]&bit)) return;
    activityAlerts[index]|=bit;
    Emit("player_alert","{\"steam_id\":\""+config.players[index].steam+"\",\"code\":\""+code+
         "\",\"count\":"+std::to_string(count)+",\"round\":"+std::to_string(score[0]+score[1]+(roundOpen?1:0))+"}",
         std::string("alert-")+code+"-"+config.players[index].steam);
    Feedback(index+1,config.players[index].locale=="pl"?
        "Zapisano sygnal do sprawdzenia przez administracje. Nie naliczono automatycznej kary.":
        "A signal was saved for admin review. No automatic penalty was applied.");
}
