"""0.6.5 observer ACL: isolated ReGameDLL QA entities, not Steam/render acceptance.

Only the preserved loopback lab is accepted. No generation, assignment or journal
file is deleted; immutable observer snapshots are written with exclusive create.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import time

parser = argparse.ArgumentParser()
parser.add_argument('--root', required=True)
parser.add_argument('--agent', required=True)
parser.add_argument('--cleanup-scope', help='Explicit failed QA match id:generation to clean normally before rerunning')
parser.add_argument('--cleanup-only', action='store_true', help='Clean the explicit failed scope and exit without a new assignment')
args = parser.parse_args()
if args.cleanup_only and not args.cleanup_scope:
    parser.error('--cleanup-only requires --cleanup-scope')
root = Path(args.root).resolve()
assert '/csco-lab/matchbot-063-profile/' in str(root), 'Isolated loopback lab only'
spec = importlib.util.spec_from_file_location('mq2_agent', args.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', 27095, os.environ['MQ2_QA_RCON_PASSWORD'])
last = 0
cfg = root/'addons/amxmodx/configs/mq2'
journal = root/'addons/amxmodx/data/mq2/events.jsonl'
proof_file = root.parent.parent/'observers-065-proof.json'
proof = {'controller': '0.6.5', 'acceptance': 'isolated ReGameDLL QA; not Steam or visual acceptance',
         'qa_sha256': hashlib.sha256((root/'addons/matchbot/dlls/matchbot_csco_mm.so').read_bytes()).hexdigest(), 'checks': []}


def command(value):
    global last
    time.sleep(max(0, 1.05-(time.monotonic()-last)))
    response = rcon.command(value)
    last = time.monotonic()
    return response


def qa(value):
    return command('mq2_qa '+value)


def obj(value):
    return json.loads(qa(value))


def status():
    return json.loads(command('mq2_status'))


def events():
    return [event for line in journal.read_text().splitlines()
            if (event := json.loads(line))['match_id'] == match_id]


def checked(label):
    proof['checks'].append(label)
    proof_file.write_text(json.dumps(proof, indent=2))
    print('PASS '+label, flush=True)


def live():
    deadline = time.monotonic()+90
    while time.monotonic() < deadline:
        state = obj('snapshot')
        if state['round_open'] and not state['freeze'] and not state['lo3']:
            return state
        qa('fast')
    raise AssertionError(('not live', state, status()))


def snapshot(revision, rows, seconds=300):
    until = int(time.time())+seconds
    body = f'MQ2OBS1 {match_id} {generation} {revision} {until}\n'
    for steam, role, xray, locale in rows:
        body += f'{steam} {role} {int(xray)} {until} {locale}\n'
    with (cfg/f'{match_id}-{generation}-observers-{revision}.txt').open('x') as target:
        target.write(body)
    response = command(f'mq2_observers {match_id} {generation} {revision}')
    assert response == 'observer_updated', response
    return until


def add_observer(steam):
    response = qa(f'observer_add {steam}')
    assert response.startswith('qa_observer_added '), response
    return int(response.split()[-1])


before = status()
assert before['controller_version'] == '0.6.5' and before['observer_acl_version'] == 1
binary_bytes = (root/'addons/matchbot/dlls/matchbot_csco_mm.so').read_bytes()
assert b'mq2_qa' in binary_bytes and b'0.6.5\0' in binary_bytes, 'Installed QA binary 0.6.5 required'
metadata = command('meta list')
assert any('MatchBot' in line and '0.6.5' in line and 'RUN' in line for line in metadata.splitlines()), ('Loaded metadata mismatch', metadata)
proof['metamod_list'] = metadata
if args.cleanup_scope:
    assert re.fullmatch(r'065000[0-9a-f]{18}:[1-9][0-9]*', args.cleanup_scope), 'Only this harness match namespace'
    assert before['matchid'] == args.cleanup_scope, ('Refusing cleanup of a different scope', before)
    failed_id, failed_generation = args.cleanup_scope.split(':')
    high_before = int((cfg/'generation-matchbot.txt').read_text())
    assert high_before == int(failed_generation), 'Current high-water must match the explicit failed scope'
    previous_journal = journal.read_bytes()
    assert command('mq2_clear server_error').endswith('cleared')
    before = status()
    assert before['idle'] and before['healthy'], before
    assert int((cfg/'generation-matchbot.txt').read_text()) == high_before
    assert journal.read_bytes().startswith(previous_journal), 'Cleanup changed existing journal history'
    cleanup_proof = root.parent.parent/f'observers-065-cleanup-{failed_id}-{failed_generation}.json'
    with cleanup_proof.open('x') as saved:
        json.dump({'scope': args.cleanup_scope, 'method': 'mq2_clear server_error', 'generation_retained': high_before,
                   'journal_prefix_sha256': hashlib.sha256(previous_journal).hexdigest(), 'status': before}, saved, indent=2)
    print('PASS explicit failed-scope cleanup; history and generation retained before fresh run', flush=True)
    if args.cleanup_only:
        print('PASS cleanup-only: idle, no replacement assignment loaded', flush=True)
        raise SystemExit(0)
assert before['idle'] and before['healthy'], 'Lab must be reconciled idle before this test'
snapshot_reply = qa('snapshot')
assert 'round_open' in snapshot_reply, ('QA snapshot unavailable after idle/cleanup', snapshot_reply, before,
                                      {'qa_sha256': proof['qa_sha256'], 'metamod_list': metadata})
generation = int((cfg/'generation-matchbot.txt').read_text())+1
match_id = '065000'+f'{time.time_ns():018x}'[-18:]
players = []
for i in range(10):
    team = 1 if i < 5 else 2
    players.append({'steam_id': str(76561198000000000+i), 'team': team, 'bot': False,
                    'captain': int(i in (0, 5)), 'locale': 'pl' if team == 1 else 'en',
                    'name': ('Neo' if team == 1 else 'Forest') if i in (0, 5) else f'Player{i}'})
assignment = {'game': 'cs16', 'match_id': match_id, 'generation': generation, 'config_hash': 'e'*64,
              'contract_version': 3, 'starting_ct_team': 1, 'map': 'de_dust2', 'team_size': 5,
              'teams': {'1': 'Neo team', '2': 'Forest team'}, 'players': players,
              'rules': {'mr': 12, 'ot_mr': 3, 'test': False}}
with (cfg/f'{match_id}-{generation}.txt').open('x') as target:
    target.write(agent.AmxxAdapter.build(assignment))
assert command(f'mq2_load {match_id} {generation}').endswith('loaded')
for i in range(10):
    assert qa(f'add {i}') == 'qa_added'
qa('ready')
live()
assert 'qa_damage_applied' in qa('eliminate 2')
state = live()
baseline = status()
assert baseline['score'] == [1, 0] and baseline['restarts_completed'] == 3
assert baseline['observer_slots'] >= 2, 'Start the isolated lab with >=12 slots'
roster_client = next(row['id'] for row in state['clients'] if row['slot'] == 0)
proof.update(match_id=match_id, generation=generation, baseline=baseline)
base_events = events()
base_connected = [e for e in base_events if e['type'] == 'connected']
base_round = next(e for e in reversed(base_events) if e['type'] == 'round')
admin, caster = '76561198010000000', '76561198010000001'
rows = [(admin, 'admin', True, 'pl'), (caster, 'commentator', False, 'en'),
        (players[0]['steam_id'], 'admin', True, 'pl')]
snapshot(1, rows)
assert command(f'mq2_observers {match_id} {generation} 1') == 'observer_already_updated'
assert command(f'mq2_observers {match_id} {generation+1} 1') == 'observer_scope'
first = add_observer(admin)
probe = obj(f'observer_probe {first}')
assert probe['observer'] and probe['team'] == 3 and probe['roster_index'] == 0
assert probe['camera_policy'] == 0 and probe['voice_to_roster_blocked']
assert qa(f'observer_cmd {first} jointeam 1') == 'qa_observer_handled'
# Native CSCO accepts .ready, /ready and !ready equally. The dot spelling keeps
# this test inside the unchanged production GoldSrcRcon character allowlist.
assert qa(f'observer_cmd {first} say .ready') == 'qa_observer_handled'
assert qa(f'observer_cmd {first} say hello') == 'qa_observer_handled'
assert qa(f'observer_cmd {first} xray on') == 'qa_observer_handled'
assert obj(f'observer_probe {first}')['xray']
assert qa(f'observer_cmd {roster_client} jointeam 6') == 'qa_observer_handled'
roster_probe = obj(f'observer_probe {roster_client}')
assert not roster_probe['observer'] and roster_probe['team'] == 2 and roster_probe['roster_index'] == 1
assert roster_probe['camera_policy'] == 2 and not roster_probe['xray']
assert qa(f'observer_add {players[0]["steam_id"]}') == 'qa_observer_roster'
second = add_observer(caster)
assert qa(f'observer_cmd {second} xray on') == 'qa_observer_handled'
assert not obj(f'observer_probe {second}')['xray']
checked('live spectator routing; roster admin denied; both-team camera only for observer; ready/team/chat isolation; per-grant xray')

# Actual engine disconnect and reconnect; no roster connection event/pause/score mutation.
qa(f'observer_drop {first}')
assert not obj('pause-state')['disconnect']
assert status()['score'] == [1, 0]
first = add_observer(admin)
assert not obj(f'observer_probe {first}')['xray'], 'Reconnect must not inherit a slot toggle'
assert len([e for e in events() if e['type'] == 'connected']) == len(base_connected)
checked('observer exit/reconnect preserves score and roster connectivity; no disconnect pause; fresh session xray off')

# Revocation is a new immutable revision; stale retries cannot grant access back.
snapshot(2, [])
assert command(f'mq2_observers {match_id} {generation} 1') == 'observer_stale'
assert status()['connected_observers'] == 0
assert qa(f'observer_add {admin}') == 'qa_observer_denied'
assert not obj('pause-state')['disconnect']
checked('empty ACL revokes connected observers; stale revision denied; no reconnect pause')

# A short real wall-clock lease expires without touching match time or recovery.
expiry = snapshot(3, [(admin, 'admin', True, 'en')], seconds=7)
first = add_observer(admin)
while time.time() <= expiry+1:
    time.sleep(.2)
assert status()['connected_observers'] == 0
assert qa(f'observer_add {admin}') == 'qa_observer_denied'
assert command(f'mq2_observers {match_id} {generation} 3') == 'observer_invalid'
assert not obj('pause-state')['disconnect']
checked('real observer ACL expiry fails closed and cannot be replayed')

# Confirm all score/stat payload identities remain exactly the match roster.
current_events = events()
assert len([e for e in current_events if e['type'] == 'connected']) == len(base_connected)
assert not any(e['type'] in ('pause', 'resume', 'abandoned', 'not_ready') for e in current_events)
for event in current_events:
    if event['type'] in ('round', 'finished') and 'players' in event['data']:
        assert set(event['data']['players']) == {p['steam_id'] for p in players}
assert base_round in current_events, 'Existing history must be preserved'
checked('observer identities absent from participant statistics, penalties and connection journal')

# Recovery must clear permissions and reject every dynamic update.
snapshot(4, [(admin, 'admin', True, 'pl')])
qa('direct-reset')
recovery = status()
assert recovery['phase'] == 'recovery' and not recovery['healthy'] and recovery['observer_revision'] == 0
assert command(f'mq2_observers {match_id} {generation} 4') == 'observer_scope'
checked('recovery clears observer grants and rejects updates')
proof['events'] = events()
assert command('mq2_clear server_error').endswith('cleared')
final = status()
assert final['idle'] and final['healthy'] and final['observer_revision'] == 0
assert int((cfg/'generation-matchbot.txt').read_text()) == generation
proof['final_status'] = final
proof_file.write_text(json.dumps(proof, indent=2))
print('PASS normal cleanup/idle; generation and journal retained; Steam rendering/authentication still requires acceptance', flush=True)
