"""0.6.1 isolated GameDLL acceptance. QA entities, NEVER real Steam acceptance."""
import argparse, hashlib, importlib.util, json, os, time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True)
p.add_argument('--mode',choices=['tactical','disconnect','ready'],default='tactical');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-061/' in str(root)
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
rcon=agent.GoldSrcRcon('127.0.0.1',27095,os.environ['MQ2_QA_RCON_PASSWORD']);last=0
def cmd(text):
 global last
 time.sleep(max(0,1.05-(time.monotonic()-last)));value=rcon.command(text);last=time.monotonic();return value
def qa(text):return cmd('mq2_qa '+text)
def obj(text):return json.loads(qa(text))
def status():return json.loads(cmd('mq2_status'))
def snap():return obj('snapshot')
def pause():return obj('pause-state')
def feedback(slot):return [x for x in qa(f'feedback-all {slot}').splitlines() if x!='qa_empty']
def events():return [e for x in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if (e:=json.loads(x))['match_id']==mid]
def live():
 until=time.monotonic()+85
 while time.monotonic()<until:
  v=snap()
  if v['round_open'] and not v['freeze'] and not v['lo3']:return v
  qa('fast')
 raise AssertionError(('not live',status(),v))
def wait_pause():
 until=time.monotonic()+30
 while time.monotonic()<until:
  v=pause()
  if v['paused']:return v
 raise AssertionError(('not paused',status(),v))
def clear():
 assert cmd('mq2_clear server_error').endswith('cleared')
 assert status()['idle'] and status()['healthy']
def load(full=True,one=False,ready=True):
 global mid,generation,players
 if not status()['idle']:clear() # Normal recovery cleanup, never erase history/high-water mark.
 generation=int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text())+1
 mid=('7e5700' if full else '052000')+f'{time.time_ns():018x}'[-18:]
 size=5 if full else 2;players=[]
 for i in range(size*2):
  team=1 if i<size else 2;captain=i in (0,size);bot=full and (not captain or (one and i!=0))
  steam='bot:'+hashlib.sha256(f'{mid}:{generation}:{team}:{i+1}'.encode()).hexdigest()[:24] if bot else str(76561198000000000+i)
  players.append({'steam_id':steam,'team':team,'name':('Neo' if team==1 else 'Forest') if captain else 'Player'+str(i),
                  'bot':bot,'captain':int(captain),'locale':'pl' if team==1 else 'en'})
 payload={'game':'cs16','match_id':mid,'generation':generation,'config_hash':'b'*64,'contract_version':3,'starting_ct_team':2,
          'map':'de_dust2','team_size':size,'teams':{'1':'Neo team','2':'Forest team'},'players':players,
          'rules':{'mr':15 if full else 8,'ot_mr':3,'test':full}}
 if full:payload['rules']['test_type']='full';payload['test_owner']=players[0]['steam_id']
 (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(payload))
 assert cmd(f'mq2_load {mid} {generation}').endswith('loaded'),status()
 for i,row in enumerate(players):
  if not row['bot']:assert qa(f'add {i}')=='qa_added'
 assert not any('Dealt:' in x or 'Zadane:' in x for x in feedback(0))
 if not ready:return snap()
 qa('ready');v=live();assert status()['restarts_completed']==3
 assert next(x for x in v['clients'] if x['slot']==0)['team']==1
 print('PASS signed starting T/load/ready/3 restarts,',mid,'generation',generation,flush=True)
 return v
def expect_line(slot,text):
 rows=feedback(slot);assert text in rows,(text,rows);return rows
def persist(label):
 (root.parent.parent/f'feedback-061-{label}.json').write_text(json.dumps({'match_id':mid,'generation':generation,'events':events()},indent=2))

assert status()['controller_version']=='0.6.1'
assert status()['reconnect_budget']==1 and status()['tactical_limit']==3 and status()['ready_seconds']==300
if a.mode=='tactical':
 load(ready=False);qa('ready')
 # Observe first real freeze following the third actual restart. Do not advance it.
 end=time.monotonic()+40
 while time.monotonic()<end:
  v=snap()
  if not v['lo3'] and v['freeze'] and status()['restarts_completed']==3:break
 assert status()['phase']=='live' and v['freeze'] and not v['round_open'],(status(),v)
 qa('talk 0 pause');p=wait_pause();assert p['timeouts']==[1,0] and p['tactical'],p
 stable=obj('player 5');score=status()['score'];start=time.monotonic()
 qa('timeout 1');assert qa('legacy-pause 1')=='qa_denied';assert qa('legacy-pause -1')=='qa_denied'
 qa('talk 0 unpause');qa('talk 0 unpause');assert pause()['votes']==1
 # Bot captain is not used; one captain's vote never resumes, ordinary 30-second timer does.
 while time.monotonic()-start<35:
  if not pause()['paused']:break
  time.sleep(1)
 assert 18<time.monotonic()-start<35
 assert not pause()['paused'] and status()['score']==score and obj('player 5')==stable
 qa('talk 0 pause');assert pause()['timeouts']==[2,0] and pause()['paused']
 qa('talk 5 unpause');assert pause()['votes']==2
 qa('talk 0 unpause');assert not pause()['paused']
 qa('talk 0 pause');assert pause()['timeouts']==[3,0] and pause()['votes']==0
 qa('talk 0 unpause');qa('expire-vote 5 0');assert not pause()['paused']
 qa('talk 0 pause');assert not pause()['paused'] and not pause()['pending'] and pause()['timeouts']==[3,0]
 assert status()['score']==score and obj('player 5')==stable
 assert len([e for e in events() if e['type']=='resume'])==3
 print('PASS first freeze, natural 30s expiry, consecutive freeze pauses 1/2/3, fourth denied; captain-only, both vote orders, duplicates, expiry race; score/equipment/position retained',flush=True)
 live();qa('timeout 5');assert pause()['pending'] and not pause()['paused'] and pause()['timeouts']==[3,0]
 qa('timeout 5');qa('eliminate 2');wait_pause();assert pause()['timeouts']==[3,1]
 qa('talk 5 unpause');qa('drop 5');qa('add 5');assert pause()['votes']==2
 qa('expire-vote 0 1');assert not pause()['paused'] and pause()['votes']==0
 assert len([e for e in events() if e['type']=='resume'])==4
 assert status()['score']==[1,0];persist('tactical');clear()
 print('PASS live-round request waits for round end; one charge on start, independent team budget, captain reconnect, reverse expiry race',flush=True)
elif a.mode=='disconnect':
 load(False);qa('timeout 0');assert pause()['timeouts']==[0,0]
 qa('drop 1');qa('eliminate 2');wait_pause()
 assert pause()['disconnect'] and pause()['timeouts']==[0,0] and obj('safety')['reconnect_used']==[1,0]
 start=time.monotonic();qa('talk 0 unpause');qa('talk 2 unpause');assert pause()['votes']==0 and pause()['disconnect']
 # Real system-pause timer; no accelerated clock. Queued tactical request must survive it.
 while time.monotonic()-start<100:
  p=pause()
  if not p['disconnect']:break
  time.sleep(3)
 assert 78<time.monotonic()-start<100
 assert p['tactical'] and p['timeouts']==[1,0] and status()['score']==[1,0],p
 qa('add 1');qa('talk 0 unpause');qa('talk 2 unpause');live()
 print('PASS one real 90s reconnect pause, captain votes blocked, pending tactical preserved and charged only afterwards',flush=True)
 qa('drop 1');qa('eliminate 2')
 end=time.monotonic()+18
 while time.monotonic()<end:
  if snap()['roster'][1]['absence']==3:break
 assert snap()['roster'][1]['absence']==3 and not pause()['paused'] and obj('safety')['reconnect_used']==[1,0]
 qa('add 1');live();qa('drop 3');qa('eliminate 1');wait_pause()
 assert pause()['disconnect'] and obj('safety')['reconnect_used']==[1,1]
 qa('add 3');qa('fast');live();assert status()['score']==[2,1]
 qa('timeout 2');qa('eliminate 1');wait_pause();qa('talk 2 unpause');qa('direct-reset')
 assert status()['phase']=='recovery' and not status()['healthy'] and pause()['votes']==0
 n=sum(e['type']=='resume' for e in events());qa('talk 0 unpause');qa('fast')
 assert sum(e['type']=='resume' for e in events())==n and status()['phase']=='recovery'
 persist('disconnect');clear()
 print('PASS second disconnect -> grace only, opposing team retains own free pause; score preserved; recovery denies timer and votes',flush=True)
elif a.mode=='ready':
 for full in (True,False):
  before=int(time.time());load(full,ready=False)
  loaded=next(e for e in events() if e['type']=='loaded')
  assert before+300<=loaded['data']['ready_deadline']<=int(time.time())+300
  # All connected, one human never readies. Test and ranked both expire.
  for i,p in enumerate(players):
   if i:qa(f'talk {i} ready')
  qa('ready-fast');time.sleep(1);qa('talk 0 ready')
  assert obj('safety')['ready_expired']
  rows=[e for e in events() if e['type']=='not_ready'];assert len(rows)==1 and rows[0]['data']['missing']==[players[0]['steam_id']],rows
  assert not any(e['type']=='live' for e in events()) and status()['score']==[0,0]
  assert any('Uplynal czas' in x for x in feedback(0));persist('ready-test' if full else 'ready-ranked');clear()
 print('PASS journal has exact 300s deadline, connected unready player cancels ranked/full-test once, late /ready denied, no LIVE, normal idle cleanup',flush=True)
