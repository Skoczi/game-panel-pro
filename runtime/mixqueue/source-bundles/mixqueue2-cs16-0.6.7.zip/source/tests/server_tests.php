<?php

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\Engine;
use Flute\Modules\MixQueue2\Domain\ServerRegistry;
use Flute\Modules\MixQueue2\Domain\ServerTests;
use Flute\Modules\MixQueue2\Http\AgentApi;

function testFixture(): array
{
    $e = fixture(1);
    $caps = Engine::json(['modes' => ['5v5'], 'maps' => ['de_dust2', 'de_nuke']]);
    $e->db->run('UPDATE mq2_servers SET game=?,adapter=?,capabilities=? WHERE id=?', ['cs16', 'amxx', $caps, 's1']);
    $ob = [
        'map_inventory' => [
            'version' => 1,
            'source' => 'bsp_v30',
            'complete' => true,
            'maps' => ['de_dust2', 'de_nuke']
        ],
        'bridge' => 1,
        'idle' => true,
        'healthy' => true,
        'matchid' => '',
        'agent_protocol' => 2,
        'controller' => 'matchbot',
        'controller_version' => '0.5.2',
        'solo_test' => true
    ];
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', ['s1', Engine::json($ob), $e->now()]);
    return [$e, new ServerTests($e), $ob];
}

function tevent(array $t, string $type, int $sequence, array $data = []): array
{
    return [
        'event_id' => Engine::id(),
        'match_id' => $t['id'],
        'generation' => (int) $t['generation'],
        'schema_version' => 1,
        'boot_id' => str_repeat('a', 32),
        'sequence' => $sequence,
        'type' => $type,
        'data' => $data
    ];
}

function pollTest(Engine $e, array $ob): array
{
    $raw = Engine::json(['action' => 'poll', 'healthy' => true, 'observation' => $ob]);
    $key = str_repeat('x', 32);
    $stamp = (string) $e->now();
    return ( new AgentApi($e, ['s1' => $key]) )->handle(
        's1',
        $stamp,
        hash_hmac('sha256', "s1\n$stamp\n$raw", $key),
        $raw
    );
}

$cases = [
    'solo lifecycle never creates ranked records or changes ELO' => function () {
        [$e, $tests, $ob] = testFixture();
        $ratings = $e->db->all('SELECT * FROM mq2_ratings');
        $t = $tests->start('s1', '1', 'de_dust2');
        rejects(fn() => $tests->start('s1', '1', 'de_dust2'), 'server_busy');
        rejects(fn() => $e->join('1', 'cs16-5v5'), 'test_busy');
        $cmd = pollTest($e, $ob)['commands'][0];
        check(
            count($cmd['payload']['players']) === 1 && $cmd['payload']['rules']['test'] === true,
            'Not a solo command'
        );
        $load = tevent($t, 'loaded', 1, ['map' => 'de_dust2', 'config_hash' => $cmd['payload']['config_hash']]);
        $wrong = $load;
        $wrong['data']['config_hash'] = str_repeat('0', 64);
        rejects(fn() => $e->event('s1', $wrong), 'config');
        check($e->event('s1', $load) && !$e->event('s1', $load), 'Idempotence failed');
        rejects(fn() => $e->event('foreign', tevent($t, 'live', 2)), 'lease');
        rejects(fn() => $e->event('s1', tevent($t, 'live', 3)), 'sequence');
        rejects(fn() => $e->event('s1', tevent($t, 'live', 2)), 'transition');
        $e->event('s1', tevent($t, 'connected', 2, ['steam_id' => $t['steam_id'], 'connected' => true]));
        $e->event('s1', tevent($t, 'live', 3));
        $e->event('s1', tevent($t, 'pause', 4));
        $e->event('s1', tevent($t, 'resume', 5));
        check($tests->find($t['id'])['state'] === 'live', 'Pause broke solo lifecycle');
        $e->event('s1', tevent($t, 'finished', 6, ['team1_score' => 16, 'team2_score' => 0]));
        check($tests->find($t['id'])['state'] === 'stopping', 'Missing cleanup');
        check((bool) $e->db->one('SELECT * FROM mq2_leases'), 'Lease freed before idle');
        $idle = tevent($t, 'idle', 7);
        $e->event('s1', $idle);
        check(!$e->event('s1', $idle), 'Idle duplicate rejected');
        check(!$e->db->one('SELECT * FROM mq2_leases'), 'Lease not released');
        foreach ([
            'mq2_matches',
            'mq2_match_players',
            'mq2_settlements',
            'mq2_rating_changes',
            'mq2_penalties'
        ] as $table)
            check(!$e->db->one("SELECT * FROM $table"), "Ranked pollution: $table");
        check($ratings === $e->db->all('SELECT * FROM mq2_ratings'), 'Ratings changed');
    },
    'stop drains pending events but holds reservation until idle' => function () {
        [$e, $tests] = testFixture();
        $t = $tests->start('s1', '1', 'de_dust2');
        $tests->stop($t['id'], '1');
        $tests->stop($t['id'], '1');
        $commands = $e->commands('s1');
        check(count($commands) === 1 && $commands[0]['type'] === 'abort', 'Load not superseded');
        $e->event('s1', tevent($t, 'loaded', 1));
        check($tests->find($t['id'])['state'] === 'stopping', 'Delayed load resurrected test');
        rejects(fn() => ( new ServerRegistry($e) )->assertIdle('s1'), 'server_busy');
        $e->event('s1', tevent($t, 'idle', 2));
        $next = $tests->start('s1', '1', 'de_nuke');
        check((int) $next['generation'] === ( (int) $t['generation'] + 1 ), 'Generation reuse');
        rejects(fn() => $e->event('s1', tevent($t, 'idle', 3)), 'lease');
    },
    'capability and freshness are mandatory' => function () {
        [$e, $tests, $ob] = testFixture();
        rejects(fn() => $tests->start('s1', '1', 'de_bad'), 'test_map');
        $old = $ob;
        unset($old['agent_protocol']);
        $e->db->run('UPDATE mq2_observations SET payload=?', [Engine::json($old)]);
        rejects(fn() => $tests->start('s1', '1', 'de_dust2'), 'test_version');
        $legacy = $ob;
        unset($legacy['controller']);
        $legacy['controller_version'] = '0.3.0';
        $e->db->run('UPDATE mq2_observations SET payload=?', [Engine::json($legacy)]);
        rejects(fn() => $tests->start('s1', '1', 'de_dust2'), 'test_version');
        pollTest($e, $legacy);
        check(
            !(bool) $e->db->one('SELECT healthy FROM mq2_servers WHERE id=?', ['s1'])['healthy'],
            'Legacy controller entered the pool'
        );
        pollTest($e, $ob);
        $e->db->run('UPDATE mq2_observations SET payload=?,observed_at=?', [Engine::json($ob), $e->now() - 31]);
        rejects(fn() => $tests->start('s1', '1', 'de_dust2'), 'test_offline');
    },
    'worker expires abandoned tests without releasing an unconfirmed server' => function () {
        [$e, $tests] = testFixture();
        $t = $tests->start('s1', '1', 'de_dust2');
        $e->db->run('UPDATE mq2_server_tests SET deadline=?', [$e->now() - 1]);
        $e->tick();
        check($tests->find($t['id'])['state'] === 'stopping', 'Timeout missing');
        check((bool) $e->db->one('SELECT * FROM mq2_leases'), 'Unsafe timeout release');
        check(!$e->db->one('SELECT * FROM mq2_penalties'), 'Test penalty');
    },
    'lost identity initiates cleanup through signed agent API' => function () {
        [$e, $tests, $ob] = testFixture();
        $t = $tests->start('s1', '1', 'de_dust2');
        $cmd = $e->commands('s1')[0];
        $e->event('s1', tevent($t, 'loaded', 1, [
            'map' => 'de_dust2',
            'config_hash' => $cmd['payload']['config_hash']
        ]));
        $commands = pollTest($e, $ob)['commands'];
        check(
            $tests->find($t['id'])['state'] === 'stopping' && $commands[0]['type'] === 'abort',
            'Identity loss not reconciled'
        );
    }
];
foreach ($cases as $name => $fn) {
    $fn();
    echo "PASS $name\n";
}
echo count($cases) . " server-test scenarios passed\n";
