<?php

declare(strict_types = 1);

// Replay an actual isolated controller journal. Only assignment identity/map/hash
// are rebound to this independent fixture; event payloads and ordering stay intact.
define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Statistics};

$journal = json_decode(file_get_contents($argv[1]), true, 512, JSON_THROW_ON_ERROR);
$e = fixture();
$e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
    'cs16',
    Engine::json(['modes' => ['5v5'], 'maps' => $e->ladder('cs16-5v5')['maps']]),
    's1'
]);
$m = readyMatch($e, 'cs16-5v5');
$players = $e->db->all('SELECT user_id,team FROM mq2_match_players WHERE match_id=? ORDER BY team,user_id', [$m['id']]);
foreach ($players as $i => $p) {
    $steam = (string) ( 76561198000000000 + $i );
    $e->db->run('UPDATE mq2_match_players SET steam_id=? WHERE match_id=? AND user_id=?', [
        $steam,
        $m['id'],
        $p['user_id']
    ]);
}
$e->db->run('UPDATE mq2_commands SET payload=? WHERE match_id=? AND type=?', [
    Engine::json($e->configuration($m['id'])),
    $m['id'],
    'load'
]);
foreach ($journal as $v) {
    $v['match_id'] = $m['id'];
    $v['generation'] = (int) $m['generation'];
    if ($v['type'] === 'loaded') {
        $v['data']['map'] = $m['picked_map'];
        $v['data']['config_hash'] = $e->configuration($m['id'])['config_hash'];
    }
    check($e->event('s1', $v), 'Native event was not accepted: ' . $v['type']);
    check($e->event('s1', $v) === false, 'Native replay was not idempotent: ' . $v['type']);
}
$surrender = array_values(array_filter($journal, fn($v) => $v['type'] === 'surrendered'))[0]['data'];
$final = $e->match($m['id']);
check($final['state'] === 'finished', 'Native surrender did not finish');
check(
    (int) $final['team1_score'] === $surrender['team1_score']
    && (int) $final['team2_score'] === $surrender['team2_score'],
    'Native score changed'
);
check((int) $e->db->one('SELECT winner FROM mq2_match_results')['winner'] === 2, 'Wrong native winner');
check(count($e->db->all('SELECT * FROM mq2_penalties')) === 1, 'Wrong native penalty count');
check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Wrong native ELO count');
check(count($e->db->all('SELECT * FROM mq2_settlements')) === 1, 'Wrong native settlement count');
$profile = ( new Statistics($e) )->profile($players[0]['user_id'], 'cs16-5v5');
check($profile['overall']['losses'] === 1, 'Native profile result missing');
echo
    'PASS real controller journal: '
        . count($journal)
        . " events, retries, penalty, surrender, ELO and native profile\n"
;
