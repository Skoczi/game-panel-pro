"""0.6.4 MR12/MR15/Wingman integration against an isolated ReGameDLL instance.

QA entities represent Steam roster members. Actual engine round endings and
phase transitions are used; only pending LO3/freeze transitions are accelerated.
This is not real Steam-client acceptance.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--agent', required=True)
p.add_argument('--resume', action='store_true', help='Resume only after the two recorded successful regulation cases')
a = p.parse_args()
root = Path(a.root).resolve()
assert '/csco-lab/matchbot-063-profile/' in str(root)
spec = importlib.util.spec_from_file_location('agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', 27095, os.environ['MQ2_QA_RCON_PASSWORD'])
last = 0
proof = {'controller': '0.6.4', 'acceptance': 'isolated GameDLL QA; not Steam-client acceptance',
         'qa_sha256': hashlib.sha256((root/'addons/matchbot/dlls/matchbot_csco_mm.so').read_bytes()).hexdigest(),
         'language_sha256': hashlib.sha256((root/'addons/matchbot/language.txt').read_bytes()).hexdigest(),
         'cases': []}
case = None


def cmd(value):
    global last
    time.sleep(max(0, 1.05 - (time.monotonic() - last)))
    result = rcon.command(value)
    last = time.monotonic()
    return result


def qa(value):
    return cmd('mq2_qa '+value)


def obj(value):
    return json.loads(qa(value))


def status():
    return json.loads(cmd('mq2_status'))


def events():
    return [event for line in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines()
            if (event := json.loads(line))['match_id'] == mid]


def record(stage, clock):
    case['clocks'].append({'stage': stage, **clock})


def clear():
    assert cmd('mq2_clear server_error').endswith('cleared')
    state = status()
    assert state['idle'] and state['healthy'] and state['rules_ready'], state
    assert obj('botstate')['native_bots'] == 0
    assert int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) == generation


def finish():
    case['events'] = events()
    clear()
    proof['cases'].append(case)
    (root.parent.parent/'formats-064-proof.json').write_text(json.dumps(proof, indent=2))


def check(stage, paused=False, overtime=False, frozen=None):
    clock = obj('round-clock')
    assert clock['healthy'] and clock['team_size'] == size, clock
    expected = 30 if kind != 'ranked' else 120 if size == 2 else 105
    freeze = 8 if size == 2 else 10
    assert clock['configured_seconds'] == expected, clock
    assert clock['freeze_seconds'] == freeze, clock
    assert abs(clock['buy_minutes'] - (.5 if paused else .25)) < .0001, clock
    assert clock['startmoney'] == (10000 if overtime else 800), clock
    assert clock['c4_seconds'] == 35 and clock['voice_enabled'] == 1 and clock['pausable'] == 0, clock
    if frozen is not None:
        assert clock['freeze'] == frozen, clock
    if frozen and not paused:
        assert clock['intro_seconds'] == clock['clock_seconds'] == freeze, clock
    if not clock['freeze']:
        assert clock['clock_seconds'] == expected and clock['round_open'], clock
    record(stage, clock)
    return clock


def live():
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        state = obj('snapshot')
        boundary = obj('break-clock')
        assert not boundary['in_break'], ('Unexpected half boundary before expected played-round count', boundary)
        if state['round_open'] and not state['freeze'] and not state['lo3']:
            return state
        qa('fast')
    raise AssertionError(('not live', status(), state))


def first_freeze(expected_state=3):
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        # One atomic native response: separate snapshot/state queries can cross
        # warmup -> FIRST_HALF while LO3 is only just starting.
        state = obj('break-clock')
        if state['freeze'] and not state['round_open'] and not state['lo3'] and state['completed']==3 and state['state']==expected_state:
            clock = obj('round-clock')
            if clock['state'] == expected_state:
                assert clock['healthy'], clock
                return clock
        # Poll the real clock here. During LO3 the final freeze can already be
        # active while the LO3 task still reports running; accelerating that
        # transition would accidentally skip the exact freeze under test.
    raise AssertionError(('not first live freeze', status(), state))


def load(test_kind, team_size, mr):
    global mid, generation, players, kind, size, case
    kind, size = test_kind, team_size
    assert status()['idle'] and status()['healthy']
    generation = int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) + 1
    mid = ('7e5700' if kind == 'full' else '064000') + f'{time.time_ns():018x}'[-18:]
    players = []
    for i in range(1 if kind == 'solo' else size*2):
        team, captain = (1 if i < size else 2), i in (0, size)
        bot = kind == 'full' and i != 0
        identity = ('bot:' + hashlib.sha256(f'{mid}:{generation}:{team}:{i+1}'.encode()).hexdigest()[:24]
                    if bot else str(76561198000000000+i))
        players.append({'steam_id': identity, 'team': team, 'captain': int(captain), 'bot': bot,
                        'name': ('Neo' if team == 1 else 'Forest') if captain else 'Player'+str(i),
                        'locale': 'pl' if team == 1 else 'en'})
    assignment = {'game': 'cs16', 'match_id': mid, 'generation': generation, 'config_hash': 'a'*64,
                  'contract_version': 3, 'starting_ct_team': 2, 'map': 'de_dust2', 'team_size': size,
                  'teams': {'1': 'Neo team', '2': 'Forest team'}, 'players': players,
                  'rules': {'mr': mr, 'ot_mr': 3, 'test': kind != 'ranked'}}
    if kind == 'full':
        assignment['rules']['test_type'] = 'full'
        assignment['test_owner'] = players[0]['steam_id']
    (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(assignment))
    response = cmd(f'mq2_load {mid} {generation}')
    assert response.endswith('loaded'), (response, status())
    for i, row in enumerate(players):
        if not row['bot']:
            assert qa(f'add {i}') == 'qa_added'
    case = {'case': f'{kind}_{size}v{size}', 'match_id': mid, 'generation': generation, 'clocks': [], 'mr': mr}
    warm = obj('round-clock')
    assert warm['healthy'] and warm['freeze_seconds'] == 0 and warm['startmoney'] == 16000, warm
    assert warm['mr']==mr and warm['ot_mr']==3 and warm['regulation_rounds']==mr*2 and warm['overtime_rounds']==6, warm
    record('warmup', warm)
    if kind == 'ranked':
        qa('ready')
    else:
        qa('talk 0 ready')
    first_freeze()
    check('initial_freeze', frozen=True)


def pause_cycle(number, overtime=False, already_pending=False):
    before = obj('player '+str(size))
    if not already_pending:
        qa('talk 0 pause')
    state = obj('pause-state')
    assert state['paused'] and state['tactical'] and state['timeouts'] == [number, 0], state
    check(f'pause_{number}', paused=True, overtime=overtime, frozen=True)
    qa('talk 0 unpause')
    assert obj('pause-state')['paused']
    qa(f'talk {size} unpause')
    check(f'resumed_freeze_{number}', overtime=overtime, frozen=True)
    assert obj('player '+str(size)) == before
    assert sum(event['type'] == 'resume' for event in events()) == number


def win(team, boundary=False, queue_timeout=False):
    live()
    if boundary:
        qa('feedback-clear')
    if queue_timeout:
        qa('talk 0 pause')
        state = obj('pause-state')
        assert state['pending'] and not state['paused'] and state['timeouts'] == [1, 0], state
    response = qa('eliminate '+str(3-team))
    assert 'qa_damage_applied' in response, response


def observe_break(expected_score, before_overtime, pending_timeout=False):
    until = time.monotonic()+15
    while time.monotonic()<until:
        first = obj('break-clock')
        if first['in_break']:
            break
    assert first['in_break'], first
    assert abs(first['deadline']-first['since']-20)<.01, first
    assert first['kind'] == ('before_overtime' if before_overtime else 'halftime'), first
    assert first['phase'] == 'halftime' and first['state'] == 4, first
    assert [first['team1_score'], first['team2_score']] == expected_score, first
    assert not first['round_open'] and not first['lo3'] and first['freeze'], first
    assert first['title_halftime'] and first['header_bytes'] <= 63, first
    assert first['tactical_pending'] == pending_timeout and not first['tactical_running'], first
    baseline_timeouts = first['timeouts']
    attempted = obj('break-try-next')
    assert attempted['in_break'] and attempted['state'] == 4, attempted
    # Tactical commands do not shorten the system intermission or consume a quota.
    qa('talk 0 pause')
    qa('talk 0 unpause')
    pl = qa('feedback-all 0')
    en = qa('feedback-all '+str(size))
    if before_overtime:
        score_text = ':'.join(map(str, expected_score))
        assert all(text in pl for text in ['REMIS', score_text, 'MR3', 'do 4 wygranych', '3:3']), pl
        assert all(text in en for text in ['TIED', score_text, 'MR3', 'first to 4', '3:3']), en
    else:
        assert 'Zmiana stron' in pl and '20 s' in pl, pl
        assert 'Switching sides' in en and '20 s' in en, en
    samples = [first]
    until = time.monotonic()+25
    while time.monotonic()<until:
        current = obj('break-clock')
        samples.append(current)
        if not current['in_break']:
            break
        assert current['phase']=='halftime' and not current['round_open'] and not current['lo3'], current
        assert current['timeouts'] == baseline_timeouts
        assert current['tactical_pending'] == pending_timeout and not current['tactical_running'], current
        assert [current['team1_score'], current['team2_score']] == expected_score
    assert not current['in_break'] and 20 <= current['now']-first['since'] < 23, current
    assert current['timeouts'] == baseline_timeouts
    assert status()['healthy'] and status()['rules_ready']
    assert sum(event['type']=='loaded' for event in events()) == 1
    case.setdefault('breaks', []).append({'score': expected_score, 'first': first, 'samples': samples, 'pl': pl, 'en': en})
    print('PASS real20s '+first['kind']+' at '+':'.join(map(str, expected_score))+'; PL/EN, frozen, no tactical quota/reset', flush=True)


def wait_round(count, reason, timeout=45):
    deadline = time.monotonic()+timeout
    while time.monotonic()<deadline:
        scored = [event for event in events() if event['type'] in ('round', 'finished')]
        if len(scored)>=count:
            break
        time.sleep(.3)
    assert len(scored)==count and scored[-1]['data']['round_reason']==reason, scored
    assert status()['healthy'] and status()['rules_ready']
    return scored[-1]


assert status()['controller_version']=='0.6.4'
if a.resume:
    saved=json.loads((root.parent.parent/'formats-064-proof.json').read_text())
    assert saved['qa_sha256']==proof['qa_sha256'] and saved['controller']=='0.6.4'
    assert len(saved['cases'])==2 and [row['mr'] for row in saved['cases']]==[12,15]
    proof=saved
    interrupted=status()
    assert interrupted['matchid'].startswith('064000') and interrupted['phase']=='live'
    interrupted_mid=interrupted['matchid'].split(':')[0]
    proof['harness_sampling_retry']={'reason':'Separate old snapshot and new state crossed warmup/LO3; now read one atomic break-clock response',
        'status_before_cleanup':interrupted,'actual_round_clock':obj('round-clock'),
        'events':[json.loads(line) for line in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if json.loads(line)['match_id']==interrupted_mid]}
    assert cmd('mq2_clear server_error').endswith('cleared')
    assert status()['idle'] and status()['healthy']
    print('PASS harness resumed with atomic LO3/state sampling; preserved two completed cases and interrupted attempt history',flush=True)
else:
    assert status()['idle'] and status()['healthy']

    # Signed MR12: 12:12, tied first overtime 15:15, then second overtime 19:15.
    load('ranked',5,12)
    pause_cycle(1)
    check('after_tactical_resume',frozen=True)
    expected=[0,0]
    boundaries={12:False,24:True,27:False,30:True,33:False}
    for number,team in enumerate([1]*12+[2]*12+[1]*3+[2]*3+[1]*4,1):
        win(team,boundary=number in boundaries)
        expected[team-1]+=1
        wait_round(number,'elimination')
        assert status()['score']==expected
        if number in boundaries:
            observe_break(expected,before_overtime=boundaries[number])
        elif number<34:
            assert not obj('break-clock')['in_break']
    assert status()['phase']=='finished' and status()['score']==[19,15]
    scored=[row for row in events() if row['type'] in ('round','finished')]
    assert len(scored)==34 and sum(row['type']=='finished' for row in scored)==1
    assert all(row['data']['round_reason']=='elimination' and len(row['data']['players'])==10 for row in scored)
    clock=obj('finish-clock')
    assert clock['active'] and clock['connected']==10 and abs(clock['deadline']-clock['since']-180)<.01
    case['postmatch_clock']=clock
    print('PASS MR12 12:12 ->15:15 ->19:15; real5x20s breaks, 3+3 MR3, 34 complete ten-player snapshots, one finished, retained180s deadline',flush=True)
    finish()

# Complete regulation regression paths using real damage and round transitions.
for selected,size_ in ([(8,2)] if a.resume else [(15,5),(8,2)]):
    load('ranked',size_,selected)
    for number in range(1,selected+2):
        win(1,boundary=number==selected)
        wait_round(number,'elimination')
        assert status()['score']==[number,0]
        if number==selected:observe_break([selected,0],before_overtime=False)
    assert status()['phase']=='finished'
    assert sum(row['type']=='finished' for row in events())==1
    print('PASS regulation '+str(size_)+'v'+str(size_)+' MR'+str(selected)+' ends '+str(selected+1)+':0',flush=True)
    finish()

# Format drift cannot change signed round/win boundaries or bypass recovery.
for setting,value in [('mb_play_rounds','30'),('mb_play_rounds_ot','8'),('mb_play_ot_mode','2')]:
    load('ranked',5,12)
    live()
    win(1)
    wait_round(1,'elimination')
    live()
    cmd(setting+' '+value)
    qa('eliminate 2')
    deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        state=status()
        if state['phase']=='recovery':break
    assert state['phase']=='recovery' and not state['healthy'] and state['score']==[1,0],state
    assert state['rules_issue']==setting,state
    assert len([row for row in events() if row['type'] in ('round','finished')])==1
    assert cmd(f'mq2_load {mid} {generation}')=='busy'
    case['drift']={'cvar':setting,'attempted_value':value,'status':state}
    print('PASS '+setting+' drift: recovery before incorrect score/state/reset, 1:0 retained, reload refused',flush=True)
    finish()

assert status()['idle'] and status()['healthy']
proof['final_status']=status()
proof['final_generation']=generation
(root.parent.parent/'formats-064-proof.json').write_text(json.dumps(proof,indent=2))
print('PASS complete isolated064format runtime; GameDLL entities, not realSteamclients',flush=True)
