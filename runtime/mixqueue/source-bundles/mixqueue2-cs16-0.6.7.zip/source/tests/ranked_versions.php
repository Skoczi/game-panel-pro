<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, ServerRegistry};
use Flute\Modules\MixQueue2\Infrastructure\ReleaseCatalog;

$current = cs16Status();
check(ServerRegistry::supportsRankedCs16($current), 'Minimum accepted runtime rejected');
foreach (['0.5.2', '0.6.0', '0.6.1', '0.6.2', '0.6.3', '0.6.4-dev', '', null] as $version)
    check(!ServerRegistry::supportsRankedCs16([...$current, 'controller_version' => $version]), 'Older/invalid controller admitted');
foreach (['0.5.2', '0.6.0', '0.6.1-dev', '', null] as $version)
    check(!ServerRegistry::supportsRankedCs16([...$current, 'agent_version' => $version]), 'Older/invalid agent admitted');
check(ServerRegistry::supportsRankedCs16([
    ...$current, 'controller_version' => ReleaseCatalog::CS16, 'agent_version' => ReleaseCatalog::AGENT
]), 'Recommended release rejected');
foreach (['assignment_contract' => 2, 'stats_version' => 1, 'side_choice' => 0, 'pause_policy' => 1,
    'tactical_limit' => 2, 'tactical_seconds' => 60, 'ready_seconds' => 180,
    'rules_ready' => false, 'player_ready' => false, 'idle' => false, 'matchid' => 'active'] as $field => $value)
    check(!ServerRegistry::supportsRankedCs16([...$current, $field => $value]), 'Version bypassed capability: ' . $field);
echo "PASS ranked version minimums, malformed versions and capability checks\n";

foreach (['5v5' => 10, '2v2' => 4] as $mode => $size) {
    $e = fixture($size);
    $ladder = 'cs16-' . $mode;
    $maps = $e->ladder($ladder)['maps'];
    $e->db->run('UPDATE mq2_servers SET game=?,adapter=?,capabilities=?', [
        'cs16', 'amxx', Engine::json(['maps' => $maps, 'modes' => [$mode]])
    ]);
    $old = [...$current, 'controller_version' => '0.6.1', 'agent_version' => '0.6.0',
        'map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $maps]];
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', ['s1', Engine::json($old), $e->now()]);
    for ($i = 1; $i <= $size; ++$i) $e->join((string) $i, $ladder);
    check($e->tick() === 0, 'Old server allocated ranked ' . $mode);
    check(!$e->db->all('SELECT * FROM mq2_leases'), 'Rejected version consumed a lease');
    check((int) $e->db->one('SELECT generation FROM mq2_servers')['generation'] === 0, 'Rejected version consumed generation');
    check(count($e->db->all('SELECT * FROM mq2_claims')) === $size, 'Version gate lost waiting players');
    $e->db->run('UPDATE mq2_observations SET payload=?', [Engine::json([...$old, ...$current])]);
    check($e->tick() === 1, 'Compatible minimum did not allocate ' . $mode);
}
echo "PASS MR15/MR8 old runtime rejection preserves queue/lease/generation; compatible minimum allocates\n";
