"""Cleanup recovery against an isolated, idle HLDS; inject lost replies after real commands.

No web/API calls. Never run against a server with a live assignment or real players.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import time

p = argparse.ArgumentParser()
p.add_argument('--game-root', required=True)
p.add_argument('--agent', required=True)
p.add_argument('--port', type=int, default=27095)
a = p.parse_args()
spec = importlib.util.spec_from_file_location('mq_agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', a.port, os.environ['MQ2_QA_RCON_PASSWORD'])


class FaultRcon:
    def __init__(self, fault):
        self.fault, self.cleared, self.calls = fault, False, []

    def command(self, command):
        # Respect the test engine's query limits, including challenge packets.
        time.sleep(1.05)
        self.calls.append(command)
        result = rcon.command(command)
        if command == 'mq2_clear':
            self.cleared = True
            if self.fault == 'clear_reply':
                self.fault = None
                raise TimeoutError('QA: drop response after real clear')
        elif command == 'mq2_status' and self.cleared and self.fault == 'status_reply':
            self.fault = None
            raise TimeoutError('QA: drop first post-clear status')
        return result


for fault in (None, 'clear_reply', 'status_reply'):
    spool = agent.Spool(':memory:')
    adapter = agent.AmxxAdapter.__new__(agent.AmxxAdapter)
    adapter.spool, adapter.root = spool, Path(a.game_root)
    adapter.rcon = FaultRcon(fault)
    assert adapter.cleanup_complete(adapter.status()), 'QA server must be idle before starting'
    mid = f'{time.time_ns():024x}'
    payload = {'match_id':mid,'generation':1,'config_hash':'b'*64,'game':'cs16',
               'team_size':5,'mode':'5v5','map':'de_dust2',
               'rules':{'mr':15,'ot_mr':3,'test':True},
               'players':[{'steam_id':'76561198000000000','team':1}]}
    command = {'id':mid,'match_id':mid,'generation':1,'type':'load','payload':payload}
    adapter.execute(command)
    assert adapter.status()['matchid'] == mid+':1'
    started = time.monotonic()
    try:
        adapter.execute({**command, 'type':'abort'})
    except TimeoutError:
        assert fault == 'status_reply'
    # Same command redelivery must never repeat a completed clear.
    adapter.execute({**command, 'type':'abort'})
    events = []
    spool.flush(events.append)
    assert len(events) == 1 and events[0]['event']['type'] == 'idle', events
    assert adapter.rcon.calls.count('mq2_clear') == 1, adapter.rcon.calls
    assert adapter.cleanup_complete(adapter.status())
    print(json.dumps({'fault':fault,'clear_commands':1,'idle_events':1,
                      'elapsed_seconds':round(time.monotonic()-started,2)}), flush=True)
    spool.db.close()
