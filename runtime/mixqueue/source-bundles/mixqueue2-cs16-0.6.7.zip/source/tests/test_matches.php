<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, TestMatches, Statistics};
use Flute\Modules\MixQueue2\Http\Application;

function fullFixture(int $humans = 2, int $generation = 0, bool $lab = false): array
{
    $e = fixture(10);
    $db = $e->db;
    $l = $e->ladder('cs16-5v5');
    if ($lab) {
        $l['maps'] = ['de_dust2', 'de_inferno', 'de_nuke'];
        $db->run('UPDATE mq2_ladders SET maps=? WHERE id=?', [Engine::json($l['maps']), 'cs16-5v5']);
    }
    $db->run('UPDATE mq2_servers SET generation=? WHERE id=?', [$generation, 's1']);
    $db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
        'cs16',
        Engine::json(['modes' => ['5v5'], 'maps' => $l['maps']]),
        's1'
    ]);
    $db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
        's1',
        Engine::json([
            ...cs16Status(),
            'idle' => true,
            'solo_test' => true,
            'matchid' => '',
            'full_test' => true,
            'assignment_contract' => 2,
            'agent_version' => '0.5.2',
            'map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $l['maps']],
            'agent_protocol' => 2,
            'controller' => 'matchbot',
            'controller_version' => '0.5.3'
        ]),
        $e->now()
    ]);
    $t = new TestMatches($e);
    $id = $t->create('1', 's1');
    check($t->create('1', 's1') === $id, 'Create retry duplicated');
    $t->fill($id, '1');
    $t->fill($id, '1');
    for ($i = 2; $i <= $humans; $i++) {
        $t->invite($id, '1', (string) $i);
        $t->join($id, (string) $i);
        $t->join($id, (string) $i);
    }
    check(count($db->all('SELECT * FROM mq2_match_players WHERE match_id=?', [$id])) === 10, 'Roster not 10');
    check(
        count($db->all('SELECT * FROM mq2_test_bots WHERE match_id=?', [$id])) === ( 10 - $humans ),
        'Incorrect bots'
    );
    return [$e, $t, $id];
}

function startFull(Engine $e, TestMatches $t, string $id, int $humans, bool $simulateLive = true): array
{
    $t->start($id, '1');
    $t->start($id, '1');
    for ($i = 1; $i <= $humans; $i++)
        $e->ready((string) $i, $id, true);
    while (( $m = $e->match($id) )['state'] === 'veto') {
        $p = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND captain=1 AND team=?', [
            $id,
            ( (int) $m['turn'] % 2 ) + 1
        ]);
        check(!str_starts_with($p['user_id'], 'bot:'), 'Bot did not auto veto');
        $e->ban($p['user_id'], $id, json_decode($m['maps'], true)[0], (int) $m['version']);
    }
    if ($simulateLive)
        live($e, $m);
    return $m;
}

if (defined('MQ2_FULL_HELPERS_ONLY'))
    return;
foreach ([1, 2, 10] as $n) {
    [$e, $t, $id] = fullFixture($n);
    $m = startFull($e, $t, $id, $n);
    $db = $e->db;
    $config = $e->configuration($id);
    check($config['contract_version'] === 2 && $config['rules']['test'] === true, 'Unsigned test flag');
    check(count($config['players']) === 10, 'Assignment dropped bots');
    $e->identify('1', $e->player('1')['steam_id'], 'Changed name');
    check($e->configuration($id) === $config, 'Captain labels changed after lock');
    $app = new Application($e);
    $state = $app->state('1', 'cs16-5v5', $id, true, true);
    check(count($state['match']['players']) === 10, 'API dropped bots');
    check(
        count($state['history']) === 1 && count($app->state('1', 'cs16-5v5')['history']) === 0,
        'History mixed ranked and test'
    );
    $stats = [];
    foreach ($config['players'] as $p)
        $stats[$p['steam_id']] = [
            'kills' => 2,
            'deaths' => 1,
            'assists' => 1,
            'damage' => 140,
            'headshots' => 1,
            'rounds' => 3
        ];
    event($e, $m, 'round', ['team1_score' => 2, 'team2_score' => 1, 'players' => $stats]);
    rejects(fn() => $t->stop($id, '2'), 'forbidden');
    $t->stop($id, '1');
    $t->stop($id, '1');
    $data = [
        'team1_score' => 2,
        'team2_score' => 1,
        'players' => $stats,
        'reason' => 'test_admin',
        'actor' => $config['test_owner']
    ];
    $ev = event($e, $m, 'test_ended', $data);
    check(!$e->event('s1', $ev), 'Replay applied');
    check($e->match($id)['state'] === 'finished', 'Did not finish');
    check(
        (int) $db->one('SELECT winner FROM mq2_match_results WHERE match_id=?', [$id])['winner'] === 0,
        'Manual end invented a winner'
    );
    check(
        !$db->all('SELECT * FROM mq2_ratings') && !$db->all('SELECT * FROM mq2_penalties'),
        'Test polluted ranked tables'
    );
    check(( new Statistics($e) )->profile('1', 'cs16-5v5')['overall']['played'] === 0, 'Overall polluted');
    rejects(fn() => $t->remove([$id], '1', 1), 'test_active');
    event($e, $m, 'idle');
    rejects(fn() => $t->remove([$id], '1', 2), 'delete_count');
    $t->remove([$id], '1', 1);
    check(!$db->one('SELECT id FROM mq2_matches WHERE id=?', [$id]), 'Delete incomplete');
    check(!$e->event('s1', $ev), 'Deleted event not acknowledged noop');
    $db->run('DELETE FROM mq2_test_tombstones');
    check(!$e->event('s1', $ev), 'Expired tombstone blocked agent');
    check(count($db->all('SELECT id FROM mq2_players')) === 10, 'Deleted real account');
    echo "PASS full test $n humans: lobby, bots, ready/veto, partial snapshot, no ELO, cleanup, delete/retry\n";
}
[$e, $t, $id] = fullFixture(2);
$app = new Application($e);
rejects(fn() => $app->act('2', ['action' => 'test_fill', 'match' => $id]), 'forbidden');
rejects(fn() => $t->join($id, '3'), 'test_invite');
$t->move($id, '1', '2');
$t->captain($id, '1', '2');
check(
    (int) $e->db->one('SELECT team FROM mq2_match_players WHERE match_id=? AND user_id=?', [$id, '2'])['team'] === 1,
    'Move failed'
);
rejects(fn() => $e->ready('1', $id, false), 'expired');
$t->start($id, '1');
$e->ready('1', $id, false);
check(
    !$e->db->all('SELECT * FROM mq2_penalties') && !$e->db->all('SELECT * FROM mq2_claims'),
    'Ready decline penalized test'
);
$t->remove([$id], '1', 1);
echo "PASS permissions, team swap, captain, ready decline without penalties\n";
