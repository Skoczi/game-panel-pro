import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

// Exercise the shipped sound policy with a suspended/running Web Audio device.
// This is independent of the browser screenshot checks and needs no game server.
const source = readFileSync(new URL('../module/Resources/assets/mixqueue.js', import.meta.url), 'utf8');
const policy = source.slice(source.indexOf('    const readyMatch ='), source.indexOf('    async function unlockReadySound'));
assert.ok(policy.length > 100);
const store = new Map();
let starts = 0;
const device = {
  state: 'suspended', currentTime: 0, destination: {},
  createOscillator: () => ({ frequency: {}, connect() {}, disconnect() {}, start() { starts++; }, stop() {} }),
  createGain: () => ({ gain: { setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {}, disconnect() {} }),
};
const makeMatch = (id='one') => ({id, state:'ready', deadline:130, players:[{user_id:'1',accepted:0},{user_id:'2',accepted:0}]});
const state = {me:{id:'1'}, system_test:false, match:makeMatch()};
const storage = {getItem:key=>store.get(key),setItem:(key,value)=>store.set(key,value)};
function boot() {
  const context = vm.createContext({state, seconds:target=>Math.max(0,target-100), localStorage:storage, sessionStorage:storage, device});
  vm.runInContext(policy + '\n audioContext=device; globalThis.run=playReadySound; globalThis.mute=value=>soundMuted=value;', context);
  return context;
}
let page=boot();
page.run(); assert.equal(starts,0,'Autoplay must wait for a running context');
device.state='running';
page.run(); assert.equal(starts,3,'One three-tone notification');
for(let i=0;i<20;i++) page.run();
assert.equal(starts,3,'Polling must not repeat the notification');
page=boot(); page.run(); assert.equal(starts,3,'Reload must not repeat a played match');
state.match=makeMatch('two'); page.mute(true); page.run(); assert.equal(starts,3,'Muted');
page.mute(false); page.run(); assert.equal(starts,6,'A new match can notify after unmuting');
state.match=makeMatch('three'); state.match.players[0].accepted=1; page.run(); assert.equal(starts,6,'Already accepted');
state.match=makeMatch('four'); state.match.deadline=99; page.run(); assert.equal(starts,6,'Expired');
state.match=makeMatch('five'); state.system_test=true; page.run(); assert.equal(starts,6,'Read-only demo');
state.system_test=false; state.me.id='observer'; page.run(); assert.equal(starts,6,'Observer');
state.me.id='1'; state.match.state='veto'; page.run(); assert.equal(starts,6,'No sound outside ready check');
state.match=makeMatch('storage-denied'); storage.getItem=()=>{throw Error('disabled')}; storage.setItem=()=>{throw Error('disabled')};
page=boot(); page.run(); page.run(); assert.equal(starts,9,'Memory fallback without browser storage');
console.log('PASS ready sound: autoplay, poll/reload dedupe, mute, accepted, expiry, observer, demo, state transition, storage fallback');
