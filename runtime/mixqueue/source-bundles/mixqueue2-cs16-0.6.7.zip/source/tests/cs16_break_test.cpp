#include "../games/cs16/matchbot/MatchBot/MatchCSCOBreak.h"
#include "../games/cs16/matchbot/MatchBot/MatchCSCOContract.h"
#include <cassert>
#include <iostream>
int main() {
    for(const auto& name:{std::string(64,'A'),std::string("Żółć 🎮 Żółć 🎮 team")}) {
        const auto title=mq2::server_title("HALFTIME",name,name);
        assert(title.size()<=31 && mq2::name_valid(title,31));
        assert(title.find("[HALFTIME] ")==0 && title.find(" vs ")!=std::string::npos);
    }
    mq2::HalfBreak clock;
    assert(!clock.due("m:1",100));
    assert(clock.start("m:1",100,5,false));
    assert(!clock.start("m:1",105,6,true));
    assert(clock.remaining(100)==20 && clock.remaining(119.9f)==1);
    assert(!clock.due("m:1",119.999f) && clock.due("m:1",120));
    assert(!clock.due("m:2",121));
    assert(clock.until==120 && clock.nextState==5 && !clock.beforeOvertime);
    // A new match/generation, map change, cleanup or recovery resets the clock.
    clock.reset();assert(!clock.active && clock.scope.empty() && clock.until==0);
    assert(clock.start("m:2",20,6,true));
    assert(!clock.due("m:2",39.99f) && clock.due("m:2",40));
    assert(clock.beforeOvertime);
    for(int mr:{8,12,15}) {
        int one=mr,two=mr;
        for(int overtime=0;overtime<3;++overtime) {
            // Regulation is tied; exactly three wins reach the OT halftime.
            for(int played=1;played<=3;++played) {
                ++one;
                assert(!mq2::won(one,two,mr,3));
                assert(mq2::overtime_half_complete(played,0,3)==(played==3));
            }
            for(int played=1;played<=3;++played) {
                ++two;
                assert(!mq2::won(one,two,mr,3));
                assert(mq2::overtime_half_complete(3,played,3)==(played==3));
            }
            assert(one==two && one==mr+3*(overtime+1));
        }
    }
    assert(!mq2::overtime_half_complete(0,0,3));
    assert(!mq2::overtime_half_complete(1,1,3));
    assert(mq2::overtime_half_complete(2,1,3));
    assert(!mq2::overtime_half_complete(1,1,0));
    std::cout<<"PASS scoped 20-second break and MR8/MR12/MR15 overtime boundaries\n";
}
