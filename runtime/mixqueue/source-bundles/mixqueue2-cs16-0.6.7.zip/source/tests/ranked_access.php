<?php

declare(strict_types = 1);

namespace Flute\Core\Support { class BaseController {} }
namespace Symfony\Component\HttpFoundation {
    class JsonResponse {
        public object $headers;
        public function __construct(public mixed $data, public int $status = 200) {
            $this->headers = new class { public function set(...$args): void {} };
        }
    }
}
namespace {
define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';

use Flute\Modules\MixQueue2\Domain\{Engine, Observers};
use Flute\Modules\MixQueue2\Http\{Application, Identity};
use Flute\Modules\MixQueue2\Http\Controllers\PlayController;
use Flute\Modules\MixQueue2\Infrastructure\Runtime;

// Mock only the CMS boundary. Exercise the production Engine factories too.
$identity = new class {
    public string $id = '1';
    public array $accounts = [];
    public function getCurrentUser() { return $this->accounts[$this->id]; }
    public function get($id, ...$args) { return $this->accounts[(string) $id] ?? null; }
    public function can(...$args): bool { return false; }
};
function user() { return $GLOBALS['identity']; }
function app(...$args) { return new class {
    public function validateToken($value): bool { return $value === 'fixture-csrf'; }
    public function getLang(): string { return 'en'; }
}; }
function request() { return $GLOBALS['testRequest']; }
function session() { return new class { public function get($key, $default = null) { return $default; } }; }
function action(PlayController $controller, string $actor, array $input) {
    user()->id = $actor;
    $GLOBALS['testRequest'] = new class($input) {
        public object $headers;
        public function __construct(private array $body) {
            $this->headers = new class {
                public function get($key, $default = '') { return $key === 'X-CSRF-Token' ? 'fixture-csrf' : $default; }
            };
        }
        public function getContent(): string { return json_encode($this->body); }
    };
    return $controller->action();
}

$dir = sys_get_temp_dir() . '/mq2-ranked-access-' . bin2hex(random_bytes(8));
mkdir($dir, 0700);
$config = $dir . '/config.php';
$dsn = 'sqlite:' . $dir . '/fixture.sqlite';
$oldConfig = getenv('MQ2_CONFIG');
$oldDsn = getenv('MQ2_TEST_DSN');
putenv('MQ2_TEST_DSN=' . $dsn);
putenv('MQ2_CONFIG=' . $config);
try {
    file_put_contents($config, '<?php return ' . var_export(['dsn' => $dsn, 'beta_ids' => ['1'], 'admin_ids' => []], true) . ';');
    $fixture = fixture(2);
    foreach (['1', '2'] as $id) user()->accounts[$id] = (object) [
        'id' => $id, 'name' => 'Synthetic ' . $id, 'avatar' => '', 'isTemporary' => false,
        'socialNetworks' => [(object) ['socialNetwork' => (object) ['key' => 'steam'], 'value' => $fixture->player($id)['steam_id']]]
    ];
    (new Observers($fixture))->grant('fixture-admin', [
        'steam_id' => $fixture->player('2')['steam_id'], 'scope' => 'global', 'role' => 'commentator',
        'xray' => false, 'duration' => 3600, 'locale' => 'en', 'reason' => 'Synthetic observer'
    ], true);
    foreach ([Runtime::engine(), require dirname(__DIR__) . '/runtime.php'] as $production) {
        $controller = new PlayController($production, new Application($production));
        check(!Identity::rankedAllowed('2'), 'Observer unexpectedly eligible for ranked');
        $direct = action($controller, '2', ['action' => 'join', 'ladder' => 'cs16-5v5']);
        check($direct->status === 403, 'Observer direct join permitted');
        if (!$fixture->party('1')) {
            check(action($controller, '1', ['action' => 'invite', 'user' => '2'])->status === 200, 'Invite failed');
            $invite = $fixture->db->one('SELECT id FROM mq2_invites WHERE user_id=?', ['2']);
            check(action($controller, '2', ['action' => 'accept_invite', 'invite' => $invite['id']])->status === 200, 'Observer party access lost');
        }
        $joined = action($controller, '1', ['action' => 'join', 'ladder' => 'cs16-5v5']);
        check($joined->status === 403 && $joined->data['error'] === 'beta', 'Leader queued ineligible party');
        foreach (['mq2_claims', 'mq2_tickets', 'mq2_ticket_members', 'mq2_ratings'] as $table)
            check(!$fixture->db->all('SELECT * FROM ' . $table), 'Rejected party left partial state: ' . $table);
        check(count($fixture->party('1')['members']) === 2, 'Rejection changed party');
    }
    echo "PASS CS16 observer-only member rejected atomically through both production factories and real PlayController\n";
    $allowed = new Engine($fixture->db, fn() => $fixture->now(), [1, 2]);
    $ticket = $allowed->join('1', 'cs16-5v5');
    check(count($allowed->db->all('SELECT * FROM mq2_claims')) === 2, 'Eligible numeric/string IDs rejected');
    $restricted = new Engine($fixture->db, fn() => $fixture->now(), ['1']);
    $restricted->tick();
    check(!$restricted->db->all('SELECT * FROM mq2_claims'), 'Legacy ineligible waiting ticket retained');
    check($restricted->db->one('SELECT state FROM mq2_tickets WHERE id=?', [$ticket])['state'] === 'cancelled', 'Ticket not retired');
    check(!$restricted->db->all('SELECT * FROM mq2_penalties'), 'Policy change punished waiting players');
    rejects(fn() => (new Engine($fixture->db, fn() => $fixture->now(), []))->join('1', 'cs16-5v5'), 'beta');
    echo "PASS eligible party allowed, empty list denied, legacy waiting claim retired without penalty\n";

    // Separate memory fixture: readiness requeue cannot re-admit a removed user.
    putenv('MQ2_TEST_DSN=sqlite::memory:');
    $e = fixture(10);
    for ($i = 1; $i <= 10; ++$i) $e->join((string) $i, 'csco-5v5');
    $e->tick();
    $match = $e->db->one('SELECT * FROM mq2_matches');
    for ($i = 1; $i < 10; ++$i) $e->ready((string) $i, $match['id'], true);
    $later = new Engine($e->db, fn() => 2000000031, array_map('strval', range(1, 8)));
    $later->tick();
    check(count($e->db->all('SELECT * FROM mq2_claims')) === 8, 'Requeue admitted removed user or dropped eligible users');
    check(!$e->db->one('SELECT * FROM mq2_claims WHERE user_id=?', ['9']), 'Removed user requeued');
    check(!$e->db->one('SELECT * FROM mq2_penalties WHERE user_id=?', ['9']), 'Accepted removed user penalized');
    echo "PASS accepted eligible players requeue; removed eligibility does not create a new claim or penalty\n";
} finally {
    unset($production, $controller, $fixture, $allowed, $restricted, $engine);
    putenv($oldConfig === false ? 'MQ2_CONFIG' : 'MQ2_CONFIG=' . $oldConfig);
    putenv($oldDsn === false ? 'MQ2_TEST_DSN' : 'MQ2_TEST_DSN=' . $oldDsn);
    foreach (['config.php', 'fixture.sqlite-wal', 'fixture.sqlite-shm', 'fixture.sqlite'] as $file)
        if (is_file($dir . '/' . $file)) unlink($dir . '/' . $file);
    rmdir($dir);
}
}
