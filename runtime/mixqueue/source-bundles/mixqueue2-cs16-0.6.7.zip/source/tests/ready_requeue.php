<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\Engine;

foreach ([false, true] as $party) {
    $e = fixture(11);
    if ($party) {
        foreach (['2', '3'] as $who) {
            $e->invite('1', $who);
            $invite = $e->db->one('SELECT id FROM mq2_invites WHERE user_id=?', [$who]);
            $e->acceptInvite($who, $invite['id']);
        }
    }
    for ($i = 1; $i <= 10; ++$i)
        if (!$party || !in_array($i, [2, 3], true))
            $e->join((string) $i, 'csco-5v5');
    $joined = $e->db->all('SELECT user_id,ticket_id FROM mq2_claims');
    $e->tick();
    $m = $e->db->one('SELECT * FROM mq2_matches');
    $missing = $party ? '1' : '10';
    for ($i = 1; $i <= 10; ++$i)
        if ((string) $i !== $missing)
            $e->ready((string) $i, $m['id'], true);
    $later = new Engine($e->db, fn() => 2000000031);
    $later->serverHeartbeat('s1', true);
    $later->tick();
    check($e->match($m['id'])['state'] === 'cancelled', 'Unaccepted room survived');
    check(
        count($e->db->all('SELECT * FROM mq2_claims WHERE match_id IS NULL')) === 9,
        'Ready players did not automatically return'
    );
    check(!$e->db->one('SELECT * FROM mq2_claims WHERE user_id=?', [$missing]), 'Missing acceptance requeued');
    check((int) $e->db->one('SELECT COUNT(*) n FROM mq2_penalties')['n'] === 1, 'Ready players penalized');
    foreach ($e->db->all('SELECT * FROM mq2_tickets WHERE state=?', ['waiting']) as $ticket)
        check((int) $ticket['joined_at'] === 2000000000, 'Queue priority was reset');
    if ($party) {
        check(!$e->party('1'), 'Unready member retained controls over ready party');
        check(
            count($e->party('2')['members']) === 2 && $e->party('2')['leader_id'] !== '1',
            'Ready party split or leader lost'
        );
        $a = $e->db->one('SELECT ticket_id FROM mq2_claims WHERE user_id=?', ['2']);
        $b = $e->db->one('SELECT ticket_id FROM mq2_claims WHERE user_id=?', ['3']);
        check($a === $b, 'Ready party split across queue tickets');
    }
    $later->tick();
    check(count($e->db->all('SELECT * FROM mq2_claims')) === 9, 'Repeated worker duplicated queue');
    $later->join('11', 'csco-5v5');
    $later->tick();
    $next = $e->db->one('SELECT * FROM mq2_matches WHERE state=?', ['ready']);
    check($next && $next['id'] !== $m['id'], 'Replacement did not make another match automatically');
    check(
        count($e->db->all('SELECT * FROM mq2_match_players WHERE match_id=?', [$next['id']])) === 10,
        'Replacement roster wrong'
    );
    check(
        !$e->db->one('SELECT * FROM mq2_match_players WHERE match_id=? AND user_id=?', [$next['id'], $missing]),
        'Missing player leaked into next match'
    );
    if ($party)
        check(
            count($e->db->all('SELECT DISTINCT team FROM mq2_match_players WHERE match_id=? AND user_id IN (?,?)', [
                $next['id'],
                '2',
                '3'
            ])) === 1,
            'Party separated onto opposing teams'
        );
    check(!$e->db->all('SELECT * FROM mq2_rating_changes'), 'Ready timeout applied ELO');
}
echo
    "PASS ready timeout auto-requeues nine accepted, preserves age/party, removes only missing, replacement rematch without another join, replay/idempotence and no ELO\n"
;
