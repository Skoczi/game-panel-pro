<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\Engine;
use Flute\Modules\MixQueue2\Domain\Problem;
use Flute\Modules\MixQueue2\Infrastructure\Store;

if (( $argv[1] ?? '' ) === 'child') {
    $dsn = getenv('MQ2_TEST_DSN');
    $e = new Engine(
        new Store(new PDO($dsn, getenv('MQ2_TEST_USER') ?: null, getenv('MQ2_TEST_PASSWORD') ?: null)),
        fn() => 2000000000
    );
    try {
        if ($argv[2] === 'join') {
            $e->join('1', 'csco-5v5');
        } elseif ($argv[2] === 'tick') {
            $e->tick();
        } elseif ($argv[2] === 'solo') {
            ( new \Flute\Modules\MixQueue2\Domain\ServerTests($e) )->start('s1', '11', 'de_dust2');
        } elseif ($argv[2] === 'remove') {
            $registry = new \Flute\Modules\MixQueue2\Domain\ServerRegistry($e);
            $server = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']);
            $registry->remove('s1', $registry::revision($server), 'race');
        } else {
            $event = json_decode(file_get_contents($argv[3]), true);
            $e->event('s1', $event);
        }
        exit(0);
    } catch (Problem $ex) {
        exit($ex->key === 'busy' ? 10 : 20);
    }
}
$file = null;
if (!getenv('MQ2_TEST_DSN')) {
    $file = tempnam(sys_get_temp_dir(), 'mq2-race-');
    putenv('MQ2_TEST_DSN=sqlite:' . $file);
}
$e = fixture();
function race(string $action, ?string $eventPath = null, ?string $secondAction = null): array
{
    $args = [PHP_BINARY];
    if (PHP_OS_FAMILY === 'Windows') {
        $args = [...$args, '-d', 'extension_dir=' . ini_get('extension_dir'), '-d', 'extension=pdo_sqlite'];
    }
    $args = [...$args, __FILE__, 'child', $action, $eventPath ?? ''];
    $processes = [];
    for ($i = 0; $i < 2; $i++) {
        $args[count($args) - 2] = $i === 1 ? $secondAction ?? $action : $action;
        $pipes = [];
        $processes[] = proc_open($args, [0 => ['pipe', 'r'], 1 => STDOUT, 2 => STDERR], $pipes);
        fclose($pipes[0]);
    }
    $codes = array_map('proc_close', $processes);
    sort($codes);
    return $codes;
}

check(race('join') === [0, 10], 'Concurrent join did not reject one claimant');
check(count($e->db->all('SELECT * FROM mq2_claims')) === 1, 'Duplicate user claim');
echo "PASS two processes: one queue claim\n";
for ($i = 2; $i <= 10; $i++) {
    $e->join((string) $i, 'csco-5v5');
}
check(race('tick') === [0, 0], 'Worker race failed');
check(count($e->db->all('SELECT * FROM mq2_matches')) === 1, 'Two matches created');
check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Duplicate server claim');
echo "PASS two processes: one match and one server lease\n";
$m = $e->db->one('SELECT * FROM mq2_matches');
for ($i = 1; $i <= 10; $i++) {
    $e->ready((string) $i, $m['id'], true);
}
while (( $m = $e->match($m['id']) )['state'] === 'veto') {
    $p = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1', [
        $m['id'],
        ( (int) $m['turn'] % 2 ) + 1
    ]);
    $e->ban($p['user_id'], $m['id'], json_decode($m['maps'], true)[0], (int) $m['version']);
}
live($e, $m);
$eventPath = tempnam(sys_get_temp_dir(), 'mq2-event-');
file_put_contents($eventPath, Engine::json([
    'event_id' => 'concurrent-final',
    'match_id' => $m['id'],
    'generation' => (int) $m['generation'],
    'type' => 'finished',
    'data' => ['team1_score' => 16, 'team2_score' => 10]
]));
check(race('finish', $eventPath) === [0, 0], 'Settlement retry race failed');
check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Double rating settlement');
check((int) $e->db->one('SELECT SUM(played) AS total FROM mq2_ratings')['total'] === 10, 'Double games played');
echo "PASS two processes: one ELO settlement\n";
event($e, $e->match($m['id']), 'idle');
for ($i = 1; $i <= 10; $i++) {
    $e->join((string) $i, 'csco-5v5');
}
$codes = race('remove', null, 'tick');
check($codes === [0, 0] || $codes === [0, 20], 'Removal/allocation race failed');
$server = $e->db->one('SELECT id FROM mq2_servers WHERE id=?', ['s1']);
$lease = $e->db->one('SELECT server_id FROM mq2_leases WHERE server_id=?', ['s1']);
check((bool) $server === (bool) $lease, 'Allocation and removal produced an orphan lease');
check(
    (bool) $server !== (bool) $e->db->one('SELECT id FROM mq2_server_archives WHERE id=?', ['s1']),
    'Server archive is inconsistent'
);
echo "PASS two processes: server removal versus match allocation\n";
function resetSoloFixture(Engine $e): Engine
{
    $tables = $e->db->driver === 'mysql'
        ? $e->db->all("SHOW TABLES LIKE 'mq2_%'")
        : $e->db->all("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'mq2_%'");
    foreach ($tables as $row) {
        $table = array_values($row)[0];
        if (!in_array($table, ['mq2_schema', 'mq2_mutex'], true))
            $e->db->run('DELETE FROM ' . $table);
    }
    $e = fixture(11);
    $e->db->run('UPDATE mq2_servers SET game=?,adapter=?,capabilities=? WHERE id=?', [
        'cs16',
        'amxx',
        Engine::json(['modes' => ['5v5'], 'maps' => $e->ladder('cs16-5v5')['maps']]),
        's1'
    ]);
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
        's1',
        Engine::json([
            'idle' => true,
            'agent_protocol' => 2,
            'solo_test' => true,
            'controller' => 'matchbot',
            ...cs16Status(),
            'map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $e->ladder('cs16-5v5')['maps']]
        ]),
        $e->now()
    ]);
    return $e;
}

$e = resetSoloFixture($e);
check(race('solo') === [0, 20], 'Concurrent solo test was not rejected');
check(
    count($e->db->all('SELECT * FROM mq2_leases')) === 1 && count($e->db->all('SELECT * FROM mq2_server_tests')) === 1,
    'Duplicate solo lease'
);
echo "PASS two processes: one solo test reservation\n";
$e = resetSoloFixture($e);
for ($i = 1; $i <= 10; $i++)
    $e->join((string) $i, 'cs16-5v5');
$codes = race('solo', null, 'tick');
check($codes === [0, 0] || $codes === [0, 20], 'Solo/allocation race failed');
check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Duplicate shared server reservation');
check(
    ( count($e->db->all('SELECT * FROM mq2_matches')) + count($e->db->all('SELECT * FROM mq2_server_tests')) ) === 1,
    'Solo and ranked assigned the same server'
);
echo "PASS two processes: solo versus ranked allocation\n";
unlink($eventPath);
$e = null;
if ($file) {
    foreach ([$file, $file . '-wal', $file . '-shm'] as $p) {
        if (is_file($p)) {
            unlink($p);
        }
    }
}
