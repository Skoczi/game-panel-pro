#include "../games/cs16/matchbot/MatchBot/MatchCSCOObserverProjection.h"
#include <cassert>
#include <iostream>
#include <limits>

using mq2::observer::Vec;
using mq2::observer::Marker;
using mq2::observer::Project;
using mq2::observer::WirePoint;
static bool near(float one,float two,float tolerance=0.0001f) { return std::fabs(one-two)<tolerance; }
static float length(const Vec& v) { return std::sqrt(v.x*v.x+v.y*v.y+v.z*v.z); }
static Vec sub(const Vec& a,const Vec& b) { return {a.x-b.x,a.y-b.y,a.z-b.z}; }
static void same(const Vec& a,const Vec& b) { assert(near(a.x,b.x)&&near(a.y,b.y)&&near(a.z,b.z)); }
static void valid(const Marker& marker,const Vec& eye,float distance) {
    assert(near(length(sub(marker.center,eye)),distance));
    same({(marker.horizontal[0].x+marker.horizontal[1].x)/2,
          (marker.horizontal[0].y+marker.horizontal[1].y)/2,
          (marker.horizontal[0].z+marker.horizontal[1].z)/2},marker.center);
    same({(marker.vertical[0].x+marker.vertical[1].x)/2,
          (marker.vertical[0].y+marker.vertical[1].y)/2,
          (marker.vertical[0].z+marker.vertical[1].z)/2},marker.center);
}
int main() {
    Marker marker;
    assert(Project({0,0,0},{0,0,0},{1000,0,0},24,marker));
    same(marker.center,{24,0,0});
    same(marker.horizontal[0],{24,0.432f,0});
    same(marker.horizontal[1],{24,-0.432f,0});
    same(marker.vertical[0],{24,0,-0.432f});
    valid(marker,{0,0,0},24);
    Marker nearTarget=marker;
    assert(Project({0,0,0},{0,0,0},{100,0,0},24,marker));
    same(marker.center,nearTarget.center); // depth relocation is independent of target distance
    assert(Project({0,0,0},{0,0,0},{100,100,0},24,marker));
    valid(marker,{0,0,0},24);
    assert(near(marker.center.x,16.970563f)&&near(marker.center.y,16.970563f));
    assert(Project({100,200,30},{0,90,0},{100,1200,30},16,marker));
    same(marker.center,{100,216,30});
    assert(marker.horizontal[1].x>marker.center.x);
    valid(marker,{100,200,30},16);
    assert(Project({0,0,0},{-45,0,0},{100,0,100},24,marker));
    assert(near(marker.center.x,16.970563f)&&near(marker.center.z,16.970563f));
    assert(marker.vertical[1].x<marker.center.x&&marker.vertical[1].z>marker.center.z);
    assert(Project({0,0,0},{45,0,0},{100,0,-100},24,marker));
    assert(marker.center.z<0);
    assert(Project({0,0,0},{0,0,90},{100,0,0},24,marker));
    assert(marker.horizontal[1].z<0&&marker.vertical[1].y<0);
    assert(Project({0,0,0},{0,450,0},{0,100,0},24,marker));
    same(marker.center,{0,24,0});
    assert(Project({0,0,0},{0,0,0},{100,0,0},8,marker));
    assert(Project({0,0,0},{0,0,0},{100,0,0},32,marker));
    // Caller can retrace with a closer radial plane; apparent marker size stays constant.
    Marker far;
    assert(Project({0,0,0},{0,0,0},{100,30,20},32,far));
    assert(Project({0,0,0},{0,0,0},{100,30,20},12,marker));
    assert(near(length(sub(marker.horizontal[1],marker.center))/marker.center.x,
                length(sub(far.horizontal[1],far.center))/far.center.x));
    for(const Vec& target:{Vec{-100,0,0},Vec{0,100,0},Vec{0,0,100},Vec{1,100,0},Vec{0,0,0}}) {
        assert(!Project({0,0,0},{0,0,0},target,24,marker));
        same(marker.center,{0,0,0}); // failed projection cannot reuse a stale marker
    }
    assert(!Project({0,0,0},{0,0,0},{100,100,0},8,marker)); // near-plane forward depth
    for(float depth:{0.0f,7.99f,32.01f,std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN()})
        assert(!Project({0,0,0},{0,0,0},{100,0,0},depth,marker));
    assert(!Project({0,0,std::numeric_limits<float>::quiet_NaN()},{0,0,0},{100,0,0},24,marker));
    assert(!Project({0,0,0},{0,std::numeric_limits<float>::infinity(),0},{100,0,0},24,marker));
    assert(!Project({0,0,0},{0,0,0},{100,0,std::numeric_limits<float>::quiet_NaN()},24,marker));
    assert(WirePoint({-4096,-4096,-4096}));
    assert(WirePoint({4095.875f,4095.875f,4095.875f}));
    for(const Vec& point:{Vec{-4096.125f,0,0},Vec{0,-4096.125f,0},Vec{0,0,-4096.125f},
        Vec{4096,0,0},Vec{0,4096,0},Vec{0,0,4096},
        Vec{std::numeric_limits<float>::infinity(),0,0},Vec{0,std::numeric_limits<float>::quiet_NaN(),0}})
        assert(!WirePoint(point));
    // Even a valid projection near the world edge must not overflow TE coordinates.
    assert(Project({4090,0,0},{0,0,0},{5000,0,0},32,marker));
    assert(!WirePoint(marker.center)&&!WirePoint(marker.horizontal[0]));
    std::cout<<"PASS observer marker projection: forward/side/yaw/pitch/roll, radial depth, stable angular size, backward/near-plane/invalid rejection, GoldSrc wire-coordinate bounds; no renderer or Steam acceptance implied\n";
}
