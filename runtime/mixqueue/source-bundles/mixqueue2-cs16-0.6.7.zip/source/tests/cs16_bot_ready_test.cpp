#include "../games/cs16/matchbot/MatchBot/MatchCSCOBotReady.h"
#include <cassert>
#include <iostream>
#include <limits>

int main() {
    using namespace mq2;
    BotOnlyReadyClock ready;
    const std::string first="7e5700aaaaaaaaaaaaaaaaaa:7",next="7e5700bbbbbbbbbbbbbbbbbb:8";
    assert(!ready.due(first,1000));
    assert(!ready.start("",100));
    assert(!ready.start(first,std::numeric_limits<float>::infinity()));
    assert(!ready.start(first,std::numeric_limits<float>::quiet_NaN()));
    // The clock is armed at loaded on the new map, not by the earlier load command.
    assert(ready.start(first,100));
    for(float now:{0.f,99.f,100.f,114.f,114.999f}) assert(!ready.due(first,now));
    assert(ready.due(first,115));assert(ready.due(first,300));
    assert(!ready.due(next,115));
    assert(!ready.due(first,std::numeric_limits<float>::infinity()));
    assert(!ready.due(first,std::numeric_limits<float>::quiet_NaN()));
    // Retried loading/presence changes cannot move a live assignment's deadline.
    assert(!ready.start(first,110));assert(!ready.start(next,110));
    assert(ready.until==115 && ready.scope==first);
    // Cleanup, recovery and deactivation invalidate both the deadline and scope.
    ready.reset();assert(!ready.active && !ready.due(first,300));
    assert(ready.start(next,3));assert(!ready.due(next,17.999f));assert(ready.due(next,18));
    assert(!ready.due(first,300));
    std::cout<<"PASS bot-only ready: 15-second loaded deadline, exact boundary, immutable scope, repeated start, map clock, cleanup/recovery reset and nonfinite rejection\n";
}
