<?php

declare(strict_types = 1);

// Replay actual isolated GameDLL telemetry. Only fixture identities, map/hash and
// clocks are rebound; native scores, statistics, readiness and pause data remain.
define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';

use Flute\Modules\MixQueue2\Domain\{Engine, ServerTests, Statistics};
use Flute\Modules\MixQueue2\Http\AgentApi;

function native062Submit(Engine $e, array $event): bool
{
    $raw = Engine::json(['action' => 'event', 'event' => $event]);
    $key = str_repeat('x', 32);
    $stamp = (string) $e->now();
    return ( new AgentApi($e, ['s1' => $key]) )->handle(
        's1',
        $stamp,
        hash_hmac('sha256', "s1\n$stamp\n$raw", $key),
        $raw
    )['accepted'];
}

$path = $argv[1] ?? dirname(__DIR__) . '/var/implementation-062/native-bots-final-proof.json';
$proof = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
$replayed = 0;
echo 'Native proof SHA-256: ' . hash_file('sha256', $path) . "\n";
foreach ($proof['cases'] as $source) {
    if (!isset($source['events']))
        continue;
    $case = $source['case'];
    $soloCase = str_contains($case, 'solo');
    $full = !$soloCase && !str_contains($case, 'ranked');
    $size = $full ? 5 : 2;
    $solo = null;
    if ($soloCase) {
        [$e, $t, $id] = fullFixture(1);
        $t->stop($id, '1');
        $solo = new ServerTests($e);
        $m = $solo->start('s1', '1', $e->ladder('cs16-5v5')['maps'][0]);
        $map = ['76561198000000000' => $m['steam_id']];
        $pickedMap = $m['map'];
        $hash = $e->commands('s1')[0]['payload']['config_hash'];
    } else {
        if ($full) {
            [$e, $t, $id] = fullFixture(1);
            $m = startFull($e, $t, $id, 1, false);
        } else {
            $e = fixture(4);
            $maps = $e->ladder('cs16-2v2')['maps'];
            $e->db->run('UPDATE mq2_servers SET game=?,capabilities=?', [
                'cs16',
                Engine::json(['modes' => ['2v2'], 'maps' => $maps])
            ]);
            $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
                's1',
                Engine::json(
                    cs16Status()
                    + [
                        'map_inventory' => ['version' => 1, 'complete' => true, 'source' => 'bsp_v30', 'maps' => $maps]
                    ]
                ),
                $e->now()
            ]);
            $m = readyMatch($e, 'cs16-2v2', 4);
        }
        $roster = $e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,captain DESC,user_id', [
            $m['id']
        ]);
        $map = [];
        for ($i = 0; $i < ( $size * 2 ); ++$i) {
            $team = $i < $size ? 1 : 2;
            $identity = $full && $i !== 0
                ? 'bot:'
                . substr(
                    hash('sha256', $source['match_id'] . ':' . $source['generation'] . ':' . $team . ':' . ( $i + 1 )),
                    0,
                    24
                )
                : (string) ( 76561198000000000 + $i );
            $map[$identity] = $roster[$i]['steam_id'];
        }
        $pickedMap = $m['picked_map'];
        $hash = $e->configuration($m['id'])['config_hash'];
    }
    $ratings = $e->db->all('SELECT * FROM mq2_ratings');
    $dates = [];
    $sequence = 0;
    $lastStats = [];
    $lastScore = [0, 0];
    foreach ($source['events'] as $row) {
        $row['match_id'] = $m['id'];
        $row['generation'] = (int) $m['generation'];
        // The agent adds this transport envelope when draining controller journals.
        $row['schema_version'] = 1;
        $row['boot_id'] = str_repeat('a', 32);
        $row['sequence'] = ++$sequence;
        if ($row['type'] === 'loaded') {
            $row['data']['map'] = $pickedMap;
            $row['data']['config_hash'] = $hash;
            if (isset($row['data']['ready_deadline']))
                $row['data']['ready_deadline'] = $e->now() + 300;
        }
        foreach (['steam_id', 'actor'] as $field) {
            if (isset($row['data'][$field])) {
                check(isset($map[$row['data'][$field]]), "$case: unexpected identity $field");
                $row['data'][$field] = $map[$row['data'][$field]];
            }
        }
        if (isset($row['data']['missing']))
            $row['data']['missing'] = array_map(fn($id) => $map[$id], $row['data']['missing']);
        if (isset($row['data']['players'])) {
            $stats = [];
            foreach ($row['data']['players'] as $steam => $counters) {
                check(isset($map[$steam]), "$case: statistics contain identity outside assignment");
                $stats[$map[$steam]] = $counters;
            }
            $row['data']['players'] = $stats;
            $lastStats = $stats;
        }
        if (isset($row['data']['team1_score']))
            $lastScore = [$row['data']['team1_score'], $row['data']['team2_score']];
        if (isset($row['data']['occurred_at']))
            $row['data']['occurred_at'] = $e->now();
        if (isset($row['data']['deadline']))
            $row['data']['deadline'] =
                $dates[$row['data']['deadline']] ??= $e->now() + ( $row['data']['seconds'] ?? 30 );
        check(native062Submit($e, $row), "$case: rejected {$row['type']}");
        check(!native062Submit($e, $row), "$case: duplicate applied {$row['type']}");
    }
    $damage = 0;
    $kills = 0;
    if (!$soloCase) {
        $current = $e->match($m['id']);
        check([(int) $current['team1_score'], (int) $current['team2_score']] === $lastScore, "$case: score changed");
        foreach ($lastStats as $steam => $counters) {
            $stored = json_decode(
                $e->db->one('SELECT stats FROM mq2_match_players WHERE match_id=? AND steam_id=?', [
                    $m['id'],
                    $steam
                ])['stats'],
                true
            );
            foreach ($counters as $counter => $value)
                check($stored[$counter] === $value, "$case: native $counter changed for $steam");
            check(( $stored['stats_version'] ?? null ) === 2, "$case: extended AI stats were downgraded");
            $damage += $counters['damage'];
            $kills += $counters['kills'];
        }
        if ($full)
            check(count($lastStats) === 10 && $damage > 0 && $kills > 0, "$case: no actual AI combat counters");
        $e->cancel($m['id'], 'native-journal-audit', 'server_error');
    } else {
        check($solo->find($m['id'])['state'] === 'live', "$case: solo did not become live");
        $solo->stop($m['id'], '1');
    }
    // These two actions verify backend lifecycle only. Native proof ends before
    // cleanup; this synthetic idle is not evidence of a GameDLL cleanup run.
    check(!!$e->db->all('SELECT * FROM mq2_leases'), "$case: lease released before idle");
    $idle = [
        'event_id' => Engine::id(),
        'match_id' => $m['id'],
        'generation' => (int) $m['generation'],
        'schema_version' => 1,
        'boot_id' => str_repeat('a', 32),
        'sequence' => ++$sequence,
        'type' => 'idle',
        'data' => []
    ];
    check(native062Submit($e, $idle) && !native062Submit($e, $idle), "$case: idle not idempotent");
    check(!$e->db->all('SELECT * FROM mq2_leases'), "$case: idle did not release");
    check(
        count($e->db->all('SELECT * FROM mq2_events WHERE match_id=?', [$m['id']])) === $sequence,
        "$case: journal history lost"
    );
    check($e->db->all('SELECT * FROM mq2_ratings') === $ratings, "$case: ELO changed");
    check(!$e->db->all('SELECT * FROM mq2_rating_changes'), "$case: rating changes created");
    check(!$e->db->all('SELECT * FROM mq2_penalties'), "$case: player penalized");
    check(!$e->db->all('SELECT * FROM mq2_settlements'), "$case: settlement created");
    check(
        ( new Statistics($e) )->profile('1', $full || $soloCase ? 'cs16-5v5' : 'cs16-2v2')['overall']['played'] === 0,
        "$case: test or unfinished ranked match polluted overall"
    );
    echo
        "PASS $case: "
            . ( $sequence - 1 )
            . " signed native events, damage=$damage kills=$kills; exact counters, duplicates, history, backend idle, no ELO/penalty\n"
    ;
    ++$replayed;
}
check($replayed >= 3, 'Missing expected full combat, tactical pause and ranked native journals');
echo "PASS native 0.6.2 journals ($replayed cases); isolated QA clients, not Steam acceptance\n";
