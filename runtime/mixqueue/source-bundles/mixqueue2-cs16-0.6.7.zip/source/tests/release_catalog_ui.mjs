import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

// Run the shipped renderers with alternate versions to prove labels are data-driven.
for (const locale of ['pl', 'en']) {
  const name = locale === 'pl' ? 'servers.js' : 'servers.en.js';
  const source = readFileSync(new URL(`../module/Resources/assets/${name}`, import.meta.url), 'utf8');
  const diagnostics = source.slice(source.indexOf('  function diagnostics(s)'), source.indexOf('  function removal(s)'));
  const installation = source.slice(source.indexOf('  function installation(s)'), source.indexOf('  root.addEventListener("change"'));
  assert.ok(diagnostics.length > 500 && installation.length > 500);
  const versions = { cs16: '9.8.7', agent: '8.7.6', source: '7.6.5', ranked_controller_min: '6.5.4', ranked_agent_min: '5.4.3' };
  let html = '';
  const context = vm.createContext({
    versions, config: { downloads: '/admin/matchmaking/servers/download', versions },
    esc: String, names: { cs16: 'CS 1.6', csgo: 'CS:GO' },
    open: (_title, content) => { html = content; },
  });
  vm.runInContext(diagnostics + installation, context);
  context.installation({ id: 's1', name: 'Test', game: 'cs16' });
  assert.ok(html.includes('v9.8.7') && html.includes('v8.7.6'));
  assert.ok(html.includes('?package=cs16') && html.includes('?package=agent'));
  assert.ok(!html.includes('v7.6.5'));
  context.installation({ id: 's2', name: 'Test', game: 'csgo' });
  assert.ok(html.includes('v7.6.5') && html.includes('v8.7.6') && html.includes('?package=source'));
  const server = { id: 's1', name: 'Test', game: 'cs16', missing_maps: [], ranked_supported: false };
  context.diagnostics(server);
  assert.ok(html.includes('MatchBot 6.5.4') && html.includes('5.4.3'));
  assert.ok(!html.includes('9.8.7'), 'Recommended package version is not the ranked minimum');
  assert.ok(html.includes(locale === 'pl' ? 'Wymagany MatchBot' : 'are required.'));
  context.diagnostics({ ...server, ranked_supported: true, controller_version: '1.2.3', agent_version: '2.3.4' });
  assert.ok(html.includes('MatchBot 1.2.3 · Agent 2.3.4'));
  assert.ok(!html.includes('6.5.4'), 'Accepted server displays observed versions');
  console.log(`PASS ${locale}: dynamic download versions and aliases, ranked minimum help, observed versions`);
}
