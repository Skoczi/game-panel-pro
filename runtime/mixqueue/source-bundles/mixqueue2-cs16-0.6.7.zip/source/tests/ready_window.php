<?php

declare(strict_types = 1);

define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';
use Flute\Modules\MixQueue2\Domain\Engine;
use Flute\Modules\MixQueue2\Http\Application;

function windowFixture(bool $connect = true): array
{
    [$e, $t, $id] = fullFixture(2);
    $m = startFull($e, $t, $id, 2, false);
    $config = $e->configuration($id);
    $data = ['map' => $m['picked_map'], 'config_hash' => $config['config_hash'], 'ready_deadline' => $e->now() + 300];
    foreach ([0, -1, '2000000300', true, $e->now() + 306] as $bad)
        rejects(fn() => event($e, $m, 'loaded', array_replace($data, ['ready_deadline' => $bad])), 'readiness');
    $loaded = event($e, $m, 'loaded', $data);
    check(!$e->event('s1', $loaded), 'Duplicate loaded changed window');
    check($e->configuration($id) === $config, 'Readiness mutated signed config');
    check((int) $e->match($id)['deadline'] === ( $e->now() + 315 ), 'Not the server deadline plus transport grace');
    $roster = $e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,user_id', [
        $id
    ]);
    foreach ($roster as $i => $p) {
        if ($connect)
            event($e, $m, 'connected', ['steam_id' => $p['steam_id'], 'connected' => true]);
        event($e, $m, 'player_ready', ['steam_id' => $p['steam_id'], 'ready' => $connect && $i !== 0]);
    }
    return [$e, $m, $roster, $loaded];
}

if (defined('MQ2_WINDOW_HELPERS_ONLY'))
    return;
[$e, $m, $roster] = windowFixture();
$api = ( new Application($e) )->state('1', 'cs16-5v5', $m['id'], true)['match'];
check(
    (int) $api['game_ready']['deadline'] === ( $e->now() + 300 ) && !$api['game_ready']['completed_at'],
    'UI lost authoritative deadline'
);
rejects(fn() => event($e, $m, 'live'), 'readiness');
rejects(fn() => event($e, $m, 'not_ready', [
    'missing' => [$roster[0]['steam_id']],
    'occurred_at' => $e->now() + 299
]), 'readiness');
$last = $roster[0]['steam_id'];
$before = new Engine($e->db, fn() => 2000000299);
event($before, $m, 'player_ready', ['steam_id' => $last, 'ready' => true]);
check((int) $e->match($m['id'])['deadline'] === 2000000359, 'LO3 has no independent guard');
$later = new Engine($e->db, fn() => 2000000301);
event($later, $m, 'player_ready', ['steam_id' => $last, 'ready' => true]);
check((int) $e->match($m['id'])['deadline'] === 2000000359, 'Repeated ready extended guard');
$later->serverHeartbeat('s1', true);
$later->tick();
check($e->match($m['id'])['state'] === 'connecting', 'All-ready cancelled at original deadline');
event($later, $m, 'live');
check($e->match($m['id'])['state'] === 'live', 'LO3 blocked at deadline');

[$e, $m, $roster] = windowFixture();
event($e, $m, 'player_ready', ['steam_id' => $roster[0]['steam_id'], 'ready' => true]);
event($e, $m, 'connected', ['steam_id' => $roster[0]['steam_id'], 'connected' => false]);
check((int) $e->match($m['id'])['deadline'] === ( $e->now() + 315 ), 'Disconnect restarted window');
check(!(int) $e->db->one('SELECT completed_at FROM mq2_ready_windows')['completed_at'], 'Disconnect left complete');
event($e, $m, 'connected', ['steam_id' => $roster[0]['steam_id'], 'connected' => true]);
check(!(int) $e->db->one('SELECT completed_at FROM mq2_ready_windows')['completed_at'], 'Reconnect auto-readied human');

foreach ([true, false] as $connect) {
    [$e, $m, $roster] = windowFixture($connect);
    $later = new Engine($e->db, fn() => 2000000300);
    $missing = $connect ? [$roster[0]['steam_id']] : array_column($roster, 'steam_id');
    event($later, $m, 'not_ready', ['missing' => $missing, 'occurred_at' => $later->now()]);
    check($e->match($m['id'])['state'] === 'cancelled', 'Test deadline not cancelled');
    check(
        !$e->db->all('SELECT * FROM mq2_penalties') && !$e->db->all('SELECT * FROM mq2_rating_changes'),
        'Test received sanction/ELO'
    );
    check($e->db->one('SELECT state FROM mq2_leases')['state'] === 'quarantine', 'Released without idle');
    event($later, $m, 'live');
    check($e->match($m['id'])['state'] === 'cancelled', 'Late live revived cancellation');
    event($later, $m, 'idle');
    check(!$e->db->all('SELECT * FROM mq2_leases'), 'Idle failed release');
    check((int) $e->db->one('SELECT COUNT(*) n FROM mq2_events')['n'] > 0, 'History deleted');
}
[$e, $m] = windowFixture();
$fallback = new Engine($e->db, fn() => 2000000315);
$fallback->serverHeartbeat('s1', true);
$fallback->tick();
check($e->match($m['id'])['reason'] === 'ready_deadline', 'Missing event left match hanging');
check(!$e->db->all('SELECT * FROM mq2_penalties'), 'Fallback incident punished players');
echo
    "PASS shared 300s window, invalid deadlines, immutable assignment, duplicate/delayed ready, LO3, disconnect, test/no-show cancellation, idle-only release, no ELO/penalties\n"
;
