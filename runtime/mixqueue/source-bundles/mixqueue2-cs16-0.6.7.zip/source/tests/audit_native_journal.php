<?php
declare(strict_types=1);
// Actual isolated 0.5.3 journals. Rebind only fixture identity, map/hash and
// wall-clock origin; preserve ordering and all gameplay/feedback values.
define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__.'/run.php';
use Flute\Modules\MixQueue2\Domain\Engine;

$directory=$argv[1] ?? dirname(__DIR__).'/var/acceptance-053';
foreach (['full','budget','ready','signals'] as $case) {
    $source=json_decode(file_get_contents($directory.'/feedback-053-'.$case.'.json'),true,512,JSON_THROW_ON_ERROR);
    $identities=[];
    foreach ($source['events'] as $row) {
        if (isset($row['data']['steam_id'])) $identities[$row['data']['steam_id']]=true;
        foreach (array_keys($row['data']['players'] ?? []) as $steam) $identities[$steam]=true;
    }
    $size=count($identities);
    check(in_array($size,[4,10],true),'Unexpected journal roster');
    $e=fixture(); $ladder='cs16-'.($size===4?'2v2':'5v5');
    $maps=$e->ladder($ladder)['maps'];
    $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?',['cs16',Engine::json(['modes'=>['2v2','5v5'],'maps'=>$maps]),'s1']);
    $ob=[...cs16Status(),'map_inventory'=>['version'=>1,'source'=>'bsp_v30','complete'=>true,'maps'=>$maps]];
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)',['s1',Engine::json($ob),$e->now()]);
    $m=readyMatch($e,$ladder,$size,true);
    $roster=$e->db->all('SELECT steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,user_id',[$m['id']]);
    $map=array_combine(array_keys($identities),array_column($roster,'steam_id'));
    $ob['matchid']=$m['id'].':'.$m['generation']; $ob['phase']='warmup';$ob['idle']=false;
    $e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?',[Engine::json($ob),'s1']);
    $sequence=0; $dates=[];
    foreach ($source['events'] as $row) {
        $row['match_id']=$m['id'];$row['generation']=(int)$m['generation'];$row['sequence']=++$sequence;
        if ($row['type']==='loaded') $row['data']=['map'=>$m['picked_map'],'config_hash'=>$e->configuration($m['id'])['config_hash']];
        if (isset($row['data']['steam_id'])) $row['data']['steam_id']=$map[$row['data']['steam_id']];
        if (isset($row['data']['players'])) {
            $stats=[];foreach ($row['data']['players'] as $steam=>$stat) $stats[$map[$steam]]=$stat;
            $row['data']['players']=$stats;
        }
        if (isset($row['data']['missing'])) $row['data']['missing']=array_map(fn($steam)=>$map[$steam],$row['data']['missing']);
        if (isset($row['data']['occurred_at'])) $row['data']['occurred_at']=$e->now();
        if (isset($row['data']['deadline'])) {
            $original=$row['data']['deadline'];
            $row['data']['deadline']=$dates[$original] ??= $e->now()+60;
        }
        check($e->event('s1',$row),$case.': rejected '.$row['type']);
        check(!$e->event('s1',$row),$case.': duplicate '.$row['type']);
    }
    if ($case==='full') {
        check($e->match($m['id'])['state']==='finished','Full match not settled');
        check(count($e->db->all('SELECT * FROM mq2_rating_changes'))===10,'Fixture settlement duplicated');
        check(!(int)$e->db->one('SELECT active FROM mq2_pause_info WHERE match_id=?',[$m['id']])['active'],'Pause remained active');
    }
    if ($case==='ready') {
        check($e->match($m['id'])['state']==='cancelled','Readiness did not cancel');
        check(count($e->db->all('SELECT * FROM mq2_penalties'))===1,'Wrong readiness sanction count');
    }
    if ($case==='signals') check(count($e->db->all('SELECT * FROM mq2_reports'))===3,'Missing behaviour signals');
    if ($case!=='ready') check(!$e->db->all('SELECT * FROM mq2_penalties'),'Unexpected automatic sanction');
    echo 'PASS native 0.5.3 journal '.$case.': '.$sequence." ordered events, duplicate replay rejected\n";
}
