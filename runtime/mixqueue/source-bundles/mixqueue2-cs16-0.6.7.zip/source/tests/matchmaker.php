<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Matchmaker};

function queueUnits(array $sizes, array $ratings, int $joinedAt = 0): array
{
    $units = [];
    $user = 0;
    foreach ($sizes as $i => $size) {
        $players = [];
        for ($j = 0; $j < $size; ++$j)
            $players[] = ['user_id' => (string) ++$user, 'ticket_id' => (string) $i, 'rating' => $ratings[$i]];
        $units[] = ['id' => (string) $i, 'joined_at' => $joinedAt, 'players' => $players];
    }
    return $units;
}

function validTeams(array $match, int $size, float $allowed): void
{
    check(count($match['teams'][1]) === $size && count($match['teams'][2]) === $size, 'Unequal teams');
    check(
        !array_intersect(array_column($match['teams'][1], 'ticket_id'), array_column($match['teams'][2], 'ticket_id')),
        'Party split between opponents'
    );
    check(abs($match['probability'] - 0.5) <= $allowed, 'Match exceeds probability limit');
}

$maker = new Matchmaker();
$units = queueUnits([3, 2, 2, 1, 1, 1], [1579, 1878, 674, 1733, 751, 541]);
foreach ([120, 1000, 86400] as $wait) {
    $match = $maker->choose($units, 5, $wait);
    check($match !== null, 'F02: admissible intact-party partition discarded at ' . $wait . ' seconds');
    validTeams($match, 5, 0.20);
    $team = array_column($match['teams'][1], 'user_id');
    sort($team, SORT_NUMERIC);
    check($team === ['1', '2', '3', '6', '7'], 'Wrong admissible partition');
    check(abs($match['probability'] - 0.30974758784484846) < 1e-12, 'Unexpected legal ELO balance');
}
foreach ([0, 29, 30, 59, 60, 89, 90, 119] as $wait)
    check($maker->choose($units, 5, $wait) === null, 'Waiting policy relaxed before a legal match exists');
echo "PASS F02: legal alternative selected at the probability cap, intact parties, earlier age limits retained\n";

$initial = queueUnits([3, 2, 2, 1, 1, 1], [1131, 1325, 1503, 1321, 1051, 1640]);
$match = $maker->choose($initial, 5, 0);
check($match !== null, 'Legal alternative discarded during the initial 60/40 window');
validTeams($match, 5, 0.10);
check(abs($match['probability'] - 0.4248756012949829) < 1e-12, 'Wrong initial-window alternative');
echo "PASS initial probability window also considers admissible alternatives\n";

// Party similarity must still influence the cost when both partitions are legal.
$unrestricted = $maker->balance($units, 5);
check(abs($unrestricted['probability'] - 0.2828751382263433) < 1e-12, 'Unrestricted balance contract changed');
$relaxed = $maker->choose($initial, 5, 30);
$preferred = $maker->balance($initial, 5);
check($relaxed !== null && $relaxed['teams'] === $preferred['teams'], 'Lowest admissible cost was not retained');
check($relaxed['cost'] < $match['cost'], 'Party-similarity preference no longer affects cost');
echo "PASS cost preference retained among legal partitions and standalone balance remains compatible\n";

$stepped = queueUnits([5, 5], [1000, 1075]);
$stepped[1]['joined_at'] = 119;
check($maker->choose($stepped, 5, 120) === null, 'Oldest age incorrectly widened the youngest ticket limit');
check($maker->choose($stepped, 5, 148) === null, 'Probability limit widened before 30 seconds');
$match = $maker->choose($stepped, 5, 149);
check($match !== null, 'Probability limit did not widen at 30 seconds');
validTeams($match, 5, 0.125);
check($maker->choose(queueUnits([5, 5], [1000, 1160]), 5, 86400) === null, 'Long waits bypassed the hard cap');
check($maker->choose(queueUnits([3, 3, 3, 1], [1000, 1000, 1000, 1000]), 5, 86400) === null, 'Impossible parties were split');
echo "PASS youngest-ticket age, 30-second widening, hard cap and impossible-party rejection\n";

$oldest = queueUnits([5, 5, 5], [1000, 1000, 1000]);
foreach ($oldest as $i => &$ticket)
    $ticket['joined_at'] = $i;
unset($ticket);
$match = $maker->choose(array_reverse($oldest), 5, 120);
check($match !== null && array_column($match['tickets'], 'id') === ['0', '1'], 'Oldest-ticket preference changed');
$duos = $maker->choose(queueUnits([2, 1, 1], [1000, 1000, 1000]), 2, 120);
check($duos !== null, '2v2 allocation regressed');
validTeams($duos, 2, 0.20);
echo "PASS oldest-ticket preference and intact-party 2v2 allocation\n";

// Exercise the public Engine queue path with a free, eligible CS16 server.
$e = fixture(10);
$maps = $e->ladder('cs16-5v5')['maps'];
$e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
    'cs16', Engine::json(['modes' => ['5v5'], 'maps' => $maps]), 's1'
]);
$e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
    's1',
    Engine::json([
        ...cs16Status(),
        'controller_version' => '0.6.5',
        'agent_version' => '0.6.2',
        'map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $maps]
    ]),
    $e->now()
]);
foreach ($units as $unit) {
    $leader = $unit['players'][0]['user_id'];
    foreach ($unit['players'] as $player) {
        $e->db->run('INSERT INTO mq2_ratings(user_id,ladder_id,rating) VALUES(?,?,?)', [
            $player['user_id'], 'cs16-5v5', $player['rating']
        ]);
        if ($player['user_id'] !== $leader) {
            $invite = $e->invite($leader, $player['user_id']);
            $e->acceptInvite($player['user_id'], $invite);
        }
    }
    $e->join($leader, 'cs16-5v5');
}
foreach ([119, 120] as $wait) {
    $later = new Engine($e->db, fn() => 2000000000 + $wait);
    for ($i = 1; $i <= 10; ++$i)
        $later->heartbeat((string) $i);
    $later->serverHeartbeat('s1', true);
    $e->db->run('UPDATE mq2_observations SET observed_at=? WHERE server_id=?', [$later->now(), 's1']);
    check($later->tick() === ( $wait === 120 ? 1 : 0 ), 'Engine did not respect the first admissible queue age');
}
$created = $e->db->one('SELECT * FROM mq2_matches');
check($created !== null && $created['state'] === 'ready', 'Engine did not create ready-check');
check(count($e->db->all('SELECT * FROM mq2_match_players')) === 10, 'Engine roster incomplete');
check(!$e->db->all('SELECT * FROM mq2_claims WHERE match_id IS NULL'), 'Players left waiting after match creation');
check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Server reservation missing');
foreach ($units as $unit) {
    $leader = $unit['players'][0]['user_id'];
    $rows = $e->db->all('SELECT DISTINCT team FROM mq2_match_players WHERE ticket_id=(SELECT ticket_id FROM mq2_claims WHERE user_id=?)', [$leader]);
    check(count($rows) === 1, 'Engine separated a party');
}
echo "PASS CS16 Engine creates one full ready-check and lease as soon as the legal partition is admissible\n";
