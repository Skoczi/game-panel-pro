"""0.6.4 production binary, isolated loopback lab. Not Steam client acceptance."""
import argparse, importlib.util, json, os, time, hashlib, re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True);p.add_argument('--mode',choices=['run','recover'],default='run');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-063-profile/' in str(root),'Isolated lab only'
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
adapter=agent.AmxxAdapter({'game_root':str(root),'rcon_port':27095,'rcon_password_env':'MQ2_QA_RCON_PASSWORD'},agent.Spool(':memory:'))
def cmd(v):time.sleep(1.1);return adapter.rcon.command(v)
def status():return json.loads(cmd('mq2_status'))
def cvar(name):
    reply=cmd(name);match=re.search(r'(?:=|is)\s*"([^"]*)"',reply)
    assert match,(name,reply)
    return match[1]
def bot_settings():return {name:cvar(name) for name in ['bot_difficulty','bot_join_after_player','bot_chatter','bot_quota']}
def same_bot_settings(actual,expected):
    return all((actual[name]==expected[name] if name=='bot_chatter' else float(actual[name])==float(expected[name])) for name in expected)
cfg=root/'addons/amxmodx/configs/mq2';journal=root/'addons/amxmodx/data/mq2/events.jsonl'
proof=root.parent.parent/'production-064-proof.json'
binary=root/'addons/matchbot/dlls/matchbot_csco_mm.so'
binary_bytes=binary.read_bytes()
production_sha256=hashlib.sha256(binary_bytes).hexdigest()
assert b'mq2_qa' not in binary_bytes and b'0.6.4\0' in binary_bytes
assert status()['controller_version']=='0.6.4'
if a.mode=='recover':
    saved=json.loads(proof.read_text());load=saved['load'];s=status()
    assert saved['production_sha256']==production_sha256,'Production binary changed before recovery'
    assert s['phase']=='recovery' and not s['healthy'] and s['matchid']==f"{load['match_id']}:{load['generation']}",s
    assert cmd('hostname')==saved['original'],'Recovery did not restore hostname'
    assert same_bot_settings(bot_settings(),saved['bot_settings']),'Recovery did not restore managed bot settings'
    assert '"Bot ' not in cmd('status'),'Recovery recreated assignment bots'
    try:adapter.execute(load)
    except RuntimeError:pass
    else:raise AssertionError('Recovery bypass')
    cleanup={'id':'064-recovery','type':'cleanup','match_id':load['match_id'],'generation':load['generation'],'payload':{'reason':'server_error'}}
    adapter.execute(cleanup);time.sleep(2);adapter.execute(cleanup)
    assert status()['idle'] and status()['healthy']
    assert cmd('hostname')==saved['original']
    assert int((cfg/'generation-matchbot.txt').read_text())==load['generation']
    assert not (cfg/'original-bots.txt').exists()
    saved['recovery_passed']=True;saved['final_status']=status();saved['final_generation']=load['generation']
    proof.write_text(json.dumps(saved,indent=2))
    print('PASS production 0.6.4: process recovery quarantined, original hostname restored, normal cleanup/idle, high-water preserved')
    raise SystemExit(0)
# The lab is a separate preserved copy. Reconcile any copied prior lab marker via normal command.
if not status()['idle']:
    cmd('mq2_clear server_error');time.sleep(2)
assert status()['idle'] and status()['healthy']
assert 'round_open' not in cmd('mq2_qa snapshot'),'QA command in release'
assert 'CSCO.GG' in cmd('mb_log_tag')
original=cmd('hostname');original_bots=bot_settings();high=int((cfg/'generation-matchbot.txt').read_text())
# Actual adapter assignment, no fake player or QA command: production 2v2 warmup.
ranked_generation=high+1
ranked_id='064000'+f'{time.time_ns():018x}'[-18:]
ranked_payload={'contract_version':3,'starting_ct_team':2,'game':'cs16','match_id':ranked_id,
                'generation':ranked_generation,'map':'de_dust2','team_size':2,'config_hash':'a'*64,
                'rules':{'mr':8,'ot_mr':3,'test':False},
                'teams':{'1':'Player 1 team','2':'Player 3 team'},'players':[]}
for index in range(4):
    ranked_payload['players'].append(dict(steam_id=str(76561198000000000+index),
        team=1 if index<2 else 2,bot=False,captain=int(index in (0,2)),locale='en',name=f'Player {index+1}'))
ranked_load=dict(id='064-ranked-two',type='load',match_id=ranked_id,generation=ranked_generation,payload=ranked_payload)
adapter.execute(ranked_load);time.sleep(2)
ranked_status=status()
assert ranked_status['phase']=='warmup' and ranked_status['healthy'] and ranked_status['rules_ready'],ranked_status
ranked_values={name:float(cvar(name)) for name in ['mp_roundtime','mp_freezetime','mp_buytime','sv_voiceenable','pausable','bot_quota']}
assert ranked_values=={'mp_roundtime':2.0,'mp_freezetime':0.0,'mp_buytime':2.0,'sv_voiceenable':1.0,'pausable':0.0,'bot_quota':0.0},ranked_values
ranked_events=[json.loads(line) for line in journal.read_text().splitlines() if json.loads(line)['match_id']==ranked_id]
assert sum(row['type']=='loaded' for row in ranked_events)==1 and ranked_events[0]['type']=='loaded'
assert not any(row['type'] in ('live','round','finished','test_ended') for row in ranked_events)
ranked_cleanup=dict(id='064-ranked-two-cleanup',type='abort',match_id=ranked_id,
                    generation=ranked_generation,payload={'reason':'server_error'})
adapter.execute(ranked_cleanup);time.sleep(2);adapter.execute(ranked_cleanup)
ranked_idle=status()
assert ranked_idle['idle'] and ranked_idle['healthy'] and ranked_idle['rules_ready'],ranked_idle
assert cmd('hostname')==original and same_bot_settings(bot_settings(),original_bots)
assert not (cfg/'active-matchbot.txt').exists() and not (cfg/'original-bots.txt').exists()
assert int((cfg/'generation-matchbot.txt').read_text())==ranked_generation
assert cmd(f'mq2_load {ranked_id} {ranked_generation}')=='stale_generation'
ranked_proof={'match_id':ranked_id,'generation':ranked_generation,'warmup_status':ranked_status,
              'warmup_cvars':ranked_values,'events':ranked_events,'cleanup_status':ranked_idle}
print('PASS production 0.6.4: assigned ranked 2v2 warmup uses roundtime 2, freeze 0, buytime 2, voice 1, pausable 0; normal cleanup before full test',flush=True)
high=ranked_generation;gen=high+1
mid='7e5700'+f'{time.time_ns():018x}'[-18:]
payload={'contract_version':3,'starting_ct_team':2,'game':'cs16','match_id':mid,'generation':gen,'map':'de_dust2','team_size':5,
         'config_hash':'d'*64,'rules':{'mr':12,'ot_mr':3,'test':True,'test_type':'full'},
         'test_owner':'76561198000000000','teams':{'1':'Steam owner team','2':'Bot 2-1 team'},'players':[]}
for team in (1,2):
    for i in range(1,6):
        human=team==1 and i==1
        identity=payload['test_owner'] if human else 'bot:'+hashlib.sha256(f'{mid}:{gen}:{team}:{i}'.encode()).hexdigest()[:24]
        payload['players'].append(dict(steam_id=identity,team=team,bot=not human,captain=int(i==1),locale='en',name='Steam owner' if human else f'Bot {team}-{i}'))
path=cfg/f'{mid}-{gen}.txt'
assert cmd(f'mq2_load {mid} {gen}')=='storage_failure'
path.write_text('broken assignment\n',encoding='utf-8')
assert cmd(f'mq2_load {mid} {gen}')=='malformed_assignment'
for invalid_mr in (8,11,13,16):
    rejected={**payload,'rules':{**payload['rules'],'mr':invalid_mr}}
    path.write_text(agent.AmxxAdapter.build(rejected),encoding='utf-8')
    assert cmd(f'mq2_load {mid} {gen}')=='malformed_assignment'
path.write_text(agent.AmxxAdapter.build({**payload,'map':'de_csco_missing_064'}),encoding='utf-8')
assert cmd(f'mq2_load {mid} {gen}')=='missing_map'
assert int((cfg/'generation-matchbot.txt').read_text())==high
assert status()['idle'] and status()['healthy'] and cmd('hostname')==original
assert not any(json.loads(x)['match_id']==mid for x in journal.read_text().splitlines()),'Rejected load emitted event'
# Replacing only this new, never accepted lab assignment fixture is intentional.
path.write_text(agent.AmxxAdapter.build(payload),encoding='utf-8')
load=dict(id='064-load',type='load',match_id=mid,generation=gen,payload=payload)
adapter.execute(load);time.sleep(3);adapter.execute(load)
assert status()['phase']=='warmup' and status()['healthy']
assert float(cvar('mb_play_rounds'))==24 and float(cvar('mb_play_rounds_ot'))==6 and float(cvar('mb_play_ot_mode'))==1
assert '[WARMUP]' in cmd('hostname')
native_clients=cmd('status')
assert sum('"Bot ' in line for line in native_clients.splitlines())==9,native_clients
assert cvar('bot_quota')=='9'
assert 'de_dust2' in adapter.map_inventory()['maps'] and 'de_csco_missing_064' not in adapter.map_inventory()['maps']
adapter.execute(dict(id='064-end',type='finish_test',match_id=mid,generation=gen,payload={'reason':'test_admin'}))
assert status()['phase']=='finished' and '[FINISHED]' in cmd('hostname')
events=[json.loads(x) for x in journal.read_text().splitlines() if json.loads(x)['match_id']==mid]
assert sum(x['type']=='loaded' for x in events)==1
assert events[0]['type']=='loaded'
ended=[x for x in events if x['type']=='test_ended'];assert len(ended)==1 and len(ended[0]['data']['players'])==10
cleanup=dict(id='064-clear',type='cleanup',match_id=mid,generation=gen,payload={'reason':'test_admin'})
adapter.execute(cleanup);time.sleep(2);adapter.execute(cleanup)
assert status()['idle'] and cmd('hostname')==original
assert same_bot_settings(bot_settings(),original_bots)
assert not (cfg/'original-bots.txt').exists() and '"Bot ' not in cmd('status')
assert cmd(f'mq2_load {mid} {gen}')=='stale_generation'
print('PASS production 0.6.4: distinct storage/config/map rejections, no false loaded, real BSP inventory, load retry, 9 bots warmup, test_ended snapshot, cleanup/hostname, stale generation',flush=True)
# Arm a different assignment for an actual process restart, never reset generation.
gen+=1;mid='7e5700'+f'{time.time_ns():018x}'[-18:]
payload.update(match_id=mid,generation=gen)
for row in payload['players']:
    if row['bot']:
        i=int(row['name'].split('-')[-1]);row['steam_id']='bot:'+hashlib.sha256(f"{mid}:{gen}:{row['team']}:{i}".encode()).hexdigest()[:24]
load=dict(id='064-arm',type='load',match_id=mid,generation=gen,payload=payload)
adapter.execute(load);time.sleep(3)
assert status()['phase']=='warmup'
proof.write_text(json.dumps({'controller_version':'0.6.4','production_sha256':production_sha256,
                           'acceptance':'isolated production GameDLL; no real Steam client',
                           'ranked_2v2_warmup':ranked_proof,'load':load,'original':original,'bot_settings':original_bots,'completed_events':events,
                           'warmup_native_clients':native_clients},indent=2),encoding='utf-8')
print('Armed isolated process restart; this is not a player reconnect test',flush=True)
