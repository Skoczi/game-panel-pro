import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

spec = importlib.util.spec_from_file_location('mq_agent', Path(__file__).parents[1] / 'agent/mq_agent.py')
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)


class ObserverAgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.a = agent.AmxxAdapter.__new__(agent.AmxxAdapter)
        self.a.root = Path(self.tmp.name)
        self.a.spool = agent.Spool(':memory:')
        self.addCleanup(self.a.spool.db.close)
        self.a.rcon = Mock()
        self.now = int(time.time())
        self.payload = {'version': 1, 'revision': 2, 'expires_at': self.now + 300,
                        'observers': [{'steam_id': '76561198000000042', 'role': 'commentator',
                                       'xray': True, 'expires_at': self.now + 300, 'locale': 'pl'}]}
        self.command = {'id': 'c' * 24, 'type': 'observer_update', 'match_id': 'a' * 24,
                        'generation': 4, 'payload': self.payload}
        self.status = {'bridge': 1, 'controller': 'matchbot', 'matchid': 'a' * 24 + ':4',
                       'healthy': True, 'observer_acl_version': 1, 'observer_revision': 1,
                       'observer_expires_at': self.now + 200}
        self.confirmed = {**self.status, 'observer_revision': 2, 'observer_expires_at': self.now + 300}

    def replies(self, *values):
        self.a.rcon.command.side_effect = [json.dumps(v) if isinstance(v, dict) else v for v in values]

    def path(self):
        return self.a.root / 'addons/amxmodx/configs/mq2' / ('a' * 24 + '-4-observers-2.txt')

    def test_snapshot_and_confirmation_without_load_or_match_event(self):
        self.replies(self.status, 'observer_updated', self.confirmed)
        self.a.execute(self.command)
        self.assertEqual(agent.AmxxAdapter.build_observers('a' * 24, 4, self.payload), self.path().read_text())
        self.assertEqual(['mq2_status', 'mq2_observers ' + 'a' * 24 + ' 4 2', 'mq2_status'],
                         [c.args[0] for c in self.a.rcon.command.call_args_list])
        self.assertEqual(0, self.a.spool.db.execute('SELECT count(*) FROM events').fetchone()[0])
        self.assertEqual([], list(self.path().parent.glob('*.next')))

    def test_retry_is_idempotent_but_conflicting_revision_is_rejected(self):
        self.replies(self.status, 'observer_updated', self.confirmed,
                     self.confirmed, 'observer_already_updated', self.confirmed, self.confirmed)
        self.a.execute(self.command)
        original = self.path().read_bytes()
        self.a.execute(self.command)
        self.payload['observers'] = []
        with self.assertRaisesRegex(ValueError, 'conflict'):
            self.a.execute(self.command)
        self.assertEqual(original, self.path().read_bytes())

    def test_newer_revision_never_replays_old_grant(self):
        self.replies({**self.status, 'observer_revision': 3})
        self.a.execute(self.command)
        self.assertFalse(self.path().exists())
        self.assertEqual(1, self.a.rcon.command.call_count)

    def test_existing_directory_and_oversized_snapshot_are_rejected_before_rcon(self):
        path = self.path()
        path.mkdir(parents=True)
        with self.assertRaisesRegex(ValueError, 'Unsafe'):
            self.a.update_observers(self.command, self.status)
        path.rmdir()
        path.write_bytes(b'x' * 8193)
        with self.assertRaisesRegex(ValueError, 'Unsafe'):
            self.a.update_observers(self.command, self.status)
        self.a.rcon.command.assert_not_called()
        self.assertEqual(b'x' * 8193, path.read_bytes())

    def test_symlink_snapshot_is_rejected_even_with_matching_content(self):
        path = self.path()
        path.parent.mkdir(parents=True)
        target = self.a.root / 'target.txt'
        content = agent.AmxxAdapter.build_observers('a' * 24, 4, self.payload).encode()
        target.write_bytes(content)
        try:
            path.symlink_to(target)
        except (OSError, NotImplementedError) as error:
            self.skipTest('Symlink creation unavailable: ' + str(error))
        for dangling in (False, True):
            with self.subTest(dangling=dangling):
                if dangling:
                    target.unlink()
                with self.assertRaisesRegex(ValueError, 'Unsafe'):
                    self.a.update_observers(self.command, self.status)
                self.assertTrue(path.is_symlink())
        self.a.rcon.command.assert_not_called()

    def test_replacement_between_stat_and_open_is_rejected(self):
        path = self.path()
        path.parent.mkdir(parents=True)
        content = agent.AmxxAdapter.build_observers('a' * 24, 4, self.payload).encode()
        path.write_bytes(content)
        replacement = self.a.root / 'replacement.txt'
        replacement.write_bytes(content)
        real_open = os.open

        def replace_then_open(filename, flags):
            replacement.replace(path)
            return real_open(filename, flags)

        with patch.object(agent.os, 'open', side_effect=replace_then_open):
            with self.assertRaisesRegex(ValueError, 'Unsafe'):
                self.a.update_observers(self.command, self.status)
        self.a.rcon.command.assert_not_called()

    def test_snapshot_growing_after_open_is_rejected(self):
        path = self.path()
        path.parent.mkdir(parents=True)
        path.write_bytes(b'x' * 8192)
        self.assertEqual(b'x' * 8192, self.a.read_observer_snapshot(path))
        real_fdopen = os.fdopen

        def grow_then_read(fd, *args, **kwargs):
            with path.open('ab') as stream:
                stream.write(b'x' * 8193)
            return real_fdopen(fd, *args, **kwargs)

        with patch.object(agent.os, 'fdopen', side_effect=grow_then_read):
            with self.assertRaisesRegex(ValueError, 'changed during read'):
                self.a.update_observers(self.command, self.status)
        self.a.rcon.command.assert_not_called()

    def test_concurrent_publish_does_not_read_or_replace_oversized_snapshot(self):
        path = self.path()

        def conflicting_publish(source, destination):
            Path(destination).write_bytes(b'x' * 8193)
            raise FileExistsError()

        with patch.object(agent.os, 'link', side_effect=conflicting_publish):
            with self.assertRaisesRegex(ValueError, 'Unsafe'):
                self.a.update_observers(self.command, self.status)
        self.assertEqual(b'x' * 8193, path.read_bytes())
        self.assertEqual([], list(path.parent.glob('*.next')))
        self.a.rcon.command.assert_not_called()

    @unittest.skipUnless(hasattr(os, 'mkfifo') and hasattr(os, 'O_NONBLOCK'), 'POSIX FIFO test')
    def test_fifo_and_fifo_replacement_cannot_block_dispatch_cleanup(self):
        # Run in a child with a deadline: a blocking open must fail this test,
        # rather than hanging the test suite and concealing the cleanup failure.
        script = '''
import json, os, runpy, sys
from pathlib import Path
from unittest.mock import Mock, patch
module = runpy.run_path(sys.argv[1])
adapter = module['AmxxAdapter'].__new__(module['AmxxAdapter'])
adapter.root = Path(sys.argv[2])
adapter.rcon = Mock()
adapter.status = Mock(return_value=json.loads(sys.argv[3]))
command = json.loads(sys.argv[4])
path = Path(sys.argv[5])
real_open = os.open
def fifo_then_open(filename, flags):
    path.unlink()
    os.mkfifo(path)
    return real_open(filename, flags)
runner = module['Agent'].__new__(module['Agent'])
runner.adapter = adapter
with patch.object(os, 'open', side_effect=fifo_then_open) if sys.argv[6] == 'race' else patch.object(os, 'open', wraps=real_open):
    runner.dispatch(command)
adapter.rcon.command.assert_not_called()
adapter.execute = Mock()
runner.dispatch({**command, 'type': 'cleanup'})
adapter.execute.assert_called_once()
'''
        path = self.path()
        path.parent.mkdir(parents=True)
        for mode in ('existing', 'race'):
            with self.subTest(mode=mode):
                if mode == 'existing':
                    os.mkfifo(path)
                else:
                    path.write_text('snapshot')
                result = subprocess.run(
                    [sys.executable, '-B', '-c', script, str(Path(agent.__file__).resolve()),
                     str(self.a.root), json.dumps(self.status), json.dumps(self.command), str(path), mode],
                    capture_output=True, text=True, timeout=5)
                self.assertEqual(0, result.returncode, result.stderr)
                path.unlink()

    def test_bad_scope_recovery_idle_and_old_controller(self):
        for change in ({'matchid': 'b' * 24 + ':4'}, {'matchid': 'a' * 24 + ':5'},
                       {'matchid': ''}, {'healthy': False}, {'controller': 'old'},
                       {'observer_acl_version': 0}, {'observer_acl_version': True}):
            with self.subTest(change=change):
                self.replies({**self.status, **change})
                with self.assertRaises(RuntimeError):
                    self.a.execute(self.command)
                self.assertFalse(self.path().exists())

    def test_validation_boundaries(self):
        invalid = [{'version': True}, {'revision': True}, {'revision': 0},
                   {'revision': 2147483648}, {'expires_at': self.now},
                   {'expires_at': self.now + 601}, {'observers': {}},
                   {'observers': self.payload['observers'] * 17}]
        for change in invalid:
            with self.subTest(change=change):
                with self.assertRaises(ValueError):
                    agent.AmxxAdapter.build_observers('a' * 24, 4, {**self.payload, **change}, self.now)
        for change in ({'steam_id': 'BOT'}, {'steam_id': 'STEAM_ID_PENDING'},
                       {'steam_id': '76561197960265727'}, {'steam_id': '76561202255233024'},
                       {'role': 'admin;quit'}, {'xray': 1}, {'locale': 'pl\nadmin'},
                       {'expires_at': self.now - 1}, {'expires_at': self.now + 301}):
            with self.subTest(row=change):
                p = copy.deepcopy(self.payload)
                p['observers'][0].update(change)
                with self.assertRaises(ValueError):
                    agent.AmxxAdapter.build_observers('a' * 24, 4, p, self.now)
        duplicate = {**self.payload, 'observers': self.payload['observers'] * 2}
        with self.assertRaises(ValueError):
            agent.AmxxAdapter.build_observers('a' * 24, 4, duplicate, self.now)

    def test_empty_snapshot_revokes_without_cleanup(self):
        self.payload['observers'] = []
        self.replies(self.status, 'observer_updated', self.confirmed)
        self.a.execute(self.command)
        self.assertEqual(1, len(self.path().read_text().splitlines()))

    def test_rcon_exchange_alone_is_not_confirmation(self):
        for reply in ('ok', '', 'observer_invalid', 'observer_stale', 'observer_scope', 'observer_storage'):
            with self.subTest(reply=reply):
                self.replies(self.status, reply)
                with self.assertRaises((RuntimeError, ConnectionError)):
                    self.a.execute(self.command)
        self.replies(self.status, 'observer_updated', self.status)
        with self.assertRaises(ConnectionError):
            self.a.execute(self.command)

    def test_status_separates_agent_capability_from_controller_capability(self):
        self.replies(self.status)
        observed = self.a.status()
        self.assertEqual(1, observed['observer_agent_version'])
        self.assertEqual(1, observed['observer_acl_version'])
        self.assertEqual('0.6.3', observed['agent_version'])
        self.replies({'bridge': 1})
        observed = self.a.status()
        self.assertEqual(1, observed['observer_agent_version'])
        self.assertNotIn('observer_acl_version', observed)

    def test_failed_observer_update_does_not_block_cleanup_or_emit_fake_ack(self):
        runner = agent.Agent.__new__(agent.Agent)
        runner.adapter = Mock()
        runner.adapter.execute.side_effect = [TimeoutError('lost reply'), None]
        runner.spool = self.a.spool
        runner.dispatch(self.command)
        runner.dispatch({**self.command, 'type': 'cleanup'})
        self.assertEqual(['observer_update', 'cleanup'],
                         [call.args[0]['type'] for call in runner.adapter.execute.call_args_list])
        self.assertEqual(0, self.a.spool.db.execute('SELECT count(*) FROM events').fetchone()[0])


if __name__ == '__main__':
    unittest.main()
