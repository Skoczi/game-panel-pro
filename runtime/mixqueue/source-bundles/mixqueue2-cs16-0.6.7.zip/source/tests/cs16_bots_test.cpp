#include "../games/cs16/matchbot/MatchBot/MatchCSCOBots.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <limits>

static void word(std::string& out,uint32_t v,unsigned n=4) {for(unsigned i=0;i<n;++i)out+=char(v>>(i*8));}
static void real(std::string& out,float value){uint32_t bits;std::memcpy(&bits,&value,4);word(out,bits);}
static void replace(std::string& out,size_t at,uint32_t v,unsigned n=4){for(unsigned i=0;i<n;++i)out[at+i]=char(v>>(i*8));}
static std::string header(uint32_t version=5,uint32_t areas=1) {
    std::string out;word(out,0xfeedface);word(out,version);word(out,2057288);
    if(version==5){word(out,1,2);word(out,5,2);out.append("Bomb\0",5);}
    word(out,areas);return out;
}
static std::string area(uint32_t version=5,uint32_t id=1,uint32_t adjacent=0,uint32_t spotId=7,bool details=false) {
    std::string out;word(out,id);word(out,0,1);
    for(float v:{0.f,0.f,0.f,100.f,100.f,0.f,0.f,0.f})real(out,v);
    word(out,adjacent?1:0);if(adjacent)word(out,adjacent);
    for(int d=1;d<4;++d)word(out,0);
    word(out,details?1:0,1);
    if(details){word(out,spotId);real(out,25);real(out,25);real(out,0);word(out,1,1);}
    word(out,details?1:0,1);
    if(details){word(out,id);word(out,adjacent);word(out,0,1);word(out,0);word(out,0,1);}
    word(out,details?1:0);
    if(details){word(out,id);word(out,0,1);word(out,adjacent);word(out,1,1);word(out,1,1);word(out,spotId);word(out,128,1);}
    if(version==5)word(out,1,2);
    return out;
}
static std::string nav(uint32_t version=5) {return header(version)+area(version);}
static bool valid(const std::string& bytes,uint32_t bsp=2057288){std::istringstream in(bytes);return mq2::bot_nav_header(in,bsp);}
int main(int argc,char** argv) {
    assert(valid(nav()));assert(valid(nav(4)));assert(!valid(nav(3)));assert(!valid(nav(6)));
    assert(!valid(nav(),123));assert(!valid(nav(),0));assert(!valid(header(5,0)));assert(!valid(header(5,16385)));
    auto data=nav();data[0]=0;assert(!valid(data));
    for(size_t n=0;n<nav().size();++n)assert(!valid(nav().substr(0,n)));
    data=nav();data[14]=0;data[15]=0;assert(!valid(data));
    data=nav();data[14]=char(0xff);data[15]=1;assert(!valid(data));
    data=nav();data[20]='x';assert(!valid(data));
    data=nav();data[12]=char(0xff);data[13]=char(0xff);assert(!valid(data));
    data=nav();data[16]='\0';assert(!valid(data));
    const size_t base=header().size();
    for(uint32_t id:{0u,UINT32_MAX}){data=nav();replace(data,base,id);assert(!valid(data));}
    data=header(5,2)+area()+area();assert(!valid(data)); // Duplicate area identity.
    for(float bad:{std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN(),40000.f}) {
        data=nav();uint32_t bits;std::memcpy(&bits,&bad,4);replace(data,base+5,bits);assert(!valid(data));
    }
    data=nav();replace(data,base+17,0);assert(!valid(data)); // Degenerate X extent.
    data=nav();replace(data,base+21,0);assert(!valid(data)); // Degenerate Y extent.
    data=nav();replace(data,base+37,UINT32_MAX);assert(!valid(data)); // Connection length overflow.
    data=nav();replace(data,base+54,17,1);assert(!valid(data)); // Native fixed-size approach overflow.
    data=nav();replace(data,base+55,UINT32_MAX);assert(!valid(data)); // Encounter length overflow.
    data=nav();replace(data,base+59,2,2);assert(!valid(data)); // Unknown place index.
    assert(!valid(nav()+std::string(1,'\0')));
    data=header()+area(5,1,99);assert(!valid(data)); // Missing adjacency target.
    data=header()+area(5,1,1);assert(!valid(data)); // Self-connection.
    const auto rich=header(5,2)+area(5,1,2,7,true)+area(5,2,1,8,true);
    assert(valid(rich));
    assert(valid(header(5,2)+area(5,1,2,0,true)+area(5,2,1,8,true))); // Native hiding IDs start at zero.
    assert(valid(header(4,2)+area(4,1,2,7,true)+area(4,2,1,8,true)));
    for(size_t n=0;n<rich.size();++n)assert(!valid(rich.substr(0,n)));
    data=header(5,2)+area(5,1,2,7,true)+area(5,2,1,7,true);assert(!valid(data)); // Duplicate hiding spot.
    const size_t approach=base+37+20+1+17+1;
    data=rich;replace(data,approach,999);assert(!valid(data));
    data=rich;replace(data,approach+8,8,1);assert(!valid(data));
    const size_t encounter=approach+14+4;
    data=rich;replace(data,encounter+4,4,1);assert(!valid(data));
    data=rich;replace(data,encounter+5,999);assert(!valid(data));
    data=rich;replace(data,encounter+11,999);assert(!valid(data)); // Unknown encounter hiding spot.
    if(argc==2){std::ifstream generated(argv[1],std::ios::binary);assert(generated && mq2::bot_nav_header(generated,2057288));}
    std::cout<<"CSCO native bot NAV structure, geometry, references and bounds tests passed\n";
}
