"""Bot-only matches require an explicit signed mode and capable native controller."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

from test_agent import agent
import test_agent
from test_agent_051 import bsp


def bot_only_payload():
    payload = test_agent.FullTestContract().fixture()
    payload.update(contract_version=3, starting_ct_team=1)
    payload['rules']['bot_only'] = True
    captain = payload['players'][0]
    captain.update(bot=True, name='Bot 1-1', locale='en',
                   steam_id='bot:' + agent.hashlib.sha256(
                       f"{payload['match_id']}:{payload['generation']}:1:1".encode()).hexdigest()[:24])
    payload['teams']['1'] = 'Bot 1-1 team'
    return payload


class BotOnlyContract(unittest.TestCase):
    def test_all_bot_wire_preserves_external_owner_and_captains(self):
        for side in (1, 2):
            p = bot_only_payload()
            p['starting_ct_team'] = side
            wire = agent.AmxxAdapter.build(p)
            rows = wire.splitlines()
            self.assertEqual(12, len(rows))
            self.assertTrue(rows[0].startswith('MQ2V3 '))
            self.assertTrue(rows[0].endswith(' 3 ' + str(side)))
            self.assertTrue(rows[1].startswith(p['test_owner'] + ' '))
            self.assertTrue(all(row.startswith('BOT bot:') for row in rows[2:]))
            self.assertFalse(any(p['test_owner'] in row for row in rows[2:]))
            self.assertEqual(2, sum(int(row.split()[4]) for row in rows[2:]))
            self.assertEqual(wire, agent.AmxxAdapter.build(p))

    def test_explicit_boolean_never_enables_mode_by_coercion(self):
        for value in ('true', 'false', 0, 1, None, [], {}):
            with self.subTest(value=value):
                p = bot_only_payload()
                p['rules']['bot_only'] = value
                with self.assertRaises(ValueError):
                    agent.AmxxAdapter.build(p)

    def test_ranked_solo_and_legacy_cannot_opt_into_bot_only(self):
        changes = [dict(test=False), dict(test='true'), dict(test_type='solo'),
                   dict(test_type=None)]
        for rules in changes:
            with self.subTest(rules=rules):
                p = bot_only_payload()
                p['rules'].update(rules)
                with self.assertRaises(ValueError):
                    agent.AmxxAdapter.build(p)
        for version in (None, 1, 2, 3.0, '3', True):
            with self.subTest(version=version):
                p = bot_only_payload()
                p['contract_version'] = version
                with self.assertRaises(ValueError):
                    agent.AmxxAdapter.build(p)

    def test_ten_bots_balanced_scope_and_real_owner_are_required(self):
        cases = []
        p = bot_only_payload(); p['players'].pop(); cases.append(p)
        p = bot_only_payload(); p['players'][1]['team'] = 2; cases.append(p)
        p = bot_only_payload(); p['players'][0] = test_agent.FullTestContract().fixture()['players'][0]; cases.append(p)
        p = bot_only_payload(); p['generation'] += 1; cases.append(p)
        p = bot_only_payload(); p['players'][1]['steam_id'] = p['players'][0]['steam_id']; cases.append(p)
        p = bot_only_payload(); p['players'][1]['steam_id'] = 'bot:' + 'f' * 24; cases.append(p)
        p = bot_only_payload(); p['team_size'] = 2; cases.append(p)
        p = bot_only_payload(); p['players'][0]['captain'] = 0; cases.append(p)
        p = bot_only_payload(); p['match_id'] = 'a' * 24; cases.append(p)
        for owner in (None, '-', '', '76561197960265728', '76561197960265727', '76561202255233024'):
            p = bot_only_payload(); p['test_owner'] = owner; cases.append(p)
        p = bot_only_payload(); p['test_owner'] = p['players'][0]['steam_id']; cases.append(p)
        p = bot_only_payload(); p.pop('test_owner'); cases.append(p)
        for index, p in enumerate(cases):
            with self.subTest(case=index), self.assertRaises(ValueError):
                agent.AmxxAdapter.build(p)

    def test_existing_full_test_is_identical_with_flag_absent_or_false(self):
        for version in (2, 3):
            p = test_agent.FullTestContract().fixture()
            p.update(contract_version=version, starting_ct_team=2)
            old_wire = agent.AmxxAdapter.build(p)
            p['rules']['bot_only'] = False
            self.assertEqual(old_wire, agent.AmxxAdapter.build(p))
            self.assertEqual('2', old_wire.splitlines()[0].split()[8])
        for value in (False, None):
            p = bot_only_payload()
            if value is None:
                del p['rules']['bot_only']
            else:
                p['rules']['bot_only'] = value
            with self.assertRaisesRegex(ValueError, 'Missing real test owner'):
                agent.AmxxAdapter.build(p)


class BotOnlySubmission(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.a = agent.AmxxAdapter.__new__(agent.AmxxAdapter)
        self.a.root = self.root
        self.a.spool = agent.Spool(':memory:')
        self.addCleanup(self.a.spool.db.close)
        self.a.rcon = Mock()
        self.p = bot_only_payload()
        self.command = dict(id='b' * 24, type='load', match_id=self.p['match_id'],
                            generation=self.p['generation'], payload=self.p)
        self.native = dict(bridge=1, controller='matchbot', controller_version='0.6.7',
                           healthy=True, idle=True, matchid='', assignment_contract=3,
                           full_test=True, solo_test=True, bot_only_test=True,
                           bot_only_ready_seconds=15)
        bsp(self.root / ('maps/' + self.p['map'] + '.bsp'))

    def replies(self, status=None, reply='loaded'):
        self.a.rcon.command.reset_mock()
        self.a.rcon.command.side_effect = [json.dumps(self.native if status is None else status), reply]

    def assignment_path(self):
        return self.root / 'addons/amxmodx/configs/mq2' / f"{self.p['match_id']}-{self.p['generation']}.txt"

    def assert_no_submission(self):
        self.assertEqual(['mq2_status'], [c.args[0] for c in self.a.rcon.command.call_args_list])
        self.assertFalse(self.assignment_path().exists())
        self.assertEqual(0, self.a.spool.db.execute('SELECT count(*) FROM events').fetchone()[0])

    def test_submission_keeps_native_journal_as_authority_and_retries_same_file(self):
        for reply in ('loading_map', 'loaded', 'already_loaded'):
            with self.subTest(reply=reply):
                self.replies(reply=reply)
                self.a.execute(self.command)
                self.assertEqual(agent.AmxxAdapter.build(self.p), self.assignment_path().read_text())
                self.assertEqual(['mq2_status', f"mq2_load {self.p['match_id']} {self.p['generation']}"],
                                 [c.args[0] for c in self.a.rcon.command.call_args_list])
                self.assertEqual(0, self.a.spool.db.execute('SELECT count(*) FROM events').fetchone()[0])
                self.assertEqual([], list(self.assignment_path().parent.glob('*.next')))

    def test_capability_and_version_fail_closed_before_file_or_load(self):
        cases = [dict(controller_version=v) for v in ('0.6.6', '0.6.2', '0.6.7-dev', '', 'invalid')]
        cases += [dict(bot_only_test=v) for v in (None, False, 1, 'true')]
        cases += [dict(bot_only_ready_seconds=v) for v in (None, 0, 14, 16, True, 15.0, '15')]
        cases += [dict(assignment_contract=v) for v in (None, 2, 3.0, '3')]
        cases += [dict(full_test=False), dict(healthy=False), dict(controller='other')]
        for change in cases:
            with self.subTest(change=change):
                self.replies({**self.native, **change})
                with self.assertRaises(RuntimeError):
                    self.a.execute(self.command)
                self.assert_no_submission()
        for missing in ('bot_only_test', 'bot_only_ready_seconds', 'assignment_contract'):
            status = {k: v for k, v in self.native.items() if k != missing}
            self.replies(status)
            with self.assertRaises(RuntimeError):
                self.a.execute(self.command)
            self.assert_no_submission()

    def test_invalid_mode_cannot_be_silently_downgraded(self):
        for rules, contract in (({'bot_only': 'true'}, 3), ({'test': False}, 3), ({}, 2)):
            p = copy.deepcopy(self.p)
            p['rules'].update(rules)
            p['contract_version'] = contract
            self.replies()
            with self.assertRaises(agent.LoadRejected) as error:
                self.a.execute({**self.command, 'payload': p})
            self.assertEqual('malformed_assignment', error.exception.code)
            self.assert_no_submission()

    def test_missing_map_and_foreign_assignment_keep_all_state(self):
        self.replies({**self.native, 'matchid': 'a' * 24 + ':1'})
        with self.assertRaisesRegex(RuntimeError, 'Foreign'):
            self.a.execute(self.command)
        self.assert_no_submission()
        (self.root / ('maps/' + self.p['map'] + '.bsp')).unlink()
        self.replies()
        with self.assertRaises(agent.LoadRejected) as error:
            self.a.execute(self.command)
        self.assertEqual('missing_map', error.exception.code)
        self.assert_no_submission()

    def test_ambiguous_load_reply_never_synthesizes_ready_or_loaded(self):
        for reply in ('', 'not loaded', TimeoutError('lost response')):
            self.replies(reply=reply)
            with self.assertRaises((ConnectionError, TimeoutError)):
                self.a.execute(self.command)
            self.assertEqual(0, self.a.spool.db.execute('SELECT count(*) FROM events').fetchone()[0])

    def test_normal_one_plus_nine_does_not_require_new_capabilities(self):
        p = test_agent.FullTestContract().fixture()
        status = {k: v for k, v in self.native.items()
                  if k not in ('bot_only_test', 'bot_only_ready_seconds')}
        status.update(controller_version='0.5.1', assignment_contract=2)
        self.replies(status)
        self.a.execute({**self.command, 'payload': p})
        self.assertEqual(agent.AmxxAdapter.build(p), self.assignment_path().read_text())


if __name__ == '__main__':
    unittest.main(verbosity=2)
