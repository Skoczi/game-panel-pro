"""0.5.3 isolated GameDLL acceptance. QA entities, NEVER real Steam acceptance."""
import argparse, hashlib, importlib.util, json, os, time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True)
p.add_argument('--mode',choices=['full','ranked','expiry','damage'],default='full');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-053/' in str(root)
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
rcon=agent.GoldSrcRcon('127.0.0.1',27095,os.environ['MQ2_QA_RCON_PASSWORD']);last=0
def cmd(text):
 global last
 time.sleep(max(0,1.05-(time.monotonic()-last)));value=rcon.command(text);last=time.monotonic();return value
def qa(text):return cmd('mq2_qa '+text)
def obj(text):return json.loads(qa(text))
def status():return json.loads(cmd('mq2_status'))
def snap():return obj('snapshot')
def pause():return obj('pause-state')
def feedback(slot):return [x for x in qa(f'feedback-all {slot}').splitlines() if x!='qa_empty']
def events():return [e for x in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if (e:=json.loads(x))['match_id']==mid]
def live():
 until=time.monotonic()+85
 while time.monotonic()<until:
  v=snap()
  if v['round_open'] and not v['freeze'] and not v['lo3']:return v
  qa('fast')
 raise AssertionError(('not live',status(),v))
def wait_pause():
 until=time.monotonic()+30
 while time.monotonic()<until:
  v=pause()
  if v['paused']:return v
 raise AssertionError(('not paused',status(),v))
def clear():
 assert cmd('mq2_clear server_error').endswith('cleared')
 assert status()['idle'] and status()['healthy']
def load(full=True,one=False,ready=True):
 global mid,generation,players
 if not status()['idle']:clear() # Normal recovery cleanup, never erase history/high-water mark.
 generation=int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text())+1
 mid=('7e5700' if full else '053000')+f'{time.time_ns():018x}'[-18:]
 size=5 if full else 2;players=[]
 for i in range(size*2):
  team=1 if i<size else 2;captain=i in (0,size);bot=full and (not captain or (one and i!=0))
  steam='bot:'+hashlib.sha256(f'{mid}:{generation}:{team}:{i+1}'.encode()).hexdigest()[:24] if bot else str(76561198000000000+i)
  players.append({'steam_id':steam,'team':team,'name':('Neo' if team==1 else 'Forest') if captain else 'Player'+str(i),
                  'bot':bot,'captain':int(captain),'locale':'pl' if team==1 else 'en'})
 payload={'game':'cs16','match_id':mid,'generation':generation,'config_hash':'b'*64,'contract_version':2,
          'map':'de_dust2','team_size':size,'teams':{'1':'Neo team','2':'Forest team'},'players':players,
          'rules':{'mr':15 if full else 8,'ot_mr':3,'test':full}}
 if full:payload['rules']['test_type']='full';payload['test_owner']=players[0]['steam_id']
 (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(payload))
 assert cmd(f'mq2_load {mid} {generation}').endswith('loaded'),status()
 for i,row in enumerate(players):
  if not row['bot']:assert qa(f'add {i}')=='qa_added'
 assert not any('Dealt:' in x or 'Zadane:' in x for x in feedback(0))
 if not ready:return snap()
 qa('ready');v=live();assert status()['restarts_completed']==3
 print('PASS load/ready/3 restarts,',mid,'generation',generation,flush=True)
 return v
def expect_line(slot,text):
 rows=feedback(slot);assert text in rows,(text,rows);return rows
def persist(label):
 (root.parent.parent/f'feedback-053-{label}.json').write_text(json.dumps({'match_id':mid,'generation':generation,'events':events()},indent=2))


assert status()['controller_version']=='0.5.3'
load(False)
for cycle in range(3):
 qa('drop 1');qa('eliminate 2')
 if cycle<2:
  wait_pause();assert obj('safety')['reconnect_used']==[cycle+1,0]
  qa('add 1');before=status()['score'];qa('fast');live();assert status()['score']==before
 else:
  until=time.monotonic()+15
  while time.monotonic()<until and snap()['roster'][1]['absence']!=3: time.sleep(1)
  assert snap()['roster'][1]['absence']==3,snap()
  assert not pause()['paused'],pause()
  assert obj('safety')['reconnect_used']==[2,0]
  assert any(e['type']=='reconnect_window' and e['data']['stage']=='grace' for e in events())
  qa('add 1');live()
assert status()['score']==[3,0]
print('PASS two reconnect pauses; third disconnect grace only; return keeps score and budget',flush=True)
persist('budget')
cmd('mp_infinite_ammo 1');time.sleep(7)
s=status();assert s['phase']=='recovery' and not s['healthy'] and s['rules_issue']=='mp_infinite_ammo',s
assert s['score']==[3,0];qa('talk 0 unpause');assert status()['phase']=='recovery'
clear();assert status()['rules_ready']
print('PASS active rule drift -> bounded recovery, score retained, no unpause bypass, normal cleanup',flush=True)
load(False,ready=False)
for i in (0,2,3):qa(f'talk {i} ready')
qa('ready-fast');time.sleep(2)
assert obj('safety')['ready_expired']
ev=[e for e in events() if e['type']=='not_ready'];assert len(ev)==1 and ev[0]['data']['missing']==[players[1]['steam_id']],ev
assert not any(e['type']=='live' for e in events());persist('ready');clear()
print('PASS connected unready participant expires once; no LIVE; normal cleanup',flush=True)
load(False)
for cycle in range(3):
 qa('activity-fast');qa('eliminate 2');live()
alerts=[e for e in events() if e['type']=='player_alert' and e['data']['code']=='afk']
assert len(alerts)==1 and alerts[0]['data']['steam_id']==players[1]['steam_id'],alerts
qa('activity-fast');qa('eliminate 2');live()
assert len([e for e in events() if e['type']=='player_alert' and e['data']['code']=='afk'])==1
for cycle in range(3):
 qa('damage 0 1 1000');qa('eliminate 2');live()
alerts=[e for e in events() if e['type']=='player_alert']
assert sum(e['data']['code']=='team_kills' for e in alerts)==1,alerts
assert sum(e['data']['code']=='team_damage' for e in alerts)==1,alerts
persist('signals');clear()
print('PASS conservative AFK/TK/team-damage signals, once per identity/code, no automatic kick/ban',flush=True)
