<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\Engine;

$e = fixture();
foreach ([1800, 3600, 7200, 86400, 86400] as $i => $duration) {
    $later = new Engine($e->db, fn() => 2000000000 + ( $i * 86401 ));
    $later->db->tx(fn() => $later->readinessPenalty('1', ['ready_missed', 'not_ready', 'no_show'][$i % 3]));
    $p = $e->db->one('SELECT * FROM mq2_penalties WHERE user_id=? ORDER BY created_at DESC', ['1']);
    check(( (int) $p['expires_at'] - $later->now() ) === $duration, 'Wrong escalation / shared counter');
}
$later = new Engine($e->db, fn() => 2000000000 + ( 4 * 86401 ) + ( 7 * 86400 ));
$later->db->tx(fn() => $later->readinessPenalty('1', 'not_ready'));
$p = $e->db->one('SELECT * FROM mq2_penalties WHERE user_id=? ORDER BY created_at DESC', ['1']);
check(( (int) $p['expires_at'] - $later->now() ) === 1800, 'Seven-day reset failed');
check(count($e->db->all('SELECT * FROM mq2_penalties WHERE user_id=?', ['1'])) === 6, 'Reset deleted penalty history');
$e->db->run('INSERT INTO mq2_penalties VALUES(?,?,?,?,?)', [Engine::id(), '2', 'abandoned', 2000001800, 2000000000]);
$e->db->tx(fn() => $e->readinessPenalty('2', 'ready_missed'));
$p = $e->db->one('SELECT * FROM mq2_penalties WHERE user_id=? AND reason=?', ['2', 'ready_missed']);
check(( (int) $p['expires_at'] - $e->now() ) === 1800, 'Abandon inflated readiness counter');
$edge = new Engine($e->db, fn() => 2000000000 + ( 7 * 86400 ) - 1);
$edge->db->tx(fn() => $edge->readinessPenalty('2', 'no_show'));
$p = $e->db->one('SELECT * FROM mq2_penalties WHERE user_id=? ORDER BY created_at DESC', ['2']);
check(( (int) $p['expires_at'] - $edge->now() ) === 3600, 'Strike forgotten before seven days');
echo
    "PASS readiness 30/60/120/1440 minutes, shared acceptance/no-show/not-ready counter, capped escalation, rolling 7-day boundary, preserved history, unrelated penalties excluded\n"
;
