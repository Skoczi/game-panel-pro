<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Statistics, TestMatches};
use Flute\Modules\MixQueue2\Http\Application;

function botOnlyFixture(array $changes = []): array
{
    $e = fixture(2);
    $maps = $e->ladder('cs16-5v5')['maps'];
    $e->db->run('UPDATE mq2_servers SET game=?,adapter=?,capabilities=? WHERE id=?', [
        'cs16', 'amxx', Engine::json(['modes' => ['5v5'], 'maps' => $maps]), 's1'
    ]);
    $status = array_replace([
        ...cs16Status(), 'controller_version' => '0.6.7', 'agent_version' => '0.6.3',
        'solo_test' => true, 'full_test' => true, 'bot_only_test' => true, 'bot_only_ready_seconds' => 15,
        'map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $maps]
    ], $changes);
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', ['s1', Engine::json($status), $e->now()]);
    return [$e, new TestMatches($e), new Application($e)];
}

function noBotOnlyRankedWrites(Engine $e): void
{
    foreach (['mq2_ratings', 'mq2_rating_changes', 'mq2_penalties', 'mq2_sanctions'] as $table)
        check(!$e->db->all('SELECT * FROM ' . $table), 'Bot-only test polluted ' . $table);
    check(( new Statistics($e) )->profile('1', 'cs16-5v5')['overall']['played'] === 0, 'Owner received player statistics');
}

foreach ([
    ['controller_version' => '0.6.6'], ['controller_version' => '0.6.7-dev'],
    ['agent_version' => '0.6.2'], ['agent_version' => '0.6.3-dev'],
    ['assignment_contract' => 2], ['bot_only_test' => false], ['bot_only_test' => 1],
    ['bot_only_ready_seconds' => 300], ['bot_only_ready_seconds' => '15']
] as $changes) {
    [$e, $tests, $app] = botOnlyFixture($changes);
    rejects(fn() => $tests->create('1', 's1', 15, true, 'de_dust2'), 'test_bot_only_version');
    check(!$e->db->all('SELECT * FROM mq2_matches') && !$e->db->all('SELECT * FROM mq2_leases'), 'Rejected capability reserved a match');
    check((int) $e->db->one('SELECT generation FROM mq2_servers')['generation'] === 0, 'Rejected capability advanced generation');
    check(!$app->state('1', 'cs16-5v5', null, true)['operations']['servers'][0]['bot_only_ready'], 'Unsupported server offered bot-only mode');
}
echo "PASS bot-only runtime/capability gate fails before reservation and is exposed to administration\n";

[$e, $tests, $app] = botOnlyFixture();
$options = $app->state('1', 'cs16-5v5', null, true)['operations']['servers'][0];
check($options['test_ready'] && $options['bot_only_ready'] && $options['bot_only_error'] === null, 'Eligible server unavailable');
check(in_array('de_dust2', $options['test_maps'], true), 'Verified test maps missing');
rejects(fn() => $app->act('1', ['action' => 'test_create', 'server' => 's1', 'bot_only' => true, 'map' => 'de_dust2']), 'forbidden');
foreach (['true', 1, null, []] as $value)
    rejects(fn() => $app->act('1', ['action' => 'test_create', 'server' => 's1', 'bot_only' => $value, 'map' => 'de_dust2'], true), 'test_mode');
foreach ([null, 1, []] as $map)
    rejects(fn() => $app->act('1', ['action' => 'test_create', 'server' => 's1', 'bot_only' => true, 'map' => $map], true), 'test_map');
foreach ([null, '', '../de_dust2', 'de_not_installed'] as $map)
    rejects(fn() => $tests->create('1', 's1', 15, true, $map), 'test_map');
rejects(fn() => $tests->create('1', 's1', 15, false, 'de_dust2'), 'test_map');
check(!$e->db->all('SELECT * FROM mq2_matches') && !$e->db->all('SELECT * FROM mq2_claims'), 'Invalid input left test state');
echo "PASS explicit admin-only boolean mode and verified map required; invalid input rolls back\n";

foreach ([12, 15] as $mr) {
    [$e, $tests, $app] = botOnlyFixture();
    $app->act('1', ['action' => 'test_create', 'server' => 's1', 'mr' => $mr, 'bot_only' => true, 'map' => 'de_dust2'], true);
    $m = $e->db->one('SELECT * FROM mq2_matches');
    $id = $m['id'];
    check($m['state'] === 'preparing' && $m['picked_map'] === 'de_dust2', 'Bot-only creation waits for a human');
    check(count($e->db->all('SELECT * FROM mq2_match_players')) === 10 && count($e->db->all('SELECT * FROM mq2_test_bots')) === 10, 'Not exactly ten bots');
    check(!$e->db->one('SELECT * FROM mq2_match_players WHERE user_id=?', ['1']) && !$e->db->all('SELECT * FROM mq2_claims'), 'Owner occupies a roster slot or queue claim');
    check(!$e->db->all('SELECT * FROM mq2_draft_actions'), 'Bot-only test ran web veto');
    check((int) $tests->find($id)['locked'] === 1, 'Bot-only roster can be changed');
    $config = $e->configuration($id);
    check($config['rules']['test'] === true && $config['rules']['test_type'] === 'full' && $config['rules']['bot_only'] === true, 'Explicit full-test mode missing');
    check($config['rules']['mr'] === $mr && $config['contract_version'] === 3 && $config['starting_ct_team'] === 1, 'Wrong frozen rules/contract');
    check($config['test_owner'] === $e->player('1')['steam_id'] && !in_array($config['test_owner'], array_column($config['players'], 'steam_id'), true), 'Owner not outside roster');
    foreach ([1, 2] as $team) {
        $players = array_values(array_filter($config['players'], fn($p) => $p['team'] === $team));
        check(count($players) === 5 && count(array_filter($players, fn($p) => $p['bot'])) === 5, 'Not five bots per team');
        check(array_sum(array_column($players, 'captain')) === 1, 'Bot captain metadata invalid');
    }
    $commands = $e->commands('s1');
    check(count($commands) === 1 && $commands[0]['type'] === 'load' && $commands[0]['payload'] === $config, 'Immediate immutable load missing');
    check($tests->create('1', 's1', $mr, true, 'de_dust2') === $id, 'Create retry changed assignment');
    $tests->start($id, '1');
    check(count($e->db->all('SELECT * FROM mq2_commands')) === 1, 'Retry duplicated load');
    rejects(fn() => $tests->create('1', 's1', $mr, true, 'de_nuke'), 'test_busy');
    rejects(fn() => $tests->create('1', 's1', $mr), 'test_busy');
    rejects(fn() => $tests->invite($id, '1', '2'), 'test_locked');
    rejects(fn() => $tests->join($id, '2'), 'test_locked');
    rejects(fn() => $tests->move($id, '1', $config['players'][0]['steam_id']), 'test_locked');
    rejects(fn() => $tests->stop($id, '2'), 'forbidden');
    rejects(fn() => $app->state('2', 'cs16-5v5', $id), 'forbidden');
    $ownerState = $app->state('1', 'cs16-5v5', null, false, true);
    check($ownerState['match']['id'] === $id && $ownerState['claim'] === null, 'Owner cannot discover managed test');
    check($ownerState['match']['address'] === null, 'Ownership invented player/observer admission');
    check(count($ownerState['history']) === 1 && $ownerState['history'][0]['team'] === null && $ownerState['history'][0]['rating_delta'] === null, 'Owner test history impersonates a player');
    check(!$app->state('1', 'cs16-5v5')['history'], 'Bot-only test entered ranked history');
    $e->identify('1', $config['test_owner'], 'Renamed owner');
    check($e->configuration($id) === $config, 'Owner rename changed assignment');
    // Native bot readiness is automatic after 15s; the 300s joining deadline remains a safety timeout.
    event($e, $m, 'loaded', ['map' => $m['picked_map'], 'config_hash' => $config['config_hash'], 'ready_deadline' => $e->now() + 300]);
    check((int) $e->match($id)['deadline'] === $e->now() + 315, 'Bot auto-ready replaced the safety timeout');
    foreach ($config['players'] as $p) {
        event($e, $m, 'connected', ['steam_id' => $p['steam_id'], 'connected' => true]);
        event($e, $m, 'player_ready', ['steam_id' => $p['steam_id'], 'ready' => false]);
    }
    $before = new Engine($e->db, fn() => 2000000014);
    $before->serverHeartbeat('s1', true);
    $before->tick();
    check($e->match($id)['state'] === 'connecting', 'Warmup did not wait for native readiness');
    rejects(fn() => event($before, $m, 'live'), 'readiness');
    $ready = new Engine($e->db, fn() => 2000000015);
    foreach ($config['players'] as $p)
        event($ready, $m, 'player_ready', ['steam_id' => $p['steam_id'], 'ready' => true]);
    event($ready, $m, 'live');
    $e->db->run('UPDATE mq2_presence SET seen_at=0 WHERE user_id=?', ['1']);
    $ready->tick();
    check($e->match($id)['state'] === 'live', 'Owner web presence is required for bot gameplay');
    $final = event($ready, $m, 'finished', ['team1_score' => $mr + 1, 'team2_score' => 4]);
    check(!$ready->event('s1', $final), 'Natural finish replay applied twice');
    check($e->match($id)['state'] === 'finished', 'Bot-only match did not finish');
    check($e->db->one('SELECT algorithm FROM mq2_settlements WHERE match_id=?', [$id])['algorithm'] === 'test-no-elo-v1', 'Wrong settlement policy');
    check((int) $e->db->one('SELECT winner FROM mq2_match_results WHERE match_id=?', [$id])['winner'] === 1, 'Bot result lost');
    check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Lease released before idle');
    $cleanup = $e->db->one('SELECT available_at FROM mq2_commands WHERE type=?', ['cleanup']);
    check((int) $cleanup['available_at'] === $ready->now() + Engine::CS16_POST_MATCH_SECONDS, 'Normal post-match grace lost');
    noBotOnlyRankedWrites($e);
    event($ready, $m, 'idle');
    check(!$e->db->all('SELECT * FROM mq2_leases') && (int) $tests->find($id)['released_at'] > 0, 'Bot test not released');
    check($app->state('1', 'cs16-5v5', $id, false, true)['history'][0]['id'] === $id, 'Owner lost released result');
    $tests->remove([$id], '1', 1);
    check(!$e->db->all('SELECT * FROM mq2_test_bots') && !$e->db->all('SELECT * FROM mq2_match_players'), 'Bot test removal incomplete');
    check(count($e->db->all('SELECT * FROM mq2_players')) === 2 && !$ready->event('s1', $final), 'Cleanup damaged accounts or replay drain');
    echo 'PASS bot-only MR' . $mr . ": auto-load, owner outside roster, 15s readiness journal, natural finish/history/idle/remove; no ELO or penalties\n";
}

foreach (['manual', 'load_failure', 'ready_timeout'] as $case) {
    [$e, $tests] = botOnlyFixture();
    $id = $tests->create('1', 's1', 15, true, 'de_dust2');
    $m = $e->match($id);
    $config = $e->configuration($id);
    if ($case === 'manual') {
        $tests->stop($id, '1');
        event($e, $m, 'test_ended', ['team1_score' => 0, 'team2_score' => 0, 'reason' => 'test_admin', 'actor' => $config['test_owner']]);
        check($e->match($id)['state'] === 'finished', 'Outside-roster owner could not stop the test');
    } elseif ($case === 'load_failure') {
        event($e, $m, 'load_rejected', ['code' => 'test_bot_nav_missing']);
        check($e->match($id)['state'] === 'cancelled', 'Missing AI navigation did not cancel safely');
    } else {
        event($e, $m, 'loaded', ['map' => $m['picked_map'], 'config_hash' => $config['config_hash'], 'ready_deadline' => $e->now() + 300]);
        foreach ($config['players'] as $p)
            event($e, $m, 'player_ready', ['steam_id' => $p['steam_id'], 'ready' => false]);
        $later = new Engine($e->db, fn() => 2000000300);
        event($later, $m, 'not_ready', ['missing' => array_column($config['players'], 'steam_id'), 'occurred_at' => $later->now()]);
        check($e->match($id)['state'] === 'cancelled', 'Bot readiness failure did not cancel safely');
    }
    noBotOnlyRankedWrites($e);
    check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Failed test released without idle');
    event($e, $m, 'idle');
    check(!$e->db->all('SELECT * FROM mq2_leases'), 'Failed test lease did not release');
}
echo "PASS owner stop, AI load failure and bot readiness timeout retain test-only cleanup and no sanctions\n";
