import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

// Exercise the actual browser calculation without booting the polling UI.
const source = readFileSync(new URL('../module/Resources/assets/mixqueue.js', import.meta.url), 'utf8');
const start = source.indexOf('      const leaderHelp = {');
const end = source.indexOf('      const sort = columns.some', start);
assert(start > 0 && end > start);
const compute = new Function('m', 'columns', 'metric', source.slice(start, end) + '\nreturn leaders;');
const metric = (p, key) => key === 'kd' && p.metrics.kd_infinite ? Infinity : p.metrics[key];
const players = (...stats) => stats.map((metrics, i) => ({user_id:String(i), team:i % 2 + 1, metrics}));
const leaders = (rows, keys) => compute({players:rows}, keys.map(k=>[k]), metric);
const ids = (result, key) => [...(result.get(key) || [])].sort();

let result = leaders(players({kills:10, deaths:4, assists:3}, {kills:12, deaths:6, assists:5}, {kills:12, deaths:2, assists:5}), ['kills','deaths','assists']);
assert.deepEqual(ids(result,'kills'), ['1','2'], 'ties across both teams');
assert.deepEqual(ids(result,'deaths'), ['1']);
assert.deepEqual(ids(result,'assists'), ['1','2']);
result = leaders(players({kills:0, assists:2}, {kills:0, assists:2}, {}), ['kills','assists','adr']);
assert.equal(result.size, 0, 'zero-only, uniform and missing columns');
result = leaders(players({adr:90.01}, {adr:90.04}, {adr:50}), ['adr']);
assert.deepEqual(ids(result,'adr'), ['0','1'], 'same displayed precision is a tie');
result = leaders(players({kd:null,kd_infinite:true}, {kd:5}, {kd:null}), ['kd']);
assert.deepEqual(ids(result,'kd'), ['0'], 'valid infinite K/D outranks finite K/D');
result = leaders(players({kills:null}, {kills:NaN}, {kills:8}, {kills:2}), ['kills']);
assert.deepEqual(ids(result,'kills'), ['2'], 'missing and NaN cannot win');
assert.equal(leaders(players({rating_before:1000},{rating_before:2000}),['rating_before']).size, 0);
assert.deepEqual(ids(leaders(players({kills:3},{kills:8}), ['kills']),'kills'), ['1']);
assert.deepEqual(ids(leaders(players({kills:20},{kills:12}), ['kills']),'kills'), ['0'], 'recomputed for a different round snapshot');
console.log('PASS scoreboard leaders: global ties, no zero/uniform/missing/ELO accents, displayed precision, infinite K/D, round changes');
