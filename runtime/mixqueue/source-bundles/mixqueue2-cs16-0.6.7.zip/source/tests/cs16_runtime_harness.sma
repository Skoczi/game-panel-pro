// QA build only. NEVER include this plugin in a release/download package.
// Uses the production controller, with synthetic round inputs for headless tests.
#define plugin_init mq2_real_plugin_init
#include "mq2_match.sma"
#undef plugin_init
public plugin_init() {
    mq2_real_plugin_init();
    register_srvcmd("mq2_qa_live", "qa_live");
    register_srvcmd("mq2_qa_round", "qa_round");
}
public qa_live() { if(gState==1 && !gStarting) start_live(); }
public qa_round() {
    new value[8]; read_argv(1,value,charsmax(value));
    new team=str_to_num(value);
    if(team<0 || team>1 || gIntermission) {server_print("qa_not_ready");return;}
    gIgnoreUntil=0.0;round_win(team);
}
