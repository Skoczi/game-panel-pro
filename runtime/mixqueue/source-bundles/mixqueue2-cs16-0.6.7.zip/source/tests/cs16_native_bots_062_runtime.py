"""Real ReGameDLL bot movement/combat in a network-none lab; no Steam claim.

Only the human slot is a QA entity. Bot damage, shots, kills and round results
must originate in the engine AI: this harness never invokes a damage/kill hook.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--agent', required=True)
a = p.parse_args()
root = Path(a.root).resolve()
assert '/csco-lab/matchbot-062-ai/' in str(root)
spec = importlib.util.spec_from_file_location('agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', 27095, os.environ['MQ2_QA_RCON_PASSWORD'])
last = 0
proof = {'acceptance': 'real native bot AI with QA human; not Steam client acceptance', 'cases': []}


def cmd(command):
    global last
    time.sleep(max(0, 1.05 - (time.monotonic() - last)))
    reply = rcon.command(command)
    last = time.monotonic()
    return reply


def qa(command):
    return cmd('mq2_qa ' + command)


def obj(command):
    return json.loads(qa(command))


def status():
    return json.loads(cmd('mq2_status'))


def cvar(name):
    reply = cmd(name)
    match = re.search(r'(?:=|is)\s*"([^"]*)"', reply)
    assert match, (name, reply)
    return match[1]


def events():
    return [event for line in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines()
            if (event := json.loads(line))['match_id'] == mid]


def save(case):
    proof['cases'].append(case)
    (root.parent.parent/'native-bots-062-proof.json').write_text(json.dumps(proof, indent=2))


def clear():
    assert cmd('mq2_clear server_error').endswith('cleared')
    state = status()
    assert state['idle'] and state['healthy'], state
    bots = obj('botstate')
    assert bots['native_bots'] == bots['owned_bots'] == bots['quota'] == 0, bots


def live():
    deadline = time.monotonic() + 85
    while time.monotonic() < deadline:
        snap = obj('snapshot')
        if snap['round_open'] and not snap['freeze'] and not snap['lo3']:
            return snap
        qa('fast')
    raise AssertionError(('not live', status(), snap))


def load(full=True, map_name='de_dust2', reject=None, solo=False):
    global mid, generation, players
    assert status()['idle']
    generation = int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) + 1
    mid = ('7e5700' if full else '062000') + f'{time.time_ns():018x}'[-18:]
    size = 5 if full or solo else 2
    players = []
    for index in range(1 if solo else size*2):
        team = 1 if index < size else 2
        captain = index in (0, size)
        bot = full and index != 0
        steam = ('bot:' + hashlib.sha256(f'{mid}:{generation}:{team}:{index+1}'.encode()).hexdigest()[:24]
                 if bot else str(76561198000000000+index))
        name = ('Neo' if team == 1 else 'Forest') if captain else 'Player'+str(index)
        players.append({'steam_id': steam, 'name': name, 'team': team, 'bot': bot,
                        'captain': int(captain), 'locale': 'pl' if team == 1 else 'en'})
    assignment = {'game': 'cs16', 'match_id': mid, 'generation': generation, 'config_hash': 'd'*64,
                  'contract_version': 3, 'starting_ct_team': 2, 'map': map_name, 'team_size': size,
                  'teams': {'1': 'Neo team', '2': 'Forest team'}, 'players': players,
                  'rules': {'mr': 15 if size == 5 else 8, 'ot_mr': 3, 'test': full or solo}}
    if full:
        assignment['rules']['test_type'] = 'full'
        assignment['test_owner'] = players[0]['steam_id']
    (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(assignment))
    response = cmd(f'mq2_load {mid} {generation}')
    if reject:
        assert response.endswith(reject), (response, status())
        assert status()['idle'] and status()['healthy']
        assert int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) == generation - 1
        assert not events()
        save({'case': reject, 'match_id': mid, 'attempted_generation': generation, 'response': response})
        return
    assert response.endswith('loaded'), (response, status())
    for index, row in enumerate(players):
        if not row['bot']:
            assert qa(f'add {index}') == 'qa_added'
    return obj('snapshot')


assert status()['controller_version'] == '0.6.2'
if not status()['idle']:
    clear()
# Deliberately non-default settings prove that assignment-owned overrides are
# restored during normal cleanup. Changes are limited to this network-none lab.
cmd('bot_difficulty 3')
cmd('bot_join_after_player 1')
cmd('bot_chatter minimal')
baseline = {name: cvar(name) for name in ['bot_difficulty', 'bot_join_after_player', 'bot_chatter', 'bot_quota']}
cmd('bot_enable 0')
load(reject='test_ai_disabled')
cmd('bot_enable 1')
assert (root/'maps/de_nuke.bsp').is_file() and not (root/'maps/de_nuke.nav').exists()
load(map_name='de_nuke', reject='test_bot_nav_missing')
print('PASS disabled AI and absent NAV rejected before consuming generation or emitting assignment events', flush=True)
initial = load()
bots = obj('botstate')
assert bots['preflight'] == '' and bots['native_bots'] == bots['owned_bots'] == bots['quota'] == 9, bots
bootstrap = events()
assert bootstrap[0]['type'] == 'loaded' and sum(row['type'] == 'loaded' for row in bootstrap) == 1, bootstrap
connected = [row['data']['steam_id'] for row in bootstrap if row['type'] == 'connected' and row['data']['connected']]
assert len(connected) == len(set(connected)) == 10, connected
identities = []
for client in initial['clients']:
    if client['slot'] <= 0:
        continue
    row = obj('botstate ' + str(client['id']))
    signed = players[row['slot']]
    assert row['native_bot'] and row['owned'] and signed['bot'], row
    assert row['name'] == signed['name'], (row, signed)
    assert row['team'] == signed['team'], (row, signed)  # Logical1=T, logical2=CT here.
    identities.append(row)
assert len(identities) == 9
qa('talk 0 ready')  # Only the human accepts; assigned native bots must auto-ready.
live()
clock = obj('round-clock')
assert clock['configured_seconds'] == clock['clock_seconds'] == 30 and clock['healthy'], clock
assert status()['restarts_completed'] == 3
print('PASS signed1+9 has nine owned native AI bots with names/teams, ready and three restarts, actual30s LIVE', flush=True)

deadline = time.monotonic() + 180
positions = {}
moved = set()
shots = []
samples = []
combat = []
turn = 0
while time.monotonic() < deadline:
    snap = obj('snapshot')
    score = (snap['ct_score'], snap['t_score'])
    for client in snap['clients']:
        if client['slot'] <= 0 or not client['alive'] or not snap['round_open'] or snap['freeze']:
            continue
        previous = positions.get(client['slot'])
        if previous and previous[0] == score and math.dist(previous[1], client['xyz']) > 32:
            moved.add(players[client['slot']]['team'])
        positions[client['slot']] = (score, client['xyz'])
    watched = identities[turn % len(identities)]
    row = obj('botstate ' + str(watched['id']))
    samples.append(row)
    if row.get('weapon_shots', 0) > 0 or row.get('buttons', 0) & 1:
        shots.append(row)
    rounds = [event for event in events() if event['type'] == 'round']
    if rounds:
        combat = [stats for steam, stats in rounds[-1]['data']['players'].items()
                  if steam.startswith('bot:') and stats.get('damage', 0) > 0]
    if moved == {1, 2} and shots and combat:
        break
    turn += 1
assert moved == {1, 2}, moved
assert shots, 'No native weapon shooting sample observed'
assert combat, 'No AI combat damage recorded in round journal'
state = status()
assert state['healthy'], state
save({'case': 'native_ai_movement_and_combat', 'match_id': mid, 'generation': generation,
      'identities': identities, 'movement_teams': sorted(moved), 'shooting_samples': shots,
      'samples': samples, 'events': events()})
print('PASS bots on both signed teams move while alive in same round, native shooting and actual combat damage journaled', flush=True)

# Only one human captain: bot captain does not auto-consent. The tactical timer
# must be the resume authority, retaining result and player statistics.
qa('talk 0 pause')
deadline = time.monotonic() + 80
while time.monotonic() < deadline:
    pause = obj('pause-state')
    if pause['paused']:
        break
assert pause['paused'] and pause['tactical'], pause
before = status()['score']
paused_at = time.monotonic()
qa('talk 0 unpause')
assert obj('pause-state')['paused']
while time.monotonic() - paused_at < 36:
    if not obj('pause-state')['paused']:
        break
assert not obj('pause-state')['paused']
assert 22 < time.monotonic()-paused_at < 38
assert status()['score'] == before
assert sum(event['type'] == 'resume' for event in events()) == 1
live()
assert obj('round-clock')['configured_seconds'] == 30
save({'case': 'native_ai_tactical_timeout', 'match_id': mid, 'generation': generation, 'score': before, 'events': events()})
clear()
restored = {name: cvar(name) for name in baseline}
assert restored == baseline, (baseline, restored)
assert not (root/'addons/amxmodx/configs/mq2/original-bots.txt').exists()
save({'case': 'native_bot_settings_restored', 'before': baseline, 'after': restored})
print('PASS one human captain cannot bypass bot captain; tactical timer resumes once, score preserved, bots cleaned normally', flush=True)

load(False)
qa('ready')
live()
assert obj('round-clock')['configured_seconds'] == 105
cmd('bot_add_ct')
time.sleep(2)
bots = obj('botstate')
assert bots['native_bots'] == bots['owned_bots'] == bots['quota'] == 0, bots
assert status()['healthy']
save({'case': 'ranked_rejects_native_bot', 'match_id': mid, 'generation': generation, 'botstate': bots, 'events': events()})
clear()
cmd('bot_add_t')
time.sleep(2)
bots = obj('botstate')
assert bots['native_bots'] == bots['owned_bots'] == bots['quota'] == 0, bots
print('PASS ranked stays105s and rejects unsigned bot; idle also rejects bot and quota remains0; history retained', flush=True)

initial = load(False, solo=True)
bots = obj('botstate')
assert bots['native_bots'] == bots['owned_bots'] == bots['quota'] == 1, bots
opponents = [obj('botstate '+str(row['id'])) for row in initial['clients'] if row['slot'] < 0]
assert len(opponents) == 1 and opponents[0]['native_bot'] and opponents[0]['owned'], opponents
assert opponents[0]['team'] == 2 and opponents[0]['name'] == 'CSCO Test Opponent', opponents
qa('talk 0 ready')
live()
assert obj('round-clock')['configured_seconds'] == 30
assert status()['restarts_completed'] == 3
save({'case': 'solo_native_opponent', 'match_id': mid, 'generation': generation, 'opponents': opponents, 'events': events()})
clear()
print('PASS solo creates one native opponent with signed-side ownership, auto-ready and30s LIVE, normal cleanup', flush=True)
