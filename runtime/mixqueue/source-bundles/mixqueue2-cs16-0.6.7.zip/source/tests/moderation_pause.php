<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Moderation};
use Flute\Modules\MixQueue2\Http\Application;

$e = fixture(11);
$m = readyMatch($e);
live($e, $m);
$e->report('1', $m['id'], 'Please review player behaviour');
$r = $e->db->one('SELECT id FROM mq2_reports')['id'];
$app = new Application($e);
$input = [
    'action' => 'resolve_report',
    'report' => $r,
    'reason' => 'Reviewed evidence: repeated griefing',
    'duration' => 1800,
    'user' => '2'
];
rejects(fn() => $app->act('1', $input, false), 'forbidden');
rejects(fn() => $app->act('1', [...$input, 'duration' => -1], true), 'duration');
rejects(fn() => $app->act('1', [...$input, 'user' => '11'], true), 'participant');
$app->act('1', $input, true);
$row = $e->db->one('SELECT * FROM mq2_sanctions');
check($row['user_id'] === '2' && (int) $row['expires_at'] === ( $e->now() + 1800 ), 'Wrong sanction');
check(
    $e->match($m['id'])['state'] === 'live' && count($e->db->all('SELECT * FROM mq2_claims')) === 10,
    'Sanction interrupted active match'
);
rejects(fn() => $app->act('1', $input, true), 'report');
$e->cancel($m['id'], '1', 'Test completed safely');
rejects(fn() => $e->join('2', 'csco-5v5'), 'penalty');
$revoke = ['action' => 'revoke_sanction', 'sanction' => $row['id'], 'reason' => 'Reviewed appeal and revoked'];
rejects(fn() => $app->act('2', $revoke, false), 'forbidden');
$app->act('1', $revoke, true);
$e->join('2', 'csco-5v5');
check((int) $e->db->one('SELECT revoked_at FROM mq2_sanctions')['revoked_at'] === $e->now(), 'Revoke lost history');
check(count($e->db->all("SELECT * FROM mq2_audit WHERE action LIKE 'sanction.%'")) === 2, 'Missing audit');

$e = fixture();
$m = readyMatch($e);
live($e, $m);
$pause = ['serial' => 1, 'kind' => 'tactical', 'team' => 2, 'votes' => 0, 'deadline' => $e->now() + 60];
event($e, $m, 'pause', $pause);
event($e, $m, 'pause_update', [...$pause, 'votes' => 2]);
rejects(fn() => event($e, $m, 'pause_update', [...$pause, 'serial' => 2, 'votes' => 3]), 'pause');
rejects(fn() => event($e, $m, 'pause_update', [...$pause, 'votes' => 1]), 'pause');
check(
    ( new Application($e) )->state('1', 'csco-5v5', $m['id'])['match']['pause_info']['votes'] === 2,
    'Pause votes lost'
);
event($e, $m, 'resume');
check(!(int) $e->db->one('SELECT active FROM mq2_pause_info')['active'], 'Resume did not clear pause');
event($e, $m, 'pause', [...$pause, 'serial' => 2]);
check((int) $e->db->one('SELECT votes FROM mq2_pause_info')['votes'] === 0, 'Consent carried into next pause');
echo
    "PASS moderation permission, participant scope, active match preservation, appeal/revoke audit, pause serial/votes/expiry metadata\n"
;

// Authenticated controller signals create review cases only, once per player/code.
$e = fixture();
$m = readyMatch($e);
live($e, $m);
$e->db->run('UPDATE mq2_matches SET ladder_id=? WHERE id=?', ['cs16-5v5', $m['id']]);
$m = $e->match($m['id']);
$steam = $e->player('2')['steam_id'];
$signal = ['steam_id' => $steam, 'code' => 'team_damage', 'count' => 300, 'round' => 1];
event($e, $m, 'player_alert', $signal);
event($e, $m, 'player_alert', $signal);
check(
    count($e->db->all('SELECT * FROM mq2_reports')) === 1 && !$e->db->all('SELECT * FROM mq2_penalties'),
    'Signal duplicate/automatic penalty'
);
rejects(fn() => event($e, $m, 'player_alert', [...$signal, 'steam_id' => 'foreign']), 'roster');
rejects(fn() => event($e, $m, 'player_alert', [...$signal, 'count' => 1]), 'player_alert');
echo "PASS controller signals require review, threshold/roster validation, no automatic penalty, deduplication\n";
