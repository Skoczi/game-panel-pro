#include "../games/cs16/matchbot/MatchBot/MatchCSCOEnd.h"
#include <cassert>
#include <iostream>
#include <limits>

// Deliberately different values: production maps the named GameDLL constants,
// not numbers copied from a particular SDK build.
enum class Scenario {
    ROUND_TARGET_BOMB=41,ROUND_BOMB_DEFUSED,ROUND_CTS_WIN,ROUND_TERRORISTS_WIN,
    ROUND_TARGET_SAVED,ROUND_HOSTAGE_NOT_RESCUED,ROUND_TERRORISTS_NOT_ESCAPED,
    ROUND_VIP_NOT_ESCAPED,ROUND_VIP_ESCAPED,ROUND_GAME_RESTART,ROUND_NONE
};
int main() {
    mq2::PostMatchClock clock;
    assert(!clock.active && clock.remaining("m:1",100)==0);
    assert(!clock.start("",100) && !clock.start("m:1",std::numeric_limits<float>::infinity()));
    assert(clock.start("m:1",100));
    assert(clock.remaining("m:1",100)==180 && clock.remaining("m:1",279.9f)==1);
    assert(clock.remaining("m:1",280)==0 && clock.active);
    assert(clock.remaining("m:1",1000)==0 && clock.active); // No autonomous cleanup.
    assert(!clock.start("m:1",300) && clock.until==280); // Duplicate result cannot extend stay.
    assert(clock.remaining("m:2",101)==0); // No cross-generation reuse.
    clock.reset();assert(!clock.active && clock.until==0 && clock.scope.empty());
    assert(clock.start("m:2",10) && clock.remaining("m:2",10)==180);
    auto reason=[](Scenario s) {return std::string(mq2::round_reason(s));};
    assert(reason(Scenario::ROUND_TARGET_BOMB)=="bomb_exploded");
    assert(reason(Scenario::ROUND_BOMB_DEFUSED)=="bomb_defused");
    assert(reason(Scenario::ROUND_CTS_WIN)=="elimination" && reason(Scenario::ROUND_TERRORISTS_WIN)=="elimination");
    for(const auto s:{Scenario::ROUND_TARGET_SAVED,Scenario::ROUND_HOSTAGE_NOT_RESCUED,
                     Scenario::ROUND_TERRORISTS_NOT_ESCAPED,Scenario::ROUND_VIP_NOT_ESCAPED}) assert(reason(s)=="time");
    for(const auto s:{Scenario::ROUND_VIP_ESCAPED,Scenario::ROUND_GAME_RESTART,Scenario::ROUND_NONE,Scenario(999)}) assert(reason(s)=="other");
    std::cout<<"PASS scoped postmatch retention and named GameDLL round reasons\n";
}
