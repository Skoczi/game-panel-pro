<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{RoundTimeline, Engine};
use Flute\Modules\MixQueue2\Http\Application;

function roundEvent(int $seq, int $a, int $b, ?string $reason = null, string $type = 'round'): array
{
    return ['generation' => 7, 'sequence' => $seq, 'type' => $type, 'data' => [
        'team1_score' => $a, 'team2_score' => $b
    ] + ($reason === null ? [] : ['round_reason' => $reason])];
}
$events = [roundEvent(1, 1, 0, 'elimination'), roundEvent(2, 1, 1, 'bomb_defused'),
    roundEvent(3, 2, 1, 'bomb_exploded'), roundEvent(4, 2, 2, 'time'), roundEvent(5, 3, 2, 'other', 'finished')];
$rounds = RoundTimeline::project(array_reverse($events), 3, 2, 7);
check(array_column($rounds, 'winner') === [1, 2, 1, 2, 1], 'Logical winners or sequence ordering incorrect');
check(array_column($rounds, 'reason') === ['elimination', 'bomb_defused', 'bomb_exploded', 'time', 'other'], 'Reasons lost');
check($rounds[4]['score'] === [3, 2], 'Final round absent');
$events[] = roundEvent(6, 4, 2, 'elimination');
$events[] = array_replace(roundEvent(0, 0, 1, 'time'), ['generation' => 6]);
check(RoundTimeline::project($events, 3, 2, 7) === $rounds, 'Late/foreign observations changed result');
$legacy = RoundTimeline::project([roundEvent(1, 1, 0), roundEvent(2, 1, 0), roundEvent(3, 3, 1), roundEvent(4, 3, 2)], 3, 2, 7);
check($legacy[0]['winner'] === 1 && $legacy[0]['reason'] === null, 'Legacy reason invented');
check($legacy[1]['winner'] === null && $legacy[3]['score'] === null && $legacy[4]['winner'] === 2, 'Gap fabricated or subsequent valid round lost');
check(count(RoundTimeline::project([], 22, 19, 7)) === 41, 'Missing history not represented honestly');
check(RoundTimeline::project([], 0, 0, 7) === [], 'Zero-round phantom timeline');
$ended = [roundEvent(1, 1, 0), roundEvent(2, 1, 0, null, 'test_ended'), roundEvent(3, 2, 0)];
check(RoundTimeline::project($ended, 2, 0, 7)[1]['winner'] === null, 'Post-admin-stop round accepted');
foreach ([null, '', 'kill', '<script>', [], 1] as $bad) rejects(fn() => RoundTimeline::validateReason(['round_reason' => $bad]), 'round_reason');
RoundTimeline::validateReason([]);
foreach (RoundTimeline::REASONS as $valid) RoundTimeline::validateReason(['round_reason' => $valid]);

$e = fixture();
$m = readyMatch($e);
live($e, $m);
$before = $e->match($m['id']);
rejects(fn() => event($e, $m, 'round', ['team1_score' => 1, 'team2_score' => 0, 'round_reason' => 'fake']), 'round_reason');
check($e->match($m['id']) === $before, 'Rejected reason mutated score');
$first = event($e, $m, 'round', ['team1_score' => 1, 'team2_score' => 0, 'round_reason' => 'bomb_defused']);
check(!$e->event('s1', $first), 'Duplicate round applied');
event($e, $m, 'round', ['team1_score' => 1, 'team2_score' => 1]);
$public = (new Application($e))->state('1', $m['ladder_id'], $m['id'])['match']['round_timeline'];
check(count($public) === 2 && $public[0]['reason'] === 'bomb_defused' && $public[1]['reason'] === null, 'Public projection or old-controller compatibility');
check(array_keys($public[0]) === ['number', 'winner', 'reason', 'score'], 'Internal journal fields exposed');
$e->identify('visitor', '76561198000000999', 'Viewer');
event($e, $m, 'round', ['team1_score'=>2,'team2_score'=>1,'players'=>[
    '76561198000000001'=>['kills'=>4,'deaths'=>2,'assists'=>1,'damage'=>210,'rounds'=>3,'headshots'=>2]
]]);
$view=(new Application($e))->state('visitor',$m['ladder_id'],$m['id'])['match'];
$p=array_values(array_filter($view['players'],static fn($p)=>$p['user_id']==='1'))[0];
check($view['state']==='live' && $view['address']===null, 'Visitor live view or private connect isolation');
check($p['metrics']['kills']===4 && $p['metrics']['deaths']===2 && $p['metrics']['assists']===1
    && $p['metrics']['adr']===70.0 && $p['metrics']['hs_percent']===50.0, 'Visitor round statistics mismatch');
echo "PASS round timeline: authoritative reasons, logical winners, sequence, final round, missing legacy data, gaps, duplicate/terminal/generation isolation, validation rollback, public projection\n";
