<?php

declare(strict_types = 1);

define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';

use Flute\Modules\MixQueue2\Domain\{Engine, ServerRegistry, ServerTests, Statistics, TestMatches};

function graceClock(Engine $e, int $at): Engine
{
    return new Engine($e->db, static fn() => $at);
}

function graceRanked(string $game = 'cs16', bool $legacy = false): array
{
    $e = fixture();
    $maps = $e->ladder($game . '-5v5')['maps'];
    $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
        $game,
        Engine::json(['maps' => $maps, 'modes' => ['5v5']]),
        's1'
    ]);
    if ($game === 'cs16') {
        $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
            's1',
            Engine::json([
                ...cs16Status(),
                'map_inventory' => ['version' => 1, 'complete' => true, 'source' => 'bsp_v30', 'maps' => $maps]
            ]),
            $e->now()
        ]);
    }
    $m = readyMatch($e, $game . '-5v5', 10, $legacy);
    live($e, $m);
    return [$e, $m];
}

function graceStats(Engine $e, array $m, int $rounds): array
{
    $stats = [];
    foreach ($e->db->all('SELECT steam_id FROM mq2_match_players WHERE match_id=?', [$m['id']]) as $p) {
        $stats[$p['steam_id']] = array_replace(array_fill_keys(Statistics::COUNTERS, 0), [
            'kills' => 2,
            'deaths' => 1,
            'assists' => 1,
            'damage' => 180,
            'headshots' => 1,
            'rounds' => $rounds
        ]);
    }
    return $stats;
}

function graceCommand(Engine $e, string $id): array
{
    $rows = $e->db->all('SELECT * FROM mq2_commands WHERE match_id=? AND type=? AND state=?', [
        $id, 'cleanup', 'pending'
    ]);
    check(count($rows) === 1, 'Expected one durable pending cleanup');
    return $rows[0];
}

// The grace starts once, in the same transaction that settles the result.
[$e, $m] = graceRanked();
$at = $e->now();
$stats = graceStats($e, $m, 16);
$final = event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 0, 'stats_version' => 2, 'players' => $stats]);
$command = graceCommand($e, $m['id']);
check((int) $command['available_at'] === $at + 180 && (int) $command['created_at'] === $at, 'Wrong cleanup deadline');
check($e->match($m['id'])['state'] === 'finished' && !$e->commands('s1'), 'Result delayed or cleanup dispatched early');
check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'ELO was not settled immediately');
check((int) $e->db->one('SELECT SUM(delta) AS n FROM mq2_rating_changes')['n'] === 0, 'ELO not zero sum');
$storedStats = $e->db->all('SELECT user_id,stats FROM mq2_match_players WHERE match_id=? ORDER BY user_id', [$m['id']]);
$ratings = $e->db->all('SELECT * FROM mq2_ratings ORDER BY user_id,ladder_id');
check((new Statistics($e))->profile('1', 'cs16-5v5')['overall']['played'] === 1, 'Result absent from profile during grace');
rejects(fn() => (new ServerRegistry($e))->assertIdle('s1'), 'server_busy');

// Reconstruct the worker at 179 seconds: neither duplicate IDs nor later copies of
// the final journal observation may move the durable deadline or settle ELO twice.
$later = graceClock($e, $at + 179);
check(!$later->event('s1', $final), 'Duplicate final was applied');
event($later, $m, 'finished', $final['data']);
check(graceCommand($later, $m['id']) === $command, 'Duplicate/restart moved the deadline');
check(!$later->commands('s1'), 'Cleanup dispatched at 179 seconds');
$later->serverHeartbeat('s1', true);
$later->db->run('UPDATE mq2_observations SET observed_at=?', [$later->now()]);
$later->tick();
for ($i = 1; $i <= 10; ++$i) {
    $later->heartbeat((string) $i);
    $later->join((string) $i, 'cs16-5v5');
}
check($later->tick() === 0 && count($e->db->all('SELECT * FROM mq2_matches')) === 1, 'Reserved postmatch server reallocated');
check((int) $e->db->one('SELECT generation FROM mq2_leases')['generation'] === (int) $m['generation'], 'Lease generation changed');

$due = graceClock($e, $at + 180);
$delivered = $due->commands('s1');
check(count($delivered) === 1 && $delivered[0]['id'] === $command['id'], 'Cleanup not dispatched at 180 seconds');
check((int) $delivered[0]['generation'] === (int) $m['generation'], 'Cleanup targeted another generation');
check(!$due->commands('s1') && !graceClock($e, $at + 189)->commands('s1'), 'Retry was not throttled');
$retry = graceClock($e, $at + 190)->commands('s1');
check(count($retry) === 1 && $retry[0]['id'] === $command['id'], 'Retry created a new cleanup');
check(!!$e->db->one('SELECT * FROM mq2_leases'), 'Dispatch/retry released the lease without idle');
check($ratings === $e->db->all('SELECT * FROM mq2_ratings ORDER BY user_id,ladder_id'), 'Retry changed ratings');
check($storedStats === $e->db->all('SELECT user_id,stats FROM mq2_match_players WHERE match_id=? ORDER BY user_id', [$m['id']]), 'Grace changed statistics');
check(count($e->db->all('SELECT * FROM mq2_settlements')) === 1, 'Repeated settlement');
$released = graceClock($e, $at + 191);
$idle = event($released, $m, 'idle');
check(!$released->event('s1', $idle) && !$e->db->all('SELECT * FROM mq2_leases'), 'Idle did not release exactly once');
check($e->match($m['id'])['state'] === 'finished' && !!$e->db->one('SELECT * FROM mq2_events'), 'Cleanup deleted history');
echo "PASS ranked: immediate result/stats/ELO, durable 179/180 deadline, retries, queue exclusion and idle-only release\n";

// An older cleanup must never be dispatched against a changed lease identity.
[$e, $m] = graceRanked();
event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 0]);
$e->db->run('UPDATE mq2_leases SET generation=generation+1 WHERE server_id=?', ['s1']);
check(!graceClock($e, $e->now() + 180)->commands('s1'), 'Cleanup crossed generation boundary');
echo "PASS cleanup delivery remains bound to the exact lease generation\n";

// A valid surrender still ends play normally; preserve its true partial score.
[$e, $m] = graceRanked('cs16', true);
$team = $e->db->all('SELECT steam_id FROM mq2_match_players WHERE match_id=? AND team=1 ORDER BY user_id', [$m['id']]);
$leaver = $team[0]['steam_id'];
event($e, $m, 'connected', ['steam_id' => $leaver, 'connected' => false]);
event($e, $m, 'reconnect_window', ['steam_id' => $leaver, 'stage' => 'grace', 'seconds' => 180, 'deadline' => $e->now() + 180]);
event($e, $m, 'abandoned', ['steam_id' => $leaver, 'cooldown_seconds' => 1800]);
event($e, $m, 'surrendered', [
    'team1_score' => 8, 'team2_score' => 2, 'loser_team' => 1,
    'yes_votes' => array_column(array_slice($team, 1, 3), 'steam_id'), 'players' => []
]);
check((int) graceCommand($e, $m['id'])['available_at'] === $e->now() + 180, 'Surrender skipped grace');
check((int) $e->match($m['id'])['team1_score'] === 8 && (int) $e->db->one('SELECT winner FROM mq2_match_results')['winner'] === 2, 'Surrender result changed');
check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10 && count($e->db->all('SELECT * FROM mq2_penalties')) === 1, 'Surrender settlement/penalty changed');
echo "PASS surrender: partial score and one settlement retained during grace\n";

[$e, $tests, $id] = fullFixture(1);
$m = startFull($e, $tests, $id, 1);
$at = $e->now();
$stats = graceStats($e, $m, 16);
$final = event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 0, 'stats_version' => 2, 'players' => $stats]);
check((int) graceCommand($e, $id)['available_at'] === $at + 180 && !$e->commands('s1'), 'Full test skipped grace');
check($e->match($id)['state'] === 'finished' && (int) $tests->find($id)['released_at'] === 0, 'Full test released early');
$e->db->run('UPDATE mq2_test_matches SET expires_at=? WHERE match_id=?', [$at + 1, $id]);
$later = graceClock($e, $at + 179);
$later->tick();
check(!$later->event('s1', $final) && !$later->commands('s1'), 'Expiry/replay shortened full-test grace');
check(!$e->db->all('SELECT * FROM mq2_ratings') && !$e->db->all('SELECT * FROM mq2_penalties'), 'Full test changed ELO/penalties');
check((new Statistics($e))->profile('1', 'cs16-5v5')['overall']['played'] === 0, 'Full test polluted overall');
$due = graceClock($e, $at + 180);
check(count($due->commands('s1')) === 1, 'Full test cleanup not due');
event($due, $m, 'idle');
check((int) $tests->find($id)['released_at'] === $at + 180 && !$e->db->all('SELECT * FROM mq2_leases'), 'Full test not released by idle');
check(count($e->db->all('SELECT * FROM mq2_match_players WHERE match_id=?', [$id])) === 10 && (int) $e->db->one('SELECT winner FROM mq2_match_results')['winner'] === 1, 'Full test result deleted');
echo "PASS full test: natural finish gets 180 seconds; no ELO/penalty; expiry cannot shorten grace\n";

foreach (['test_admin', 'test_timeout', 'server_error'] as $reason) {
    [$e, $tests, $id] = fullFixture(1);
    $m = startFull($e, $tests, $id, 1);
    $tests->stop($id, '1', $reason);
    check($e->commands('s1')[0]['type'] === 'finish_test', 'Operational stop delayed');
    event($e, $m, 'test_ended', [
        'team1_score' => 0, 'team2_score' => 0, 'players' => [],
        'reason' => $reason, 'actor' => $e->player('1')['steam_id']
    ]);
    $command = $e->commands('s1');
    check(count($command) === 1 && $command[0]['type'] === 'cleanup' && (int) $command[0]['available_at'] === $e->now(), 'Operational cleanup delayed');
    check(!!$e->db->one('SELECT * FROM mq2_leases'), 'Operational cleanup released without idle');
}
[$e, $tests, $id] = fullFixture(1);
$m = startFull($e, $tests, $id, 1);
$tests->stop($id, '1');
event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 0]);
check($e->commands('s1')[0]['type'] === 'cleanup', 'Late natural finish delayed an already requested operational stop');
[$e, $m] = graceRanked();
$e->cancel($m['id'], 'admin', 'server_error');
check($e->commands('s1')[0]['type'] === 'abort' && !$e->db->all('SELECT * FROM mq2_settlements'), 'Abort delayed or settled');
echo "PASS admin/test timeout/server error and abort remain immediate\n";

foreach (['csgo', 'csco'] as $game) {
    [$e, $m] = graceRanked($game);
    event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 0]);
    check($e->commands('s1')[0]['type'] === 'cleanup', $game . ' cleanup unexpectedly delayed');
}
echo "PASS CS:GO and Classic Offensive keep immediate cleanup\n";

// Solo uses its existing persisted details and sequenced stream, never ranked data.
$e = fixture(1);
$maps = ['de_dust2'];
$e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', ['cs16', Engine::json(['maps' => $maps, 'modes' => ['5v5']]), 's1']);
$e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
    's1', Engine::json([...cs16Status(), 'solo_test' => true, 'map_inventory' => ['version' => 1, 'complete' => true, 'source' => 'bsp_v30', 'maps' => $maps]]), $e->now()
]);
$tests = new ServerTests($e);
$solo = $tests->start('s1', '1', 'de_dust2');
$load = $e->commands('s1')[0]['payload'];
$sequence = 0;
$emit = function (Engine $engine, string $type, array $data = []) use ($solo, &$sequence): array {
    $event = ['event_id' => Engine::id(), 'match_id' => $solo['id'], 'generation' => (int) $solo['generation'], 'sequence' => ++$sequence, 'type' => $type, 'data' => $data];
    $engine->event('s1', $event);
    return $event;
};
$emit($e, 'loaded', ['map' => 'de_dust2', 'config_hash' => $load['config_hash']]);
$emit($e, 'connected', ['steam_id' => $solo['steam_id'], 'connected' => true]);
$emit($e, 'live');
$final = $emit($e, 'finished', ['team1_score' => 16, 'team2_score' => 0]);
$at = $e->now();
check((int) graceCommand($e, $solo['id'])['available_at'] === $at + 180 && !$e->commands('s1'), 'Solo skipped grace');
$later = graceClock($e, $at + 179);
check(!$later->event('s1', $final) && !$later->commands('s1'), 'Solo retry shortened grace');
$emit($later, 'finished', ['team1_score' => 16, 'team2_score' => 0]);
check((int) graceCommand($e, $solo['id'])['available_at'] === $at + 180, 'Solo late event moved deadline');
$later->tick();
$due = graceClock($e, $at + 180);
check(count($due->commands('s1')) === 1 && !!$e->db->one('SELECT * FROM mq2_leases'), 'Solo delivery/release mismatch');
$emit($due, 'idle');
check(!$e->db->all('SELECT * FROM mq2_leases') && $tests->find($solo['id'])['state'] === 'ended', 'Solo idle failed');
check((int) json_decode($tests->find($solo['id'])['details'], true)['team1_score'] === 16, 'Solo result lost');
foreach (['mq2_matches', 'mq2_settlements', 'mq2_ratings', 'mq2_penalties'] as $table)
    check(!$e->db->all('SELECT * FROM ' . $table), 'Solo polluted ' . $table);
echo "PASS solo: sequenced finish/replay, durable 179/180 cleanup, result retained and idle-only release\n";
