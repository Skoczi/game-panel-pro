<?php

declare(strict_types = 1);

define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';
use Flute\Modules\MixQueue2\Domain\{Engine, MapInventory};
use Flute\Modules\MixQueue2\Infrastructure\Catalog;

[$e, $t, $id] = fullFixture(1);
$all = array_keys(Catalog::CS16_MAPS);
check(
    count($all) === 12 && $e->ladder('cs16-5v5')['maps'] === $all && $e->ladder('cs16-2v2')['maps'] === $all,
    'CS16 catalogue missing maps'
);
$before = json_decode($e->match($id)['maps'], true);
$t->start($id, '1');
check(json_decode($e->match($id)['maps'], true) === $before, 'Lobby start changed rotation for the same generation');
$server = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']);
$inventory = new MapInventory($e);
$appearances = array_fill_keys($all, 0);
foreach (range(1, 12) as $generation) {
    $pool = $inventory->pool($server, $e->ladder('cs16-5v5'), $generation);
    check(count($pool) === 11 && count(array_unique($pool)) === 11, 'Veto must keep equal bans');
    foreach ($pool as $map) {
        check(isset($appearances[$map]), 'Unverified map in pool');
        $appearances[$map]++;
    }
}
check(array_unique(array_values($appearances)) === [11], 'A map is permanently excluded from the even catalogue');
[$active, $test, $matchId] = fullFixture(1, 12, true);
startFull($active, $test, $matchId, 1);
$assignment = $active->configuration($matchId);
$match = $active->match($matchId);
$active->db->run('UPDATE mq2_ladders SET maps=? WHERE id=?', [Engine::json($all), 'cs16-5v5']);
$active->db->run('UPDATE mq2_servers SET capabilities=? WHERE id=?', [
    Engine::json(['modes' => ['5v5'], 'maps' => $all]),
    's1'
]);
check($active->configuration($matchId) === $assignment, 'Catalogue update changed an active assignment');
check($active->match($matchId) === $match, 'Catalogue update changed an active match');
echo "PASS 12-map catalogue; all maps eligible across generations; stable lobby pool; balanced bans\n";
echo "PASS catalogue expansion preserves active match, rules, map and assignment hash\n";
