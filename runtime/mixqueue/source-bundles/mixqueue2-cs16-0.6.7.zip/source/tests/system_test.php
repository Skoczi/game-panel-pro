<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';

use Flute\Modules\MixQueue2\Domain\DemoDataset;

$engine = fixture();
$players = [];
for ($id = 1; $id <= 16; ++$id) {
    $players[] = ['id' => (string) $id, 'name' => 'Player ' . $id, 'avatar' => ''];
}
$before = $engine->db->all('SELECT * FROM mq2_ratings');
foreach (['cs16', 'csgo', 'csco'] as $game) {
    foreach (['5v5' => 10, '2v2' => 4] as $mode => $size) {
        $ladder = $engine->ladder($game . '-' . $mode);
        $demo = new DemoDataset($ladder, $players, 1790622000);
        $state = $demo->state('1', null, []);
        check($state['system_test'] === true && $state['claim'] === null, 'Preview claims real queue');
        check(count($state['history']) === 20 && count($state['ranking']) === 16, 'Missing preview content');
        $profile = $demo->profile('1');
        check($profile['overall']['played'] === 26 && $profile['pages'] === 2, 'Demo profile history');
        check(count($demo->profile('1', 2)['recent']) === 6, 'Demo profile pagination');
        check($profile['rating'] === $state['rating']['rating'], 'Profile and lobby ELO differ');
        $previous = null;
        foreach (array_reverse(array_merge($demo->profile('1')['recent'], $demo->profile('1', 2)['recent'])) as $row) {
            $match = $demo->state('1', $row['id'], [])['match'];
            check(
                count($match['players']) === $size
                && count(array_unique(array_column($match['players'], 'user_id'))) === $size,
                'Duplicate or missing roster player'
            );
            check($match['address'] === null, 'Demo exposes a game connection');
            $timeline = $match['round_timeline'];
            check(count($timeline) === $match['team1_score'] + $match['team2_score'], 'Demo timeline length differs from result');
            check(end($timeline)['score'] === [$match['team1_score'], $match['team2_score']], 'Demo timeline final score differs');
            if ($previous !== null) {
                check($row['rating_before'] === $previous, 'Discontinuous ELO history');
            }
            $previous = $row['rating_after'];
            check(array_sum(array_column($match['players'], 'rating_delta')) === 0, 'Demo ELO not zero sum');
            $teams = [];
            foreach ([1, 2] as $team) {
                $teams[$team] = array_filter($match['players'], static fn($p) => $p['team'] === $team);
            }
            check(
                array_sum(array_column(array_column($teams[1], 'stats'), 'kills')) === array_sum(array_column(
                    array_column($teams[2], 'stats'),
                    'deaths'
                )),
                'Kill/death totals inconsistent'
            );
            if ($game === 'cs16') {
                check($match['players'][0]['metrics']['assists'] === $match['players'][0]['stats']['assists'], 'Native demo assists inconsistent');
            }
        }
        check($previous === $profile['rating'], 'Final ELO differs from history');
        rejects(static fn() => $demo->state('1', 'real-match-id', []), 'demo_match');
    }
}
check($engine->db->all('SELECT * FROM mq2_ratings') === $before, 'Preview wrote real ratings');
check($engine->db->all('SELECT * FROM mq2_matches') === [], 'Preview inserted live matches');
echo "PASS system preview: six ladders, consistent rosters and ELO, 26-match profiles, pagination, no real writes\n";
