<?php

declare(strict_types = 1);

// Replay the actual isolated GameDLL 40-round journal into a fresh CS 1.6 ladder.
// Only assignment/Steam identifiers, selected map and config hash are rebound.
define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';

use Flute\Modules\MixQueue2\Domain\Engine;

$e = fixture();
$e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
    'cs16',
    Engine::json(['modes' => ['5v5'], 'maps' => $e->ladder('cs16-5v5')['maps']]),
    's1'
]);
$e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
    's1',
    Engine::json([
        ...cs16Status(),
        'map_inventory' => [
            'version' => 1,
            'source' => 'bsp_v30',
            'complete' => true,
            'maps' => $e->ladder('cs16-5v5')['maps']
        ]
    ]),
    $e->now()
]);
$m = readyMatch($e, 'cs16-5v5', 10, true);
$roster = $e->db->all('SELECT steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,user_id', [$m['id']]);
$identities = [];
foreach ($roster as $slot => $player) {
    $identities[(string) ( 76561198000000000 + $slot )] = $player['steam_id'];
}
$rows = json_decode(file_get_contents(__DIR__ . '/fixtures/matchbot-5v5-22-18.json'), true, 512, JSON_THROW_ON_ERROR);
$sequence = 0;
$finish = null;
foreach ($rows as $row) {
    $row['match_id'] = $m['id'];
    $row['generation'] = (int) $m['generation'];
    $row['sequence'] = ++$sequence; // Assigned by the agent's durable spool.
    if ($row['type'] === 'loaded') {
        $row['data']['map'] = $m['picked_map'];
        $row['data']['config_hash'] = $e->configuration($m['id'])['config_hash'];
    }
    if (isset($row['data']['steam_id'])) {
        $row['data']['steam_id'] = $identities[$row['data']['steam_id']];
    }
    if (isset($row['data']['players'])) {
        $stats = [];
        foreach ($row['data']['players'] as $steam => $playerStats) {
            $stats[$identities[$steam]] = $playerStats;
        }
        $row['data']['players'] = $stats;
    }
    check($e->event('s1', $row), 'Native event rejected: ' . $row['type']);
    if ($row['type'] === 'finished') {
        $finish = $row;
    }
}
$result = $e->match($m['id']);
check($result['state'] === 'finished', 'Journal did not settle match');
check((int) $result['team1_score'] === 22 && (int) $result['team2_score'] === 18, 'Journal score mismatch');
check($finish !== null && !$e->event('s1', $finish), 'Duplicate finish was applied');
check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Rating settlement was not exactly once');
check(
    !$e->db->all('SELECT * FROM mq2_ratings WHERE ladder_id<>? AND played>0', ['cs16-5v5']),
    'Rating crossed ladders'
);
$kills = $damage = $deaths = 0;
foreach ($e->db->all('SELECT stats FROM mq2_match_players WHERE match_id=?', [$m['id']]) as $p) {
    $stats = json_decode($p['stats'], true);
    $kills += $stats['kills'];
    $deaths += $stats['deaths'];
    $damage += $stats['damage'];
    check($stats['rounds'] === 40, 'Round participation lost');
}
check($kills === 200 && $deaths === 200 && $damage === 20000, 'Native statistics lost in backend');
$e->event('s1', [
    'event_id' => 'verified-idle',
    'match_id' => $m['id'],
    'generation' => (int) $m['generation'],
    'sequence' => ++$sequence,
    'type' => 'idle',
    'data' => []
]);
check(!$e->db->all('SELECT * FROM mq2_leases'), 'Confirmed cleanup did not release lease');
echo "PASS 52 native events -> CS 1.6 backend, 22:18, 200 kills/deaths, 20000 damage, exactly-once ELO, cleanup\n";
