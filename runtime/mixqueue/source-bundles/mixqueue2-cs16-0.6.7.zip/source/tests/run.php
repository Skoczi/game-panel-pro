<?php

declare(strict_types = 1);

require dirname(__DIR__) . '/bootstrap.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Matchmaker, Problem};
use Flute\Modules\MixQueue2\Infrastructure\{Store, Catalog};

$passed = 0;
function check(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function rejects(callable $fn, string $key): void
{
    try {
        $fn();
    } catch (Problem $e) {
        check($e->key === $key, "Expected $key, got {$e->key}");
        return;
    }
    throw new RuntimeException("Expected rejection: $key");
}

function fixture(int $players = 10): Engine
{
    $db = new Store(
        new PDO(
            getenv('MQ2_TEST_DSN') ?: 'sqlite::memory:',
            getenv('MQ2_TEST_USER') ?: null,
            getenv('MQ2_TEST_PASSWORD') ?: null
        )
    );
    if ($db->driver === 'mysql') {
        check(
            in_array(
                $db->one('SELECT DATABASE() AS db')['db'],
                ['mq2_test', 'mq2_test_audit_053', 'mq2_test_audit_060', 'mq2_test_audit_061', 'mq2_test_audit_062', 'mq2_test_audit_063'],
                true
            ),
            'Refusing to reset a non-test database'
        );
    }
    $db->migrate();
    if ($db->driver === 'mysql') {
        foreach ($db->all("SHOW TABLES LIKE 'mq2_%'") as $row) {
            $table = array_values($row)[0];
            if (!in_array($table, ['mq2_schema', 'mq2_mutex'], true)) {
                $db->run('DELETE FROM `' . $table . '`');
            }
        }
    }
    Catalog::install($db, true);
    $e = new Engine($db, fn() => 2000000000);
    for ($i = 1; $i <= $players; $i++) {
        $e->identify((string) $i, '765611980000000' . str_pad((string) $i, 2, '0', STR_PAD_LEFT), "Player $i");
        $e->heartbeat((string) $i);
    }
    $l = $e->ladder('csco-5v5');
    $db->run('INSERT INTO mq2_servers VALUES(?,?,?,?,?,?,?,0,?,?)', [
        's1',
        'Warsaw',
        'csco',
        '127.0.0.1:27015',
        'test',
        1,
        1,
        $e->now(),
        Engine::json(['modes' => ['5v5', '2v2'], 'maps' => $l['maps']])
    ]);
    $e->tick();
    return $e;
}

function cs16Status(): array
{
    return [
        'controller' => 'matchbot',
        'controller_version' => '0.6.4',
        'assignment_contract' => 3,
        'stats_version' => 2,
        'side_choice' => 1,
        'agent_protocol' => 2,
        'agent_version' => '0.6.1',
        'ruleset' => 2,
        'reconnect_budget' => 1,
        'pause_policy' => 2,
        'tactical_limit' => 3,
        'tactical_seconds' => 30,
        'ready_seconds' => 300,
        'player_ready' => true,
        'rules_ready' => true,
        'idle' => true,
        'matchid' => ''
    ];
}

function readyMatch(Engine $e, string $ladder = 'csco-5v5', int $players = 10, bool $legacy = false): array
{
    for ($i = 1; $i <= $players; $i++) {
        $e->join((string) $i, $ladder);
    }
    check($e->tick() === 1, 'Match not created');
    $id = $e->db->one('SELECT id FROM mq2_matches')['id'];
    if ($legacy) {
        $rules = json_decode($e->match($id)['rules'], true);
        unset($rules['veto_policy'], $rules['veto_first']);
        $e->db->run('UPDATE mq2_matches SET rules=? WHERE id=?', [Engine::json($rules), $id]);
    }
    for ($i = 1; $i <= $players; $i++) {
        $e->ready((string) $i, $id, true);
    }
    while (( $m = $e->match($id) )['state'] === 'veto') {
        $c = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1', [
            $id,
            Engine::vetoTeam($m)
        ]);
        $e->ban($c['user_id'], $id, json_decode($m['maps'], true)[0], (int) $m['version']);
    }
    if ($m['state'] === 'side_selection') {
        $r = json_decode($m['rules'], true);
        $c = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1', [
            $id,
            $r['side_chooser']
        ]);
        $e->chooseSide($c['user_id'], $id, 'ct', (int) $m['version']);
    }
    return $e->match($id);
}

function event(Engine $e, array $m, string $type, array $data = [], ?string $eventId = null): array
{
    if (
        isset(json_decode($e->match($m['id'])['rules'], true)['starting_ct_team'])
        && in_array($type, ['round', 'finished', 'surrendered', 'test_ended'], true)
        && !isset($data['players'])
    ) {
        $data['stats_version'] = 2;
        $data['players'] = [];
        foreach ($e->db->all('SELECT steam_id FROM mq2_match_players WHERE match_id=?', [$m['id']]) as $p)
            $data['players'][$p['steam_id']] = array_replace(
                array_fill_keys(\Flute\Modules\MixQueue2\Domain\Statistics::COUNTERS, 0),
                ['rounds' => ( $data['team1_score'] ?? 0 ) + ( $data['team2_score'] ?? 0 )]
            );
    }
    $v = [
        'event_id' => $eventId ?? Engine::id(),
        'match_id' => $m['id'],
        'generation' => (int) $m['generation'],
        'type' => $type,
        'data' => $data
    ];
    $e->event('s1', $v);
    return $v;
}

function live(Engine $e, array $m): void
{
    event($e, $m, 'loaded', ['map' => $m['picked_map'], 'config_hash' => $e->configuration($m['id'])['config_hash']]);
    foreach ($e->db->all('SELECT steam_id FROM mq2_match_players WHERE match_id=?', [$m['id']]) as $p) {
        event($e, $m, 'connected', ['steam_id' => $p['steam_id'], 'connected' => true]);
    }
    event($e, $m, 'live');
}

if (defined('MQ2_TEST_HELPERS_ONLY')) {
    return;
}
$tests = [
    'audit: 3,3,1,1,2 always forms 5v5 without splitting parties' => function () {
        $units = [];
        $n = 0;
        foreach ([3, 3, 1, 1, 2] as $i => $size) {
            $ps = [];
            for ($j = 0; $j < $size; $j++) {
                $ps[] = ['user_id' => (string) ++$n, 'ticket_id' => (string) $i, 'rating' => 1200 - ( $i * 10 )];
            }
            $units[] = ['id' => (string) $i, 'joined_at' => 0, 'players' => $ps];
        }
        $r = ( new Matchmaker() )->choose($units, 5, 100);
        check($r !== null, 'No valid split');
        check(count($r['teams'][1]) === 5 && count($r['teams'][2]) === 5, 'Unequal teams');
        check(
            !array_intersect(array_column($r['teams'][1], 'ticket_id'), array_column($r['teams'][2], 'ticket_id')),
            'Party split'
        );
    },
    'audit: non-contiguous 5,4,5 candidate selection' => function () {
        $u = [];
        foreach ([5, 4, 5] as $i => $size) {
            $p = [];
            for ($j = 0; $j < $size; $j++) {
                $p[] = ['user_id' => "$i-$j", 'rating' => 1000];
            }
            $u[] = ['id' => (string) $i, 'joined_at' => $i, 'players' => $p];
        }
        $r = ( new Matchmaker() )->choose($u, 5, 100);
        check(array_column($r['tickets'], 'id') === ['0', '2'], 'Skipped valid group');
    },
    'global claim prevents joining another game' => function () {
        $e = fixture();
        $e->join('1', 'csco-5v5');
        rejects(fn() => $e->join('1', 'csgo-5v5'), 'busy');
        check(count($e->db->all('SELECT * FROM mq2_tickets')) === 1, 'Rollback failed');
    },
    'party membership and leader authorization' => function () {
        $e = fixture();
        $id = $e->invite('1', '2');
        $e->acceptInvite('2', $id);
        rejects(fn() => $e->join('2', 'csco-5v5'), 'leader');
        $e->join('1', 'csco-5v5');
        $e->leaveParty('2');
        check(!$e->db->all('SELECT * FROM mq2_claims'), 'Party left dangling claim');
    },
    'full lifecycle settles once with zero-sum ELO' => function () {
        $e = fixture();
        $m = readyMatch($e);
        live($e, $m);
        $v = event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 12]);
        check($e->event('s1', $v) === false, 'Duplicate accepted twice');
        check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Ledger size');
        check(
            (int) $e->db->one('SELECT SUM(delta) AS total FROM mq2_rating_changes')['total'] === 0,
            'Rating inflation'
        );
        check(!$e->db->all('SELECT * FROM mq2_claims'), 'Claims held');
        check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Server released before idle');
        event($e, $m, 'idle');
        check(!$e->db->all('SELECT * FROM mq2_leases'), 'Server not released');
        check($e->event('s1', $v) === false, 'Replay after idle failed');
    },
    'forged assignment and wrong map rejected' => function () {
        $e = fixture();
        $m = readyMatch($e);
        rejects(fn() => $e->event('s1', [
            'event_id' => 'old',
            'match_id' => $m['id'],
            'generation' => 0,
            'type' => 'loaded',
            'data' => ['map' => $m['picked_map']]
        ]), 'lease');
        rejects(fn() => event($e, $m, 'loaded', ['map' => 'wrong']), 'map');
        check($e->match($m['id'])['state'] === 'preparing', 'Mutation on failed event');
    },
    'invalid final score rolls back all changes' => function () {
        $e = fixture();
        $m = readyMatch($e);
        live($e, $m);
        rejects(fn() => event($e, $m, 'finished', ['team1_score' => 12, 'team2_score' => 11]), 'final_score');
        check(!$e->db->all('SELECT * FROM mq2_settlements'), 'Invalid settlement');
        check((int) $e->match($m['id'])['team1_score'] === 0, 'Partial commit');
    },
    'overtime result settles' => function () {
        $e = fixture();
        $m = readyMatch($e);
        live($e, $m);
        event($e, $m, 'finished', ['team1_score' => 19, 'team2_score' => 17]);
        check($e->match($m['id'])['state'] === 'finished', 'Overtime rejected');
    },
    'abort supersedes undelivered load and keeps quarantine' => function () {
        $e = fixture();
        $m = readyMatch($e);
        $e->cancel($m['id'], 'admin', 'Testing cancellation');
        $commands = $e->commands('s1');
        check(array_column($commands, 'type') === ['abort'], 'Load escaped after cancel');
        check($e->db->one('SELECT state FROM mq2_leases')['state'] === 'quarantine', 'Lease lost');
    },
    'ready rejection requeues accepted players only' => function () {
        $e = fixture();
        for ($i = 1; $i <= 10; $i++) {
            $e->join((string) $i, 'csco-5v5');
        }
        $e->tick();
        $id = $e->db->one('SELECT id FROM mq2_matches')['id'];
        $e->ready('1', $id, true);
        $e->ready('2', $id, false);
        check(count($e->db->all('SELECT * FROM mq2_claims')) === 1, 'Wrong requeue');
        check(!$e->db->all('SELECT * FROM mq2_leases'), 'Ready reservation retained');
    },
    'agent rejects bad signatures and old timestamps' => function () {
        $e = fixture();
        $key = str_repeat('k', 32);
        $api = new Flute\Modules\MixQueue2\Http\AgentApi($e, ['s1' => $key]);
        $raw = Engine::json(['action' => 'poll', 'healthy' => true]);
        $t = (string) $e->now();
        rejects(fn() => $api->handle('s1', $t, 'fake', $raw), 'signature');
        $old = (string) ( $e->now() - 61 );
        $sig = hash_hmac('sha256', "s1\n$old\n$raw", $key);
        rejects(fn() => $api->handle('s1', $old, $sig, $raw), 'signature');
        check(
            isset($api->handle('s1', $t, hash_hmac('sha256', "s1\n$t\n$raw", $key), $raw)['commands']),
            'Valid HMAC rejected'
        );
    },
    'event sequence gaps and config mismatch rejected' => function () {
        $e = fixture();
        $m = readyMatch($e);
        $v = [
            'event_id' => 'seq-test',
            'match_id' => $m['id'],
            'generation' => (int) $m['generation'],
            'sequence' => 2,
            'type' => 'loaded',
            'data' => ['map' => $m['picked_map'], 'config_hash' => $e->configuration($m['id'])['config_hash']]
        ];
        rejects(fn() => $e->event('s1', $v), 'sequence');
        $v['sequence'] = 1;
        $v['data']['config_hash'] = 'wrong';
        rejects(fn() => $e->event('s1', $v), 'config');
        $v['data']['config_hash'] = $e->configuration($m['id'])['config_hash'];
        $e->event('s1', $v);
        check($e->event('s1', $v) === false, 'Sequence retry failed');
    },
    'unprivileged caller cannot cancel or toggle queues' => function () {
        $e = fixture();
        $app = new Flute\Modules\MixQueue2\Http\Application($e);
        rejects(fn() => $app->act('1', [
            'action' => 'cancel',
            'match' => 'x',
            'reason' => 'Abuse attempt'
        ]), 'forbidden');
        rejects(fn() => $app->act('1', ['action' => 'ladder_toggle', 'ladder' => 'csco-5v5']), 'forbidden');
    },
    'stats persist and absent metrics are not invented' => function () {
        $e = fixture();
        $m = readyMatch($e);
        live($e, $m);
        $steam = $e->player('1')['steam_id'];
        event($e, $m, 'finished', [
            'team1_score' => 16,
            'team2_score' => 8,
            'players' => [$steam => ['kills' => 23, 'deaths' => 14, 'damage' => 1840, 'rounds' => 24]]
        ]);
        $stats = json_decode(
            $e->db->one('SELECT stats FROM mq2_match_players WHERE user_id=? AND match_id=?', ['1', $m['id']])['stats'],
            true
        );
        check($stats['kills'] === 23 && !isset($stats['assists']), 'Stats lost or unavailable assists invented');
    },
    'veto stale version cannot apply another action' => function () {
        $e = fixture();
        for ($i = 1; $i <= 10; $i++) {
            $e->join((string) $i, 'csco-5v5');
        }
        $e->tick();
        $m = $e->db->one('SELECT * FROM mq2_matches');
        for ($i = 1; $i <= 10; $i++) {
            $e->ready((string) $i, $m['id'], true);
        }
        $m = $e->match($m['id']);
        $p = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=1 AND captain=1', [$m['id']]);
        $e->ban($p['user_id'], $m['id'], 'de_mirage', (int) $m['version']);
        rejects(fn() => $e->ban($p['user_id'], $m['id'], 'de_inferno', (int) $m['version']), 'stale');
        check(count($e->db->all('SELECT * FROM mq2_draft_actions')) === 1, 'Double veto committed');
    }
];
$tests['no-show penalizes only on a healthy server'] = function () {
    $e = fixture();
    $m = readyMatch($e);
    event($e, $m, 'loaded', ['map' => $m['picked_map'], 'config_hash' => $e->configuration($m['id'])['config_hash']]);
    $clock = $e->now() + 301;
    $later = new Engine($e->db, fn() => $clock);
    $later->serverHeartbeat('s1', true);
    $later->tick();
    check(
        count($e->db->all('SELECT * FROM mq2_penalties WHERE reason=?', ['no_show'])) === 10,
        'Missing no-show penalty'
    );
    check(!$e->db->all('SELECT * FROM mq2_rating_changes'), 'No-show changed ELO');
    $e = fixture();
    $m = readyMatch($e);
    event($e, $m, 'loaded', ['map' => $m['picked_map'], 'config_hash' => $e->configuration($m['id'])['config_hash']]);
    $later = new Engine($e->db, fn() => $clock);
    $later->tick();
    check(!$e->db->all('SELECT * FROM mq2_penalties'), 'Server outage penalized players');
};
$tests['lost controller identity quarantines the server'] = function () {
    $e = fixture();
    $m = readyMatch($e);
    live($e, $m);
    $key = str_repeat('k', 32);
    $api = new Flute\Modules\MixQueue2\Http\AgentApi($e, ['s1' => $key]);
    $raw = Engine::json(['action' => 'poll', 'healthy' => true, 'observation' => ['matchid' => '', 'idle' => true]]);
    $stamp = (string) $e->now();
    $api->handle('s1', $stamp, hash_hmac('sha256', "s1\n$stamp\n$raw", $key), $raw);
    check($e->db->one('SELECT state FROM mq2_leases')['state'] === 'quarantine', 'Lost identity was ignored');
    check(
        (int) $e->db->one('SELECT healthy FROM mq2_servers')['healthy'] === 0,
        'Quarantined server advertised healthy'
    );
    check(count($e->db->all('SELECT * FROM mq2_claims')) === 10, 'Players released into another match');
};
$tests['report resolution requires admin and preserves audit'] = function () {
    $e = fixture();
    $m = readyMatch($e);
    $e->report('1', $m['id'], 'Testowe zgÅ‚oszenie problemu');
    $id = $e->db->one('SELECT id FROM mq2_reports')['id'];
    $app = new Flute\Modules\MixQueue2\Http\Application($e);
    $input = ['action' => 'resolve_report', 'report' => $id, 'reason' => 'Zweryfikowano dziennik meczu.'];
    rejects(fn() => $app->act('1', $input, false), 'forbidden');
    $app->act('1', $input, true);
    check($e->db->one('SELECT state FROM mq2_reports')['state'] === 'resolved', 'Report not resolved');
    check($e->db->one('SELECT action FROM mq2_audit')['action'] === 'report.resolve', 'No moderation audit');
};
foreach (['csco', 'csgo', 'cs16'] as $game) {
    foreach (['5v5' => 10, '2v2' => 4] as $mode => $players) {
        $tests["$game $mode lifecycle keeps ratings isolated"] = function () use ($game, $mode, $players) {
            $e = fixture($players);
            $ladder = "$game-$mode";
            $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
                $game,
                Engine::json(['modes' => [$mode], 'maps' => $e->ladder($ladder)['maps']]),
                's1'
            ]);
            if ($game === 'cs16')
                $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
                    's1',
                    Engine::json([
                        ...cs16Status(),
                        'map_inventory' => [
                            'version' => 1,
                            'source' => 'bsp_v30',
                            'complete' => true,
                            'maps' => $e->ladder($ladder)['maps']
                        ]
                    ]),
                    $e->now()
                ]);
            $m = readyMatch($e, $ladder, $players);
            live($e, $m);
            event($e, $m, 'finished', ['team1_score' => $mode === '2v2' ? 9 : 16, 'team2_score' => 5]);
            check($e->match($m['id'])['state'] === 'finished', 'Match did not finish');
            check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === $players, 'Wrong settlement size');
            check(
                !$e->db->all('SELECT * FROM mq2_ratings WHERE ladder_id<>? AND played>0', [$ladder]),
                'Rating crossed ladders'
            );
            event($e, $m, 'idle');
            check(!$e->db->all('SELECT * FROM mq2_leases'), 'Lease leaked');
        };
    }
}
$tests['drain releases waiting claims without cancelling active matches'] = function () {
    $e = fixture(12);
    $m = readyMatch($e);
    $e->join('11', 'csco-5v5');
    $e->setLadderEnabled('csco-5v5', false, 'test');
    check(!$e->db->one('SELECT * FROM mq2_claims WHERE user_id=?', ['11']), 'Waiting claim remains');
    check($e->match($m['id'])['state'] === 'preparing', 'Active match cancelled');
    rejects(fn() => $e->join('12', 'csco-5v5'), 'disabled');
    live($e, $m);
    event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 7]);
    check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Drain prevented settlement');
};
$tests['ready timeout after drain does not requeue accepted users'] = function () {
    $e = fixture();
    for ($i = 1; $i <= 10; $i++)
        $e->join((string) $i, 'csco-5v5');
    $e->tick();
    $m = $e->db->one('SELECT * FROM mq2_matches');
    $e->ready('1', $m['id'], true);
    $e->setLadderEnabled('csco-5v5', false, 'test');
    $later = new Engine($e->db, fn() => $e->now() + 31);
    $later->tick();
    check(!$e->db->all('SELECT * FROM mq2_claims'), 'Ready timeout recreated claims after drain');
};
$tests['server registry validates configuration and rejects duplicate IDs'] = function () {
    $e = fixture();
    $registry = new \Flute\Modules\MixQueue2\Domain\ServerRegistry($e);
    $server = [
        'id' => 'panel-test',
        'name' => 'Panel test',
        'game' => 'csgo',
        'address' => 'game.example:27015',
        'create' => true,
        'capabilities' => ['maps' => ['de_dust2'], 'modes' => ['5v5']]
    ];
    $registry->save($server, '1');
    $row = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['panel-test']);
    check(
        !(int) $row['enabled'] && !(int) $row['healthy'] && $row['adapter'] === 'get5',
        'New server must remain disabled and unverified'
    );
    rejects(fn() => $registry->save($server, '1'), 'server_exists');
    rejects(fn() => $registry->save([...$server, 'id' => '../escape'], '1'), 'server_id');
    rejects(fn() => $registry->save([...$server, 'address' => 'http://localhost:80/path'], '1'), 'server_address');
    rejects(fn() => $registry->save([
        ...$server,
        'capabilities' => ['maps' => ['de_dust2;quit'], 'modes' => ['5v5']]
    ], '1'), 'server_maps');
    rejects(fn() => $registry->setEnabled('panel-test', true, '1'), 'server_offline');
    $e->serverHeartbeat('panel-test', true);
    rejects(fn() => $registry->setEnabled('panel-test', true, '1'), 'server_pool');
};
$tests['server update requires current revision and fresh health before enabling'] = function () {
    $e = fixture();
    $registry = new \Flute\Modules\MixQueue2\Domain\ServerRegistry($e);
    $row = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']);
    $input = [
        'id' => 's1',
        'name' => 'Updated',
        'game' => 'csco',
        'address' => 'host.example:27016',
        'capabilities' => json_decode($row['capabilities'], true),
        'revision' => \Flute\Modules\MixQueue2\Domain\ServerRegistry::revision($row)
    ];
    $registry->save($input, '1');
    rejects(fn() => $registry->save($input, '1'), 'server_changed');
    rejects(fn() => $registry->setEnabled('s1', true, '1'), 'server_offline');
    $e->serverHeartbeat('s1', true);
    $registry->setEnabled('s1', true, '1');
    check(
        (int) $e->db->one('SELECT enabled FROM mq2_servers WHERE id=?', ['s1'])['enabled'] === 1,
        'Valid server failed enable'
    );
};
$tests['server disable preserves active match and rejects reconfiguration'] = function () {
    $e = fixture();
    for ($i = 1; $i <= 10; $i++)
        $e->join((string) $i, 'csco-5v5');
    $e->tick();
    $registry = new \Flute\Modules\MixQueue2\Domain\ServerRegistry($e);
    $row = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']);
    rejects(fn() => $registry->save([
        'id' => 's1',
        'name' => 'Busy',
        'game' => 'csco',
        'address' => 'host:27015',
        'capabilities' => json_decode($row['capabilities'], true),
        'revision' => \Flute\Modules\MixQueue2\Domain\ServerRegistry::revision($row)
    ], '1'), 'server_busy');
    $registry->setEnabled('s1', false, '1');
    check(count($e->db->all('SELECT * FROM mq2_leases')) === 1, 'Disable released active lease');
    check(count($e->db->all('SELECT * FROM mq2_claims')) === 10, 'Disable released active players');
};
$tests['private enrollment key authenticates only its registered agent'] = function () {
    $e = fixture();
    $dir = sys_get_temp_dir() . '/mq2-keys-' . bin2hex(random_bytes(6));
    mkdir($dir, 0700);
    try {
        $settings = ['server_keys_dir' => $dir];
        $key = \Flute\Modules\MixQueue2\Infrastructure\ServerKeys::provision($settings, 's1');
        check(strlen($key) === 64, 'Key entropy/encoding missing');
        check(
            $key === \Flute\Modules\MixQueue2\Infrastructure\ServerKeys::provision($settings, 's1'),
            'Repeat export unexpectedly rotated key'
        );
        rejects(fn() => \Flute\Modules\MixQueue2\Infrastructure\ServerKeys::get($settings, '../s1'), 'server_id');
        $api = new \Flute\Modules\MixQueue2\Http\AgentApi($e, ['s1' => $key]);
        $raw = json_encode(['action' => 'poll', 'healthy' => true, 'observation' => ['idle' => true]]);
        $time = (string) $e->now();
        $sig = hash_hmac('sha256', "s1\n$time\n$raw", $key);
        $api->handle('s1', $time, $sig, $raw);
        rejects(fn() => $api->handle('s2', $time, $sig, $raw), 'signature');
        rejects(fn() => $api->handle('s1', $time, $sig, $raw . ' '), 'signature');
    } finally {
        if (is_file($dir . '/s1.key'))
            unlink($dir . '/s1.key');
        rmdir($dir);
    }
};
$tests['removal rejects stale revision and active or quarantined lease'] = function () {
    $e = fixture();
    $registry = new \Flute\Modules\MixQueue2\Domain\ServerRegistry($e);
    $row = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']);
    $revision = $registry::revision($row);
    rejects(fn() => $registry->remove('s1', '', '1'), 'server_changed');
    $m = readyMatch($e);
    rejects(fn() => $registry->remove('s1', $revision, '1'), 'server_busy');
    $e->db->run('UPDATE mq2_leases SET state=? WHERE server_id=?', ['quarantine', 's1']);
    rejects(fn() => $registry->remove('s1', $revision, '1'), 'server_busy');
    check(!$e->db->all('SELECT * FROM mq2_server_archives'), 'Rejected removal archived server');
    check((bool) $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']), 'Active server disappeared');
};
$tests['removal preserves completed matches and denies old agents and ID reuse'] = function () {
    $e = fixture();
    $registry = new \Flute\Modules\MixQueue2\Domain\ServerRegistry($e);
    $m = readyMatch($e);
    live($e, $m);
    event($e, $m, 'finished', ['team1_score' => 16, 'team2_score' => 5]);
    event($e, $m, 'idle');
    $row = $e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']);
    $registry->remove('s1', $registry::revision($row), '1');
    check(!$e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']), 'Removed server still active');
    $archive = $e->db->one('SELECT * FROM mq2_server_archives WHERE id=?', ['s1']);
    check(
        json_decode($archive['configuration'], true) === $row && $archive['actor'] === '1',
        'Recovery archive incorrect'
    );
    check($e->match($m['id'])['state'] === 'finished', 'Match history lost');
    check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Rating history lost');
    rejects(fn() => $registry->remove('s1', $registry::revision($row), '1'), 'server_missing');
    rejects(fn() => $registry->save([
        'id' => 's1',
        'name' => 'Replacement',
        'game' => 'csco',
        'address' => 'host:27015',
        'create' => true,
        'capabilities' => json_decode($row['capabilities'], true)
    ], '1'), 'server_retired');
    $key = str_repeat('k', 64);
    $api = new \Flute\Modules\MixQueue2\Http\AgentApi($e, ['s1' => $key]);
    $raw = json_encode(['action' => 'poll', 'healthy' => true, 'observation' => ['idle' => true]]);
    $time = (string) $e->now();
    rejects(fn() => $api->handle('s1', $time, hash_hmac('sha256', "s1\n$time\n$raw", $key), $raw), 'server');
    check(!$e->db->one('SELECT * FROM mq2_servers WHERE id=?', ['s1']), 'Agent resurrected server');
};
foreach ($tests as $name => $test) {
    try {
        $test();
        $passed++;
        echo "PASS $name\n";
    } catch (Throwable $e) {
        fwrite(STDERR, "FAIL $name: {$e->getMessage()}\n{$e->getTraceAsString()}\n");
        exit(1);
    }
}
echo "$passed tests passed\n";
