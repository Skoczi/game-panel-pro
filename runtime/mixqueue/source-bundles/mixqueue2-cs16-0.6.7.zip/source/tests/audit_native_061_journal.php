<?php

declare(strict_types = 1);

// Actual isolated GameDLL journals; only assignment identity and clock are rebound.
define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';
use Flute\Modules\MixQueue2\Domain\Engine;

foreach (['tactical', 'disconnect', 'ready-test', 'ready-ranked'] as $case) {
    $source = json_decode(
        file_get_contents(dirname(__DIR__) . '/var/acceptance-061/feedback-061-' . $case . '.json'),
        true,
        512,
        JSON_THROW_ON_ERROR
    );
    $full = in_array($case, ['tactical', 'ready-test'], true);
    $size = $full ? 5 : 2;
    if ($full) {
        [$e, $t, $id] = fullFixture(2);
        $m = startFull($e, $t, $id, 2, false);
    } else {
        $e = fixture(4);
        $maps = $e->ladder('cs16-2v2')['maps'];
        $e->db->run('UPDATE mq2_servers SET game=?,capabilities=?', [
            'cs16',
            Engine::json(['modes' => ['2v2'], 'maps' => $maps])
        ]);
        $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
            's1',
            Engine::json(
                cs16Status()
                + ['map_inventory' => ['version' => 1, 'complete' => true, 'source' => 'bsp_v30', 'maps' => $maps]]
            ),
            $e->now()
        ]);
        $m = readyMatch($e, 'cs16-2v2', 4);
    }
    $roster = $e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,captain DESC,user_id', [
        $m['id']
    ]);
    $map = [];
    for ($i = 0; $i < ( $size * 2 ); $i++) {
        $team = $i < $size ? 1 : 2;
        $bot = $full && !in_array($i, [0, $size], true);
        $identity = $bot
            ? 'bot:'
            . substr(
                hash('sha256', $source['match_id'] . ':' . $source['generation'] . ':' . $team . ':' . ( $i + 1 )),
                0,
                24
            )
            : (string) ( 76561198000000000 + $i );
        $map[$identity] = $roster[$i]['steam_id'];
    }
    $sequence = 0;
    $dates = [];
    foreach ($source['events'] as $row) {
        if ($row['type'] === 'not_ready')
            $e = new Engine($e->db, fn() => 2000000300);
        $e->serverHeartbeat('s1', true);
        $ob = cs16Status() + ['full_test' => true];
        $ob['matchid'] = $m['id'] . ':' . $m['generation'];
        $ob['phase'] = $row['type'] === 'not_ready' ? 'warmup' : 'live';
        $ob['idle'] = false;
        $e->db->run('UPDATE mq2_observations SET payload=?,observed_at=? WHERE server_id=?', [
            Engine::json($ob),
            $e->now(),
            's1'
        ]);
        $row['match_id'] = $m['id'];
        $row['generation'] = (int) $m['generation'];
        $row['sequence'] = ++$sequence;
        if ($row['type'] === 'loaded')
            $row['data'] = [
                'map' => $m['picked_map'],
                'config_hash' => $e->configuration($m['id'])['config_hash'],
                'ready_deadline' => $e->now() + 300
            ];
        if (isset($row['data']['steam_id']))
            $row['data']['steam_id'] = $map[$row['data']['steam_id']];
        if (isset($row['data']['missing']))
            $row['data']['missing'] = array_map(fn($id) => $map[$id], $row['data']['missing']);
        if (isset($row['data']['players'])) {
            $stats = [];
            foreach ($row['data']['players'] as $steam => $data)
                $stats[$map[$steam]] = $data;
            $row['data']['players'] = $stats;
        }
        if (isset($row['data']['occurred_at']))
            $row['data']['occurred_at'] = $e->now();
        if (isset($row['data']['deadline']))
            $row['data']['deadline'] =
                $dates[$row['data']['deadline']] ??= $e->now() + ( $row['data']['seconds'] ?? 30 );
        check($e->event('s1', $row), $case . ': rejected ' . $row['type']);
        check(!$e->event('s1', $row), $case . ': replay duplicated ' . $row['type']);
    }
    $penalties = count($e->db->all('SELECT * FROM mq2_penalties'));
    check($penalties === ( $case === 'ready-ranked' ? 1 : 0 ), 'Wrong native readiness penalty');
    check(!$e->db->all('SELECT * FROM mq2_rating_changes'), 'Unfinished/cancelled journal changed ELO');
    if (str_starts_with($case, 'ready-'))
        check($e->match($m['id'])['state'] === 'cancelled', 'Native ready deadline did not cancel');
    else
        $e->cancel($m['id'], 'test', 'server_error');
    event($e, $m, 'idle');
    check(!$e->db->all('SELECT * FROM mq2_leases'), 'Idle did not release');
    echo
        "PASS native 0.6.1 $case journal: $sequence ordered events, readiness/pause transitions, duplicate rejection, penalties, idle release\n"
    ;
}
