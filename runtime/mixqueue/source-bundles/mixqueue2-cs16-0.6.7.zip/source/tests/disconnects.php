<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Statistics};
use Flute\Modules\MixQueue2\Http\Application;

$e = fixture();
$e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
    'cs16',
    Engine::json(['modes' => ['5v5'], 'maps' => $e->ladder('cs16-5v5')['maps']]),
    's1'
]);
$e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
    's1',
    Engine::json([
        ...cs16Status(),
        'map_inventory' => [
            'version' => 1,
            'source' => 'bsp_v30',
            'complete' => true,
            'maps' => $e->ladder('cs16-5v5')['maps']
        ]
    ]),
    $e->now()
]);
$m = readyMatch($e, 'cs16-5v5', 10, true);
live($e, $m);
$teams = [1 => [], 2 => []];
foreach ($e->db->all('SELECT * FROM mq2_match_players WHERE match_id=? ORDER BY user_id', [$m['id']]) as $p)
    $teams[(int) $p['team']][] = $p;
$leaver = $teams[1][0];
$steam = $leaver['steam_id'];
event($e, $m, 'round', ['team1_score' => 8, 'team2_score' => 2]);
event($e, $m, 'connected', ['steam_id' => $steam, 'connected' => false]);
rejects(fn() => event($e, $m, 'abandoned', ['steam_id' => $steam, 'cooldown_seconds' => 1800]), 'disconnect_state');
event($e, $m, 'reconnect_window', [
    'steam_id' => $steam,
    'stage' => 'pause',
    'seconds' => 90,
    'deadline' => $e->now() + 90
]);
event($e, $m, 'pause');
event($e, $m, 'connected', ['steam_id' => $steam, 'connected' => true]);
check(!$e->db->all('SELECT * FROM mq2_disconnects'), 'Return did not cancel reconnect window');
check(!$e->db->all('SELECT * FROM mq2_penalties'), 'Return was penalized');
event($e, $m, 'connected', ['steam_id' => $steam, 'connected' => false]);
event($e, $m, 'reconnect_window', [
    'steam_id' => $steam,
    'stage' => 'grace',
    'seconds' => 180,
    'deadline' => $e->now() + 180
]);
event($e, $m, 'resume');
$a = event($e, $m, 'abandoned', ['steam_id' => $steam, 'cooldown_seconds' => 1800]);
check($e->event('s1', $a) === false, 'Abandon event replay changed state');
event($e, $m, 'abandoned', ['steam_id' => $steam, 'cooldown_seconds' => 1800]);
$penalties = $e->db->all('SELECT * FROM mq2_penalties');
check(
    count($penalties) === 1 && (int) $penalties[0]['expires_at'] === ( $e->now() + 1800 ),
    'Penalty duplicated or wrong duration'
);
$votes = array_column(array_slice($teams[1], 1), 'steam_id');
$body = [
    'team1_score' => 8,
    'team2_score' => 2,
    'loser_team' => 1,
    'yes_votes' => array_slice($votes, 0, 2),
    'players' => []
];
rejects(fn() => event($e, $m, 'surrendered', $body), 'surrender_majority');
rejects(fn() => event($e, $m, 'surrendered', array_replace($body, ['yes_votes' => [
    $votes[0],
    $votes[0],
    $votes[1]
]])), 'surrender_vote');
rejects(fn() => event($e, $m, 'surrendered', array_replace($body, ['yes_votes' => [
    $votes[0],
    $votes[1],
    $teams[2][0]['steam_id']
]])), 'surrender_vote');
check(!$e->db->all('SELECT * FROM mq2_settlements'), 'Rejected vote settled match');
// Late return keeps the cooldown but removes the short-handed surrender condition.
event($e, $m, 'connected', ['steam_id' => $steam, 'connected' => true]);
rejects(fn() => event($e, $m, 'surrendered', array_replace($body, ['yes_votes' => array_slice(
    $votes,
    0,
    3
)])), 'surrender_majority');
event($e, $m, 'connected', ['steam_id' => $steam, 'connected' => false]);
$final = event($e, $m, 'surrendered', array_replace($body, ['yes_votes' => array_slice($votes, 0, 3)]));
check($e->event('s1', $final) === false, 'Surrender replay changed ratings');
event($e, $m, 'surrendered', array_replace($body, ['yes_votes' => array_slice($votes, 0, 3)]));
check(count($e->db->all('SELECT * FROM mq2_settlements')) === 1, 'Duplicate settlement');
check(count($e->db->all('SELECT * FROM mq2_rating_changes')) === 10, 'Wrong rating change count');
check((int) $e->db->one('SELECT SUM(delta) AS n FROM mq2_rating_changes')['n'] === 0, 'ELO not zero sum');
check((int) $e->db->one('SELECT winner FROM mq2_match_results')['winner'] === 2, 'Wrong winner');
check((int) $e->match($m['id'])['team1_score'] === 8, 'Surrender invented rounds');
foreach ($teams[1] as $p) {
    $profile = ( new Statistics($e) )->profile($p['user_id'], 'cs16-5v5');
    check(
        $profile['overall']['losses'] === 1 && $profile['overall']['wins'] === 0,
        'Leading surrender team marked winner'
    );
}
$state = ( new Application($e) )->state($leaver['user_id'], 'cs16-5v5', $m['id']);
check(
    (int) $state['history'][0]['winner'] === 2 && $state['match']['result']['reason'] === 'surrender',
    'Public result missing'
);
rejects(fn() => $e->join($leaver['user_id'], 'csgo-5v5'), 'penalty');
$e->join($teams[1][1]['user_id'], 'csgo-5v5');
check(count($e->db->all('SELECT * FROM mq2_penalties')) === 1, 'Teammates penalized');
echo
    "PASS reconnect cancellation, exact 30-minute cooldown, replay idempotency, late return, majority 3/4, foreign/duplicate votes, surrender 8:2 loss, ELO once, native profile and queue enforcement\n"
;
