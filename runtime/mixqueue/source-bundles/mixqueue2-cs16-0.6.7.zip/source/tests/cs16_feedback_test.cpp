#include "../games/cs16/matchbot/MatchBot/MatchCSCOFeedback.h"
#include <cassert>
#include <iostream>
#include <limits>
using namespace mq2;
int main() {
    PauseConsent p;
    assert(p.vote("match:1",1,true)==Consent::no_pause);
    assert(!p.request("",1) && !p.request("match:1",3));
    for(int first:{1,2}) {
        assert(p.request("match:1",first));
        assert(!p.request("match:1",3-first));
        assert(p.vote("match:1",first,true)==Consent::no_pause);
        p.start();
        assert(p.vote("match:1",first,false)==Consent::denied && p.votes==0);
        assert(p.vote("match:2",first,true)==Consent::no_pause && p.votes==0);
        assert(p.vote("match:1",first,true)==Consent::waiting);
        const auto serial=p.serial; // Reconnect keeps the same signed team/consent.
        assert(p.vote("match:1",first,true)==Consent::duplicate && p.serial==serial);
        assert(p.vote("match:1",3-first,true)==Consent::ready && p.votes==3);
        p.reset();assert(!p.running && !p.pending && p.votes==0 && p.serial!=serial);
    }
    p.request("old:1",1);p.start();p.vote("old:1",1,true);p.reset();
    p.request("new:2",2);p.start();assert(p.votes==0 && p.vote("old:1",2,true)==Consent::no_pause);
    assert(hp_loss(100,75)==25 && hp_loss(25,-200)==25 && hp_loss(-1,-10)==0);
    assert(hp_loss(20,25)==0 && hp_loss(100,std::numeric_limits<float>::infinity())==0);
    assert(display_damage(hp_loss(100,83.25))==17);
    DamageLedger l;l.begin("match:1");const auto token=l.current.serial;
    for(int i=1;i<=4;++i) {l.current.identity[i]="steam"+std::to_string(i);l.current.name[i]="Neo"+std::to_string(i);l.current.team[i]=i==1 || i==4?1:2;}
    l.current.locale[1]="pl";l.current.locale[2]="en";
    l.add(token,1,2,20);l.add(token,1,2,30);l.add(token,2,1,27);l.add(token,1,3,84);
    l.add(token,4,1,5);l.add(token,0,1,10);l.add(token,1,1,5);
    assert(!l.available && !l.seal());
    l.end();l.end(); // Nested RoundEnd precedes the lethal TakeDamage return.
    assert(l.add(token,1,2,hp_loss(50,-300)));assert(l.seal() && !l.seal());
    assert(!l.add(token,1,2,999));
    const auto lines=damage_lines(l.completed,1);
    assert(lines.size()==4 && lines[0]=="vs Neo2 | Zadane: 100 (3 trafienia) | Otrzymane: 27 (1 trafienie)");
    assert(lines[1].find("84 (1 trafienie)")!=std::string::npos);
    assert(lines[2].find("[DRUZYNA]")!=std::string::npos);
    assert(lines[3]=="Swiat / C4 / sam | Otrzymane: 15 (2 trafienia)");
    assert(damage_lines(l.completed,2)[0]=="vs Neo1 | Dealt: 27 (1 hit) | Taken: 100 (3 hits)");
    const auto snapshot=l.completed;
    l.begin("match:1");assert(!l.add(token,1,2,100));assert(l.completed.damage==snapshot.damage);
    l.current.identity[1]="replacement";l.end();l.seal();
    assert(damage_lines(l.completed,1)==std::vector<std::string>{"No damage this round."});
    l.reset();assert(!l.available && !l.pending && !l.add(token,1,2,50));
    for(int hits:{0,1,2,4,5,11,12,14,21,22,112}) {
        const std::string suffix=hits==1?"trafienie":hits==2 || hits==4 || hits==22?"trafienia":"trafien";
        assert(hits_text(hits,true)==std::to_string(hits)+" "+suffix);
    }
    assert(wire_text("Neo^4\n%s") == "Neo 4 %s");
    assert(wire_text("ab\xC4\x85",3)=="ab");
    std::cout<<"PASS captain consent scope/orders/duplicates/reset; measured HP; final-hit snapshot; identity epoch; dealt/taken/world/team; PL/EN; safe text\n";
}
