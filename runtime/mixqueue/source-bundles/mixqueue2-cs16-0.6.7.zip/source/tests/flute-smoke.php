<?php

declare(strict_types = 1);

require dirname(__DIR__) . '/bootstrap.php';
require getenv('FLUTE_AUTOLOAD');
$classes = [
    Flute\Modules\MixQueue2\Providers\MixQueue2Provider::class,
    Flute\Modules\MixQueue2\Http\Controllers\PlayController::class
];
foreach ($classes as $class) {
    if (!class_exists($class)) {
        throw new RuntimeException($class . ' failed to load');
    }
    echo 'PASS Flute class ' . $class . "\n";
}
$routes = 0;
foreach (( new ReflectionClass($classes[1]) )->getMethods() as $method) {
    foreach ($method->getAttributes() as $attribute) {
        $instance = $attribute->newInstance();
        if ($instance instanceof Flute\Core\Router\Annotations\Route) {
            $routes++;
        }
    }
}
if ($routes !== 3) {
    throw new RuntimeException('Unexpected route count');
}
echo "PASS three Flute route attributes\n";
$container = new DI\Container();
( new $classes[0]() )->register($container);
echo "PASS Flute container registration without database or schema writes\n";
