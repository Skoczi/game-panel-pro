"""Guard regressions without loading a game server or changing release files."""
import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location('version_guard', ROOT / 'bin/check-matchbot-version.py')
GUARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUARD)


class ControllerVersionGuard(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        source = ROOT / 'games/cs16/matchbot/MatchBot'
        for filename in ('MatchVersion.h', 'MetaMod.cpp', 'MatchCSCO.cpp'):
            (self.directory / filename).write_bytes((source / filename).read_bytes())

    def replace(self, filename, before, after):
        path = self.directory / filename
        text = path.read_text(encoding='utf-8')
        self.assertIn(before, text)
        path.write_text(text.replace(before, after), encoding='utf-8')

    def test_current_sources_share_version(self):
        self.assertRegex(GUARD.check_sources(self.directory), '^' + GUARD.SEMVER + '$')

    def test_old_metamod_literal_is_rejected(self):
        self.replace('MetaMod.cpp', 'CSCO_CONTROLLER_VERSION,', '"0.5.2",')
        with self.assertRaisesRegex(ValueError, 'Plugin_info.version'):
            GUARD.check_sources(self.directory)

    def test_independent_status_literal_is_rejected(self):
        self.replace('MatchCSCO.cpp', '+CSCO_CONTROLLER_VERSION+', '+"0.5.2"+')
        with self.assertRaisesRegex(ValueError, 'Status controller_version'):
            GUARD.check_sources(self.directory)

    def test_stale_release_expectation_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'does not match expected'):
            GUARD.check_sources(self.directory, '999.999.999')

    def test_future_shared_bump_needs_no_consumer_edits(self):
        path = self.directory / 'MatchVersion.h'
        path.write_text('#pragma once\n#define CSCO_CONTROLLER_VERSION "9.8.7"\n', encoding='utf-8')
        self.assertEqual('9.8.7', GUARD.check_sources(self.directory, '9.8.7'))

    def test_local_override_is_rejected(self):
        self.replace('MetaMod.cpp', '#include "MatchVersion.h"',
                     '#include "MatchVersion.h"\n#undef CSCO_CONTROLLER_VERSION\n'
                     '#define CSCO_CONTROLLER_VERSION "0.5.2"')
        with self.assertRaisesRegex(ValueError, 'must not override'):
            GUARD.check_sources(self.directory)

    def test_duplicate_header_definition_is_rejected(self):
        path = self.directory / 'MatchVersion.h'
        path.write_text(path.read_text(encoding='utf-8') + '\n#define CSCO_CONTROLLER_VERSION "0.5.2"\n',
                        encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'exactly one'):
            GUARD.check_sources(self.directory)


if __name__ == '__main__':
    unittest.main()
