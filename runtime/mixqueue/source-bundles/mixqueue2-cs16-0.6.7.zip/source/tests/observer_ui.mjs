import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

// Execute the shipped connection/refresh policy with real failure responses.
const source = readFileSync(new URL('../module/Resources/assets/mixqueue.js', import.meta.url), 'utf8');
const helpers = source.slice(source.indexOf('    function discardAuthorizedState'), source.indexOf('    async function request'));
const refresh = source.slice(source.indexOf('    async function refresh('), source.indexOf('    function openDialog('));
assert.ok(helpers.length > 100 && refresh.length > 500);
const observer = () => ({match: {id: 'private-test', address: '127.0.0.1:27015', observer: {state: 'ready', admission_until: 300}}, system_test: false});
function boot() {
  let removed = 0, rendered = 0;
  const root = {innerHTML: 'private-match steam://connect/127.0.0.1:27015', setAttribute() {}, querySelectorAll: () => [{remove() {removed++;}}]};
  const context = vm.createContext({root, state: observer(), readyDialog: null,
    esc: String, button: () => '<button>Retry</button>', seconds: value => Math.max(0, Number(value) - 200),
    render: () => {rendered++;}, notify() {}, busy: false, refreshAgain: false,
    game: 'cs16', mode: '5v5', selectedMatch: 'private-test', selectedRound: null, testHistory: false,
    config: {api: '/api'}, location: {href: 'http://localhost/play'}, URL, AbortSignal,
    historicalRound: () => null, Date,
  });
  vm.runInContext(helpers + refresh, context);
  return {context, root, removed: () => removed, rendered: () => rendered};
}

let h = boot();
assert.equal(h.context.expireObserverAdmission(), false);
assert.equal(h.context.state.match.address, '127.0.0.1:27015');
h.context.state.match.observer.admission_until = 199;
assert.equal(h.context.expireObserverAdmission(), true);
assert.equal(h.context.state.match.address, null);
assert.equal(h.removed(), 1, 'Controls removed even while rendering could be blocked by a modal');
assert.equal(h.context.state.match.observer.state, 'pending');
h = boot();
h.context.state.match.observer = null;
assert.equal(h.context.dropObserverConnection(), false, 'Player connection is not an observer lease');

for (const status of [401, 403]) {
  h = boot();
  h.context.fetch = async () => ({status, ok: false, json: async () => ({message: 'Access revoked'})});
  await h.context.refresh();
  assert.equal(h.context.state, null, 'Authorization failure keeps no previous private match state');
  assert.ok(!h.root.innerHTML.includes('steam://') && !h.root.innerHTML.includes('private-match'));
  assert.ok(h.root.innerHTML.includes('Access revoked'));
}
h = boot();
h.context.fetch = async () => ({status: 403, ok: false, json: async () => {throw new Error('HTML response');}});
await h.context.refresh();
assert.equal(h.context.state, null, 'Non-JSON 403 still discards authorized state');
assert.ok(!h.root.innerHTML.includes('private-match'));
h = boot();
h.context.fetch = async () => {throw new Error('Network unavailable');};
await h.context.refresh();
assert.equal(h.context.state.match.address, null);
assert.equal(h.context.state.match.observer.admission_until, 0);
assert.equal(h.removed(), 1);
assert.equal(h.rendered(), 1);
console.log('PASS observer UI: native lease expiry, unchanged player path, 401/403 private state discard, transport failure connection removal');
