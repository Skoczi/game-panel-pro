<?php

// Shared policy regression for full test timeouts and delayed agent delivery.
define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';
use Flute\Modules\MixQueue2\Domain\{Engine, TestMatches};

function advance(Engine $e, int $seconds, bool $healthy = true): Engine
{
    $at = $e->now() + $seconds;
    if ($healthy) {
        $e->db->run('UPDATE mq2_servers SET seen_at=?', [$at]);
        $e->db->run('UPDATE mq2_observations SET observed_at=?', [$at]);
    }
    return new Engine($e->db, fn() => $at);
}

foreach (['lobby', 'ready', 'veto', 'preparing', 'connecting', 'live'] as $phase) {
    [$e, $t, $id] = fullFixture(2);
    if (in_array($phase, ['ready', 'veto']))
        $t->start($id, '1');
    if ($phase === 'veto') {
        $e->ready('1', $id, true);
        $e->ready('2', $id, true);
    }
    if (in_array($phase, ['preparing', 'connecting', 'live'])) {
        $m = startFull($e, $t, $id, 2, $phase === 'live');
        if ($phase === 'connecting')
            event($e, $m, 'loaded', [
                'map' => $m['picked_map'],
                'config_hash' => $e->configuration($id)['config_hash']
            ]);
    }
    check($e->match($id)['state'] === $phase, 'Wrong phase fixture');
    $t->stop($id, '1');
    if (in_array($phase, ['lobby', 'ready', 'veto'])) {
        check(
            $e->match($id)['state'] === 'cancelled' && !$e->db->all('SELECT * FROM mq2_leases'),
            'Reserved lease not freed'
        );
    } else {
        check(
            $e->match($id)['state'] === 'stopping' && !!$e->db->all('SELECT * FROM mq2_leases'),
            'Active lease freed before idle'
        );
        $later = advance($e, 61);
        $later->tick();
        check(
            $later->match($id)['state'] === 'finished' && !!$e->db->all('SELECT * FROM mq2_leases'),
            'Fallback lost cleanup lease'
        );
        rejects(fn() => $t->remove([$id], '1', 1), 'test_active');
        event($later, $m, 'idle');
        // Plugin journal can lag behind cleanup. Drain safely before deletion as well.
        event($later, $m, 'connected', ['steam_id' => $e->player('1')['steam_id'], 'connected' => false]);
    }
    $t->remove([$id], '1', 1);
    check(
        !$e->db->all('SELECT * FROM mq2_ratings') && !$e->db->all('SELECT * FROM mq2_penalties'),
        'Cancellation penalized test'
    );
}
echo "PASS cancellation in all 6 phases; agent loss fallback, lease waits for idle, late journal drains\n";
[$e, $t, $id] = fullFixture(1);
$t->start($id, '1');
advance($e, 31)->tick();
check(
    $e->match($id)['state'] === 'cancelled'
    && !$e->db->all('SELECT * FROM mq2_claims')
    && !$e->db->all('SELECT * FROM mq2_penalties'),
    'Ready timeout'
);
[$e, $t, $id] = fullFixture(1);
$t->start($id, '1');
$e->ready('1', $id, true);
while ($e->match($id)['state'] === 'veto') {
    $e = advance($e, 31);
    $e->tick();
}
check($e->match($id)['state'] === 'preparing', 'Veto timeout did not progress');
$e = advance($e, 301);
$e->tick();
check(
    $e->match($id)['state'] === 'cancelled' && !!$e->db->all('SELECT * FROM mq2_leases'),
    'Prepare timeout released lease early'
);
echo "PASS ready, veto, preparation timeouts without penalties\n";
[$e, $t, $id] = fullFixture(1);
$m = startFull($e, $t, $id, 1);
$later = advance($e, 61, false);
$later->tick();
check($e->match($id)['state'] === 'stopping', 'Agent loss not detected');
[$e, $t, $id] = fullFixture(1);
$t->stop($id, '1');
$a = $id;
$id = $t->create('1', 's1');
rejects(fn() => $t->remove([$a, $id], '1', 2), 'test_active');
check(!!$t->find($a), 'Bulk delete was not atomic');
$t->stop($id, '1');
$t->remove([$a, $id], '1', 2);
$ev = ['event_id' => Engine::id(), 'match_id' => $a, 'generation' => 1, 'type' => 'idle', 'data' => []];
check(!$e->event('s1', $ev), 'Deleted retry');
$ev['generation'] = 2;
rejects(fn() => $e->event('s1', $ev), 'lease');
$e->db->run('UPDATE mq2_observations SET payload=?', [Engine::json([
    'idle' => true,
    'full_test' => true,
    'assignment_contract' => 2,
    'agent_protocol' => 2,
    'controller' => 'matchbot',
    'controller_version' => '0.4.1',
    'agent_version' => '0.5.0'
])]);
rejects(fn() => $t->create('1', 's1'), 'test_version');
echo "PASS offline detection, atomic bulk deletion, foreign generation rejection and minimum-version gate\n";
