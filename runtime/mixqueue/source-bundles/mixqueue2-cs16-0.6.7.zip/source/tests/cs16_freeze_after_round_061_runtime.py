"""Focused 0.6.1 GameDLL regression: a new timeout during a scored-round freeze.

Uses isolated QA entities, not a real Steam-client acceptance test. The existing
0.6.1 harness preserves the generation high-water mark and journal history.
"""
from pathlib import Path

helpers = Path(__file__).with_name('cs16_pause_061_runtime.py').read_text()
exec(compile(helpers.split("if a.mode=='tactical':", 1)[0], str(Path(__file__).with_name('cs16_pause_061_runtime.py')), 'exec'))


def next_scored_freeze(expected_score):
    qa('eliminate 2')
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        state = snap()
        if state['freeze'] and not state['round_open'] and not state['lo3']:
            assert [state['t_score'], state['ct_score']] == expected_score, state
            return state
    raise AssertionError(('normal scored round did not reach freeze', status(), state))


def resume_once(previous_count):
    qa('talk 0 unpause')
    assert pause()['paused'] and pause()['votes'] == 1
    qa('talk 5 unpause')
    current = pause()
    assert not current['paused'] and not current['pending'], current
    assert sum(e['type'] == 'resume' for e in events()) == previous_count + 1
    return previous_count + 1


resumes = 0
load()
assert status()['score'] == [0, 0]
next_scored_freeze([1, 0])
stable = obj('player 5')
qa('talk 1 pause')
assert pause()['timeouts'] == [0, 0] and not pause()['pending']
qa('talk 0 pause')
current = pause()
assert current['paused'] and current['tactical'] and not current['pending'], current
assert current['timeouts'] == [1, 0], current
assert status()['score'] == [1, 0] and obj('player 5') == stable
assert any('Tylko kapitan' in row for row in feedback(1))
print('PASS real scored-round restart -> second-round freeze -> captain pause starts immediately; noncaptain rejected without charging quota', flush=True)

resumes = resume_once(resumes)
# The command immediately follows the two consent votes, while the resumed
# freezetime is still running. No artificial freeze or clock adjustment here.
qa('talk 0 pause')
current = pause()
assert current['paused'] and current['tactical'] and current['timeouts'] == [2, 0], current
assert status()['score'] == [1, 0] and obj('player 5') == stable
resumes = resume_once(resumes)
assert status()['score'] == [1, 0] and obj('player 5') == stable
print('PASS consecutive second pause during resumed freeze; exactly one resume per pause; score, side, HP, armor, money, weapons and position retained', flush=True)

live()
next_scored_freeze([2, 0])
stable = obj('player 5')
qa('talk 0 pause')
current = pause()
assert current['paused'] and current['tactical'] and current['timeouts'] == [3, 0], current
assert status()['score'] == [2, 0] and obj('player 5') == stable
resumes = resume_once(resumes)
qa('talk 0 pause')
current = pause()
assert not current['paused'] and not current['pending'] and current['timeouts'] == [3, 0], current
assert status()['score'] == [2, 0] and obj('player 5') == stable
assert sum(e['type'] == 'pause' for e in events()) == resumes == 3
persist('freeze-after-round')
clear()
print('PASS fresh request at 2:0 in third-round freeze; third quota accepted, fourth rejected; normal cleanup returns healthy idle; history and generations preserved', flush=True)
