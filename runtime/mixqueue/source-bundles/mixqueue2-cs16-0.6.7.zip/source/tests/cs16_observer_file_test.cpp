#include "../games/cs16/matchbot/MatchBot/MatchCSCOObserverFile.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <cstdlib>

int main() {
#ifdef _WIN32
    std::cout<<"POSIX FIFO/symlink acceptance requires the Linux controller build target\n";
    return 0;
#else
    char directory[]="/tmp/csco-observer-reader-XXXXXX";
    assert(mkdtemp(directory));const std::string base=directory;
    const auto regular=base+"/snapshot",fifo=base+"/fifo",link=base+"/link",huge=base+"/huge";
    const std::string payload="MQ2OBS1 1234567890abcdef12345678 9 1 1300\n";
    {std::ofstream out(regular);out<<payload;}
    assert(mq2::read_observer_file(regular)==payload);
    const auto reject=[](const std::string& path,const char* expected) {
        bool rejected=false;
        try {mq2::read_observer_file(path);} catch(const std::runtime_error& ex) {rejected=std::string(ex.what())==expected;}
        assert(rejected);
    };
    assert(mkfifo(fifo.c_str(),0600)==0);
    alarm(2); // A blocking open on an unread FIFO fails this test immediately.
    reject(fifo,"observer_storage");
    alarm(0);
    assert(symlink(regular.c_str(),link.c_str())==0);
    reject(link,"observer_storage");
    reject(base,"observer_storage");
    reject(base+"/missing","observer_storage");
    {std::ofstream out(huge);out<<std::string(8193,'x');}
    reject(huge,"observer_invalid");
    {std::ofstream out(regular);out<<std::string(8192,'a');}
    assert(mq2::read_observer_file(regular).size()==8192);
    assert(unlink(regular.c_str())==0);assert(unlink(fifo.c_str())==0);
    assert(unlink(link.c_str())==0);assert(unlink(huge.c_str())==0);assert(rmdir(base.c_str())==0);
    std::cout<<"PASS observer reader: bounded regular file, exact8192, oversized, FIFO nonblocking, symlink, directory and missing-file rejection\n";
#endif
}
