"""0.6.3 profile integration against an isolated ReGameDLL instance.

QA entities represent Steam roster members. Actual engine round endings and
phase transitions are used; only pending LO3/freeze transitions are accelerated.
This is not real Steam-client acceptance.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--agent', required=True)
a = p.parse_args()
root = Path(a.root).resolve()
assert '/csco-lab/matchbot-063-profile/' in str(root)
spec = importlib.util.spec_from_file_location('agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', 27095, os.environ['MQ2_QA_RCON_PASSWORD'])
last = 0
proof = {'controller': '0.6.3', 'acceptance': 'isolated GameDLL QA; not Steam-client acceptance',
         'qa_sha256': hashlib.sha256((root/'addons/matchbot/dlls/matchbot_csco_mm.so').read_bytes()).hexdigest(),
         'language_sha256': hashlib.sha256((root/'addons/matchbot/language.txt').read_bytes()).hexdigest(),
         'cases': []}
case = None


def cmd(value):
    global last
    time.sleep(max(0, 1.05 - (time.monotonic() - last)))
    result = rcon.command(value)
    last = time.monotonic()
    return result


def qa(value):
    return cmd('mq2_qa '+value)


def obj(value):
    return json.loads(qa(value))


def status():
    return json.loads(cmd('mq2_status'))


def events():
    return [event for line in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines()
            if (event := json.loads(line))['match_id'] == mid]


def record(stage, clock):
    case['clocks'].append({'stage': stage, **clock})


def clear():
    assert cmd('mq2_clear server_error').endswith('cleared')
    state = status()
    assert state['idle'] and state['healthy'] and state['rules_ready'], state
    assert obj('botstate')['native_bots'] == 0
    assert int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) == generation


def finish():
    case['events'] = events()
    clear()
    proof['cases'].append(case)
    (root.parent.parent/'profiles-063-proof.json').write_text(json.dumps(proof, indent=2))


def check(stage, paused=False, overtime=False, frozen=None):
    clock = obj('round-clock')
    assert clock['healthy'] and clock['team_size'] == size, clock
    expected = 30 if kind != 'ranked' else 120 if size == 2 else 105
    freeze = 8 if size == 2 else 10
    assert clock['configured_seconds'] == expected, clock
    assert clock['freeze_seconds'] == freeze, clock
    assert abs(clock['buy_minutes'] - (.5 if paused else .25)) < .0001, clock
    assert clock['startmoney'] == (10000 if overtime else 800), clock
    assert clock['c4_seconds'] == 35 and clock['voice_enabled'] == 1 and clock['pausable'] == 0, clock
    if frozen is not None:
        assert clock['freeze'] == frozen, clock
    if frozen and not paused:
        assert clock['intro_seconds'] == clock['clock_seconds'] == freeze, clock
    if not clock['freeze']:
        assert clock['clock_seconds'] == expected and clock['round_open'], clock
    record(stage, clock)
    return clock


def live():
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        state = obj('snapshot')
        boundary = obj('break-clock')
        assert not boundary['in_break'], ('Unexpected half boundary before expected played-round count', boundary)
        if state['round_open'] and not state['freeze'] and not state['lo3']:
            return state
        qa('fast')
    raise AssertionError(('not live', status(), state))


def first_freeze(expected_state=3):
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        state = obj('snapshot')
        if state['freeze'] and not state['round_open'] and not state['lo3']:
            clock = obj('round-clock')
            if clock['state'] == expected_state:
                assert clock['healthy'], clock
                return clock
        # Poll the real clock here. During LO3 the final freeze can already be
        # active while the LO3 task still reports running; accelerating that
        # transition would accidentally skip the exact freeze under test.
    raise AssertionError(('not first live freeze', status(), state))


def load(test_kind, team_size):
    global mid, generation, players, kind, size, case
    kind, size = test_kind, team_size
    assert status()['idle'] and status()['healthy']
    generation = int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) + 1
    mid = ('7e5700' if kind == 'full' else '063000') + f'{time.time_ns():018x}'[-18:]
    players = []
    for i in range(1 if kind == 'solo' else size*2):
        team, captain = (1 if i < size else 2), i in (0, size)
        bot = kind == 'full' and i != 0
        identity = ('bot:' + hashlib.sha256(f'{mid}:{generation}:{team}:{i+1}'.encode()).hexdigest()[:24]
                    if bot else str(76561198000000000+i))
        players.append({'steam_id': identity, 'team': team, 'captain': int(captain), 'bot': bot,
                        'name': ('Neo' if team == 1 else 'Forest') if captain else 'Player'+str(i),
                        'locale': 'pl' if team == 1 else 'en'})
    assignment = {'game': 'cs16', 'match_id': mid, 'generation': generation, 'config_hash': 'a'*64,
                  'contract_version': 3, 'starting_ct_team': 2, 'map': 'de_dust2', 'team_size': size,
                  'teams': {'1': 'Neo team', '2': 'Forest team'}, 'players': players,
                  'rules': {'mr': 8 if size == 2 else 15, 'ot_mr': 3, 'test': kind != 'ranked'}}
    if kind == 'full':
        assignment['rules']['test_type'] = 'full'
        assignment['test_owner'] = players[0]['steam_id']
    (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(assignment))
    response = cmd(f'mq2_load {mid} {generation}')
    assert response.endswith('loaded'), (response, status())
    for i, row in enumerate(players):
        if not row['bot']:
            assert qa(f'add {i}') == 'qa_added'
    case = {'case': f'{kind}_{size}v{size}', 'match_id': mid, 'generation': generation, 'clocks': []}
    warm = obj('round-clock')
    assert warm['healthy'] and warm['freeze_seconds'] == 0 and warm['startmoney'] == 16000, warm
    record('warmup', warm)
    if kind == 'ranked':
        qa('ready')
    else:
        qa('talk 0 ready')
    first_freeze()
    check('initial_freeze', frozen=True)


def pause_cycle(number, overtime=False, already_pending=False):
    before = obj('player '+str(size))
    if not already_pending:
        qa('talk 0 pause')
    state = obj('pause-state')
    assert state['paused'] and state['tactical'] and state['timeouts'] == [number, 0], state
    check(f'pause_{number}', paused=True, overtime=overtime, frozen=True)
    qa('talk 0 unpause')
    assert obj('pause-state')['paused']
    qa(f'talk {size} unpause')
    check(f'resumed_freeze_{number}', overtime=overtime, frozen=True)
    assert obj('player '+str(size)) == before
    assert sum(event['type'] == 'resume' for event in events()) == number


def win(team, boundary=False, queue_timeout=False):
    live()
    if boundary:
        qa('feedback-clear')
    if queue_timeout:
        qa('talk 0 pause')
        state = obj('pause-state')
        assert state['pending'] and not state['paused'] and state['timeouts'] == [1, 0], state
    response = qa('eliminate '+str(3-team))
    assert 'qa_damage_applied' in response, response


def observe_break(expected_score, before_overtime, pending_timeout=False):
    until = time.monotonic()+15
    while time.monotonic()<until:
        first = obj('break-clock')
        if first['in_break']:
            break
    assert first['in_break'], first
    assert abs(first['deadline']-first['since']-20)<.01, first
    assert first['kind'] == ('before_overtime' if before_overtime else 'halftime'), first
    assert first['phase'] == 'halftime' and first['state'] == 4, first
    assert [first['team1_score'], first['team2_score']] == expected_score, first
    assert not first['round_open'] and not first['lo3'] and first['freeze'], first
    assert first['title_halftime'] and first['header_bytes'] <= 63, first
    assert first['tactical_pending'] == pending_timeout and not first['tactical_running'], first
    baseline_timeouts = first['timeouts']
    attempted = obj('break-try-next')
    assert attempted['in_break'] and attempted['state'] == 4, attempted
    # Tactical commands do not shorten the system intermission or consume a quota.
    qa('talk 0 pause')
    qa('talk 0 unpause')
    pl = qa('feedback-all 0')
    en = qa('feedback-all '+str(size))
    if before_overtime:
        score_text = ':'.join(map(str, expected_score))
        assert all(text in pl for text in ['REMIS', score_text, 'MR3', 'do 4 wygranych', '3:3']), pl
        assert all(text in en for text in ['TIED', score_text, 'MR3', 'first to 4', '3:3']), en
    else:
        assert 'Zmiana stron' in pl and '20 s' in pl, pl
        assert 'Switching sides' in en and '20 s' in en, en
    samples = [first]
    until = time.monotonic()+25
    while time.monotonic()<until:
        current = obj('break-clock')
        samples.append(current)
        if not current['in_break']:
            break
        assert current['phase']=='halftime' and not current['round_open'] and not current['lo3'], current
        assert current['timeouts'] == baseline_timeouts
        assert current['tactical_pending'] == pending_timeout and not current['tactical_running'], current
        assert [current['team1_score'], current['team2_score']] == expected_score
    assert not current['in_break'] and 20 <= current['now']-first['since'] < 23, current
    assert current['timeouts'] == baseline_timeouts
    assert status()['healthy'] and status()['rules_ready']
    assert sum(event['type']=='loaded' for event in events()) == 1
    case.setdefault('breaks', []).append({'score': expected_score, 'first': first, 'samples': samples, 'pl': pl, 'en': en})
    print('PASS real20s '+first['kind']+' at '+':'.join(map(str, expected_score))+'; PL/EN, frozen, no tactical quota/reset', flush=True)


def wait_round(count, reason, timeout=45):
    deadline = time.monotonic()+timeout
    while time.monotonic()<deadline:
        scored = [event for event in events() if event['type'] in ('round', 'finished')]
        if len(scored)>=count:
            break
        time.sleep(.3)
    assert len(scored)==count and scored[-1]['data']['round_reason']==reason, scored
    assert status()['healthy'] and status()['rules_ready']
    return scored[-1]


assert status()['controller_version'] == '0.6.3'
assert status()['idle'] and status()['healthy'], 'Start only an idle isolated lab'

load('ranked', 2)
pause_cycle(1)
live()
check('normal_live', frozen=False)
assert status()['score'] == [0, 0]
print('PASS ranked2 actual120s/freeze8, tactical pause restores8s with score/equipment intact', flush=True)

# Drive real TakeDamage round endings through both halves to tied8:8. No score
# assignment, profile override or direct phase jump is used.
for round_number, team in enumerate([1]*8 + [2]*8, 1):
    win(team, boundary=round_number in (8, 16), queue_timeout=round_number == 8)
    if round_number == 8:
        observe_break([8, 0], before_overtime=False, pending_timeout=True)
        deadline = time.monotonic()+60
        while time.monotonic()<deadline:
            state = obj('pause-state')
            if state['paused']:
                break
        assert state['paused'] and state['timeouts'] == [2, 0], state
        pause_cycle(2, already_pending=True)
        live()
        check('second_half_live', frozen=False)
        assert status()['score'] == [8, 0]
        print('PASS queued final-round timeout survives20s intermission and LO3; consumes exactly one quota after break, resume preserves8:0', flush=True)
    if round_number == 16:
        observe_break([8, 8], before_overtime=True)
first_freeze(expected_state=6)
check('overtime_freeze', overtime=True, frozen=True)
pause_cycle(3, overtime=True)
live()
check('overtime_live', overtime=True, frozen=False)
assert status()['score'] == [8, 8]
assert len([event for event in events() if event['type'] == 'round']) == 16
for round_number, team in enumerate([1]*3+[2]*3, 1):
    win(team, boundary=round_number in (3, 6))
    if round_number in (1, 2, 4, 5):
        state = obj('break-clock')
        assert not state['in_break'], ('OT half ended before three played rounds', state)
    elif round_number == 3:
        observe_break([11, 8], before_overtime=False)
        live()
        check('overtime_second_half_live', overtime=True, frozen=False)
    else:
        observe_break([11, 11], before_overtime=True)
first_freeze(expected_state=6)
check('second_overtime_freeze', overtime=True, frozen=True)
live()
check('second_overtime_live', overtime=True, frozen=False)
assert status()['score'] == [11, 11]
assert len([event for event in events() if event['type'] == 'round']) == 22
# Complete the second overtime with legitimate engine round endings, then keep
# the result and participants visible for the actual post-match interval.
for round_number in range(1, 5):
    win(1, boundary=round_number == 3)
    if round_number == 3:
        observe_break([14, 11], before_overtime=False)
        live()
wait_round(26, 'elimination')
assert status()['phase']=='finished' and status()['score']==[15, 11]
ended = [event for event in events() if event['type']=='finished']
assert len(ended)==1
assert all(event['data']['round_reason']=='elimination' for event in events() if event['type'] in ('round', 'finished'))
finished_clock = obj('finish-clock')
assert finished_clock['active'] and abs(finished_clock['deadline']-finished_clock['since']-180)<.01, finished_clock
assert finished_clock['connected']==4 and finished_clock['round_reason']=='elimination', finished_clock
held_clients = sorted((p['id'], p['slot'], p['team']) for p in obj('snapshot')['clients'])
assert len(held_clients)==4
held_since = time.monotonic()
hold_samples = []
print('PASS natural15:11 and single finished; beginning actual180s retained-result check', flush=True)
while time.monotonic()-held_since<181:
    state = status()
    assert state['phase']=='finished' and state['healthy'] and state['score']==[15, 11], state
    current_clients = sorted((p['id'], p['slot'], p['team']) for p in obj('snapshot')['clients'])
    assert current_clients==held_clients
    hold_clock = obj('finish-clock')
    assert hold_clock['active'] and hold_clock['connected']==4, hold_clock
    assert not hold_clock['round_open'] and not hold_clock['lo3'] and hold_clock['restart_at']==0, hold_clock
    assert hold_clock['since']==finished_clock['since'] and hold_clock['deadline']==finished_clock['deadline'], hold_clock
    assert len([event for event in events() if event['type']=='finished'])==1
    hold_samples.append({'elapsed': time.monotonic()-held_since, 'status': state, 'clients': current_clients, 'clock': hold_clock})
    if len(hold_samples)%3==0:
        print('Postmatch retained-result check: '+str(round(time.monotonic()-held_since))+'s,15:11 and4participants unchanged', flush=True)
    time.sleep(15)
case['postmatch_hold'] = {'elapsed': time.monotonic()-held_since, 'samples': hold_samples,
                          'cleanup_authority': 'WWW tested separately; native lab waits for normal cleanup command'}
assert obj('finish-clock')['remaining']==0
finish()
print('PASS real2v2 exact3+3 MR3 and secondOT15:11; all26 elimination reasons, single finished; score/4participants retained180s then normal cleanup', flush=True)

for test_kind, team_size in [('ranked', 5), ('full', 5), ('solo', 2), ('solo', 5)]:
    load(test_kind, team_size)
    live()
    check('live', frozen=False)
    assert status()['restarts_completed'] == 3
    if test_kind=='ranked':
        first = obj('round-clock')
        started = time.monotonic()
        wait_round(1, 'time', timeout=115)
        elapsed = time.monotonic()-started
        assert abs(elapsed-first['remaining'])<4, (elapsed, first)
        case['natural_timeout'] = {'initial_clock': first, 'elapsed_seconds': elapsed}
        print('PASS ranked5 actual105s clock expires naturally with round_reason=time; no AI cvar override', flush=True)
        live()
        assert 'qa_planted' in qa('plant 0')
        assert 'qa_defused' in qa('defuse 5')
        wait_round(2, 'bomb_defused')
        live()
        assert 'qa_planted' in qa('plant 0')
        wait_round(3, 'bomb_exploded')
        print('PASS actual GameDLL C4 plant/defuse and natural35s bomb explosion emit distinct round reasons', flush=True)
    finish()
    print(f'PASS {test_kind} {team_size}v{team_size} profile selected by signed size, actual engine duration/freeze, normal cleanup', flush=True)

for drift_key, drift_value in [('mp_freezetime', '10'), ('mp_ct_default_weapons_primary', 'ak47')]:
    load('ranked', 2)
    live()
    check('before_drift', frozen=False)
    assert sum(event['type'] == 'loaded' for event in events()) == 1
    cmd(drift_key+' '+drift_value)
    changed = time.monotonic()
    deadline = changed + 12
    while time.monotonic() < deadline:
        state = status()
        if state['phase'] == 'recovery':
            break
    assert state['phase'] == 'recovery' and not state['healthy'] and not state['rules_ready'], state
    assert drift_key in state['rules_issue'], state
    assert state['score'] == [0, 0]
    assert sum(event['type'] == 'loaded' for event in events()) == 1
    assert int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) == generation
    case['case'] = 'reject_drift_'+drift_key
    case['drift'] = {'key': drift_key, 'value': drift_value, 'observed_seconds': time.monotonic()-changed,
                     'status': state}
    finish()
    print(f'PASS {drift_key} drift enters recovery without reload/score/generation reset; normal cleanup restores healthy idle', flush=True)
