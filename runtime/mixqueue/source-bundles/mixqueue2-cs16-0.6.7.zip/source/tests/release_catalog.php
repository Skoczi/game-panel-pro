<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Infrastructure\ReleaseCatalog;

$versions = ReleaseCatalog::versions();
check($versions === [
    'cs16' => '0.6.7', 'agent' => '0.6.3', 'source' => '0.4.0',
    'ranked_controller_min' => '0.6.4', 'ranked_agent_min' => '0.6.1'
], 'Current package or ranked requirements changed without release acceptance');
$base = ReleaseCatalog::files([]);
foreach (['cs16', 'agent', 'source'] as $package) {
    $file = 'mixqueue2-' . $package . '-' . $versions[$package] . '.zip';
    check($base[$package] === $file, 'Current alias points at a stale package');
    check($base[$package . '-' . $versions[$package]] === $file, 'Explicit current version disagrees with alias');
}
check(count($base) === 6, 'Unexpected base download aliases');
echo "PASS current package aliases, explicit versions and ranked minimum contract\n";

$historical = ReleaseCatalog::files([
    ['file' => 'mixqueue2-cs16-0.6.5.zip'],
    ['file' => 'mixqueue2-agent-0.6.1.zip'],
    ['file' => 'mixqueue2-source-0.3.0.zip'],
    ['file' => 'mixqueue2-cs16-0.6.5.zip', 'alias' => 'cs16']
]);
foreach (['cs16-0.6.5', 'agent-0.6.1', 'source-0.3.0'] as $key)
    check($historical[$key] === 'mixqueue2-' . $key . '.zip', 'Historical version not available');
check(array_intersect_key($historical, $base) === $base, 'Historical entries changed current aliases');
check(count($historical) === 9, 'Duplicate history entry changed the download catalog');
echo "PASS historical manifest versions remain available without replacing current aliases\n";

$invalid = [
    '../mixqueue2-cs16-0.6.5.zip',
    '..\\mixqueue2-cs16-0.6.5.zip',
    '/tmp/mixqueue2-cs16-0.6.5.zip',
    'C:\\tmp\\mixqueue2-cs16-0.6.5.zip',
    'https://example.invalid/mixqueue2-cs16-0.6.5.zip',
    '%2e%2e%2fmixqueue2-cs16-0.6.5.zip',
    'mixqueue2-cs16-0.6.5.zip/extra',
    'mixqueue2-cs16-0.6.5.zip.php',
    'mixqueue2-cs16-0.6.5.zip?file=elsewhere',
    "mixqueue2-cs16-0.6.5.zip\n",
    "mixqueue2-cs16-0.6.5.zip\0",
    'mixqueue2-cs16-0.6.zip',
    'mixqueue2-cs16-latest.zip',
    'mixqueue2-web-0.7.8.zip',
    'mixqueue2-agent-0.6.2.tar.gz',
    [], null, 123
];
check(ReleaseCatalog::files(array_map(fn($file) => ['file' => $file], $invalid)) === $base, 'Unsafe filename accepted');
check(ReleaseCatalog::files([null, 123, 'file', []]) === $base, 'Malformed entry accepted');
check(ReleaseCatalog::files(['file' => 'mixqueue2-cs16-0.6.5.zip']) === $base, 'Non-list manifest accepted');
foreach (['../cs16', '/cs16', 'cs16.zip', 'cs16-0.6.5/extra', 'unknown'] as $request)
    check(!isset($historical[$request]), 'Unlisted request became a file path');
echo "PASS traversal, URLs, suffix tricks, malformed manifests and unlisted aliases rejected\n";

$directory = dirname(__DIR__) . '/module/Resources/downloads/';
$manifest = json_decode(file_get_contents($directory . 'manifest.json'), true, 32, JSON_THROW_ON_ERROR);
$files = ReleaseCatalog::files();
$entries = array_column($manifest, null, 'file');
$verified = 0;
foreach ($manifest as $entry) {
    check(preg_match('/^mixqueue2-(cs16|agent|source)-([0-9]+\.[0-9]+\.[0-9]+)\.zip$/D', $entry['file'], $match) === 1, 'Unexpected packaged manifest entry');
    check(($files[$match[1] . '-' . $match[2]] ?? null) === $entry['file'], 'Packaged history missing from downloads');
    $path = $directory . $entry['file'];
    check(is_file($path), 'Manifest references an absent archive: ' . $entry['file']);
    check(filesize($path) === $entry['bytes'], 'Manifest byte count differs: ' . $entry['file']);
    check(hash_file('sha256', $path) === $entry['sha256'], 'Manifest checksum differs: ' . $entry['file']);
    ++$verified;
}
foreach (['cs16', 'agent', 'source'] as $package) {
    $file = $files[$package];
    if (!is_file($directory . $file) && getenv('MQ2_REQUIRE_CURRENT_DOWNLOADS') !== '1') {
        echo 'PENDING current release packaging: ' . $file . "\n";
        continue;
    }
    check(isset($entries[$file]), 'Current alias archive absent from manifest: ' . $file);
    check(is_file($directory . $file), 'Current alias archive not packaged: ' . $file);
}
check(
    hash_file('sha256', $directory . 'mixqueue2-agent-0.6.2.zip') === 'd10ddfd26d226c22b46e1c93ad254d8d64e370ab1e4b2d6e2e9e92d6fba5f53e',
    'Published agent 0.6.2 archive was rebuilt instead of reused'
);
echo 'PASS packaged manifest mappings, sizes and SHA256 (' . $verified . " archives); immutable agent 0.6.2 reuse\n";
