<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Statistics};

$e = fixture();
function statsMatch(
    Engine $e,
    int $n,
    string $ladder,
    array $stats,
    array $options = []
): void {
    $id = str_pad(dechex($n), 24, '0', STR_PAD_LEFT);
    $e->db->run(
        'INSERT INTO mq2_matches(id,ladder_id,state,version,server_id,generation,maps,picked_map,deadline,team1_score,team2_score,rules,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
            $id,
            $ladder,
            $options['state'] ?? 'finished',
            1,
            's1',
            1,
            '[]',
            $n % 2 ? 'de_dust2' : 'de_inferno',
            0,
            16,
            10,
            '{}',
            100 + $n,
            100 + $n
        ]
    );
    $e->db->run(
        'INSERT INTO mq2_match_players(match_id,user_id,ticket_id,steam_id,team,captain,rating_before,rating_delta,rating_after,stats) VALUES(?,?,?,?,?,?,?,?,?,?)',
        [$id, '1', 't1', '76561198000000001', 1, 1, 1000, 25, 1025, Engine::json($stats)]
    );
    if ($options['settled'] ?? true) {
        $e->db->run('INSERT INTO mq2_settlements VALUES(?,?,?)', [$id, 'test', 100 + $n]);
    }
}

statsMatch($e, 1, 'cs16-5v5', ['kills' => 20, 'deaths' => 10, 'damage' => 2000, 'rounds' => 20, 'headshots' => 10]);
statsMatch($e, 2, 'cs16-5v5', [
    'kills' => 10,
    'deaths' => 20,
    'assists' => 3,
    'damage' => 1000,
    'rounds' => 10,
    'headshots' => 4
]);
statsMatch($e, 3, 'cs16-5v5', []);
statsMatch($e, 4, 'cs16-5v5', ['kills' => 9000], ['state' => 'cancelled']);
statsMatch($e, 5, 'cs16-5v5', ['kills' => 9000], ['settled' => false]);
statsMatch($e, 6, 'csgo-5v5', ['kills' => 9000]);
statsMatch($e, 7, 'cs16-2v2', ['kills' => 9000]);
$service = new Statistics($e);
$p = $service->profile('1', 'cs16-5v5');
$o = $p['overall'];
check($o['played'] === 3 && $o['wins'] === 3 && $o['stats_matches'] === 2, 'Settlement/game/mode filtering failed');
check(
    $o['metrics']['kd'] === 1.0 && $o['metrics']['adr'] === 100.0 && $o['metrics']['kr'] === 1.0,
    'Weighted ratios failed'
);
check($o['metrics']['hs_percent'] === 46.67 && $o['totals']['kills'] === 30, 'Headshot percentage failed');
check($o['coverage']['assists'] === 1 && $o['totals']['assists'] === 3, 'Missing assists treated as zeros');
check(count($p['maps']) === 2 && count($p['recent']) === 3 && count($p['trend']) === 3, 'History/maps mismatch');
check($p['recent'][0]['metrics']['kills'] === null, 'Missing telemetry displayed as zero');
check($service->profile('2', 'cs16-5v5')['overall']['played'] === 0, 'Other player stats leaked');
check(Statistics::metrics(['kills' => 2, 'deaths' => 0])['kd_infinite'] === true, 'Zero deaths');
check(Statistics::metrics(['kills' => 0, 'deaths' => 0, 'headshots' => 0])['hs_percent'] === 0.0, 'Zero headshots');
check(Statistics::metrics(['kills' => -1, 'damage' => '100'])['damage'] === null, 'Invalid telemetry accepted');
$e->db->run('UPDATE mq2_match_players SET team=2 WHERE match_id=?', [str_pad('1', 24, '0', STR_PAD_LEFT)]);
check($service->profile('1', 'cs16-5v5')['overall']['losses'] === 1, 'Team 2 loss not recognized');
statsMatch($e, 8, 'cs16-5v5', ['damage' => 9000]);
check(
    $service->profile('1', 'cs16-5v5')['overall']['metrics']['adr'] === 100.0,
    'Incompatible denominator coverage included'
);
for ($n = 20; $n < 44; ++$n) {
    statsMatch($e, $n, 'cs16-5v5', []);
}
$p = $service->profile('1', 'cs16-5v5', 999);
check(
    $p['overall']['played'] === 28 && $p['pages'] === 2 && $p['page'] === 2 && count($p['recent']) === 8,
    'All-time totals or pagination clipped'
);
echo
    "PASS native statistics: settlement isolation, weighted ratios, missing telemetry, zero denominators, per-map totals, history pagination\n"
;
