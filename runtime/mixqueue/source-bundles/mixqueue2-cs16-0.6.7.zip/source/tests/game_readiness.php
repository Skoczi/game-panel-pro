<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, ServerRegistry};

function readyFixture(): array
{
    $e = fixture();
    $maps = $e->ladder('cs16-5v5')['maps'];
    $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
        'cs16',
        Engine::json(['maps' => $maps, 'modes' => ['5v5']]),
        's1'
    ]);
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
        's1',
        Engine::json([
            ...cs16Status(),
            'map_inventory' => ['version' => 1, 'complete' => true, 'source' => 'bsp_v30', 'maps' => $maps]
        ]),
        $e->now()
    ]);
    $m = readyMatch($e, 'cs16-5v5');
    event($e, $m, 'loaded', ['map' => $m['picked_map'], 'config_hash' => $e->configuration($m['id'])['config_hash']]);
    $roster = $e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY user_id', [
        $m['id']
    ]);
    foreach ($roster as $i => $row) {
        event($e, $m, 'connected', ['steam_id' => $row['steam_id'], 'connected' => true]);
        event($e, $m, 'player_ready', ['steam_id' => $row['steam_id'], 'ready' => $i !== 0]);
    }
    return [$e, $m, $roster];
}

foreach ([true, false] as $healthy) {
    [$e, $m, $roster] = readyFixture();
    $later = new Engine($e->db, fn() => 2000000301);
    $later->serverHeartbeat('s1', $healthy);
    $e->db->run('UPDATE mq2_observations SET observed_at=?,payload=?', [
        $later->now(),
        Engine::json(['matchid' => $m['id'] . ':' . $m['generation'], 'phase' => 'warmup', 'rules_ready' => true])
    ]);
    $ev = event($later, $m, 'not_ready', ['missing' => [$roster[0]['steam_id']], 'occurred_at' => $later->now()]);
    check($later->match($m['id'])['state'] === 'cancelled', 'Readiness timeout did not cancel');
    check(
        count($e->db->all('SELECT * FROM mq2_penalties')) === ( $healthy ? 1 : 0 ),
        'Server incident punished player / connected unready escaped'
    );
    if ($healthy) {
        $penalty = $e->db->one('SELECT * FROM mq2_penalties');
        check(
            $penalty['reason'] === 'not_ready'
            && $penalty['user_id'] === $roster[0]['user_id']
            && (int) $penalty['expires_at'] === ( $later->now() + 1800 ),
            'Wrong player/duration'
        );
    }
    check(!$later->event('s1', $ev), 'Replay created penalty');
    check(!$e->db->all('SELECT * FROM mq2_claims') && !$e->db->all('SELECT * FROM mq2_settlements'), 'Claims or ELO');
    check($e->db->one('SELECT state FROM mq2_leases')['state'] === 'quarantine', 'Lease released too early');
    event($later, $m, 'player_ready', ['steam_id' => $roster[0]['steam_id'], 'ready' => true]);
    event($later, $m, 'idle');
    check(!$e->db->all('SELECT * FROM mq2_leases'), 'Cleanup failed');
}
[$e, $m, $roster] = readyFixture();
rejects(fn() => event($e, $m, 'not_ready', [
    'missing' => [$roster[1]['steam_id']],
    'occurred_at' => $e->now()
]), 'readiness');
rejects(fn() => event($e, $m, 'player_ready', ['steam_id' => 'foreign', 'ready' => true]), 'readiness');
event($e, $m, 'live');
check($e->match($m['id'])['state'] === 'live', 'Live transition regressed');
$status = cs16Status();
check(ServerRegistry::supportsRankedCs16($status), 'Current ranked capabilities rejected');
foreach (['ruleset', 'reconnect_budget', 'player_ready', 'assignment_contract', 'idle', 'rules_ready'] as $key) {
    $old = $status;
    unset($old[$key]);
    check(!ServerRegistry::supportsRankedCs16($old), 'Missing capability accepted:' . $key);
}
foreach (['0.4.0', '0.5.0', '0.5.1', '0.5.2'] as $v) {
    $old = $status;
    $old['controller_version'] = $v;
    check(!ServerRegistry::supportsRankedCs16($old), 'Old ranked controller accepted');
}
check(ServerRegistry::supportsCs16([...$status, 'controller_version' => '0.5.2']), 'Test 0.5.2 compatibility lost');
echo
    "PASS readiness, connected non-ready cooldown, incident exemption, idempotency, late drain, idle release, capability gates\n"
;
