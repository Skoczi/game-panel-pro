"""0.6.0 isolated GameDLL acceptance. QA entities, NEVER real Steam acceptance."""
import argparse, hashlib, importlib.util, json, os, time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True)
p.add_argument('--mode',choices=['full','ranked','expiry','damage'],default='full');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-060/' in str(root)
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
rcon=agent.GoldSrcRcon('127.0.0.1',27095,os.environ['MQ2_QA_RCON_PASSWORD']);last=0
def cmd(text):
 global last
 time.sleep(max(0,1.05-(time.monotonic()-last)));value=rcon.command(text);last=time.monotonic();return value
def qa(text):return cmd('mq2_qa '+text)
def obj(text):return json.loads(qa(text))
def status():return json.loads(cmd('mq2_status'))
def snap():return obj('snapshot')
def pause():return obj('pause-state')
def feedback(slot):return [x for x in qa(f'feedback-all {slot}').splitlines() if x!='qa_empty']
def events():return [e for x in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if (e:=json.loads(x))['match_id']==mid]
def live():
 until=time.monotonic()+85
 while time.monotonic()<until:
  v=snap()
  if v['round_open'] and not v['freeze'] and not v['lo3']:return v
  qa('fast')
 raise AssertionError(('not live',status(),v))
def wait_pause():
 until=time.monotonic()+30
 while time.monotonic()<until:
  v=pause()
  if v['paused']:return v
 raise AssertionError(('not paused',status(),v))
def clear():
 assert cmd('mq2_clear server_error').endswith('cleared')
 assert status()['idle'] and status()['healthy']
def load(full=True,one=False):
 global mid,generation,players
 if not status()['idle']:clear() # Normal recovery cleanup, never erase history/high-water mark.
 generation=int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text())+1
 mid=('7e5700' if full else '052000')+f'{time.time_ns():018x}'[-18:]
 size=5 if full else 2;players=[]
 for i in range(size*2):
  team=1 if i<size else 2;captain=i in (0,size);bot=full and (not captain or (one and i!=0))
  steam='bot:'+hashlib.sha256(f'{mid}:{generation}:{team}:{i+1}'.encode()).hexdigest()[:24] if bot else str(76561198000000000+i)
  players.append({'steam_id':steam,'team':team,'name':('Neo' if team==1 else 'Forest') if captain else 'Player'+str(i),
                  'bot':bot,'captain':int(captain),'locale':'pl' if team==1 else 'en'})
 payload={'game':'cs16','match_id':mid,'generation':generation,'config_hash':'b'*64,'contract_version':3,'starting_ct_team':2,
          'map':'de_dust2','team_size':size,'teams':{'1':'Neo team','2':'Forest team'},'players':players,
          'rules':{'mr':15 if full else 8,'ot_mr':3,'test':full}}
 if full:payload['rules']['test_type']='full';payload['test_owner']=players[0]['steam_id']
 (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(payload))
 assert cmd(f'mq2_load {mid} {generation}').endswith('loaded'),status()
 for i,row in enumerate(players):
  if not row['bot']:assert qa(f'add {i}')=='qa_added'
 assert not any('Dealt:' in x or 'Zadane:' in x for x in feedback(0))
 qa('ready');v=live();assert status()['restarts_completed']==3
 assert next(x for x in v['clients'] if x['slot']==0)['team']==1
 print('PASS signed starting T/load/ready/3 restarts,',mid,'generation',generation,flush=True)
 return v
def expect_line(slot,text):
 rows=feedback(slot);assert text in rows,(text,rows);return rows
def persist(label):
 (root.parent.parent/f'feedback-060-{label}.json').write_text(json.dumps({'match_id':mid,'generation':generation,'events':events()},indent=2))

assert status()['controller_version']=='0.6.0'
assert 'votes' in pause(), 'QA build required'
if a.mode=='full':
 load();qa('feedback-clear')
 # Non-captain and legacy menu/team-vote paths cannot spend a timeout.
 qa('timeout 1');assert qa('legacy-pause 1')=='qa_denied';assert qa('legacy-pause -1')=='qa_denied'
 assert pause()['timeouts']==[0,0]
 assert any('Tylko kapitan Neo team' in x for x in feedback(1))
 qa('timeout 0');assert pause()['timeouts']==[1,0];qa('timeout 0');assert pause()['timeouts']==[1,0]
 # Actual armor reduction, damage in both directions, HE/C4/world/self and a friendly hit.
 qa('armor 5');before=obj('player 5')['hp'];qa('damage 0 5 50');after=obj('player 5')['hp'];assert 0<before-after<50,(before,after)
 qa('damage 5 0 27');qa('damage 0 6 40');qa('damage 1 0 10');qa('environment 0 world');qa('environment 0 c4');qa('environment 6 he')
 qa('damage 0 0 3');qa('talk 0 dmg');assert not any(' | Zadane:' in x for x in feedback(0))
 qa('eliminate 2');assert status()['score']==[1,0]
 wait_pause()
 time.sleep(2)
 rows0=feedback(0);rows5=feedback(5)
 assert any('vs Forest | Zadane:' in x and 'Otrzymane: 27 (1 trafienie)' in x for x in rows0),rows0
 assert any('vs Neo | Dealt: 27 (1 hit)' in x and 'Taken:' in x for x in rows5),rows5
 assert any('[DRUZYNA]' in x for x in rows0) and any('Swiat / C4 / sam' in x for x in rows0),rows0
 assert any('vs Player6' in x for x in rows0),rows0
 damage_rows=[x for x in rows0 if ' | Zadane:' in x or ' | Otrzymane:' in x]
 qa('feedback-clear');qa('talk 0 dmg');time.sleep(2)
 manual=[x for x in feedback(0) if ' | Zadane:' in x or ' | Otrzymane:' in x];assert manual==damage_rows,(manual,damage_rows)
 assert any('No damage' in x for x in feedback(9)) is False # Clear removed the previous automatic output.
 print('PASS armor, multiple targets, alive/dead PL/EN, world/C4/HE/friendly, no live leak, manual parity',flush=True)
 v=wait_pause();assert v['tactical'] and v['votes']==0
 assert any('Pauza Neo team' in x for x in rows0+feedback(0))
 qa('timeout 5');assert pause()['timeouts']==[1,0]
 qa('talk 1 unpause');assert pause()['votes']==0
 before_score=status()['score'];before_player=obj('player 0')
 qa('talk 0 unpause');qa('talk 0 unpause');assert pause()['votes']==1 and pause()['paused']
 qa('drop 0');qa('add 0');assert pause()['votes']==1
 qa('talk 0 unpause');assert pause()['votes']==1
 # Reconnect can respawn the returning QA entity; compare stable other captain across resume.
 stable=obj('player 5');qa('talk 5 unpause');assert not pause()['paused'] and pause()['votes']==0
 assert obj('player 5')==stable and status()['score']==before_score
 assert len([e for e in events() if e['type']=='resume'])==1
 assert abs(pause()['buytime']-.25)<.001
 qa('feedback-clear');qa('timeout 0');assert pause()['timeouts']==[1,0], 'Freeze rejection consumed quota'
 assert any('freeze' in x.lower() or 'niedostepna' in x for x in feedback(0)),feedback(0)
 print('PASS captain-only timeout, legacy denial, duplicate/reconnect consent, bilateral resume, score/equipment/position/buytime unchanged',flush=True)
 live();qa('timeout 5');qa('eliminate 1');wait_pause();assert pause()['votes']==0
 qa('talk 5 unpause');assert pause()['votes']==2
 qa('expire-vote 0 1');assert not pause()['paused'] and len([e for e in events() if e['type']=='resume'])==2
 print('PASS reverse voting order and second vote simultaneous with timer: one resume',flush=True)
 live();qa('timeout 0');qa('eliminate 2');wait_pause();qa('talk 0 unpause')
 qa('expire-vote 5 0');assert not pause()['paused'] and len([e for e in events() if e['type']=='resume'])==3
 assert pause()['votes']==0
 print('PASS natural expiry with only one consent and expiry-before-vote race: one resume',flush=True)
 live();qa('timeout 0');assert not pause()['pending'] and pause()['timeouts']==[2,1]
 # Continue actual rounds through halftime and normal final 16:1.
 while status()['score'][0]<15:
  live();qa('eliminate 2')
 assert status()['score']==[15,1]
 v=live();assert next(x for x in v['clients'] if x['slot']==0)['team']==2 # Team1 started T (1), now CT (2).
 qa('feedback-clear');qa('timeout 5');assert any('Forest team' in x for x in feedback(0))
 qa('eliminate 2');time.sleep(2)
 assert status()['phase']=='finished' and status()['score']==[16,1]
 final=next(e for e in reversed(events()) if e['type']=='finished')
 assert final['data']['stats_version']==2
 assert all('kast_rounds' in p and p['kast_rounds']<=p['rounds'] and p['utility_damage']<=p['damage'] for p in final['data']['players'].values())
 assert sum(p['opening_kills'] for p in final['data']['players'].values())==17
 assert len(final['data']['players'])==10 and all(x['rounds']==(16 if steam==players[0]['steam_id'] else 17) for steam,x in final['data']['players'].items())
 assert any('Zadane:' in x or 'Brak obrazen' in x for x in feedback(0)),feedback(0)
 assert not pause()['tactical'] and not pause()['pending'] and pause()['votes']==0
 persist('full');clear();assert not snap()['clients']
 print('PASS logical names after side swap, final-half/final-match feedback, final stats, cleanup; 16:1',flush=True)
elif a.mode=='ranked':
 load(False);qa('timeout 0');qa('eliminate 2');wait_pause();qa('talk 0 unpause');qa('drop 1')
 qa('talk 2 unpause');assert pause()['votes']==1 and pause()['paused'],'Missing player allowed early resume'
 qa('fast');assert not pause()['tactical']
 wait_pause();assert pause()['disconnect']
 qa('talk 0 unpause');qa('talk 2 unpause');assert pause()['paused'] and pause()['votes']==0
 qa('add 1');qa('fast');live();assert status()['score']==[1,0]
 print('PASS missing-player guard; disconnect pause rejects captain votes; natural reconnect expiry',flush=True)
 qa('timeout 0');qa('eliminate 2');wait_pause();qa('talk 0 unpause');qa('direct-reset')
 assert status()['phase']=='recovery' and not status()['healthy'] and pause()['votes']==0
 count=len([e for e in events() if e['type']=='resume']);qa('talk 2 unpause');qa('fast')
 assert len([e for e in events() if e['type']=='resume'])==count and status()['phase']=='recovery'
 persist('ranked');clear();assert status()['idle'] and not pause()['votes']
 print('PASS recovery clears consent and blocks timer/unpause; normal cleanup preserves high-water/history',flush=True)
elif a.mode=='expiry':
 load(one=True);qa('timeout 0');qa('eliminate 2');wait_pause();start=time.monotonic()
 qa('talk 0 unpause');assert pause()['votes']==1
 # Let the ordinary server-frame timer really elapse: no fast clock command.
 while time.monotonic()-start<75:
  if not pause()['paused']:break
  time.sleep(3)
 assert 48<time.monotonic()-start<75
 assert not pause()['paused'] and len([e for e in events() if e['type']=='resume'])==1
 assert status()['score']==[1,0] and pause()['votes']==0
 persist('expiry');clear()
 print('PASS real-time 60-second expiry in QA 1+9, no bot auto-consent, single resume, score retained',flush=True)
elif a.mode=='damage':
 load(False);qa('feedback-clear')
 # A returning identity may use the same or a different engine slot. The ledger key is the roster.
 ids={x['slot']:x['id'] for x in snap()['clients']}
 qa('damage 0 2 30');qa('drop 1');qa('drop 2');qa('add 2');qa('add 1')
 reused={x['slot']:x['id'] for x in snap()['clients']}
 assert reused[2]==ids[1] and reused[1]==ids[2],(ids,reused)
 qa('damage 3 0 20')
 qa('eliminate 2');time.sleep(2)
 rows=feedback(0)
 assert any('vs Forest | Zadane: 30 (1 trafienie)' in x for x in rows),rows
 assert any('vs Player3 |' in x and 'Otrzymane: 20 (1 trafienie)' in x for x in rows),rows
 final_hit=feedback(3);assert any('Taken: 100 (1 hit)' in x for x in final_hit),final_hit
 expect_line(1,'Brak obrazen w tej rundzie.')
 before=list(rows);qa('talk 0 dmg');time.sleep(1)
 assert feedback(0)==before+before,feedback(0)
 # Once the next round opens, it cannot reveal either the current or the old completed table.
 live();qa('feedback-clear');qa('talk 3 dmg')
 assert feedback(3)==['Damage summary is available after the round ends.']
 persist('damage');clear()
 print('PASS reconnect ledger identity, last lethal overkill capped to 100, no-damage line, exact manual replay, next-round non-disclosure',flush=True)
