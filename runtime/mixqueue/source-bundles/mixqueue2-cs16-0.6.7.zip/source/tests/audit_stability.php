<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Incidents, Matchmaker, QueueCandidates};
use Flute\Modules\MixQueue2\Http\Application;

function incidentFixture(): array
{
    $e = fixture();
    $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
        'cs16',
        Engine::json(['modes' => ['5v5'], 'maps' => $e->ladder('cs16-5v5')['maps']]),
        's1'
    ]);
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [
        's1',
        Engine::json([
            ...cs16Status(),
            'map_inventory' => [
                'version' => 1,
                'source' => 'bsp_v30',
                'complete' => true,
                'maps' => $e->ladder('cs16-5v5')['maps']
            ]
        ]),
        $e->now()
    ]);
    $m = readyMatch($e, 'cs16-5v5');
    live($e, $m);
    $e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?', [
        Engine::json(['matchid' => $m['id'] . ':' . $m['generation'], 'phase' => 'live', 'rules_ready' => true]),
        's1'
    ]);
    return [$e, $m];
}

[$e, $m] = incidentFixture();
$later = new Engine($e->db, fn() => 2000000060);
$later->tick();
check($later->match($m['id'])['state'] === 'live', 'Transient outage cancelled match');
check($e->db->one('SELECT code FROM mq2_incidents')['code'] === 'server_offline', 'Missing incident');
( new Application($later) )->state('1', 'cs16-5v5', $m['id'], true);
rejects(fn() => ( new Application($later) )->act(
    '1',
    ['action' => 'cancel_incident', 'match' => $m['id']],
    false
), 'forbidden');
$later->serverHeartbeat('s1', true);
$later->tick();
check((int) $e->db->one('SELECT resolved_at FROM mq2_incidents')['resolved_at'] > 0, 'Return did not resolve');
$later = new Engine($e->db, fn() => 2000003600);
$later->tick();
check($later->match($m['id'])['state'] === 'cancelled', 'Long outage kept players claimed');
check(!$e->db->all('SELECT * FROM mq2_claims'), 'Claims not released');
check(
    !$e->db->all('SELECT * FROM mq2_penalties') && !$e->db->all('SELECT * FROM mq2_settlements'),
    'Outage changed ELO/penalties'
);
check($e->db->one('SELECT state FROM mq2_leases')['state'] === 'quarantine', 'Unsafe lease release');
event($later, $m, 'round', ['team1_score' => 1, 'team2_score' => 0]);
check((int) $later->match($m['id'])['team1_score'] === 0, 'Late result changed cancelled match');
event($later, $m, 'idle');
check(!$e->db->all('SELECT * FROM mq2_leases'), 'Idle did not release');

[$e, $m] = incidentFixture();
$later = new Engine($e->db, fn() => 2000000900);
$later->serverHeartbeat('s1', true);
$later->tick();
check($e->db->one('SELECT code FROM mq2_incidents')['code'] === 'progress_stalled', 'No stalled warning');
check($later->match($m['id'])['state'] === 'live', 'Quiet journal auto-cancelled');
( new Incidents($later) )->cancel($m['id'], '1');
check($later->match($m['id'])['state'] === 'cancelled', 'Admin resolution failed');
rejects(fn() => ( new Incidents($later) )->cancel($m['id'], '1'), 'incident_closed');

$tickets = [];
foreach ([...array_fill(0, 24, 3), 5, 5] as $i => $n) {
    $players = [];
    for ($j = 0; $j < $n; $j++)
        $players[] = ['user_id' => "$i-$j", 'rating' => 1000];
    $tickets[] = ['id' => (string) $i, 'joined_at' => $i, 'players' => $players];
}
$match = ( new Matchmaker() )->choose($tickets, 5, 1000);
check($match !== null && array_column($match['tickets'], 'id') === ['24', '25'], '24-ticket starvation persists');
$e = fixture(0);
for ($i = 0; $i < 230; $i++)
    $e->db->run('INSERT INTO mq2_tickets VALUES(?,?,NULL,?,?,?)', [
        str_pad((string) $i, 4, '0', STR_PAD_LEFT),
        'cs16-5v5',
        $i,
        3000000000,
        'waiting'
    ]);
$seen = [];
for ($pass = 0; $pass < 5; $pass++) {
    $c = ( new QueueCandidates($e) )->tickets('cs16-5v5');
    check(count($c) <= 120, 'Unbounded candidate page');
    check($c[0]['id'] === '0000', 'Oldest candidates not protected');
    foreach ($c as $t)
        $seen[$t['id']] = true;
}
check(count($seen) === 230, 'Rotation starved suffix');
echo
    "PASS outage/recovery, no ELO/penalties, late event drain, idle release, stalled warning, admin authorization, 24-ticket starvation and bounded fair rotation\n"
;
