import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

for (const locale of ['pl', 'en']) {
  const source = readFileSync(new URL(`../module/Resources/assets/mixqueue${locale === 'en' ? '.en' : ''}.js`, import.meta.url), 'utf8');
  const render = source.slice(source.indexOf('    function testOperations()'), source.indexOf('    function roundTimeline('));
  const history = source.slice(source.indexOf('    function historyRows('), source.indexOf('    function history()'));
  const server = {id:'s1',game:'cs16',name:'Test',test_ready:true,bot_only_ready:true,test_maps:['de_nuke','de_dust2']};
  const context = vm.createContext({state:{operations:{servers:[server],tests:[]},ladders:[{id:'cs16-5v5',rules:{mr:12}}]},
    testServerSelection:null,testFormatSelection:null,testMapSelection:null,testBotOnly:true,
    esc:String,mapName:String,labels:{finished:'finished'},button:(text,action,cls,attrs)=>`<button data-action="${action}" ${attrs}>${text}</button>`,
    icon:()=>'',matchUrl:()=>'/play?match=test',image:()=>'',seconds:()=>1,time:String});
  vm.runInContext(render+history,context);
  let html = context.testOperations();
  assert.match(html, /value="de_dust2" selected/);
  assert.ok(!html.includes('value="de_tuscan"'), 'Absent map must not appear');
  context.testMapSelection='de_nuke';
  assert.match(context.testOperations(),/value="de_nuke" selected/);
  server.test_maps=['de_dust2'];
  assert.match(context.testOperations(),/value="de_dust2" selected/,'Stale map choice falls back to verified pool');
  server.bot_only_ready=false; server.bot_only_error='update required';
  html=context.testOperations();
  assert.match(html,/data-action="test_create" disabled/);
  assert.ok(html.includes('update required'));
  context.testBotOnly=false;
  html=context.testOperations();
  assert.match(html,/data-action="test_create" >/,'Compatible human tests remain enabled');
  assert.ok(!html.includes('data-test-map'));
  const match={state:'finished',test:true,team:null,winner:1,team1_score:13,team2_score:8,rating_delta:null,created_at:1,ladder_id:'cs16-5v5',picked_map:'de_dust2'};
  html=context.historyRows([match]);
  assert.ok(html.includes(locale==='en'?'ENDED':'ZAKOŃCZONO'));
  assert.ok(!html.includes('is-loss') && !html.includes('is-win'),'Nonparticipant owner has no personal result');
  html=context.gameReadyNotice({state:'connecting',ladder_id:'cs16-5v5',rules:{bot_only:true},players:[],game_readiness:[],game_ready:{deadline:300,completed_at:0}});
  assert.ok(html.includes('15') && !html.includes('data-countdown'), 'Safety deadline must not be displayed as bot readiness delay');
  console.log(`PASS ${locale}: verified map choices, Dust2 default, compatibility gate, regular tests, owner history, 15-second notice`);
}
