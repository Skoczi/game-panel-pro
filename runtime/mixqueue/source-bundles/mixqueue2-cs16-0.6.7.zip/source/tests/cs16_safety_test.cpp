#include "../games/cs16/matchbot/MatchBot/MatchCSCOSafety.h"
#include <cassert>
#include <map>
#include <string>
#include <iostream>
int main() {
    mq2::ReconnectBudget budget;
    assert(!budget.available(0) && !budget.available(3));
    assert(budget.available(1) && budget.available(2));
    budget.consume({true,false});budget.consume({true,false});
    assert(!budget.available(1) && budget.available(2));
    budget.consume({true,true});
    assert(budget.used[0]==1 && budget.used[1]==1);
    // Reconnect and halftime do not call reset; only assignment lifecycle does.
    budget.consume({false,true}); assert(!budget.available(2));
    budget.reset();assert(budget.used[0]==0 && budget.available(2));
    for(int mr:{8,12,15}) {
        std::map<std::string,float> format;
        for(const auto& rule:mq2::assignment_format_rules(mr,3)) {
            assert(!rule.optional && !format.count(rule.name));format[rule.name]=rule.expected;
        }
        assert(format.size()==3 && format.at("mb_play_rounds")==mr*2);
        assert(format.at("mb_play_rounds_ot")==6 && format.at("mb_play_ot_mode")==1);
    }
    for(int size:{2,5}) for(bool test:{false,true}) for(bool warm:{false,true}) for(bool ot:{false,true}) for(bool pause:{false,true}) for(int pauseSeconds:{30,90}) {
        std::map<std::string,float> rules;
        for(const auto& rule:mq2::tournament_rules(warm,ot,pause,pauseSeconds,test,size)) {
            assert(!rules.count(rule.name)); rules[rule.name]=rule.expected;
        }
        assert(rules["sv_gravity"]==800 && rules["mp_forcecamera"]==2);
        assert(rules["mp_infinite_ammo"]==0 && rules["mp_free_armor"]==0);
        assert(rules["mp_startmoney"]==(warm?16000:ot?10000:800));
        assert(rules["mp_buytime"]==(pause?pauseSeconds/60.0f:warm?(size==2?2.0f:1.75f):0.25f));
        assert(rules["mp_roundtime"]==(test && !warm?0.5f:size==2?2.0f:1.75f));
        assert(rules["mp_freezetime"]==(warm?0:size==2?8:10) && rules["mp_c4timer"]==35);
        assert(rules["sv_voiceenable"]==1 && rules["pausable"]==0);
        assert(rules["sv_alltalk"]==(warm?1:0) && rules["mp_friendlyfire"]==(warm?0:1));
        assert(rules["mp_falldamage"]==1 && rules["mp_roundover"]==0 && rules["mp_fraglimit"]==0);
        assert(rules["sv_autobunnyhopping"]==0 && rules["sv_enablebunnyhopping"]==0);
        assert(rules["mp_plant_c4_anywhere"]==0 && rules["mp_give_player_c4"]==1);
        assert(rules["mp_respawn_immunitytime"]==0 && rules["mp_randomspawn"]==0);
        assert(rules["ff_damage_reduction_bullets"]==0.35f && rules["ff_damage_reduction_other"]==0.35f && rules["ff_damage_reduction_grenade_self"]==1);
        assert(rules["sv_maxrate"]==(size==2?25000:30000) && rules["sv_maxupdaterate"]==(size==2?100:102));
        assert(rules["mp_consistency"]==1 && rules["mp_logfile"]==1 && rules["host_framerate"]==0);
        assert(rules["allow_spectators"]==0 && rules["mp_allow_point_servercommand"]==0);
        assert(rules["mp_scoreboard_showhealth"]==-1 && rules["mp_scoreboard_showmoney"]==-1);
        assert(!rules.count("mp_decals") && !rules.count("sv_airmove"));
    }
    std::map<std::string,std::string> loadout;
    for(const auto& rule:mq2::tournament_text_rules()) {
        assert(!loadout.count(rule.name));loadout[rule.name]=rule.expected;
    }
    assert(loadout["mp_ct_default_weapons_secondary"]=="usp" && loadout["mp_t_default_weapons_secondary"]=="glock18");
    for(const auto key:{"mp_ct_default_weapons_primary","mp_t_default_weapons_primary","mp_ct_default_grenades","mp_t_default_grenades","mp_default_weapons_random"}) assert(loadout.at(key).empty());
    std::cout<<"PASS bounded reconnect budget and mode/phase/test/overtime/pause tournament rules\n";
}
