#include "../games/cs16/matchbot/MatchBot/MatchCSCOStatistics.h"
#include <cassert>
#include <iostream>

static void disconnect_clutches() {
 using namespace mq2;
 const std::vector<int> teams={1,1,2,2};
 const std::vector<bool> present(4,true);
 RoundStatistics s;

 // A disconnect can create a 1v2 even when no further kill happens.
 s.begin(teams,present);s.disconnect(1);s.disconnect(1);s.end(1);s.seal();
 assert(s.get(0)[CLUTCH_ATTEMPTS]==1&&s.get(0)[CLUTCH_WINS]==1&&s.get(0)[CLUTCH_2]==1);
 assert(s.get(0)[KILLS]==0&&s.get(1)[DEATHS]==0&&s.get(1)[KAST]==0);

 // Rejoining before the next round restores normal participation, not an old clutch.
 s.begin(teams,present);s.end(1);s.seal();
 assert(s.get(0)[CLUTCH_ATTEMPTS]==1&&s.get(0)[CLUTCH_WINS]==1);
 assert(s.get(1)[CLUTCH_ATTEMPTS]==0&&s.get(1)[KAST]==1&&s.get(1)[ROUNDS]==2);

 // Neither the first kill nor another disconnect hook may shrink the initial 1v2.
 s.reset();s.begin(teams,present);s.disconnect(1);s.death(0,2,-1,false,1);
 s.disconnect(1);s.death(0,3,-1,false,2);s.end(1);s.seal();
 assert(s.get(0)[CLUTCH_ATTEMPTS]==1&&s.get(0)[CLUTCH_WINS]==1);
 assert(s.get(0)[CLUTCH_1]==0&&s.get(0)[CLUTCH_2]==1&&s.get(0)[KILLS]==2);

 // An enemy leaving must also preserve the size of a clutch already in progress.
 s.reset();s.begin({1,1,2,2,2},std::vector<bool>(5,true));s.death(2,1,-1,false,1);
 s.disconnect(4);s.disconnect(4);s.death(0,2,-1,false,2);s.death(0,3,-1,false,3);
 s.end(1);s.seal();
 assert(s.get(0)[CLUTCH_ATTEMPTS]==1&&s.get(0)[CLUTCH_3]==1&&s.get(0)[CLUTCH_2]==0);

 // Leaving during the attempt cannot turn a team win into a personal clutch win.
 s.reset();s.begin(teams,present);s.disconnect(1);s.disconnect(0);s.disconnect(0);
 s.end(1);s.seal();
 assert(s.get(0)[CLUTCH_ATTEMPTS]==1&&s.get(0)[CLUTCH_WINS]==0&&s.get(0)[KAST]==0);

 // Hooks outside an active round or outside its roster cannot create a clutch.
 s.reset();s.disconnect(1);s.begin(teams,present);s.disconnect(-1);s.disconnect(10);
 s.end(1);s.disconnect(1);s.seal();
 assert(s.get(0)[CLUTCH_ATTEMPTS]==0&&s.get(1)[KAST]==1);
 const auto completed=s.get(0);s.disconnect(0);assert(s.get(0)==completed);
 s.reset();s.disconnect(1);assert(s.get(0)[CLUTCH_ATTEMPTS]==0);
}

int main() {
 using namespace mq2; RoundStatistics s;
 std::vector<int> teams={1,1,2,2};std::vector<bool> present(4,true);
 s.damage(0,2,100,false);s.death(0,2,-1,true,1);assert(s.get(0)[KILLS]==0);
 s.begin(teams,present);s.damage(2,1,100,true);s.death(2,1,-1,false,10);
 s.damage(0,2,84,false);s.death(0,2,-1,true,15); // inclusive five-second trade
 s.death(0,2,-1,true,15); // duplicate death
 s.damage(0,3,73,false);s.death(0,3,-1,false,16);s.end(1);
 assert(s.get(0)[KILLS]==0);s.damage(0,3,27,false); // nested final hit
 assert(s.seal());assert(!s.seal());assert(s.get(0)[KILLS]==2&&s.get(0)[DAMAGE]==184);
 assert(s.get(0)[TRADE_KILLS]==1&&s.get(1)[TRADED_DEATHS]==1&&s.get(1)[KAST]==1);
 assert(s.get(2)[FIRST_KILLS]==1&&s.get(1)[FIRST_DEATHS]==1&&s.get(2)[UTILITY_DAMAGE]==100);
 assert(s.get(0)[TWO_K]==1&&s.get(0)[CLUTCH_2]==1&&s.get(0)[CLUTCH_WINS]==1);
 s.damage(0,2,999,false);s.objective(0,true);assert(s.get(0)[DAMAGE]==184);
 s.begin(teams,present);s.disconnect(0);s.disconnect(0);s.death(2,1,-1,false,20);s.end(2);s.seal();
 assert(s.get(0)[ROUNDS]==2&&s.get(0)[KAST]==1); // leave is not survival; participation preserved
 s.begin(teams,present);s.death(-1,0,-1,false,30);s.damage(1,0,20,false);s.death(2,1,-1,false,31);s.end(2);s.seal();
 assert(s.get(1)[DAMAGE]==0&&s.get(0)[DEATHS]==1&&s.get(2)[FIRST_KILLS]==3);
 s.reset();s.begin(teams,present);s.objective(0,true);s.objective(0,true);s.death(2,0,-1,false,1);
 s.death(1,2,-1,false,6.01);s.objective(3,false);s.end(2);s.seal();
 assert(s.get(0)[PLANTS]==1&&s.get(3)[DEFUSES]==1&&s.get(1)[TRADE_KILLS]==0&&s.get(0)[KAST]==0);
 s.begin(teams,{true,false,true,true});s.death(0,2,-1,false,1);s.end(1);s.seal();assert(s.get(1)[ROUNDS]==1);
 s.reset();s.begin(teams,present);s.damage(0,2,0.4,false);s.damage(0,2,0.4,false);s.death(1,2,0,false,1);s.end(1);s.seal();
 assert(s.get(0)[DAMAGE]==1&&s.get(0)[ASSISTS]==1&&s.get(0)[KAST]==1);
 s.reset();s.begin({1,1,1,1,1,2,2,2,2,2},std::vector<bool>(10,true));
 for(int v=5;v<10;++v)s.death(0,v,-1,false,v);
 s.end(1);s.seal();assert(s.get(0)[FIVE_K]==1&&s.get(0)[CLUTCH_WINS]==0);
 s.reset();assert(s.get(0)[KILLS]==0);
 disconnect_clutches();
 std::cout<<"Round statistics: trades, KAST, clutches, nested damage, duplicate/late hooks, objectives, disconnect clutch sizes, reconnect participation, inactive rounds, reset OK\n";
}
