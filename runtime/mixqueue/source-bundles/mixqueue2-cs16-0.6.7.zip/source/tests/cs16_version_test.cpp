// Query actual built Metamod metadata without attaching to or starting a game.
// Linux: g++ -std=c++11 -m32 -Igames/cs16/matchbot/MatchBot tests/cs16_version_test.cpp -ldl -o /tmp/cs16-version
// Run: /tmp/cs16-version /absolute/path/to/matchbot_csco_mm.so 0.6.4
#include "include/metamod/plinfo.h"
#include <dlfcn.h>
#include <cstring>
#include <iostream>

struct mutil_funcs_t;
typedef int (*MetaQuery)(char*, plugin_info_t**, mutil_funcs_t*);
static_assert(sizeof(void*) == 4, "Build the metadata probe with -m32 for the GoldSrc library");

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: cs16-version ABSOLUTE_LIBRARY_PATH EXPECTED_VERSION\n";
        return 2;
    }
    void* library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) {
        std::cerr << "FAIL: dlopen: " << dlerror() << '\n';
        return 2;
    }
    dlerror();
    MetaQuery query = reinterpret_cast<MetaQuery>(dlsym(library, "Meta_Query"));
    const char* error = dlerror();
    if (error || !query) {
        std::cerr << "FAIL: Meta_Query unavailable: " << (error ? error : "null symbol") << '\n';
        dlclose(library);
        return 2;
    }
    plugin_info_t* info = nullptr;
    char interfaceVersion[] = "5:13";
    if (!query(interfaceVersion, &info, nullptr) || !info || !info->name || !info->version) {
        std::cerr << "FAIL: Meta_Query returned invalid plugin metadata\n";
        dlclose(library);
        return 2;
    }
    const bool matches = std::strcmp(info->name, "MatchBot CSCO") == 0 &&
                         std::strcmp(info->version, argv[2]) == 0;
    std::cout << (matches ? "PASS" : "FAIL") << ": " << info->name
              << " Plugin_info.version=" << info->version << " expected=" << argv[2] << '\n';
    dlclose(library);
    return matches ? 0 : 1;
}
