<?php
declare(strict_types=1);
// Replay real isolated GameDLL telemetry. Rebind identities, map/hash and clock only.
// This is validator integration, not Steam acceptance or a production match.
define('MQ2_FULL_HELPERS_ONLY',true);
require __DIR__.'/test_matches.php';
use Flute\Modules\MixQueue2\Domain\{Engine,Statistics};

$directory=$argv[1] ?? dirname(__DIR__).'/var/acceptance-060';
foreach (['full','statistics-ot'] as $case) {
    $source=json_decode(file_get_contents($directory.'/feedback-060-'.$case.'.json'),true,512,JSON_THROW_ON_ERROR);
    $nativePlayers=[];
    foreach($source['events'] as $row) if(isset($row['data']['players'])) {$nativePlayers=array_keys($row['data']['players']);break;}
    $size=count($nativePlayers);check(in_array($size,[4,10],true),'Unexpected roster');
    if($case==='full') {
        [$e,$t,$id]=fullFixture(2);
        $maps=$e->ladder('cs16-5v5')['maps'];
        $ob=cs16Status()+['full_test'=>true,'map_inventory'=>['version'=>1,'source'=>'bsp_v30','complete'=>true,'maps'=>$maps]];
        $e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?',[Engine::json($ob),'s1']);
        $rules=json_decode($e->match($id)['rules'],true)+['veto_policy'=>2,'veto_first'=>1];
        $e->db->run('UPDATE mq2_matches SET rules=? WHERE id=?',[Engine::json($rules),$id]);
        $t->start($id,'1');$e->ready('1',$id,true);$e->ready('2',$id,true);
        while(($m=$e->match($id))['state']==='veto') {
            $p=$e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1',[$id,Engine::vetoTeam($m)]);
            $e->ban($p['user_id'],$id,json_decode($m['maps'],true)[0],(int)$m['version']);
        }
        $rules=json_decode($m['rules'],true);
        $p=$e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1',[$id,$rules['side_chooser']]);
        $e->chooseSide($p['user_id'],$id,$rules['side_chooser']===2?'ct':'t',(int)$m['version']);
        $m=$e->match($id);
    } else {
        $e=fixture();$maps=$e->ladder('cs16-2v2')['maps'];
        $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?',['cs16',Engine::json(['modes'=>['2v2'],'maps'=>$maps]),'s1']);
        $ob=cs16Status()+['map_inventory'=>['version'=>1,'source'=>'bsp_v30','complete'=>true,'maps'=>$maps]];
        $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)',['s1',Engine::json($ob),$e->now()]);
        $m=readyMatch($e,'cs16-2v2',4);
    }
    $roster=$e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,user_id',[$m['id']]);
    $map=array_combine($nativePlayers,array_column($roster,'steam_id'));
    $ob['matchid']=$m['id'].':'.$m['generation'];$ob['phase']='warmup';$ob['idle']=false;
    $e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?',[Engine::json($ob),'s1']);
    $sequence=0;$dates=[];$last=[];
    foreach($source['events'] as $row) {
        $row['match_id']=$m['id'];$row['generation']=(int)$m['generation'];$row['sequence']=++$sequence;
        if($row['type']==='loaded') $row['data']=['map'=>$m['picked_map'],'config_hash'=>$e->configuration($m['id'])['config_hash']];
        if(isset($row['data']['steam_id']))$row['data']['steam_id']=$map[$row['data']['steam_id']];
        if(isset($row['data']['players'])) {
            $last=[];foreach($row['data']['players'] as $steam=>$stats)$last[$map[$steam]]=$stats;
            $row['data']['players']=$last;
        }
        if(isset($row['data']['occurred_at']))$row['data']['occurred_at']=$e->now();
        if(isset($row['data']['deadline']))$row['data']['deadline']=$dates[$row['data']['deadline']]??=$e->now()+60;
        check($e->event('s1',$row),$case.': rejected '.$row['type']);
        check(!$e->event('s1',$row),$case.': duplicate '.$row['type']);
    }
    check($e->match($m['id'])['state']==='finished','Not finished');
    foreach($e->db->all('SELECT steam_id,stats FROM mq2_match_players WHERE match_id=?',[$m['id']]) as $p)
        check(json_decode($p['stats'],true)===$last[$p['steam_id']]+['stats_version'=>2],'Native counters altered');
    if($case==='full') {
        check(!$e->db->all('SELECT * FROM mq2_rating_changes'),'Test changed ELO');
        check((new Statistics($e))->profile('1','cs16-5v5')['overall']['played']===0,'Test polluted overall');
    } else {
        check(count($e->db->all('SELECT * FROM mq2_rating_changes'))===4,'Settlement not exactly once');
        $profile=(new Statistics($e))->profile($roster[0]['user_id'],'cs16-2v2');
        check($profile['overall']['metrics']['kast_percent']===Statistics::metrics($last[$roster[0]['steam_id']])['kast_percent'],'KAST aggregate mismatch');
    }
    check(!$e->db->all('SELECT * FROM mq2_penalties'),'Unexpected sanction');
    event($e,$m,'idle');check(!$e->db->all('SELECT * FROM mq2_leases'),'Lease retained');
    echo "PASS native 0.6.0 $case journal: $sequence ordered events, duplicate rejection, exact v2 stats, settlement and idle\n";
}
foreach([1,2] as $first) {
    [$e,$t,$id]=fullFixture(1);
    $ob=json_decode($e->db->one('SELECT payload FROM mq2_observations WHERE server_id=?',['s1'])['payload'],true);
    $ob=array_replace($ob,cs16Status());
    $e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?',[Engine::json($ob),'s1']);
    $r=json_decode($e->match($id)['rules'],true)+['veto_policy'=>2,'veto_first'=>$first];
    $e->db->run('UPDATE mq2_matches SET rules=? WHERE id=?',[Engine::json($r),$id]);
    $t->start($id,'1');$e->ready('1',$id,true);
    while(($m=$e->match($id))['state']==='veto') {
        $p=$e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1',[$id,Engine::vetoTeam($m)]);
        check($p['user_id']==='1','Bot veto stalled');
        $e->ban('1',$id,json_decode($m['maps'],true)[0],(int)$m['version']);
    }
    if($m['state']==='side_selection')$e->chooseSide('1',$id,'t',(int)$m['version']);
    check($e->match($id)['state']==='preparing' && $e->configuration($id)['starting_ct_team']===2,'Bot/owner side choice stalled');
    check(count($e->commands('s1'))===1,'Duplicate full test load');
}
echo "PASS full_test 1+9 bot-captain ban/pick/side choice, both first teams; one load\n";
