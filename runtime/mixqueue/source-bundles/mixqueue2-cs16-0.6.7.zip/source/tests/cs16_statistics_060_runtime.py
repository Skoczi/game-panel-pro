"""0.6.0 isolated GameDLL acceptance. QA entities, NEVER real Steam acceptance."""
import argparse, hashlib, importlib.util, json, os, time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--agent',required=True)
p.add_argument('--mode',choices=['full','ranked','expiry','damage'],default='full');a=p.parse_args()
root=Path(a.root).resolve();assert '/csco-lab/matchbot-060/' in str(root)
spec=importlib.util.spec_from_file_location('agent',a.agent);agent=importlib.util.module_from_spec(spec);spec.loader.exec_module(agent)
rcon=agent.GoldSrcRcon('127.0.0.1',27095,os.environ['MQ2_QA_RCON_PASSWORD']);last=0
def cmd(text):
 global last
 time.sleep(max(0,1.05-(time.monotonic()-last)));value=rcon.command(text);last=time.monotonic();return value
def qa(text):return cmd('mq2_qa '+text)
def obj(text):return json.loads(qa(text))
def status():return json.loads(cmd('mq2_status'))
def snap():return obj('snapshot')
def pause():return obj('pause-state')
def feedback(slot):return [x for x in qa(f'feedback-all {slot}').splitlines() if x!='qa_empty']
def events():return [e for x in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines() if (e:=json.loads(x))['match_id']==mid]
def live():
 until=time.monotonic()+85
 while time.monotonic()<until:
  v=snap()
  if v['round_open'] and not v['freeze'] and not v['lo3']:return v
  qa('fast')
 raise AssertionError(('not live',status(),v))
def wait_pause():
 until=time.monotonic()+30
 while time.monotonic()<until:
  v=pause()
  if v['paused']:return v
 raise AssertionError(('not paused',status(),v))
def clear():
 assert cmd('mq2_clear server_error').endswith('cleared')
 assert status()['idle'] and status()['healthy']
def load(full=True,one=False):
 global mid,generation,players
 if not status()['idle']:clear() # Normal recovery cleanup, never erase history/high-water mark.
 generation=int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text())+1
 mid=('7e5700' if full else '052000')+f'{time.time_ns():018x}'[-18:]
 size=5 if full else 2;players=[]
 for i in range(size*2):
  team=1 if i<size else 2;captain=i in (0,size);bot=full and (not captain or (one and i!=0))
  steam='bot:'+hashlib.sha256(f'{mid}:{generation}:{team}:{i+1}'.encode()).hexdigest()[:24] if bot else str(76561198000000000+i)
  players.append({'steam_id':steam,'team':team,'name':('Neo' if team==1 else 'Forest') if captain else 'Player'+str(i),
                  'bot':bot,'captain':int(captain),'locale':'pl' if team==1 else 'en'})
 payload={'game':'cs16','match_id':mid,'generation':generation,'config_hash':'b'*64,'contract_version':3,'starting_ct_team':2,
          'map':'de_dust2','team_size':size,'teams':{'1':'Neo team','2':'Forest team'},'players':players,
          'rules':{'mr':15 if full else 8,'ot_mr':3,'test':full}}
 if full:payload['rules']['test_type']='full';payload['test_owner']=players[0]['steam_id']
 (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(payload))
 assert cmd(f'mq2_load {mid} {generation}').endswith('loaded'),status()
 for i,row in enumerate(players):
  if not row['bot']:assert qa(f'add {i}')=='qa_added'
 assert not any('Dealt:' in x or 'Zadane:' in x for x in feedback(0))
 qa('ready');v=live();assert status()['restarts_completed']==3
 assert next(x for x in v['clients'] if x['slot']==0)['team']==1
 print('PASS signed starting T/load/ready/3 restarts,',mid,'generation',generation,flush=True)
 return v
def expect_line(slot,text):
 rows=feedback(slot);assert text in rows,(text,rows);return rows
def persist(label):
 (root.parent.parent/f'feedback-060-{label}.json').write_text(json.dumps({'match_id':mid,'generation':generation,'events':events()},indent=2))

assert status()['controller_version']=='0.6.0'
load(False)
qa('damage 2 1 500');qa('damage 0 2 500');qa('damage 0 3 500');time.sleep(1)
e=next(e for e in reversed(events()) if e['type']=='round');s=e['data']['players']
assert s[players[0]['steam_id']]['clutch2']==1,s
assert s[players[0]['steam_id']]['trade_kills']==1 and s[players[1]['steam_id']]['traded_deaths']==1
assert s[players[0]['steam_id']]['multi2']==1 and s[players[0]['steam_id']]['damage']==200
print('PASS actual GameDLL last-kill/clutch 1v2, 5-second trade, traded KAST and capped 200 damage',flush=True)
v=live();qa('armor 2');before=obj('player 2')['hp'];qa('environment 2 he');after=obj('player 2')['hp'];assert 0<before-after<20
qa('eliminate 2');time.sleep(1)
e=next(e for e in reversed(events()) if e['type']=='round');assert e['data']['players'][players[0]['steam_id']]['utility_damage']>0
# Tie regulation 8:8, then MR3 OT 4:2 -> final 12:10. Every elimination uses real TakeDamage.
while sum(status()['score'])<16:
 live();a1,b1=status()['score'];qa('eliminate '+('1' if b1<a1 else '2'))
while status()['phase']!='finished':
 live();a1,b1=status()['score'];qa('eliminate '+('1' if b1<10 else '2'))
 time.sleep(.3)
final=next(e for e in reversed(events()) if e['type']=='finished');assert status()['score']==[12,10]
assert all(x['rounds']==22 for x in final['data']['players'].values()),final
assert sum(x['opening_kills'] for x in final['data']['players'].values())==22
persist('statistics-ot');clear()
print('PASS starting T, regulation swap, OT and OT swap, final 12:10, 22 complete-round snapshots, normal idle',flush=True)
