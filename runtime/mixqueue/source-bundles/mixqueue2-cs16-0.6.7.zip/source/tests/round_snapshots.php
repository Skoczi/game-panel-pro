<?php

declare(strict_types = 1);

define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';

use Flute\Modules\MixQueue2\Domain\{DemoDataset, Engine, RoundSnapshots, Statistics};
use Flute\Modules\MixQueue2\Http\Application;

function snapshotStats(int $round): array
{
    return array_replace(array_fill_keys(Statistics::COUNTERS, 0), [
        'rounds' => $round, 'kills' => $round, 'deaths' => intdiv($round, 2), 'assists' => intdiv($round, 3),
        'headshots' => intdiv($round, 2), 'damage' => $round * 80, 'kast_rounds' => $round
    ]);
}
function snapshotEvent(array $match, array $roster, int $sequence, int $a, int $b, string $type = 'round'): array
{
    return ['event_id' => 'snapshot-' . $sequence, 'match_id' => $match['id'], 'generation' => (int) $match['generation'],
        'sequence' => $sequence, 'type' => $type, 'data' => ['team1_score' => $a, 'team2_score' => $b, 'stats_version' => 2,
            'players' => array_fill_keys(array_column($roster, 'steam_id'), snapshotStats($a + $b))]];
}
$match = ['id' => 'm1', 'generation' => 7, 'team1_score' => 3, 'team2_score' => 1];
$roster = [['user_id' => 'u1', 'steam_id' => 'steam1'], ['user_id' => 'u2', 'steam_id' => 'steam2']];
$r1 = snapshotEvent($match, $roster, 1, 1, 0);
$r3 = snapshotEvent($match, $roster, 3, 2, 1);
$end = snapshotEvent($match, $roster, 4, 3, 1, 'finished');
$events = [$end, $r3, $r1];
$first = RoundSnapshots::project($events, $match, $roster, 1);
check($first['available'] && $first['score'] === [1, 0] && $first['players'][0]['stats']['kills'] === 1, 'Exact cumulative snapshot or sequence ordering failed');
check($first['players'][0]['metrics']['adr'] === 80.0 && $first['players'][0]['metrics']['hs_percent'] === 0.0, 'Snapshot metrics not derived from historical counters');
check(!RoundSnapshots::project($events, $match, $roster, 2)['available'], 'Missing round was interpolated');
check(RoundSnapshots::project($events, $match, $roster, 3)['available'], 'Complete cumulative snapshot following a history gap unavailable');
check(RoundSnapshots::project($events, $match, $roster, 4)['available'], 'Terminal final-round snapshot missing');
$reorderedScore = [snapshotEvent($match, $roster, 1, 2, 0), snapshotEvent($match, $roster, 2, 1, 0)];
check(!RoundSnapshots::project($reorderedScore, $match, $roster, 1)['available'], 'Nonmonotonic signed observation used as a historical round');
check(!RoundSnapshots::project($events, $match + ['state' => 'cancelled'], $roster, 1)['available'], 'Cancelled match exposed unproven drained observations');
$duplicate = snapshotEvent($match, $roster, 2, 1, 0);
$duplicate['data']['players']['steam1']['kills'] = 9;
check(RoundSnapshots::project([$duplicate, ...$events], $match, $roster, 1) === $first, 'Duplicate rewrote a completed round');
$foreign = array_replace($r1, ['generation' => 6, 'sequence' => 0]);
$foreign['data']['players']['steam1']['kills'] = 8;
check(RoundSnapshots::project([$foreign, ...$events], $match, $roster, 1) === $first, 'Foreign generation leaked');
$foreign['generation'] = 7;
$foreign['match_id'] = 'another-match';
check(RoundSnapshots::project([$foreign, ...$events], $match, $roster, 1) === $first, 'Foreign match leaked');
$closed = snapshotEvent($match, $roster, 2, 1, 0, 'test_ended');
check(!RoundSnapshots::project([$r1, $closed, $r3], $match, $roster, 3)['available'], 'Post-terminal observation exposed');
foreach (['missing', 'foreign', 'legacy', 'invalid'] as $case) {
    $bad = $r1;
    if ($case === 'missing') unset($bad['data']['players']['steam2']);
    if ($case === 'foreign') {
        $bad['data']['players']['slot-reused'] = $bad['data']['players']['steam2'];
        unset($bad['data']['players']['steam2']);
    }
    if ($case === 'legacy') $bad['data']['stats_version'] = 1;
    if ($case === 'invalid') $bad['data']['players']['steam1']['damage'] = 'secret';
    $view = RoundSnapshots::project([$bad], $match, $roster, 1);
    check(!$view['available'] && $view['players'] === [] && $view['score'] === [1, 0], "$case telemetry not honestly unavailable");
}
check(array_keys($first) === ['number', 'score', 'available', 'players'] && array_keys($first['players'][0]) === ['user_id', 'stats', 'metrics'], 'Private event metadata exposed');
check(!str_contains(json_encode($first), 'steam'), 'Snapshot exposed Steam identities');
foreach ([0, -1, 401] as $bad) rejects(fn() => RoundSnapshots::project([], $match, $roster, $bad), 'round');
echo "PASS snapshot projection: exact sequence, cumulative gap, duplicate, terminal, generation/match/identity isolation, malformed/legacy unavailable, safe fields\n";

$e = fixture();
$m = readyMatch($e);
live($e, $m);
$roster = $e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,captain DESC,user_id', [$m['id']]);
$r1 = snapshotEvent($m, $roster, 1, 1, 0);
check($e->event('s1', $r1) && !$e->event('s1', $r1), 'Journal retry not idempotent');
$e->event('s1', snapshotEvent($m, $roster, 2, 3, 0));
$e->event('s1', snapshotEvent($m, $roster, 3, 16, 0, 'finished'));
$late = snapshotEvent($m, $roster, 4, 2, 0);
$e->event('s1', $late); // Accepted journal entry after settlement, explicitly never applied.
$e->identify('visitor', '76561198000009999', 'Viewer');
$app = new Application($e);
$base = $app->state('visitor', $m['ladder_id'], $m['id']);
check(!array_key_exists('round_snapshot', $base['match']), 'Unrequested snapshot increased every poll');
$historical = $app->state('visitor', $m['ladder_id'], $m['id'], false, false, 1)['match'];
check($historical['round_snapshot']['available'] && $historical['address'] === null, 'Public snapshot or private connection isolation failed');
check($historical['round_snapshot']['players'][0]['stats']['rounds'] === 1 && $historical['players'][0]['stats']['rounds'] === 16, 'Historical request overwrote final scoreboard');
check(!$app->state('visitor', $m['ladder_id'], $m['id'], false, false, 2)['match']['round_snapshot']['available'], 'Ignored post-settlement event exposed as history');
$before = $e->db->all('SELECT * FROM mq2_match_players WHERE match_id=?', [$m['id']]);
$other = $r1;
$other['data']['players'][$roster[0]['steam_id']]['kills'] = 99;
$e->db->run('INSERT INTO mq2_events VALUES(?,?,?,?,?,?)', ['foreign-server', 'foreign-event', $m['id'], hash('sha256', Engine::json($other)), Engine::json($other), $e->now() - 10]);
$e->db->run('UPDATE mq2_players SET steam_id=? WHERE id=?', ['76561198000111111', $roster[0]['user_id']]);
$repeated = $app->state('visitor', $m['ladder_id'], $m['id'], false, false, 1)['match']['round_snapshot'];
check($repeated === $historical['round_snapshot'], 'Foreign server or current profile identity replaced locked-roster identity');
check($before === $e->db->all('SELECT * FROM mq2_match_players WHERE match_id=?', [$m['id']]), 'Read-only request mutated scoreboard');
check(!str_contains(json_encode($repeated), '76561198'), 'API leaked roster Steam IDs');
echo "PASS snapshot API: opt-in payload, public finished view, final counters unchanged, server filter, immutable roster identities, post-settlement drain excluded\n";

[$e, $tests, $id] = fullFixture(1);
$m = startFull($e, $tests, $id, 1);
$roster = $e->db->all('SELECT user_id,steam_id FROM mq2_match_players WHERE match_id=? ORDER BY team,captain DESC,user_id', [$id]);
$e->event('s1', snapshotEvent($m, $roster, 1, 1, 0));
$e->identify('visitor', '76561198000009999', 'Viewer');
$app = new Application($e);
rejects(fn() => $app->state('visitor', 'cs16-5v5', $id, false, true, 1), 'forbidden');
$owner = $app->state('1', 'cs16-5v5', $id, false, true, 1)['match']['round_snapshot'];
check($owner['available'] && count($owner['players']) === 10, 'Test owner snapshot lost signed bot identities');
check($app->state('visitor', 'cs16-5v5', $id, true, true, 1)['match']['round_snapshot'] === $owner, 'Admin test access differs');
echo "PASS snapshot authorization: private full test rejects outsider, owner/admin retain exact human and bot rows\n";

$profiles = [];
for ($n = 1; $n <= 16; ++$n) $profiles[] = ['id' => (string) $n, 'name' => 'Player ' . $n, 'avatar' => ''];
foreach ([['cs16-5v5', 15], ['cs16-5v5', 12], ['cs16-2v2', 8], ['csgo-5v5', 15]] as [$ladderId, $mr]) {
    $ladder = $e->ladder($ladderId);
    $ladder['rules']['mr'] = $mr;
    $demo = new DemoDataset($ladder, $profiles, 1790622000);
    foreach (['demo-' . $ladderId . '-21', 'demo-' . $ladderId . '-26'] as $matchId) {
        $m = $demo->state('1', $matchId, [])['match'];
        $previous = [];
        foreach ($m['round_timeline'] as $round) {
            $snapshot = $demo->state('1', $matchId, [], $round['number'])['match']['round_snapshot'];
            check($snapshot['available'] && $snapshot['score'] === $round['score'], 'Synthetic timeline/snapshot score mismatch');
            $deaths = $kills = [1 => 0, 2 => 0];
            foreach ($snapshot['players'] as $slot => $player) {
                $stats = $player['stats'];
                if ($ladder['game'] === 'cs16') {
                    $raw = $stats;
                    unset($raw['stats_version']);
                    check(Statistics::validate($raw, $previous[$slot] ?? [], 2, $round['number']) === $stats, 'Synthetic cumulative counters violate V2 contract');
                }
                $team = $m['players'][$slot]['team'];
                $kills[$team] += $stats['kills'];
                $deaths[$team] += $stats['deaths'];
                check($stats['rounds'] === $round['number'] && $stats['deaths'] <= $round['number'], 'Synthetic round participation inconsistent');
                $previous[$slot] = $stats;
            }
            check($kills[1] === $deaths[2] && $kills[2] === $deaths[1], 'Synthetic intermediate kill/death totals inconsistent');
        }
        foreach ($snapshot['players'] as $slot => $player)
            check($player['stats'] === $m['players'][$slot]['stats'] && $player['metrics'] === $m['players'][$slot]['metrics'], 'Synthetic last snapshot differs from overall scoreboard');
        check($m['rules']['mr'] === $mr, 'Demo ignored frozen MR');
    }
}
echo "PASS synthetic snapshots: MR15/MR12/MR8, regulation/OT, every round cumulative and balanced, final scoreboard identical\n";
