"""0.6.2 focused GameDLL round-clock regression, isolated QA entities only.

No Steam-client acceptance is implied. The live 30-second expiry uses the real
engine clock; only LO3/freeze transitions use the existing QA acceleration.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--agent', required=True)
a = p.parse_args()
root = Path(a.root).resolve()
assert '/csco-lab/matchbot-061/' in str(root)
spec = importlib.util.spec_from_file_location('agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', 27095, os.environ['MQ2_QA_RCON_PASSWORD'])
last = 0
evidence = {'controller': '0.6.2', 'acceptance': 'isolated GameDLL QA; no Steam client', 'cases': []}


def cmd(text):
    global last
    time.sleep(max(0, 1.05 - (time.monotonic() - last)))
    value = rcon.command(text)
    last = time.monotonic()
    return value


def qa(text):
    return cmd('mq2_qa ' + text)


def obj(text):
    return json.loads(qa(text))


def status():
    return json.loads(cmd('mq2_status'))


def events():
    return [event for line in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines()
            if (event := json.loads(line))['match_id'] == mid]


def clear():
    assert cmd('mq2_clear server_error').endswith('cleared')
    state = status()
    assert state['idle'] and state['healthy'], state


def live():
    until = time.monotonic() + 85
    while time.monotonic() < until:
        state = obj('snapshot')
        if state['round_open'] and not state['freeze'] and not state['lo3']:
            return state
        qa('fast')  # Existing transition accelerator, never advances active round time.
    raise AssertionError(('not live', status(), state))


def clock(expected):
    state = obj('round-clock')
    assert state['configured_seconds'] == expected, state
    assert state['healthy'], state
    return state


def load(kind):
    global mid, generation, players
    assert status()['idle']
    generation = int((root/'addons/amxmodx/configs/mq2/generation-matchbot.txt').read_text()) + 1
    mid = ('7e5700' if kind == 'full' else '062000') + f'{time.time_ns():018x}'[-18:]
    size = 5 if kind in ('full', 'solo') else 2
    players = []
    for i in range(1 if kind == 'solo' else size * 2):
        team = 1 if i < size else 2
        captain = i in (0, size)
        bot = kind == 'full' and not captain
        steam = ('bot:' + hashlib.sha256(f'{mid}:{generation}:{team}:{i + 1}'.encode()).hexdigest()[:24]
                 if bot else str(76561198000000000 + i))
        players.append({'steam_id': steam, 'team': team,
                        'name': ('Neo' if team == 1 else 'Forest') if captain else 'Player' + str(i),
                        'bot': bot, 'captain': int(captain), 'locale': 'pl' if team == 1 else 'en'})
    payload = {'game': 'cs16', 'match_id': mid, 'generation': generation, 'config_hash': 'c'*64,
               'contract_version': 3, 'starting_ct_team': 2, 'map': 'de_dust2', 'team_size': size,
               'teams': {'1': 'Neo team', '2': 'Forest team'}, 'players': players,
               'rules': {'mr': 15 if size == 5 else 8, 'ot_mr': 3, 'test': kind != 'ranked'}}
    if kind == 'full':
        payload['rules']['test_type'] = 'full'
        payload['test_owner'] = players[0]['steam_id']
    (root/'addons/amxmodx/configs/mq2'/f'{mid}-{generation}.txt').write_text(agent.AmxxAdapter.build(payload))
    assert cmd(f'mq2_load {mid} {generation}').endswith('loaded'), status()
    for i, row in enumerate(players):
        if not row['bot']:
            assert qa(f'add {i}') == 'qa_added'
    warm = obj('round-clock')
    assert warm['healthy'], warm
    raw = cmd('mp_roundtime')
    match = re.search(r'(?:=|is)\s*"([\d.-]+)"', raw)
    assert match and float(match[1]) == 1.75, raw
    assert status()['phase'] == 'warmup'
    qa('ready')
    live()
    assert status()['restarts_completed'] == 3
    return warm


def retain(label, clocks):
    evidence['cases'].append({'case': label, 'match_id': mid, 'generation': generation,
                              'clocks': clocks, 'events': events()})
    (root.parent.parent/'roundtime-062-proof.json').write_text(json.dumps(evidence, indent=2))


assert status()['controller_version'] == '0.6.2'
if not status()['idle']:
    clear()  # Normal cleanup, retaining durable history and generation high-water mark.

warm = load('full')
first = clock(30)
started = time.monotonic()
initial_remaining = first['remaining']
assert not first['freeze'] and 20 < initial_remaining <= 30, first
assert not [row for row in events() if row['type'] == 'round']
while time.monotonic() - started < 38:
    if [row for row in events() if row['type'] == 'round']:
        break
    time.sleep(.25)
elapsed = time.monotonic() - started
rounds = [row for row in events() if row['type'] == 'round']
assert len(rounds) == 1, rounds
assert abs(elapsed - initial_remaining) < 2.5, (elapsed, initial_remaining)
assert [rounds[0]['data']['team1_score'], rounds[0]['data']['team2_score']] == [0, 1], rounds[0]
print('PASS full-test engine clock30s and one natural timeout round, elapsed', round(elapsed, 2), flush=True)

until = time.monotonic() + 15
while time.monotonic() < until:
    state = obj('snapshot')
    if state['freeze'] and not state['round_open']:
        break
assert state['freeze'] and not state['round_open'], state
second = clock(30)
stable = obj('player 5')
qa('talk 0 pause')
assert obj('pause-state')['paused']
assert status()['score'] == [0, 1]
qa('talk 0 unpause')
qa('talk 5 unpause')
assert not obj('pause-state')['paused']
assert obj('player 5') == stable
assert status()['score'] == [0, 1]
live()
resumed = clock(30)
assert sum(row['type'] == 'round' for row in events()) == 1
assert sum(row['type'] == 'resume' for row in events()) == 1
retain('full_test_natural_timeout_next_round_pause', [warm, first, second, resumed])
clear()
print('PASS next round and tactical resume retain30s, score and equipment; cleanup healthy idle', flush=True)

warm = load('ranked')
ranked = clock(105)
assert not ranked['freeze'] and ranked['remaining'] > 90, ranked
retain('ranked_after_full_test', [warm, ranked])
clear()
print('PASS next ranked assignment keeps105s, no test duration leaks across cleanup', flush=True)

warm = load('solo')
solo = clock(30)
assert not solo['freeze'] and 20 < solo['remaining'] <= 30, solo
retain('solo_test', [warm, solo])
clear()
print('PASS solo-test engine duration30s, warmup105s and normal cleanup; journal/generations preserved', flush=True)
