#include "../games/cs16/matchbot/MatchBot/MatchCSCOObservers.h"
#include <cassert>
#include <iostream>
#include <functional>

static const std::string id="1234567890abcdef12345678",steam="76561198000000001",other="76561198000000002";
static std::string payload(unsigned revision=1,unsigned generation=9,unsigned expiry=1300,const std::string& rows="") {
    return "MQ2OBS1 "+id+" "+std::to_string(generation)+" "+std::to_string(revision)+" "+std::to_string(expiry)+"\n"+rows;
}
static void rejects(const std::string& body,const char* code="observer_invalid") {
    bool rejected=false;
    try {mq2::parse_observers(body,id,9,1,1000);} catch(const std::runtime_error& ex) {rejected=std::string(ex.what())==code;}
    assert(rejected);
}
int main() {
    const auto rows=steam+" admin 1 1300 pl\n"+other+" commentator 0 1100 en\n";
    auto first=mq2::parse_observers(payload(1,9,1300,rows),id,9,1,1000);
    assert(first.grants.size()==2);
    assert(first.find(steam,1000)->xray);
    assert(first.find(other,1099) && !first.find(other,1100));
    assert(!first.find(steam,1300));
    assert(!first.find(steam,1001,true)); // Playing admin never receives spectator rights.
    assert(!first.find("BOT",1001) && !first.find("HLTV",1001));
    assert(!first.find("",1001) && !first.find("STEAM_ID_PENDING",1001));
    assert(mq2::steam64("STEAM_0:1:19867136")==steam);
    mq2::ObserverSnapshot current;
    assert(std::string(mq2::apply_observers(current,first))=="observer_updated");
    assert(std::string(mq2::apply_observers(current,first))=="observer_already_updated");
    auto collision=mq2::parse_observers(payload(1,9,1300,other+" admin 1 1300 en\n"),id,9,1,1000);
    assert(std::string(mq2::apply_observers(current,collision))=="observer_stale");
    assert(current.find(steam,1001)); // Rejected snapshot never mutates current permissions.
    auto revoked=mq2::parse_observers(payload(2),id,9,2,1000);
    assert(std::string(mq2::apply_observers(current,revoked))=="observer_updated");
    assert(!current.find(steam,1001));
    assert(std::string(mq2::apply_observers(current,first))=="observer_stale");
    auto generation=mq2::parse_observers(payload(3,10),id,10,3,1000);
    assert(std::string(mq2::apply_observers(current,generation))=="observer_scope");
    current=mq2::ObserverSnapshot(); // map change/recovery reset is fail closed.
    assert(!current.find(steam,1000));
    rejects(payload(1,10),"observer_scope");
    rejects(payload(2),"observer_scope");
    rejects(payload(1,9,1000));rejects(payload(1,9,1601));
    rejects(payload(1,9,1300,steam+" admin 1 1301 pl\n"));
    rejects(payload(1,9,1300,steam+" admin 1 1000 pl\n"));
    rejects(payload(1,9,1300,rows+steam+" admin 1 1300 pl\n"));
    rejects(payload(1,9,1300,steam+" owner 1 1300 pl\n"));
    rejects(payload(1,9,1300,steam+" admin 2 1300 pl\n"));
    rejects(payload(1,9,1300,steam+" admin 1 1300 de\n"));
    rejects(payload(1,9,1300,"BOT admin 1 1300 en\n"));
    rejects(payload(1,9,1300,"76561197960265727 admin 1 1300 en\n"));
    rejects(payload(1,9,1300,"76561197960265728 admin 1 1300 en\n"));
    rejects(payload(1,9,1300,"76561202255233024 admin 1 1300 en\n"));
    rejects(payload()+std::string(8200,'x'));
    rejects("MQ2OBS1 "+id+" 9 1 2147483648\n");
    rejects("MQ2OBS1 "+id+" -9 1 1300\n");
    rejects("MQ2OBS1 "+id+" 9 1 1300 unexpected\n");
    std::string many;
    for(unsigned i=0;i<17;++i) many+=std::to_string(76561198000000000ULL+i)+" admin 0 1300 en\n";
    rejects(payload(1,9,1300,many));
    std::cout<<"observer contracts: identities, roster precedence, roles, expiry, replay, revocation and scope passed\n";
}
