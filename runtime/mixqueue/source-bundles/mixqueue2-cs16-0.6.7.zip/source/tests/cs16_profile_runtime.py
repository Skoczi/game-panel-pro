"""Headless HLDS QA on an isolated test instance, never on a live game server.

First run without --harness against the release binary. Then install the QA-only
cs16_runtime_harness.amxx build to check phase transitions and synthetic scores.
This does not certify player authentication, team spawning or a real 5v5 match.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import time

p = argparse.ArgumentParser()
p.add_argument('--game-root', required=True)
p.add_argument('--agent', required=True)
p.add_argument('--port', type=int, default=27095)
p.add_argument('--harness', action='store_true')
a = p.parse_args()
spec = importlib.util.spec_from_file_location('mq_agent', a.agent)
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)
rcon = agent.GoldSrcRcon('127.0.0.1', a.port, os.environ['MQ2_QA_RCON_PASSWORD'])
root = Path(a.game_root)

def command(text):
    value=rcon.command(text)
    time.sleep(1.05)
    return value

def status():
    raw=command('mq2_status')
    assert raw.startswith('{'), repr(raw)
    return json.loads(raw)

def until(fn, seconds=12):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if fn(): return
        time.sleep(.2)
    raise AssertionError('State transition timed out: ' + json.dumps(status()))

def cvar(name, expected):
    value = command(name)
    match = re.search(r'(?:=|is)\s*"([\d.-]+)"', value)
    assert match and abs(float(match[1]) - expected) < .001, (name, expected, value)

def profile(phase, money, freeze, buy, respawn, ff):
    value = status()
    assert value['profile'] == 'cs16-classic-v1' and value['rules_phase'] == phase and value['rules_ready'], value
    for name, expected in {'mp_startmoney':money,'mp_freezetime':freeze,'mp_buytime':buy,'mp_roundtime':1.75,'mp_c4timer':35,'mp_friendlyfire':ff,'mp_maxrounds':0,'mp_timelimit':0,'sv_cheats':0}.items():
        cvar(name, expected)
    if 'is' in command('mp_forcerespawn'):
        cvar('mp_forcerespawn', 0)
        cvar('mp_round_infinite', 1 if phase=='warmup' else 0)

def load(number, size=5, mr=None, solo=False):
    mid = f'{time.time_ns()+number:024x}'
    payload = {'match_id':mid,'generation':1,'config_hash':'b'*64,'game':'cs16','team_size':size,'mode':f'{size}v{size}','map':'de_dust2','rules':{'mr':mr or (15 if size==5 else 8),'ot_mr':3},'players':[{'steam_id':str(76561198000000000+i),'team':1 if i<size else 2} for i in range(size*2)]}
    if solo:
        payload['rules']['test'] = True
        payload['players'] = payload['players'][:1]
    cfg = root/'addons/amxmodx/configs/mq2'/f'{mid}-1.txt'
    cfg.write_text(agent.AmxxAdapter.build(payload))
    command(f'mq2_load {mid} 1')
    return mid

def round_win(team):
    old = status()
    result = command(f'mq2_qa_round {team}')
    assert 'qa_not_ready' not in result
    new = status()
    assert new['score'][team] == old['score'][team] + 1, new
    total = sum(new['score'])
    if new['phase'] == 'live' and (total==15 or total>=30 and (total-30)%3==0):
        # Real HLDS restart at half boundaries, no synthetic round_start calls.
        time.sleep(4.3)
    return new

assert '0.3.0' in command('amxx plugins')
print('RUNTIME', command('version').strip().splitlines()[0])
print('GAMEDLL', command('game version').strip())
command('mq2_clear')
profile('idle',800,10,.25,0,1)
mid=load(1)
profile('warmup',16000,0,1.75,2,0)
command('mp_c4timer 45')
assert status()['rules_ready'] is False
command('mq2_clear')
profile('idle',800,10,.25,0,1)
print('PASS release: warmup, effective rules, drift detection and cleanup')
solo_id=load(3, solo=True)
assert status()['matchid']==solo_id+':1' and status()['solo_test'] is True
command('mq2_clear')
assert status()['idle'] is True
print('PASS release: single-player test config accepted and cleaned up')

if a.harness:
    mid=load(2)
    # Allow the queued warmup restart to complete before simulating player readiness.
    time.sleep(2)
    command('mq2_qa_live')
    until(lambda: status()['phase']=='live')
    profile('live',800,10,.25,0,1)
    for _ in range(15): round_win(0)
    profile('live',800,10,.25,0,1)
    for _ in range(15): round_win(1)
    profile('overtime',10000,10,.25,0,1)
    # Tied first OT must continue. Second overtime ends at 22:20.
    for team in [0,1,0,1,0,1, 0,1,0,1,0,0]: final=round_win(team)
    assert final['phase']=='finished' and final['score']==[22,20], final
    events=[json.loads(line) for line in (root/'addons/amxmodx/data/mq2/events.jsonl').read_text().splitlines()]
    assert len([e for e in events if e['match_id']==mid and e['type']=='live'])==1
    finishes=[e for e in events if e['match_id']==mid and e['type']=='finished']
    assert len(finishes)==1 and finishes[0]['data']['team1_score']==22
    command('mq2_clear')
    profile('idle',800,10,.25,0,1)
    print('PASS controller: real restart into live, halftime, repeat overtime, final journal and cleanup')
