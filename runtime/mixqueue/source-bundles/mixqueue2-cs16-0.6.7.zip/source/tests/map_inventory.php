<?php

declare(strict_types = 1);

define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';
use Flute\Modules\MixQueue2\Domain\{Engine, MapInventory, LoadFailure, ServerTests};
use Flute\Modules\MixQueue2\Http\AgentApi;

function inventory(Engine $e, array $maps, bool $complete = true): void
{
    $row = $e->db->one('SELECT payload FROM mq2_observations WHERE server_id=?', ['s1']);
    $ob = json_decode($row['payload'], true);
    $ob['map_inventory'] = ['version' => 1, 'source' => 'bsp_v30', 'complete' => $complete, 'maps' => $maps];
    $e->db->run('UPDATE mq2_observations SET payload=?,observed_at=? WHERE server_id=?', [
        Engine::json($ob),
        $e->now(),
        's1'
    ]);
}

[$e, $t, $id] = fullFixture(1);
$t->stop($id, '1');
$maps = $e->ladder('cs16-5v5')['maps'];
$four = array_slice($maps, 0, 4);
inventory($e, $four);
$next = $t->create('1', 's1');
check(
    json_decode($e->match($next)['maps'], true) === [$four[0], $four[2], $four[3]],
    'Veto used unverified map / wrong odd subset'
);
$view = ( new \Flute\Modules\MixQueue2\Http\Application($e) )->state('1', 'cs16-5v5', $next, true);
check($view['match']['all_maps'] === [$four[0], $four[2], $four[3]], 'UI leaked excluded maps');
$t->stop($next, '1');
inventory($e, $maps, false);
rejects(fn() => $t->create('1', 's1'), 'map_inventory');
inventory($e, array_slice($maps, 0, 2));
rejects(fn() => $t->create('1', 's1'), 'test_maps');
inventory($e, $maps);
$e->db->run('UPDATE mq2_observations SET observed_at=?', [$e->now() - 31]);
rejects(fn() => $t->create('1', 's1'), 'test_server');
inventory($e, ['de_nuke', 'de_dust2', '../secret']);
rejects(fn() => $t->create('1', 's1'), 'map_inventory');
echo "PASS fresh verified inventory, odd subset, invalid/stale/missing inventory, UI veto scope\n";

foreach (array_keys(LoadFailure::MESSAGES) as $code) {
    [$e, $t, $id] = fullFixture(1);
    $m = startFull($e, $t, $id, 1, false);
    $gen = $m['generation'];
    rejects(fn() => event($e, $m, 'load_rejected', ['code' => '/private/secrets']), 'load_rejection');
    $ev = event($e, $m, 'load_rejected', ['code' => $code]);
    check($e->match($id)['state'] === 'cancelled', 'Explicit failure did not cancel');
    check($e->match($id)['reason'] === 'load_rejected:' . $code, 'Safe diagnostic lost');
    check(!!$e->db->all('SELECT * FROM mq2_leases'), 'Lease released without idle proof');
    check(!$e->event('s1', $ev), 'Rejection replay applied twice');
    check(count($e->commands('s1')) === 1, 'Abort missing or load not superseded');
    $loaded = ['map' => $m['picked_map'], 'config_hash' => $e->configuration($id)['config_hash']];
    event($e, $m, 'loaded', $loaded); // Delayed journal drains after cancellation.
    check($e->match($id)['state'] === 'cancelled', 'Delayed loaded revived cancelled match');
    event($e, $m, 'idle');
    check(!$e->db->all('SELECT * FROM mq2_leases'), 'Idle did not release');
    check(
        $e->match($id)['generation'] === $gen && count($e->db->all('SELECT * FROM mq2_events')) === 3,
        'History/generation damaged'
    );
    check(
        !$e->db->all('SELECT * FROM mq2_penalties') && !$e->db->all('SELECT * FROM mq2_ratings'),
        'Failure affected test rating/penalty'
    );
}
echo "PASS all safe rejection codes, retries, late loaded drain, abort/idle release, history/generation preservation\n";

[$e, $t, $id] = fullFixture(1);
$m = startFull($e, $t, $id, 1, true);
event($e, $m, 'load_rejected', ['code' => 'server_busy']);
check($e->match($id)['state'] === 'live', 'Delayed rejection cancelled journal-confirmed gameplay');
echo "PASS loaded journal is acceptance authority\n";

[$e, $t, $id] = fullFixture(1);
$t->start($id, '1');
$e->ready('1', $id, true);
// Remove every candidate while the captain is deciding. No stale-map load may be sent.
inventory($e, []);
while (( $m = $e->match($id) )['state'] === 'veto') {
    $captain = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND captain=1 AND team=?', [
        $id,
        Engine::vetoTeam($m)
    ]);
    $e->ban($captain['user_id'], $id, json_decode($m['maps'], true)[0], (int) $m['version']);
}
check($e->match($id)['state'] === 'cancelled', 'Map removal after veto not cancelled');
check(!$e->db->all('SELECT * FROM mq2_commands WHERE type=?', ['load']), 'Absent map dispatched');
event($e, $m, 'idle');
echo "PASS map disappears after lobby/veto: normal cancellation and idle release\n";

// Ranked allocation is also gated, with no legacy-config bypass.
[$e, $t, $id] = fullFixture(1);
$t->stop($id, '1');
inventory($e, $four);
$ob=json_decode($e->db->one('SELECT payload FROM mq2_observations WHERE server_id=?',['s1'])['payload'],true);
$ob=array_replace($ob,cs16Status());
$e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?',[Engine::json($ob),'s1']);
for ($i = 1; $i <= 10; $i++)
    $e->join((string) $i, 'cs16-5v5');
check($e->tick() === 1, 'Ranked fixture not allocated');
$rankedId = $e->db->one('SELECT id FROM mq2_matches WHERE state=?', ['ready'])['id'];
for ($i = 1; $i <= 10; $i++)
    $e->ready((string) $i, $rankedId, true);
while (( $m = $e->match($rankedId) )['state'] === 'veto') {
    $captain = $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND captain=1 AND team=?', [
        $rankedId,
        Engine::vetoTeam($m)
    ]);
    $e->ban($captain['user_id'], $rankedId, json_decode($m['maps'], true)[0], (int) $m['version']);
}
check(in_array($m['picked_map'], $four, true), 'Ranked map not verified');
if ($m['state'] === 'side_selection') {
    $rules=json_decode($m['rules'],true);
    $cap=$e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1',[$m['id'],$rules['side_chooser']]);
    $e->chooseSide($cap['user_id'],$m['id'],'ct',(int)$m['version']);$m=$e->match($m['id']);
}
$e->cancel($m['id'], 'admin', 'Test complete');
event($e, $m, 'idle');
inventory($e, $maps, false);
for ($i = 1; $i <= 10; $i++)
    $e->join((string) $i, 'cs16-5v5');
check($e->tick() === 0, 'Ranked allocation accepted unverified inventory');
echo "PASS ranked pool uses same inventory gate\n";

// Solo follows the same safe failure/idle lifecycle.
[$e, $t, $id] = fullFixture(1);
$t->stop($id, '1');
$solo = new ServerTests($e);
$session = $solo->start('s1', '1', $maps[0]);
$ev = [
    'match_id' => $session['id'],
    'generation' => (int) $session['generation'],
    'event_id' => Engine::id(),
    'sequence' => 1,
    'type' => 'load_rejected',
    'data' => ['code' => 'missing_map']
];
$e->event('s1', $ev);
check($solo->find($session['id'])['state'] === 'stopping', 'Solo did not abort');
$ev['event_id'] = Engine::id();
$ev['sequence'] = 2;
$ev['type'] = 'idle';
$ev['data'] = [];
$e->event('s1', $ev);
check(
    $solo->find($session['id'])['state'] === 'ended' && !$e->db->all('SELECT * FROM mq2_leases'),
    'Solo lease not released'
);
echo "PASS solo rejection and idle release\n";
