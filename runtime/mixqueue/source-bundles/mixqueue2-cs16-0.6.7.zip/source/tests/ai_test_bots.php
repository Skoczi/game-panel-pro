<?php

declare(strict_types = 1);

define('MQ2_FULL_HELPERS_ONLY', true);
require __DIR__ . '/test_matches.php';

use Flute\Modules\MixQueue2\Domain\{Engine, LoadFailure, ServerTests, Statistics};
use Flute\Modules\MixQueue2\Http\{AgentApi, Locale};

// Exercise the production locale resolver without booting the Flute web runtime.
function app(): object
{
    return new class {
        public function getLang(): string
        {
            return $GLOBALS['mq2_ai_test_locale'];
        }
    };
}

function aiEvent(Engine $e, array $session, string $type, int $sequence, array $data = []): array
{
    return [
        'event_id' => Engine::id(),
        'match_id' => $session['id'],
        'generation' => (int) $session['generation'],
        'schema_version' => 1,
        'boot_id' => str_repeat('c', 32),
        'sequence' => $sequence,
        'type' => $type,
        'data' => $data
    ];
}

function signedAiEvent(Engine $e, array $event): bool
{
    $raw = Engine::json(['action' => 'event', 'event' => $event]);
    $key = str_repeat('x', 32);
    $stamp = (string) $e->now();
    $result = ( new AgentApi($e, ['s1' => $key]) )->handle(
        's1',
        $stamp,
        hash_hmac('sha256', "s1\n$stamp\n$raw", $key),
        $raw
    );
    return $result['accepted'];
}

$messages = [
    'test_ai_disabled' => 'AI bots are not enabled on the test server.',
    'test_bot_profiles_missing' => 'The server is missing AI bot profiles.',
    'test_bot_nav_missing' => 'The selected map has no navigation for AI bots.',
    'test_bot_nav_invalid' => 'AI bot navigation does not match the selected map or is damaged.'
];

foreach ($messages as $code => $english) {
    [$e, $full, $lobby] = fullFixture(1);
    $full->stop($lobby, '1');
    $solo = new ServerTests($e);
    $map = $e->ladder('cs16-5v5')['maps'][0];
    $session = $solo->start('s1', '1', $map);
    $generation = (int) $session['generation'];
    $ratings = $e->db->all('SELECT * FROM mq2_ratings');
    $ev = aiEvent($e, $session, 'load_rejected', 1, ['code' => $code]);
    $foreign = $ev;
    $foreign['generation']++;
    rejects(fn() => signedAiEvent($e, $foreign), 'lease');
    check(signedAiEvent($e, $ev), 'Signed AI rejection was not accepted');
    check(!signedAiEvent($e, $ev), 'AI rejection retry applied twice');
    $stopping = $solo->find($session['id']);
    $details = json_decode($stopping['details'], true);
    check($stopping['state'] === 'stopping', 'AI failure did not stop solo preparation');
    check($details['stop_reason'] === 'load_rejected:' . $code, 'AI diagnostic was lost');
    check(!!$e->db->all('SELECT * FROM mq2_leases'), 'AI failure released without idle');
    $commands = $e->commands('s1');
    check(count($commands) === 1 && $commands[0]['type'] === 'abort', 'AI failure did not supersede load with abort');
    check($commands[0]['payload']['reason'] === 'server_error', 'AI failure used wrong abort reason');

    $polish = LoadFailure::message($details['stop_reason']);
    $GLOBALS['mq2_ai_test_locale'] = 'pl';
    check(Locale::text($polish) === LoadFailure::MESSAGES[$code], 'Missing Polish AI diagnostic');
    $GLOBALS['mq2_ai_test_locale'] = 'en';
    check(Locale::text($polish) === $english, 'Missing English AI diagnostic: ' . $code);

    // Submission rejection wins until loaded has been confirmed; late journals drain.
    signedAiEvent($e, aiEvent($e, $session, 'loaded', 2));
    check($solo->find($session['id'])['state'] === 'stopping', 'Late loaded revived rejected AI test');
    $idle = aiEvent($e, $session, 'idle', 3);
    check(signedAiEvent($e, $idle) && !signedAiEvent($e, $idle), 'AI idle was not idempotent');
    $ended = $solo->find($session['id']);
    check($ended['state'] === 'ended' && !$e->db->all('SELECT * FROM mq2_leases'), 'AI idle did not release server');
    check((int) $ended['generation'] === $generation, 'AI failure reset generation');
    check(
        count($e->db->all('SELECT * FROM mq2_events WHERE match_id=?', [$session['id']])) === 3,
        'AI event history was lost'
    );
    check($e->db->all('SELECT * FROM mq2_ratings') === $ratings, 'AI rejection changed ELO');
    check(!$e->db->all('SELECT * FROM mq2_penalties'), 'AI rejection penalized player');
    check(!$e->db->all('SELECT * FROM mq2_settlements'), 'AI rejection created settlement');
    check(
        ( new Statistics($e) )->profile('1', 'cs16-5v5')['overall']['played'] === 0,
        'AI rejection polluted overall stats'
    );
    $next = $solo->start('s1', '1', $map);
    check((int) $next['generation'] === ( $generation + 1 ), 'Retry reused AI assignment generation');
    $solo->stop($next['id'], '1');
    signedAiEvent($e, aiEvent($e, $next, 'idle', 1));
    check(!!$solo->find($session['id']), 'Next AI test removed previous history');
    echo
        "PASS $code: signed solo rejection, PL/EN diagnostic, duplicate/stale/late delivery, abort/idle, history, no ELO/penalty\n"
    ;
}

check(LoadFailure::message('load_rejected:/private/path') === null, 'Untrusted controller text exposed as diagnostic');
echo "PASS AI diagnostic whitelist prevents private/raw output\n";
