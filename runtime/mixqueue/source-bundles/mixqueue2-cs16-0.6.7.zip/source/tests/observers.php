<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';

use Flute\Modules\MixQueue2\Domain\{Engine, Observers};
use Flute\Modules\MixQueue2\Http\Application;

function observerFixture(): array
{
    $e = fixture(12);
    $m = readyMatch($e);
    live($e, $m);
    $e->db->run('UPDATE mq2_matches SET ladder_id=? WHERE id=?', ['cs16-5v5', $m['id']]);
    $e->db->run('UPDATE mq2_servers SET game=? WHERE id=?', ['cs16', 's1']);
    return [$e, $e->match($m['id'])];
}

function observerStatus(Engine $e, array $m, array $changes = []): void
{
    $status = [...cs16Status(), 'healthy' => true, 'idle' => false,
        'matchid' => $m['id'] . ':' . $m['generation'], 'observer_agent_version' => 1,
        'observer_acl_version' => 1, 'observer_revision' => 0, 'observer_expires_at' => 0, 'observer_slots' => 2, ...$changes];
    $e->db->run('DELETE FROM mq2_observations WHERE server_id=?', [$m['server_id']]);
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', [$m['server_id'], Engine::json($status), $e->now()]);
    $e->db->run('UPDATE mq2_servers SET healthy=1,seen_at=? WHERE id=?', [$e->now(), $m['server_id']]);
}

function observerInput(Engine $e, array $m, array $changes = []): array
{
    return ['steam_id' => $e->player('11')['steam_id'], 'scope' => 'match', 'match_id' => $m['id'],
        'role' => 'commentator', 'xray' => false, 'duration' => 3600, 'locale' => 'pl',
        'source' => 'manual', 'reason' => 'Approved broadcast observer', ...$changes];
}

function observerState(Engine $e, array $m): array
{
    return $e->db->one('SELECT * FROM mq2_observer_states WHERE match_id=?', [$m['id']]);
}

function observerAck(Engine $e, array $m): array
{
    $state = observerState($e, $m);
    observerStatus($e, $m, ['observer_revision' => (int) $state['revision'], 'observer_expires_at' => (int) $state['expires_at']]);
    (new Observers($e))->tick();
    return $state;
}

[$e, $m] = observerFixture();
$o = new Observers($e);
$input = observerInput($e, $m);
rejects(fn() => $o->grant('1', $input), 'forbidden');
check(!$e->db->all('SELECT * FROM mq2_observer_grants'), 'Unauthorized grant persisted');
check(Observers::steam64('STEAM_0:1:1') === '76561197960265731', 'Steam2 conversion');
check(Observers::steam64('STEAM_1:1:2147483647') === '76561202255233023', 'Upper Steam2 conversion');
check(Observers::steam64('76561202255233023') === '76561202255233023', 'Future individual Steam range');
rejects(fn() => Observers::steam64('STEAM_ID_PENDING'), 'observer_steam');
rejects(fn() => Observers::steam64('STEAM_0:1:9999999999'), 'observer_steam');
rejects(fn() => $o->grant('1', [...$input, 'xray' => 1], true), 'observer_fields');
rejects(fn() => $o->grant('1', [...$input, 'role' => 'rcon'], true), 'observer_fields');
rejects(fn() => $o->grant('1', [...$input, 'match_id' => 'missing'], true), 'observer_match');
rejects(fn() => $o->grant('1', [...$input, 'steam_id' => $e->player('1')['steam_id'], 'role' => 'admin'], true), 'observer_roster');
$grant = $o->grant('1', $input, true);
check($o->access($m, $input['steam_id'])['state'] === 'unsupported', 'Offline controller accepted');
observerStatus($e, $m, ['observer_agent_version' => 0]);
$o->tick();
check(!$e->db->all("SELECT * FROM mq2_commands WHERE type='observer_update'"), 'Old agent received unsupported command');
observerStatus($e, $m);
$o->tick();
$first = observerState($e, $m);
check((int) $first['revision'] === 1, 'Initial revision');
$payload = json_decode($first['payload'], true);
check(count($payload['observers']) === 1 && $payload['observers'][0]['expires_at'] === $e->now() + 300, 'Bounded snapshot');
check($o->access($m, $input['steam_id'])['state'] === 'pending', 'No native acknowledgement');
$app = new Application($e);
check($app->state('11', 'cs16-5v5', $m['id'])['match']['address'] === null, 'Pending grant leaked connection');
observerAck($e, $m);
check($o->access($m, $input['steam_id'])['state'] === 'ready', 'Native ack ignored');
check($o->access($m, $input['steam_id'])['admission_until'] === $e->now() + 300, 'Browser admission outlives native lease');
observerStatus($e, $m, ['observer_revision' => 1, 'observer_expires_at' => $e->now() + 300, 'observer_slots' => 0]);
check($o->access($m, $input['steam_id'])['state'] === 'no_slots', 'Zero spectator capacity presented as ready');
check($app->state('11', 'cs16-5v5', $m['id'])['match']['address'] === null, 'Zero-capacity server exposes observer connect');
check($o->panel()['matches'][0]['observer_state'] === 'no_slots', 'Panel hides no-slots condition');
observerAck($e, $m);
check($app->state('11', 'cs16-5v5', $m['id'])['match']['address'] === '127.0.0.1:27015', 'Authorized observer missing address');
check($app->state('12', 'cs16-5v5', $m['id'], true)['match']['address'] === null, 'Admin flag bypassed observer grant');
check($app->state('1', 'cs16-5v5', $m['id'], true)['match']['observer'] === null, 'Roster exposed observer role');
$globalRoster = $o->grant('1', [...$input, 'steam_id' => $e->player('1')['steam_id'], 'scope' => 'global', 'role' => 'admin', 'xray' => true], true);
check(count($o->effective($m['id'])) === 1, 'Global administrator bypassed roster exclusion');
check($e->match($m['id'])['state'] === 'live' && count($e->db->all('SELECT * FROM mq2_match_players')) === 10, 'Observer mutated match or roster');
$o->tick();
check((int) observerState($e, $m)['revision'] === 1, 'Unchanged ACL generated duplicate revision');
rejects(fn() => $o->revoke('11', $grant, 'Unauthorized revocation'), 'forbidden');
$o->revoke('1', $grant, 'Broadcast access ended', true);
$revoked = observerState($e, $m);
check((int) $revoked['revision'] === 2 && json_decode($revoked['payload'], true)['observers'] === [], 'Revoke did not enqueue empty ACL');
check($app->state('11', 'cs16-5v5', $m['id'])['match']['address'] === null, 'Revoked access remains visible');
check((int) $e->db->one('SELECT revoked_at FROM mq2_observer_grants WHERE id=?', [$grant])['revoked_at'] > 0, 'Revoke lost history');
observerAck($e, $m);
observerStatus($e, $m); // Controller lost runtime ACL after map activation.
$o->tick();
check((int) observerState($e, $m)['revision'] === 3, 'Runtime ACL loss not reissued');
$o->tick();
check((int) observerState($e, $m)['revision'] === 3, 'Unacked controller reset caused revision storm');
echo "PASS observer permissions, identity validation, old-agent gate, native confirmation, connection privacy, roster exclusion, revoke and restart replay\n";

[$e, $m] = observerFixture();
$o = new Observers($e);
$input = observerInput($e, $m);
observerStatus($e, $m);
$specific = $o->grant('1', $input, true);
$other = $m;
$other['id'] = Engine::id();
$e->db->run('INSERT INTO mq2_matches(' . implode(',', array_keys($other)) . ') VALUES(' . implode(',', array_fill(0, count($other), '?')) . ')', array_values($other));
check($o->effective($other['id']) === [], 'Per-match grant leaked to another match');
$global = $o->grant('1', [...$input, 'scope' => 'global', 'role' => 'admin', 'xray' => true], true);
check($o->effective($m['id'])[0]['role'] === 'commentator' && !$o->effective($m['id'])[0]['xray'], 'Match override lost');
check($o->effective($other['id'])[0]['role'] === 'admin', 'Global grant unavailable in other match');
$o->revoke('1', $specific, 'Keep global observer policy', true);
check($o->effective($m['id'])[0]['xray'], 'Global fallback after scoped revoke');
$replacement = $o->grant('1', [...$input, 'scope' => 'global'], true);
check((int) $e->db->one('SELECT revoked_at FROM mq2_observer_grants WHERE id=?', [$global])['revoked_at'] > 0, 'Replacement failed to preserve old row');
check(count($o->effective($m['id'])) === 1 && !$o->effective($m['id'])[0]['xray'], 'Duplicate global grants or stale permission');
$ack = observerAck($e, $m);
$later = new Engine($e->db, fn() => $e->now() + 61);
observerStatus($later, $m, ['observer_revision' => (int) $ack['revision'], 'observer_expires_at' => (int) $ack['expires_at']]);
(new Observers($later))->tick();
check((int) observerState($later, $m)['revision'] === (int) $ack['revision'] + 1, 'Lease was not renewed');
$expired = new Engine($e->db, fn() => $e->now() + 3601);
observerStatus($expired, $m);
(new Observers($expired))->tick();
check((new Observers($expired))->effective($m['id']) === [] && !(new Observers($expired))->hasGrant($input['steam_id']), 'Expired grant remained effective');
check(json_decode(observerState($expired, $m)['payload'], true)['observers'] === [], 'Expired grant not removed from snapshot');
check(count($e->db->all("SELECT * FROM mq2_audit WHERE action LIKE 'observer.%'")) === 5, 'Missing grant/revoke/replace audits');
echo "PASS observer match/global scope, explicit scope override, replacement audit, bounded renewal, grant expiry\n";

[$e, $m] = observerFixture();
$o = new Observers($e);
for ($i = 1; $i <= 16; ++$i)
    $o->grant('1', observerInput($e, $m, ['steam_id' => (string) (76561198012345000 + $i), 'scope' => 'global']), true);
rejects(fn() => $o->grant('1', observerInput($e, $m, ['steam_id' => '76561198012345999', 'scope' => 'global']), true), 'observer_limit');
check(count($e->db->all('SELECT * FROM mq2_observer_grants')) === 16, 'Capacity failure not atomic');
echo "PASS observer capacity boundary and transaction rollback\n";

[$e, $m] = observerFixture();
$o = new Observers($e);
observerStatus($e, $m);
$o->grant('1', observerInput($e, $m), true);
observerAck($e, $m);
$e->db->run('UPDATE mq2_servers SET healthy=0 WHERE id=?', [$m['server_id']]);
check($o->access($m, $e->player('11')['steam_id'])['state'] === 'unsupported', 'Registry unhealthy ignored');
$o->tick();
observerStatus($e, $m);
$e->db->run('UPDATE mq2_leases SET state=? WHERE match_id=?', ['quarantine', $m['id']]);
check($o->access($m, $e->player('11')['steam_id'])['state'] === 'unsupported', 'Quarantine ignored');
$e->db->run('UPDATE mq2_leases SET state=? WHERE match_id=?', ['loaded', $m['id']]);
observerStatus($e, $m, ['observer_expires_at' => $e->now() + 2]);
check($o->access($m, $e->player('11')['steam_id'])['state'] === 'pending', 'Mismatched lease expiry accepted');
$o->tick();
check((bool) $e->db->one("SELECT id FROM mq2_commands WHERE type='observer_update' AND state='pending'"), 'Missing pending fixture');
$e->db->run('UPDATE mq2_matches SET state=? WHERE id=?', ['stopping', $m['id']]);
$o->tick();
check(!$e->db->one("SELECT id FROM mq2_commands WHERE type='observer_update' AND state='pending'"), 'Terminal observer command blocks cleanup');
check($o->access($e->match($m['id']), $e->player('11')['steam_id']) === null, 'Stopping match exposes observer connection');
echo "PASS observer registry health, quarantine, lease mismatch and terminal command retirement\n";
