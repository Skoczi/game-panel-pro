<?php

declare(strict_types = 1);

define('MQ2_TEST_HELPERS_ONLY', true);
require __DIR__ . '/run.php';
use Flute\Modules\MixQueue2\Domain\{Engine, Statistics, MapInventory};
use Flute\Modules\MixQueue2\Http\Application;

function draftFixture(int $count, int $first = 1): array
{
    $e = fixture();
    $maps = array_slice($e->ladder('cs16-5v5')['maps'], 0, $count);
    $e->db->run('UPDATE mq2_ladders SET maps=? WHERE id=?', [Engine::json($maps), 'cs16-5v5']);
    $e->db->run('UPDATE mq2_servers SET game=?,capabilities=? WHERE id=?', [
        'cs16',
        Engine::json(['modes' => ['5v5'], 'maps' => $maps]),
        's1'
    ]);
    $ob = cs16Status()
    + ['map_inventory' => ['version' => 1, 'source' => 'bsp_v30', 'complete' => true, 'maps' => $maps]];
    $e->db->run('INSERT INTO mq2_observations VALUES(?,?,?)', ['s1', Engine::json($ob), $e->now()]);
    for ($i = 1; $i <= 10; ++$i)
        $e->join((string) $i, 'cs16-5v5');
    check($e->tick() === 1, 'No match');
    $m = $e->db->one('SELECT * FROM mq2_matches');
    $id = $m['id'];
    $rules = json_decode($m['rules'], true);
    $rules['veto_first'] = $first;
    $e->db->run('UPDATE mq2_matches SET rules=? WHERE id=?', [Engine::json($rules), $id]);
    check(count(json_decode($m['maps'], true)) === $count, 'Even map pool shortened');
    for ($i = 1; $i <= 10; ++$i)
        $e->ready((string) $i, $id, true);
    return [$e, $id];
}

function captainFor(Engine $e, string $id, int $team): string
{
    return $e->db->one('SELECT user_id FROM mq2_match_players WHERE match_id=? AND team=? AND captain=1', [
        $id,
        $team
    ])['user_id'];
}

foreach ([3, 4, 7, 8, 11, 12] as $count)
    foreach ([1, 2] as $first)
        foreach (['ct', 't'] as $side) {
            [$e, $id] = draftFixture($count, $first);
            $bans = 0;
            while (( $m = $e->match($id) )['state'] === 'veto') {
                $pool = json_decode($m['maps'], true);
                $team = Engine::vetoTeam($m);
                $cap = captainFor($e, $id, $team);
                rejects(fn() => $e->ban(captainFor($e, $id, 3 - $team), $id, $pool[0], (int) $m['version']), 'captain');
                $selected = $pool[0];
                $isPick = count($pool) === 2;
                $e->ban($cap, $id, $selected, (int) $m['version']);
                rejects(fn() => $e->ban($cap, $id, $selected, (int) $m['version']), 'stale');
                if (!$isPick)
                    ++$bans;
            }
            check(
                $bans === ( $count - 2 ) && $m['state'] === 'side_selection' && $m['picked_map'] === $selected,
                'Wrong ban/pick sequence'
            );
            check(!$e->db->all('SELECT * FROM mq2_commands'), 'Load before side choice');
            $r = json_decode($m['rules'], true);
            check($r['side_chooser'] === ( 3 - $team ), 'Picker chose sides');
            $chooser = captainFor($e, $id, $r['side_chooser']);
            rejects(fn() => $e->chooseSide($cap, $id, 'ct', (int) $m['version']), 'captain');
            rejects(fn() => $e->chooseSide($chooser, $id, 'spectator', (int) $m['version']), 'side');
            $e->chooseSide($chooser, $id, $side, (int) $m['version']);
            rejects(fn() => $e->chooseSide($chooser, $id, $side, (int) $m['version']), 'stale');
            $config = $e->configuration($id);
            check(
                $config['contract_version'] === 3
                && $config['starting_ct_team'] === ( $side === 'ct' ? $r['side_chooser'] : 3 - $r['side_chooser'] ),
                'Wrong signed side'
            );
            check($config === $e->configuration($id), 'Configuration changed on retry');
            check(count($e->commands('s1')) === 1, 'Multiple loads');
        }
echo
    "PASS 24 draft combinations: 3/4/7/8/11/12 maps, both first teams and CT/T; authorization, pick semantics, retry hash\n"
;
[$e, $id] = draftFixture(4);
while (( $m = $e->match($id) )['state'] === 'veto')
    $e->ban(captainFor($e, $id, Engine::vetoTeam($m)), $id, json_decode($m['maps'], true)[0], (int) $m['version']);
$e->db->run('UPDATE mq2_matches SET deadline=? WHERE id=?', [$e->now() - 1, $id]);
$e->tick();
$r = json_decode($e->match($id)['rules'], true);
check($r['side_automatic'] && $r['starting_ct_team'] === $r['side_chooser'], 'Timeout fallback incorrect');
[$e, $id] = draftFixture(3);
while (( $m = $e->match($id) )['state'] === 'veto')
    $e->ban(captainFor($e, $id, Engine::vetoTeam($m)), $id, json_decode($m['maps'], true)[0], (int) $m['version']);
$e->cancel($id, 'admin', 'fixture');
check(
    !$e->db->all('SELECT * FROM mq2_leases') && !$e->db->all('SELECT * FROM mq2_commands'),
    'Pregame cancel dispatched RCON'
);
echo "PASS side timeout and pre-load cancellation/lease release\n";
[$e, $id] = draftFixture(4);
while (($m = $e->match($id))['state'] === 'veto')
    $e->ban(captainFor($e, $id, Engine::vetoTeam($m)), $id, json_decode($m['maps'], true)[0], (int)$m['version']);
$ob=json_decode($e->db->one('SELECT payload FROM mq2_observations WHERE server_id=?',['s1'])['payload'],true);
$ob['map_inventory']['maps']=array_values(array_diff($ob['map_inventory']['maps'],[$m['picked_map']]));
$e->db->run('UPDATE mq2_observations SET payload=? WHERE server_id=?',[Engine::json($ob),'s1']);
$r=json_decode($m['rules'],true);
$e->chooseSide(captainFor($e,$id,$r['side_chooser']),$id,'ct',(int)$m['version']);
check($e->match($id)['state']==='cancelled' && !$e->db->all('SELECT * FROM mq2_commands') && !$e->db->all('SELECT * FROM mq2_leases'),'Map disappeared after pick but load/lease survived');
echo "PASS inventory checked again after side selection; missing map cancels without load\n";
$valid = array_fill_keys(Statistics::COUNTERS, 0);
$valid = array_replace($valid, [
    'rounds' => 1,
    'kills' => 2,
    'damage' => 180,
    'kast_rounds' => 1,
    'multi2' => 1,
    'headshots' => 1
]);
$saved = Statistics::validate($valid, [], 2, 1);
check(Statistics::metrics($saved)['kast_percent'] === 100.0, 'KAST ratio');
rejects(fn() => Statistics::validate(array_diff_key($valid, ['kast_rounds' => 1]), [], 2, 1), 'stats_schema');
rejects(fn() => Statistics::validate($valid + ['foreign' => 0], [], 2, 1), 'stats_schema');
rejects(fn() => Statistics::validate(array_replace($valid, ['damage' => '180']), [], 2, 1), 'stats_counter');
rejects(fn() => Statistics::validate(array_replace($valid, ['damage' => 179]), $saved, 2, 1), 'stats_counter');
rejects(fn() => Statistics::validate(array_replace($valid, ['damage' => 181]), $saved, 2, 1), 'stats_snapshot');
rejects(fn() => Statistics::validate(array_replace($valid, ['kast_rounds' => 2]), [], 2, 1), 'stats_bounds');
rejects(fn() => Statistics::validate($valid, $saved, 1, 1), 'stats_version');
check(Statistics::metrics(['kills' => 1])['kast_percent'] === null, 'Legacy metric fabricated');
check(Statistics::validate($valid, $saved, 2, 1) === $saved, 'Identical terminal snapshot rejected');
echo "PASS v2 complete schema, strict bounds, monotonicity, final snapshot, legacy unknowns and no downgrade\n";
